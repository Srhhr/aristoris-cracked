import java.io.IOException;

public class ps implements oj<om> {
   private long a;

   public ps() {
   }

   public ps(long var1) {
      this.a = var1;
   }

   public void a(om var1) {
      var1.a(this);
   }

   public void a(nf var1) throws IOException {
      this.a = var1.readLong();
   }

   public void b(nf var1) throws IOException {
      var1.writeLong(this.a);
   }

   public long b() {
      return this.a;
   }
}
