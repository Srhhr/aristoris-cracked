import com.google.common.collect.Maps;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public class bly {
   private final Map<blx, bly.a> a = Maps.newHashMap();
   private int b;

   public boolean a(blx var1) {
      return this.a(var1, 0.0F) > 0.0F;
   }

   public float a(blx var1, float var2) {
      bly.a var3 = (bly.a)this.a.get(var1);
      if (var3 != null) {
         float var4 = (float)(var3.c - var3.b);
         float var5 = (float)var3.c - ((float)this.b + var2);
         return afm.a(var5 / var4, 0.0F, 1.0F);
      } else {
         return 0.0F;
      }
   }

   public void a() {
      ++this.b;
      if (!this.a.isEmpty()) {
         Iterator var1 = this.a.entrySet().iterator();

         while(var1.hasNext()) {
            Entry<blx, bly.a> var2 = (Entry)var1.next();
            if (((bly.a)var2.getValue()).c <= this.b) {
               var1.remove();
               this.c((blx)var2.getKey());
            }
         }
      }

   }

   public void a(blx var1, int var2) {
      this.a.put(var1, new bly.a(this.b, this.b + var2));
      this.b(var1, var2);
   }

   public void b(blx var1) {
      this.a.remove(var1);
      this.c(var1);
   }

   protected void b(blx var1, int var2) {
   }

   protected void c(blx var1) {
   }

   class a {
      private final int b;
      private final int c;

      private a(int var2, int var3) {
         this.b = var2;
         this.c = var3;
      }

      // $FF: synthetic method
      a(int var2, int var3, Object var4) {
         this(var2, var3);
      }
   }
}
