import com.mojang.authlib.GameProfile;
import com.mojang.authlib.exceptions.AuthenticationException;
import com.mojang.authlib.exceptions.AuthenticationUnavailableException;
import com.mojang.authlib.exceptions.InsufficientPrivilegesException;
import com.mojang.authlib.exceptions.InvalidCredentialsException;
import com.mojang.authlib.minecraft.MinecraftSessionService;
import io.netty.util.concurrent.GenericFutureListener;
import java.math.BigInteger;
import java.security.PublicKey;
import java.util.function.Consumer;
import javax.annotation.Nullable;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class dws implements ty {
   private static final Logger a = LogManager.getLogger();
   private final djz b;
   @Nullable
   private final dot c;
   private final Consumer<nr> d;
   private final nd e;
   private GameProfile f;

   public dws(nd var1, djz var2, @Nullable dot var3, Consumer<nr> var4) {
      this.e = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
   }

   public void a(ub var1) {
      Cipher var2;
      Cipher var3;
      String var4;
      uh var5;
      try {
         SecretKey var6 = aeu.a();
         PublicKey var7 = var1.c();
         var4 = (new BigInteger(aeu.a(var1.b(), var7, var6))).toString(16);
         var2 = aeu.a(2, var6);
         var3 = aeu.a(1, var6);
         var5 = new uh(var6, var7, var1.d());
      } catch (aev var8) {
         throw new IllegalStateException("Protocol error", var8);
      }

      this.d.accept(new of("connect.authorizing"));
      aff.a.submit(() -> {
         nr var5x = this.a(var4);
         if (var5x != null) {
            if (this.b.E() == null || !this.b.E().d()) {
               this.e.a(var5x);
               return;
            }

            a.warn(var5x.getString());
         }

         this.d.accept(new of("connect.encrypting"));
         this.e.a((oj)var5, (GenericFutureListener)((var3x) -> {
            this.e.a(var2, var3);
         }));
      });
   }

   @Nullable
   private nr a(String var1) {
      try {
         this.b().joinServer(this.b.J().e(), this.b.J().d(), var1);
         return null;
      } catch (AuthenticationUnavailableException var3) {
         return new of("disconnect.loginFailedInfo", new Object[]{new of("disconnect.loginFailedInfo.serversUnavailable")});
      } catch (InvalidCredentialsException var4) {
         return new of("disconnect.loginFailedInfo", new Object[]{new of("disconnect.loginFailedInfo.invalidSession")});
      } catch (InsufficientPrivilegesException var5) {
         return new of("disconnect.loginFailedInfo", new Object[]{new of("disconnect.loginFailedInfo.insufficientPrivileges")});
      } catch (AuthenticationException var6) {
         return new of("disconnect.loginFailedInfo", new Object[]{var6.getMessage()});
      }
   }

   private MinecraftSessionService b() {
      return this.b.Y();
   }

   public void a(ua var1) {
      this.d.accept(new of("connect.joining"));
      this.f = var1.b();
      this.e.a(ne.b);
      this.e.a((ni)(new dwu(this.b, this.c, this.e, this.f)));
   }

   public void a(nr var1) {
      if (this.c != null && this.c instanceof eoo) {
         this.b.a((dot)(new eoi(this.c, nq.i, var1)));
      } else {
         this.b.a((dot)(new doa(this.c, nq.i, var1)));
      }

   }

   public nd a() {
      return this.e;
   }

   public void a(ud var1) {
      this.e.a(var1.b());
   }

   public void a(uc var1) {
      if (!this.e.d()) {
         this.e.a(var1.b());
      }

   }

   public void a(tz var1) {
      this.d.accept(new of("connect.negotiating"));
      this.e.a((oj)(new uf(var1.b(), (nf)null)));
   }
}
