import java.util.function.Predicate;

@FunctionalInterface
public interface ebq {
   ebq a = (var0) -> {
      return (var0x) -> {
         return true;
      };
   };
   ebq b = (var0) -> {
      return (var0x) -> {
         return false;
      };
   };

   Predicate<ceh> getPredicate(cei<buo, ceh> var1);
}
