import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import java.lang.reflect.Type;
import javax.annotation.Nullable;
import org.apache.commons.lang3.StringUtils;

public class vk implements Comparable<vk> {
   public static final Codec<vk> a;
   private static final SimpleCommandExceptionType d;
   protected final String b;
   protected final String c;

   protected vk(String[] var1) {
      this.b = StringUtils.isEmpty(var1[0]) ? "minecraft" : var1[0];
      this.c = var1[1];
      if (!e(this.b)) {
         throw new v("Non [a-z0-9_.-] character in namespace of location: " + this.b + ':' + this.c);
      } else if (!d(this.c)) {
         throw new v("Non [a-z0-9/._-] character in path of location: " + this.b + ':' + this.c);
      }
   }

   public vk(String var1) {
      this(b(var1, ':'));
   }

   public vk(String var1, String var2) {
      this(new String[]{var1, var2});
   }

   public static vk a(String var0, char var1) {
      return new vk(b(var0, var1));
   }

   @Nullable
   public static vk a(String var0) {
      try {
         return new vk(var0);
      } catch (v var2) {
         return null;
      }
   }

   protected static String[] b(String var0, char var1) {
      String[] var2 = new String[]{"minecraft", var0};
      int var3 = var0.indexOf(var1);
      if (var3 >= 0) {
         var2[1] = var0.substring(var3 + 1, var0.length());
         if (var3 >= 1) {
            var2[0] = var0.substring(0, var3);
         }
      }

      return var2;
   }

   private static DataResult<vk> c(String var0) {
      try {
         return DataResult.success(new vk(var0));
      } catch (v var2) {
         return DataResult.error("Not a valid resource location: " + var0 + " " + var2.getMessage());
      }
   }

   public String a() {
      return this.c;
   }

   public String b() {
      return this.b;
   }

   public String toString() {
      return this.b + ':' + this.c;
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof vk)) {
         return false;
      } else {
         vk var2 = (vk)var1;
         return this.b.equals(var2.b) && this.c.equals(var2.c);
      }
   }

   public int hashCode() {
      return 31 * this.b.hashCode() + this.c.hashCode();
   }

   public int a(vk var1) {
      int var2 = this.c.compareTo(var1.c);
      if (var2 == 0) {
         var2 = this.b.compareTo(var1.b);
      }

      return var2;
   }

   public static vk a(StringReader var0) throws CommandSyntaxException {
      int var1 = var0.getCursor();

      while(var0.canRead() && a(var0.peek())) {
         var0.skip();
      }

      String var2 = var0.getString().substring(var1, var0.getCursor());

      try {
         return new vk(var2);
      } catch (v var4) {
         var0.setCursor(var1);
         throw d.createWithContext(var0);
      }
   }

   public static boolean a(char var0) {
      return var0 >= '0' && var0 <= '9' || var0 >= 'a' && var0 <= 'z' || var0 == '_' || var0 == ':' || var0 == '/' || var0 == '.' || var0 == '-';
   }

   private static boolean d(String var0) {
      for(int var1 = 0; var1 < var0.length(); ++var1) {
         if (!b(var0.charAt(var1))) {
            return false;
         }
      }

      return true;
   }

   private static boolean e(String var0) {
      for(int var1 = 0; var1 < var0.length(); ++var1) {
         if (!c(var0.charAt(var1))) {
            return false;
         }
      }

      return true;
   }

   public static boolean b(char var0) {
      return var0 == '_' || var0 == '-' || var0 >= 'a' && var0 <= 'z' || var0 >= '0' && var0 <= '9' || var0 == '/' || var0 == '.';
   }

   private static boolean c(char var0) {
      return var0 == '_' || var0 == '-' || var0 >= 'a' && var0 <= 'z' || var0 >= '0' && var0 <= '9' || var0 == '.';
   }

   public static boolean b(String var0) {
      String[] var1 = b(var0, ':');
      return e(StringUtils.isEmpty(var1[0]) ? "minecraft" : var1[0]) && d(var1[1]);
   }

   // $FF: synthetic method
   public int compareTo(Object var1) {
      return this.a((vk)var1);
   }

   static {
      a = Codec.STRING.comapFlatMap(vk::c, vk::toString).stable();
      d = new SimpleCommandExceptionType(new of("argument.id.invalid"));
   }

   public static class a implements JsonDeserializer<vk>, JsonSerializer<vk> {
      public vk a(JsonElement var1, Type var2, JsonDeserializationContext var3) throws JsonParseException {
         return new vk(afd.a(var1, "location"));
      }

      public JsonElement a(vk var1, Type var2, JsonSerializationContext var3) {
         return new JsonPrimitive(var1.toString());
      }

      // $FF: synthetic method
      public JsonElement serialize(Object var1, Type var2, JsonSerializationContext var3) {
         return this.a((vk)var1, var2, var3);
      }

      // $FF: synthetic method
      public Object deserialize(JsonElement var1, Type var2, JsonDeserializationContext var3) throws JsonParseException {
         return this.a(var1, var2, var3);
      }
   }
}
