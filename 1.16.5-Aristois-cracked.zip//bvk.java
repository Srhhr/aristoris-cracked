import it.unimi.dsi.fastutil.objects.Object2FloatMap;
import it.unimi.dsi.fastutil.objects.Object2FloatOpenHashMap;
import java.util.Random;
import java.util.function.Consumer;
import javax.annotation.Nullable;

public class bvk extends buo implements apf {
   public static final cfg a;
   public static final Object2FloatMap<brw> b;
   private static final ddh c;
   private static final ddh[] d;

   public static void c() {
      b.defaultReturnValue(-1.0F);
      float var0 = 0.3F;
      float var1 = 0.5F;
      float var2 = 0.65F;
      float var3 = 0.85F;
      float var4 = 1.0F;
      a(0.3F, bmd.au);
      a(0.3F, bmd.ar);
      a(0.3F, bmd.as);
      a(0.3F, bmd.aw);
      a(0.3F, bmd.av);
      a(0.3F, bmd.at);
      a(0.3F, bmd.x);
      a(0.3F, bmd.y);
      a(0.3F, bmd.z);
      a(0.3F, bmd.A);
      a(0.3F, bmd.B);
      a(0.3F, bmd.C);
      a(0.3F, bmd.qg);
      a(0.3F, bmd.ni);
      a(0.3F, bmd.aL);
      a(0.3F, bmd.bE);
      a(0.3F, bmd.nk);
      a(0.3F, bmd.nj);
      a(0.3F, bmd.aO);
      a(0.3F, bmd.rm);
      a(0.3F, bmd.kV);
      a(0.5F, bmd.ma);
      a(0.5F, bmd.gn);
      a(0.5F, bmd.cX);
      a(0.5F, bmd.bD);
      a(0.5F, bmd.dR);
      a(0.5F, bmd.bA);
      a(0.5F, bmd.bB);
      a(0.5F, bmd.bC);
      a(0.5F, bmd.nh);
      a(0.65F, bmd.aP);
      a(0.65F, bmd.ed);
      a(0.65F, bmd.di);
      a(0.65F, bmd.dj);
      a(0.65F, bmd.dQ);
      a(0.65F, bmd.kb);
      a(0.65F, bmd.qf);
      a(0.65F, bmd.oY);
      a(0.65F, bmd.ms);
      a(0.65F, bmd.oZ);
      a(0.65F, bmd.kW);
      a(0.65F, bmd.bu);
      a(0.65F, bmd.bv);
      a(0.65F, bmd.dM);
      a(0.65F, bmd.bw);
      a(0.65F, bmd.bx);
      a(0.65F, bmd.nu);
      a(0.65F, bmd.by);
      a(0.65F, bmd.bz);
      a(0.65F, bmd.rp);
      a(0.65F, bmd.bh);
      a(0.65F, bmd.bi);
      a(0.65F, bmd.bj);
      a(0.65F, bmd.bk);
      a(0.65F, bmd.bl);
      a(0.65F, bmd.bm);
      a(0.65F, bmd.bn);
      a(0.65F, bmd.bo);
      a(0.65F, bmd.bp);
      a(0.65F, bmd.bq);
      a(0.65F, bmd.br);
      a(0.65F, bmd.bs);
      a(0.65F, bmd.bt);
      a(0.65F, bmd.aM);
      a(0.65F, bmd.gj);
      a(0.65F, bmd.gk);
      a(0.65F, bmd.gl);
      a(0.65F, bmd.gm);
      a(0.65F, bmd.go);
      a(0.85F, bmd.fL);
      a(0.85F, bmd.dK);
      a(0.85F, bmd.dL);
      a(0.85F, bmd.hj);
      a(0.85F, bmd.hk);
      a(0.85F, bmd.kX);
      a(0.85F, bmd.pa);
      a(0.85F, bmd.ne);
      a(1.0F, bmd.mN);
      a(1.0F, bmd.pn);
   }

   private static void a(float var0, brw var1) {
      b.put(var1.h(), var0);
   }

   public bvk(ceg.c var1) {
      super(var1);
      this.j((ceh)((ceh)this.n.b()).a(a, 0));
   }

   public static void a(brx var0, fx var1, boolean var2) {
      ceh var3 = var0.d_(var1);
      var0.a((double)var1.u(), (double)var1.v(), (double)var1.w(), var2 ? adq.bW : adq.bV, adr.e, 1.0F, 1.0F, false);
      double var4 = var3.j(var0, var1).b(gc.a.b, 0.5D, 0.5D) + 0.03125D;
      double var6 = 0.13124999403953552D;
      double var8 = 0.737500011920929D;
      Random var10 = var0.u_();

      for(int var11 = 0; var11 < 10; ++var11) {
         double var12 = var10.nextGaussian() * 0.02D;
         double var14 = var10.nextGaussian() * 0.02D;
         double var16 = var10.nextGaussian() * 0.02D;
         var0.a(hh.F, (double)var1.u() + 0.13124999403953552D + 0.737500011920929D * (double)var10.nextFloat(), (double)var1.v() + var4 + (double)var10.nextFloat() * (1.0D - var4), (double)var1.w() + 0.13124999403953552D + 0.737500011920929D * (double)var10.nextFloat(), var12, var14, var16);
      }

   }

   public ddh b(ceh var1, brc var2, fx var3, dcs var4) {
      return d[(Integer)var1.c(a)];
   }

   public ddh a_(ceh var1, brc var2, fx var3) {
      return c;
   }

   public ddh c(ceh var1, brc var2, fx var3, dcs var4) {
      return d[0];
   }

   public void b(ceh var1, brx var2, fx var3, ceh var4, boolean var5) {
      if ((Integer)var1.c(a) == 7) {
         var2.J().a(var3, var1.b(), 20);
      }

   }

   public aou a(ceh var1, brx var2, fx var3, bfw var4, aot var5, dcj var6) {
      int var7 = (Integer)var1.c(a);
      bmb var8 = var4.b((aot)var5);
      if (var7 < 8 && b.containsKey(var8.b())) {
         if (var7 < 7 && !var2.v) {
            ceh var9 = b(var1, (bry)var2, var3, (bmb)var8);
            var2.c(1500, var3, var1 != var9 ? 1 : 0);
            if (!var4.bC.d) {
               var8.g(1);
            }
         }

         return aou.a(var2.v);
      } else if (var7 == 8) {
         d(var1, var2, var3);
         return aou.a(var2.v);
      } else {
         return aou.c;
      }
   }

   public static ceh a(ceh var0, aag var1, bmb var2, fx var3) {
      int var4 = (Integer)var0.c(a);
      if (var4 < 7 && b.containsKey(var2.b())) {
         ceh var5 = b(var0, (bry)var1, var3, (bmb)var2);
         var2.g(1);
         return var5;
      } else {
         return var0;
      }
   }

   public static ceh d(ceh var0, brx var1, fx var2) {
      if (!var1.v) {
         float var3 = 0.7F;
         double var4 = (double)(var1.t.nextFloat() * 0.7F) + 0.15000000596046448D;
         double var6 = (double)(var1.t.nextFloat() * 0.7F) + 0.06000000238418579D + 0.6D;
         double var8 = (double)(var1.t.nextFloat() * 0.7F) + 0.15000000596046448D;
         bcv var10 = new bcv(var1, (double)var2.u() + var4, (double)var2.v() + var6, (double)var2.w() + var8, new bmb(bmd.mK));
         var10.m();
         var1.c((aqa)var10);
      }

      ceh var11 = d(var0, (bry)var1, var2);
      var1.a((bfw)null, (fx)var2, adq.bU, adr.e, 1.0F, 1.0F);
      return var11;
   }

   private static ceh d(ceh var0, bry var1, fx var2) {
      ceh var3 = (ceh)var0.a(a, 0);
      var1.a(var2, var3, 3);
      return var3;
   }

   private static ceh b(ceh var0, bry var1, fx var2, bmb var3) {
      int var4 = (Integer)var0.c(a);
      float var5 = b.getFloat(var3.b());
      if ((var4 != 0 || !(var5 > 0.0F)) && !(var1.u_().nextDouble() < (double)var5)) {
         return var0;
      } else {
         int var6 = var4 + 1;
         ceh var7 = (ceh)var0.a(a, var6);
         var1.a(var2, var7, 3);
         if (var6 == 7) {
            var1.J().a(var2, var0.b(), 20);
         }

         return var7;
      }
   }

   public void a(ceh var1, aag var2, fx var3, Random var4) {
      if ((Integer)var1.c(a) == 7) {
         var2.a(var3, (ceh)var1.a(a), 3);
         var2.a((bfw)null, var3, adq.bX, adr.e, 1.0F, 1.0F);
      }

   }

   public boolean a(ceh var1) {
      return true;
   }

   public int a(ceh var1, brx var2, fx var3) {
      return (Integer)var1.c(a);
   }

   protected void a(cei.a<buo, ceh> var1) {
      var1.a(a);
   }

   public boolean a(ceh var1, brc var2, fx var3, cxe var4) {
      return false;
   }

   public ape a(ceh var1, bry var2, fx var3) {
      int var4 = (Integer)var1.c(a);
      if (var4 == 8) {
         return new bvk.c(var1, var2, var3, new bmb(bmd.mK));
      } else {
         return (ape)(var4 < 7 ? new bvk.b(var1, var2, var3) : new bvk.a());
      }
   }

   static {
      a = cex.as;
      b = new Object2FloatOpenHashMap();
      c = dde.b();
      d = (ddh[])x.a((Object)(new ddh[9]), (Consumer)((var0) -> {
         for(int var1 = 0; var1 < 8; ++var1) {
            var0[var1] = dde.a(c, buo.a(2.0D, (double)Math.max(2, 1 + var1 * 2), 2.0D, 14.0D, 16.0D, 14.0D), dcr.e);
         }

         var0[8] = var0[7];
      }));
   }

   static class b extends apa implements ape {
      private final ceh a;
      private final bry b;
      private final fx c;
      private boolean d;

      public b(ceh var1, bry var2, fx var3) {
         super(1);
         this.a = var1;
         this.b = var2;
         this.c = var3;
      }

      public int V_() {
         return 1;
      }

      public int[] a(gc var1) {
         return var1 == gc.b ? new int[]{0} : new int[0];
      }

      public boolean a(int var1, bmb var2, @Nullable gc var3) {
         return !this.d && var3 == gc.b && bvk.b.containsKey(var2.b());
      }

      public boolean b(int var1, bmb var2, gc var3) {
         return false;
      }

      public void X_() {
         bmb var1 = this.a(0);
         if (!var1.a()) {
            this.d = true;
            ceh var2 = bvk.b(this.a, this.b, this.c, var1);
            this.b.c(1500, this.c, var2 != this.a ? 1 : 0);
            this.b(0);
         }

      }
   }

   static class c extends apa implements ape {
      private final ceh a;
      private final bry b;
      private final fx c;
      private boolean d;

      public c(ceh var1, bry var2, fx var3, bmb var4) {
         super(var4);
         this.a = var1;
         this.b = var2;
         this.c = var3;
      }

      public int V_() {
         return 1;
      }

      public int[] a(gc var1) {
         return var1 == gc.a ? new int[]{0} : new int[0];
      }

      public boolean a(int var1, bmb var2, @Nullable gc var3) {
         return false;
      }

      public boolean b(int var1, bmb var2, gc var3) {
         return !this.d && var3 == gc.a && var2.b() == bmd.mK;
      }

      public void X_() {
         bvk.d(this.a, this.b, this.c);
         this.d = true;
      }
   }

   static class a extends apa implements ape {
      public a() {
         super(0);
      }

      public int[] a(gc var1) {
         return new int[0];
      }

      public boolean a(int var1, bmb var2, @Nullable gc var3) {
         return false;
      }

      public boolean b(int var1, bmb var2, gc var3) {
         return false;
      }
   }
}
