import com.google.common.collect.ImmutableList;
import com.google.common.collect.Streams;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.util.List;
import javax.annotation.Nullable;

public class dyh {
   @Nullable
   private final List<vk> a;

   private dyh(@Nullable List<vk> var1) {
      this.a = var1;
   }

   @Nullable
   public List<vk> a() {
      return this.a;
   }

   public static dyh a(JsonObject var0) {
      JsonArray var1 = afd.a((JsonObject)var0, (String)"textures", (JsonArray)null);
      List var2;
      if (var1 != null) {
         var2 = (List)Streams.stream(var1).map((var0x) -> {
            return afd.a(var0x, "texture");
         }).map(vk::new).collect(ImmutableList.toImmutableList());
      } else {
         var2 = null;
      }

      return new dyh(var2);
   }
}
