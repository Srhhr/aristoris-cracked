import it.unimi.dsi.fastutil.longs.LongSet;
import java.util.BitSet;
import java.util.Map;
import java.util.stream.Stream;
import javax.annotation.Nullable;

public class cgg extends cgp {
   private final cgh a;

   public cgg(cgh var1) {
      super(var1.g(), cgr.a);
      this.a = var1;
   }

   @Nullable
   public ccj c(fx var1) {
      return this.a.c(var1);
   }

   @Nullable
   public ceh d_(fx var1) {
      return this.a.d_(var1);
   }

   public cux b(fx var1) {
      return this.a.b(var1);
   }

   public int K() {
      return this.a.K();
   }

   @Nullable
   public ceh a(fx var1, ceh var2, boolean var3) {
      return null;
   }

   public void a(fx var1, ccj var2) {
   }

   public void a(aqa var1) {
   }

   public void a(cga var1) {
   }

   public cgi[] d() {
      return this.a.d();
   }

   @Nullable
   public cuo e() {
      return this.a.e();
   }

   public void a(chn.a var1, long[] var2) {
   }

   private chn.a c(chn.a var1) {
      if (var1 == chn.a.a) {
         return chn.a.b;
      } else {
         return var1 == chn.a.c ? chn.a.d : var1;
      }
   }

   public int a(chn.a var1, int var2, int var3) {
      return this.a.a(this.c(var1), var2, var3);
   }

   public brd g() {
      return this.a.g();
   }

   public void a(long var1) {
   }

   @Nullable
   public crv<?> a(cla<?> var1) {
      return this.a.a(var1);
   }

   public void a(cla<?> var1, crv<?> var2) {
   }

   public Map<cla<?>, crv<?>> h() {
      return this.a.h();
   }

   public void a(Map<cla<?>, crv<?>> var1) {
   }

   public LongSet b(cla<?> var1) {
      return this.a.b(var1);
   }

   public void a(cla<?> var1, long var2) {
   }

   public Map<cla<?>, LongSet> v() {
      return this.a.v();
   }

   public void b(Map<cla<?>, LongSet> var1) {
   }

   public cfx i() {
      return this.a.i();
   }

   public void a(boolean var1) {
   }

   public boolean j() {
      return false;
   }

   public cga k() {
      return this.a.k();
   }

   public void d(fx var1) {
   }

   public void e(fx var1) {
   }

   public void a(md var1) {
   }

   @Nullable
   public md i(fx var1) {
      return this.a.i(var1);
   }

   @Nullable
   public md j(fx var1) {
      return this.a.j(var1);
   }

   public void a(cfx var1) {
   }

   public Stream<fx> m() {
      return this.a.m();
   }

   public cgq<buo> s() {
      return new cgq((var0) -> {
         return var0.n().g();
      }, this.g());
   }

   public cgq<cuw> t() {
      return new cgq((var0) -> {
         return var0 == cuy.a;
      }, this.g());
   }

   public BitSet a(chm.a var1) {
      throw (UnsupportedOperationException)x.c((Throwable)(new UnsupportedOperationException("Meaningless in this context")));
   }

   public BitSet b(chm.a var1) {
      throw (UnsupportedOperationException)x.c((Throwable)(new UnsupportedOperationException("Meaningless in this context")));
   }

   public cgh u() {
      return this.a;
   }

   public boolean r() {
      return this.a.r();
   }

   public void b(boolean var1) {
      this.a.b(var1);
   }

   // $FF: synthetic method
   public bso o() {
      return this.t();
   }

   // $FF: synthetic method
   public bso n() {
      return this.s();
   }
}
