import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Random;
import java.util.function.Supplier;

public class clj {
   public static final Codec<clj> a = RecordCodecBuilder.create((var0) -> {
      return var0.group(civ.b.fieldOf("feature").forGetter((var0x) -> {
         return var0x.b;
      }), Codec.floatRange(0.0F, 1.0F).fieldOf("chance").forGetter((var0x) -> {
         return var0x.c;
      })).apply(var0, clj::new);
   });
   public final Supplier<civ<?, ?>> b;
   public final float c;

   public clj(civ<?, ?> var1, float var2) {
      this(() -> {
         return var1;
      }, var2);
   }

   private clj(Supplier<civ<?, ?>> var1, float var2) {
      this.b = var1;
      this.c = var2;
   }

   public boolean a(bsr var1, cfy var2, Random var3, fx var4) {
      return ((civ)this.b.get()).a(var1, var2, var3, var4);
   }
}
