import com.google.common.collect.Lists;
import java.util.List;
import java.util.Optional;

public class dln {
   private static final afa a;

   private static String a(String var0) {
      return djz.C().k.L ? var0 : k.a(var0);
   }

   public static List<afa> a(nu var0, int var1, dku var2) {
      djo var3 = new djo();
      var0.a((var1x, var2x) -> {
         var3.a(nu.a(a(var2x), var1x));
         return Optional.empty();
      }, ob.a);
      List<afa> var4 = Lists.newArrayList();
      var2.b().a(var3.b(), var1, ob.a, (var1x, var2x) -> {
         afa var3 = ly.a().a(var1x);
         var4.add(var2x ? afa.a(a, var3) : var3);
      });
      return var4.isEmpty() ? Lists.newArrayList(new afa[]{afa.a}) : var4;
   }

   static {
      a = afa.a(32, ob.a);
   }
}
