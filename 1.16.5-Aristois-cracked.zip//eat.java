import javax.annotation.Nullable;

public class eat {
   protected final eae a;
   protected final brx b;
   protected int c;
   protected int d;
   protected int e;
   public ecu.c[] f;

   public eat(ecu var1, brx var2, int var3, eae var4) {
      this.a = var4;
      this.b = var2;
      this.a(var3);
      this.a(var1);
   }

   protected void a(ecu var1) {
      int var2 = this.d * this.c * this.e;
      this.f = new ecu.c[var2];

      for(int var3 = 0; var3 < this.d; ++var3) {
         for(int var4 = 0; var4 < this.c; ++var4) {
            for(int var5 = 0; var5 < this.e; ++var5) {
               int var6 = this.a(var3, var4, var5);
               this.f[var6] = var1.new c();
               this.f[var6].a(var3 * 16, var4 * 16, var5 * 16);
            }
         }
      }

   }

   public void a() {
      ecu.c[] var1 = this.f;
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         ecu.c var4 = var1[var3];
         var4.d();
      }

   }

   private int a(int var1, int var2, int var3) {
      return (var3 * this.c + var2) * this.d + var1;
   }

   protected void a(int var1) {
      int var2 = var1 * 2 + 1;
      this.d = var2;
      this.c = 16;
      this.e = var2;
   }

   public void a(double var1, double var3) {
      int var5 = afm.c(var1);
      int var6 = afm.c(var3);

      for(int var7 = 0; var7 < this.d; ++var7) {
         int var8 = this.d * 16;
         int var9 = var5 - 8 - var8 / 2;
         int var10 = var9 + Math.floorMod(var7 * 16 - var9, var8);

         for(int var11 = 0; var11 < this.e; ++var11) {
            int var12 = this.e * 16;
            int var13 = var6 - 8 - var12 / 2;
            int var14 = var13 + Math.floorMod(var11 * 16 - var13, var12);

            for(int var15 = 0; var15 < this.c; ++var15) {
               int var16 = var15 * 16;
               ecu.c var17 = this.f[this.a(var7, var15, var11)];
               var17.a(var10, var16, var14);
            }
         }
      }

   }

   public void a(int var1, int var2, int var3, boolean var4) {
      int var5 = Math.floorMod(var1, this.d);
      int var6 = Math.floorMod(var2, this.c);
      int var7 = Math.floorMod(var3, this.e);
      ecu.c var8 = this.f[this.a(var5, var6, var7)];
      var8.a(var4);
   }

   @Nullable
   protected ecu.c a(fx var1) {
      int var2 = afm.a(var1.u(), 16);
      int var3 = afm.a(var1.v(), 16);
      int var4 = afm.a(var1.w(), 16);
      if (var3 >= 0 && var3 < this.c) {
         var2 = afm.b(var2, this.d);
         var4 = afm.b(var4, this.e);
         return this.f[this.a(var2, var3, var4)];
      } else {
         return null;
      }
   }
}
