import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;

public class yd {
   public static void a(CommandDispatcher<db> var0, boolean var1) {
      var0.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)dc.a("seed").requires((var1x) -> {
         return !var1 || var1x.c(2);
      })).executes((var0x) -> {
         long var1 = ((db)var0x.getSource()).e().C();
         nr var3 = ns.a((nr)(new oe(String.valueOf(var1))).a((var2) -> {
            return var2.a(k.k).a(new np(np.a.f, String.valueOf(var1))).a(new nv(nv.a.a, new of("chat.copy.click"))).a(String.valueOf(var1));
         }));
         ((db)var0x.getSource()).a(new of("commands.seed.success", new Object[]{var3}), false);
         return (int)var1;
      }));
   }
}
