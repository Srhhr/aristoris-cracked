public abstract class bay extends aqu {
   protected bay(aqe<? extends bay> var1, brx var2) {
      super(var1, var2);
      this.a(cwz.h, 0.0F);
   }

   public boolean cM() {
      return true;
   }

   public aqq dC() {
      return aqq.e;
   }

   public boolean a(brz var1) {
      return var1.j(this);
   }

   public int D() {
      return 120;
   }

   protected int d(bfw var1) {
      return 1 + this.l.t.nextInt(3);
   }

   protected void a(int var1) {
      if (this.aX() && !this.aH()) {
         this.j(var1 - 1);
         if (this.bI() == -20) {
            this.j(0);
            this.a(apk.h, 2.0F);
         }
      } else {
         this.j(300);
      }

   }

   public void ag() {
      int var1 = this.bI();
      super.ag();
      this.a(var1);
   }

   public boolean bV() {
      return false;
   }

   public boolean a(bfw var1) {
      return false;
   }
}
