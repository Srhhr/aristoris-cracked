import com.google.common.base.MoreObjects;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSortedMap;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.UnmodifiableIterator;
import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Codec;
import com.mojang.serialization.Decoder;
import com.mojang.serialization.Encoder;
import com.mojang.serialization.MapCodec;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.annotation.Nullable;

public class cei<O, S extends cej<O, S>> {
   private static final Pattern a = Pattern.compile("^[a-z0-9_]+$");
   private final O b;
   private final ImmutableSortedMap<String, cfj<?>> c;
   private final ImmutableList<S> d;

   protected cei(Function<O, S> var1, O var2, cei.b<O, S> var3, Map<String, cfj<?>> var4) {
      this.b = var2;
      this.c = ImmutableSortedMap.copyOf(var4);
      Supplier<S> var5 = () -> {
         return (cej)var1.apply(var2);
      };
      MapCodec<S> var6 = MapCodec.of(Encoder.empty(), Decoder.unit(var5));

      Entry var8;
      for(UnmodifiableIterator var7 = this.c.entrySet().iterator(); var7.hasNext(); var6 = a(var6, var5, (String)var8.getKey(), (cfj)var8.getValue())) {
         var8 = (Entry)var7.next();
      }

      Map<Map<cfj<?>, Comparable<?>>, S> var15 = Maps.newLinkedHashMap();
      List<S> var9 = Lists.newArrayList();
      Stream<List<Pair<cfj<?>, Comparable<?>>>> var10 = Stream.of(Collections.emptyList());

      cfj var12;
      for(UnmodifiableIterator var11 = this.c.values().iterator(); var11.hasNext(); var10 = var10.flatMap((var1x) -> {
         return var12.a().stream().map((var2) -> {
            List<Pair<cfj<?>, Comparable<?>>> var3 = Lists.newArrayList(var1x);
            var3.add(Pair.of(var12, var2));
            return var3;
         });
      })) {
         var12 = (cfj)var11.next();
      }

      var10.forEach((var5x) -> {
         ImmutableMap<cfj<?>, Comparable<?>> var6x = (ImmutableMap)var5x.stream().collect(ImmutableMap.toImmutableMap(Pair::getFirst, Pair::getSecond));
         S var7 = (cej)var3.create(var2, var6x, var6);
         var15.put(var6x, var7);
         var9.add(var7);
      });
      Iterator var13 = var9.iterator();

      while(var13.hasNext()) {
         S var14 = (cej)var13.next();
         var14.a((Map)var15);
      }

      this.d = ImmutableList.copyOf(var9);
   }

   private static <S extends cej<?, S>, T extends Comparable<T>> MapCodec<S> a(MapCodec<S> var0, Supplier<S> var1, String var2, cfj<T> var3) {
      return Codec.mapPair(var0, var3.e().fieldOf(var2).setPartial(() -> {
         return var3.a((cej)var1.get());
      })).xmap((var1x) -> {
         return (cej)((cej)var1x.getFirst()).a(var3, ((cfj.a)var1x.getSecond()).b());
      }, (var1x) -> {
         return Pair.of(var1x, var3.a(var1x));
      });
   }

   public ImmutableList<S> a() {
      return this.d;
   }

   public S b() {
      return (cej)this.d.get(0);
   }

   public O c() {
      return this.b;
   }

   public Collection<cfj<?>> d() {
      return this.c.values();
   }

   public String toString() {
      return MoreObjects.toStringHelper(this).add("block", this.b).add("properties", this.c.values().stream().map(cfj::f).collect(Collectors.toList())).toString();
   }

   @Nullable
   public cfj<?> a(String var1) {
      return (cfj)this.c.get(var1);
   }

   public static class a<O, S extends cej<O, S>> {
      private final O a;
      private final Map<String, cfj<?>> b = Maps.newHashMap();

      public a(O var1) {
         this.a = var1;
      }

      public cei.a<O, S> a(cfj<?>... var1) {
         cfj[] var2 = var1;
         int var3 = var1.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            cfj<?> var5 = var2[var4];
            this.a(var5);
            this.b.put(var5.f(), var5);
         }

         return this;
      }

      private <T extends Comparable<T>> void a(cfj<T> var1) {
         String var2 = var1.f();
         if (!cei.a.matcher(var2).matches()) {
            throw new IllegalArgumentException(this.a + " has invalidly named property: " + var2);
         } else {
            Collection<T> var3 = var1.a();
            if (var3.size() <= 1) {
               throw new IllegalArgumentException(this.a + " attempted use property " + var2 + " with <= 1 possible values");
            } else {
               Iterator var4 = var3.iterator();

               String var6;
               do {
                  if (!var4.hasNext()) {
                     if (this.b.containsKey(var2)) {
                        throw new IllegalArgumentException(this.a + " has duplicate property: " + var2);
                     }

                     return;
                  }

                  T var5 = (Comparable)var4.next();
                  var6 = var1.a(var5);
               } while(cei.a.matcher(var6).matches());

               throw new IllegalArgumentException(this.a + " has property: " + var2 + " with invalidly named value: " + var6);
            }
         }
      }

      public cei<O, S> a(Function<O, S> var1, cei.b<O, S> var2) {
         return new cei(var1, this.a, var2, this.b);
      }
   }

   public interface b<O, S> {
      S create(O var1, ImmutableMap<cfj<?>, Comparable<?>> var2, MapCodec<S> var3);
   }
}
