import java.util.function.IntConsumer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class dfs {
   private static final Logger a = LogManager.getLogger();
   private final dfs.a b;
   private final dfs.b c;
   private final int d;
   private final int e;
   private final int f;

   public dfs(int var1, dfs.a var2, dfs.b var3, int var4) {
      if (this.a(var1, var3)) {
         this.c = var3;
      } else {
         a.warn("Multiple vertex elements of the same type other than UVs are not supported. Forcing type to UV.");
         this.c = dfs.b.d;
      }

      this.b = var2;
      this.d = var1;
      this.e = var4;
      this.f = var2.a() * this.e;
   }

   private boolean a(int var1, dfs.b var2) {
      return var1 == 0 || var2 == dfs.b.d;
   }

   public final dfs.a a() {
      return this.b;
   }

   public final dfs.b b() {
      return this.c;
   }

   public final int c() {
      return this.d;
   }

   public String toString() {
      return this.e + "," + this.c.a() + "," + this.b.b();
   }

   public final int d() {
      return this.f;
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 != null && this.getClass() == var1.getClass()) {
         dfs var2 = (dfs)var1;
         if (this.e != var2.e) {
            return false;
         } else if (this.d != var2.d) {
            return false;
         } else if (this.b != var2.b) {
            return false;
         } else {
            return this.c == var2.c;
         }
      } else {
         return false;
      }
   }

   public int hashCode() {
      int var1 = this.b.hashCode();
      var1 = 31 * var1 + this.c.hashCode();
      var1 = 31 * var1 + this.d;
      var1 = 31 * var1 + this.e;
      return var1;
   }

   public void a(long var1, int var3) {
      this.c.a(this.e, this.b.c(), var3, var1, this.d);
   }

   public void e() {
      this.c.a(this.d);
   }

   public static enum a {
      a(4, "Float", 5126),
      b(1, "Unsigned Byte", 5121),
      c(1, "Byte", 5120),
      d(2, "Unsigned Short", 5123),
      e(2, "Short", 5122),
      f(4, "Unsigned Int", 5125),
      g(4, "Int", 5124);

      private final int h;
      private final String i;
      private final int j;

      private a(int var3, String var4, int var5) {
         this.h = var3;
         this.i = var4;
         this.j = var5;
      }

      public int a() {
         return this.h;
      }

      public String b() {
         return this.i;
      }

      public int c() {
         return this.j;
      }
   }

   public static enum b {
      a("Position", (var0, var1, var2, var3, var5) -> {
         dem.b(var0, var1, var2, var3);
         dem.x(32884);
      }, (var0) -> {
         dem.y(32884);
      }),
      b("Normal", (var0, var1, var2, var3, var5) -> {
         dem.a(var1, var2, var3);
         dem.x(32885);
      }, (var0) -> {
         dem.y(32885);
      }),
      c("Vertex Color", (var0, var1, var2, var3, var5) -> {
         dem.c(var0, var1, var2, var3);
         dem.x(32886);
      }, (var0) -> {
         dem.y(32886);
         dem.S();
      }),
      d("UV", (var0, var1, var2, var3, var5) -> {
         dem.n('蓀' + var5);
         dem.a(var0, var1, var2, var3);
         dem.x(32888);
         dem.n(33984);
      }, (var0) -> {
         dem.n('蓀' + var0);
         dem.y(32888);
         dem.n(33984);
      }),
      e("Padding", (var0, var1, var2, var3, var5) -> {
      }, (var0) -> {
      }),
      f("Generic", (var0, var1, var2, var3, var5) -> {
         dem.z(var5);
         dem.a(var5, var0, var1, false, var2, var3);
      }, dem::A);

      private final String g;
      private final dfs.b.a h;
      private final IntConsumer i;

      private b(String var3, dfs.b.a var4, IntConsumer var5) {
         this.g = var3;
         this.h = var4;
         this.i = var5;
      }

      private void a(int var1, int var2, int var3, long var4, int var6) {
         this.h.setupBufferState(var1, var2, var3, var4, var6);
      }

      public void a(int var1) {
         this.i.accept(var1);
      }

      public String a() {
         return this.g;
      }

      interface a {
         void setupBufferState(int var1, int var2, int var3, long var4, int var6);
      }
   }
}
