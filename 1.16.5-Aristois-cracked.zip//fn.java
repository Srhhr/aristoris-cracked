import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.LongArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;

public class fn {
   public static void a() {
      fk.a((String)"brigadier:bool", (Class)BoolArgumentType.class, (fj)(new fl(BoolArgumentType::bool)));
      fk.a((String)"brigadier:float", (Class)FloatArgumentType.class, (fj)(new fp()));
      fk.a((String)"brigadier:double", (Class)DoubleArgumentType.class, (fj)(new fo()));
      fk.a((String)"brigadier:integer", (Class)IntegerArgumentType.class, (fj)(new fq()));
      fk.a((String)"brigadier:long", (Class)LongArgumentType.class, (fj)(new fr()));
      fk.a((String)"brigadier:string", (Class)StringArgumentType.class, (fj)(new fs()));
   }

   public static byte a(boolean var0, boolean var1) {
      byte var2 = 0;
      if (var0) {
         var2 = (byte)(var2 | 1);
      }

      if (var1) {
         var2 = (byte)(var2 | 2);
      }

      return var2;
   }

   public static boolean a(byte var0) {
      return (var0 & 1) != 0;
   }

   public static boolean b(byte var0) {
      return (var0 & 2) != 0;
   }
}
