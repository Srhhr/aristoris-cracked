import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.UnmodifiableIterator;
import com.google.common.collect.ImmutableMap.Builder;
import com.mojang.serialization.Codec;
import java.util.Comparator;
import java.util.Random;
import java.util.Map.Entry;

public abstract class ctn extends ctt<ctu> {
   private long a;
   private ImmutableMap<ceh, cub> b = ImmutableMap.of();
   private ImmutableMap<ceh, cub> c = ImmutableMap.of();
   private cub d;

   public ctn(Codec<ctu> var1) {
      super(var1);
   }

   public void a(Random var1, cfw var2, bsv var3, int var4, int var5, int var6, double var7, ceh var9, ceh var10, int var11, long var12, ctu var14) {
      int var15 = var11 + 1;
      int var16 = var4 & 15;
      int var17 = var5 & 15;
      int var18 = (int)(var7 / 3.0D + 3.0D + var1.nextDouble() * 0.25D);
      int var19 = (int)(var7 / 3.0D + 3.0D + var1.nextDouble() * 0.25D);
      double var20 = 0.03125D;
      boolean var22 = this.d.a((double)var4 * 0.03125D, 109.0D, (double)var5 * 0.03125D) * 75.0D + var1.nextDouble() > 0.0D;
      ceh var23 = (ceh)((Entry)this.c.entrySet().stream().max(Comparator.comparing((var3x) -> {
         return ((cub)var3x.getValue()).a((double)var4, (double)var11, (double)var5);
      })).get()).getKey();
      ceh var24 = (ceh)((Entry)this.b.entrySet().stream().max(Comparator.comparing((var3x) -> {
         return ((cub)var3x.getValue()).a((double)var4, (double)var11, (double)var5);
      })).get()).getKey();
      fx.a var25 = new fx.a();
      ceh var26 = var2.d_(var25.d(var16, 128, var17));

      for(int var27 = 127; var27 >= 0; --var27) {
         var25.d(var16, var27, var17);
         ceh var28 = var2.d_(var25);
         int var29;
         if (var26.a(var9.b()) && (var28.g() || var28 == var10)) {
            for(var29 = 0; var29 < var18; ++var29) {
               var25.c(gc.b);
               if (!var2.d_(var25).a(var9.b())) {
                  break;
               }

               var2.a(var25, var23, false);
            }

            var25.d(var16, var27, var17);
         }

         if ((var26.g() || var26 == var10) && var28.a(var9.b())) {
            for(var29 = 0; var29 < var19 && var2.d_(var25).a(var9.b()); ++var29) {
               if (var22 && var27 >= var15 - 4 && var27 <= var15 + 1) {
                  var2.a(var25, this.c(), false);
               } else {
                  var2.a(var25, var24, false);
               }

               var25.c(gc.a);
            }
         }

         var26 = var28;
      }

   }

   public void a(long var1) {
      if (this.a != var1 || this.d == null || this.b.isEmpty() || this.c.isEmpty()) {
         this.b = a(this.a(), var1);
         this.c = a(this.b(), var1 + (long)this.b.size());
         this.d = new cub(new chx(var1 + (long)this.b.size() + (long)this.c.size()), ImmutableList.of(0));
      }

      this.a = var1;
   }

   private static ImmutableMap<ceh, cub> a(ImmutableList<ceh> var0, long var1) {
      Builder<ceh, cub> var3 = new Builder();

      for(UnmodifiableIterator var4 = var0.iterator(); var4.hasNext(); ++var1) {
         ceh var5 = (ceh)var4.next();
         var3.put(var5, new cub(new chx(var1), ImmutableList.of(-4)));
      }

      return var3.build();
   }

   protected abstract ImmutableList<ceh> a();

   protected abstract ImmutableList<ceh> b();

   protected abstract ceh c();
}
