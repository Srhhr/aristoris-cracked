import java.util.Random;
import javax.annotation.Nullable;

public abstract class cdd extends ccd {
   @Nullable
   protected vk g;
   protected long h;

   protected cdd(cck<?> var1) {
      super(var1);
   }

   public static void a(brc var0, Random var1, fx var2, vk var3) {
      ccj var4 = var0.c(var2);
      if (var4 instanceof cdd) {
         ((cdd)var4).a(var3, var1.nextLong());
      }

   }

   protected boolean b(md var1) {
      if (var1.c("LootTable", 8)) {
         this.g = new vk(var1.l("LootTable"));
         this.h = var1.i("LootTableSeed");
         return true;
      } else {
         return false;
      }
   }

   protected boolean c(md var1) {
      if (this.g == null) {
         return false;
      } else {
         var1.a("LootTable", this.g.toString());
         if (this.h != 0L) {
            var1.a("LootTableSeed", this.h);
         }

         return true;
      }
   }

   public void d(@Nullable bfw var1) {
      if (this.g != null && this.d.l() != null) {
         cyy var2 = this.d.l().aJ().a(this.g);
         if (var1 instanceof aah) {
            ac.N.a((aah)var1, this.g);
         }

         this.g = null;
         cyv.a var3 = (new cyv.a((aag)this.d)).a((daz)dbc.f, (Object)dcn.a((gr)this.e)).a(this.h);
         if (var1 != null) {
            var3.a(var1.eU()).a((daz)dbc.a, (Object)var1);
         }

         var2.a((aon)this, (cyv)var3.a(dbb.b));
      }

   }

   public void a(vk var1, long var2) {
      this.g = var1;
      this.h = var2;
   }

   public boolean c() {
      this.d((bfw)null);
      return this.f().stream().allMatch(bmb::a);
   }

   public bmb a(int var1) {
      this.d((bfw)null);
      return (bmb)this.f().get(var1);
   }

   public bmb a(int var1, int var2) {
      this.d((bfw)null);
      bmb var3 = aoo.a(this.f(), var1, var2);
      if (!var3.a()) {
         this.X_();
      }

      return var3;
   }

   public bmb b(int var1) {
      this.d((bfw)null);
      return aoo.a(this.f(), var1);
   }

   public void a(int var1, bmb var2) {
      this.d((bfw)null);
      this.f().set(var1, var2);
      if (var2.E() > this.V_()) {
         var2.e(this.V_());
      }

      this.X_();
   }

   public boolean a(bfw var1) {
      if (this.d.c(this.e) != this) {
         return false;
      } else {
         return !(var1.h((double)this.e.u() + 0.5D, (double)this.e.v() + 0.5D, (double)this.e.w() + 0.5D) > 64.0D);
      }
   }

   public void Y_() {
      this.f().clear();
   }

   protected abstract gj<bmb> f();

   protected abstract void a(gj<bmb> var1);

   public boolean e(bfw var1) {
      return super.e(var1) && (this.g == null || !var1.a_());
   }

   @Nullable
   public bic createMenu(int var1, bfv var2, bfw var3) {
      if (this.e(var3)) {
         this.d(var2.e);
         return this.a(var1, var2);
      } else {
         return null;
      }
   }
}
