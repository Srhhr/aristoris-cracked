import com.google.common.collect.ImmutableList;
import java.util.function.Function;

public class dum<T extends aqm> extends dtf<T> implements dth, dui {
   public dwn f;
   public dwn g;
   public dwn h;
   public dwn i;
   public dwn j;
   public dwn k;
   public dwn l;
   public dum.a m;
   public dum.a n;
   public boolean o;
   public float p;

   public dum(float var1) {
      this(eao::d, var1, 0.0F, 64, 32);
   }

   protected dum(float var1, float var2, int var3, int var4) {
      this(eao::d, var1, var2, var3, var4);
   }

   public dum(Function<vk, eao> var1, float var2, float var3, int var4, int var5) {
      super(var1, true, 16.0F, 0.0F, 2.0F, 2.0F, 24.0F);
      this.m = dum.a.a;
      this.n = dum.a.a;
      this.r = var4;
      this.s = var5;
      this.f = new dwn(this, 0, 0);
      this.f.a(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F, var2);
      this.f.a(0.0F, 0.0F + var3, 0.0F);
      this.g = new dwn(this, 32, 0);
      this.g.a(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F, var2 + 0.5F);
      this.g.a(0.0F, 0.0F + var3, 0.0F);
      this.h = new dwn(this, 16, 16);
      this.h.a(-4.0F, 0.0F, -2.0F, 8.0F, 12.0F, 4.0F, var2);
      this.h.a(0.0F, 0.0F + var3, 0.0F);
      this.i = new dwn(this, 40, 16);
      this.i.a(-3.0F, -2.0F, -2.0F, 4.0F, 12.0F, 4.0F, var2);
      this.i.a(-5.0F, 2.0F + var3, 0.0F);
      this.j = new dwn(this, 40, 16);
      this.j.g = true;
      this.j.a(-1.0F, -2.0F, -2.0F, 4.0F, 12.0F, 4.0F, var2);
      this.j.a(5.0F, 2.0F + var3, 0.0F);
      this.k = new dwn(this, 0, 16);
      this.k.a(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F, var2);
      this.k.a(-1.9F, 12.0F + var3, 0.0F);
      this.l = new dwn(this, 0, 16);
      this.l.g = true;
      this.l.a(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F, var2);
      this.l.a(1.9F, 12.0F + var3, 0.0F);
   }

   protected Iterable<dwn> a() {
      return ImmutableList.of(this.f);
   }

   protected Iterable<dwn> b() {
      return ImmutableList.of(this.h, this.i, this.j, this.k, this.l, this.g);
   }

   public void a(T var1, float var2, float var3, float var4) {
      this.p = var1.a(var4);
      super.a(var1, var2, var3, var4);
   }

   public void a(T var1, float var2, float var3, float var4, float var5, float var6) {
      boolean var7 = var1.eg() > 4;
      boolean var8 = var1.bC();
      this.f.e = var5 * 0.017453292F;
      if (var7) {
         this.f.d = -0.7853982F;
      } else if (this.p > 0.0F) {
         if (var8) {
            this.f.d = this.a(this.p, this.f.d, -0.7853982F);
         } else {
            this.f.d = this.a(this.p, this.f.d, var6 * 0.017453292F);
         }
      } else {
         this.f.d = var6 * 0.017453292F;
      }

      this.h.e = 0.0F;
      this.i.c = 0.0F;
      this.i.a = -5.0F;
      this.j.c = 0.0F;
      this.j.a = 5.0F;
      float var9 = 1.0F;
      if (var7) {
         var9 = (float)var1.cC().g();
         var9 /= 0.2F;
         var9 *= var9 * var9;
      }

      if (var9 < 1.0F) {
         var9 = 1.0F;
      }

      this.i.d = afm.b(var2 * 0.6662F + 3.1415927F) * 2.0F * var3 * 0.5F / var9;
      this.j.d = afm.b(var2 * 0.6662F) * 2.0F * var3 * 0.5F / var9;
      this.i.f = 0.0F;
      this.j.f = 0.0F;
      this.k.d = afm.b(var2 * 0.6662F) * 1.4F * var3 / var9;
      this.l.d = afm.b(var2 * 0.6662F + 3.1415927F) * 1.4F * var3 / var9;
      this.k.e = 0.0F;
      this.l.e = 0.0F;
      this.k.f = 0.0F;
      this.l.f = 0.0F;
      dwn var10000;
      if (this.d) {
         var10000 = this.i;
         var10000.d += -0.62831855F;
         var10000 = this.j;
         var10000.d += -0.62831855F;
         this.k.d = -1.4137167F;
         this.k.e = 0.31415927F;
         this.k.f = 0.07853982F;
         this.l.d = -1.4137167F;
         this.l.e = -0.31415927F;
         this.l.f = -0.07853982F;
      }

      this.i.e = 0.0F;
      this.j.e = 0.0F;
      boolean var10 = var1.dV() == aqi.b;
      boolean var11 = var10 ? this.m.a() : this.n.a();
      if (var10 != var11) {
         this.c(var1);
         this.b(var1);
      } else {
         this.b(var1);
         this.c(var1);
      }

      this.a(var1, var4);
      if (this.o) {
         this.h.d = 0.5F;
         var10000 = this.i;
         var10000.d += 0.4F;
         var10000 = this.j;
         var10000.d += 0.4F;
         this.k.c = 4.0F;
         this.l.c = 4.0F;
         this.k.b = 12.2F;
         this.l.b = 12.2F;
         this.f.b = 4.2F;
         this.h.b = 3.2F;
         this.j.b = 5.2F;
         this.i.b = 5.2F;
      } else {
         this.h.d = 0.0F;
         this.k.c = 0.1F;
         this.l.c = 0.1F;
         this.k.b = 12.0F;
         this.l.b = 12.0F;
         this.f.b = 0.0F;
         this.h.b = 0.0F;
         this.j.b = 2.0F;
         this.i.b = 2.0F;
      }

      dtg.a(this.i, this.j, var4);
      if (this.p > 0.0F) {
         float var12 = var2 % 26.0F;
         aqi var13 = this.a(var1);
         float var14 = var13 == aqi.b && this.c > 0.0F ? 0.0F : this.p;
         float var15 = var13 == aqi.a && this.c > 0.0F ? 0.0F : this.p;
         float var16;
         if (var12 < 14.0F) {
            this.j.d = this.a(var15, this.j.d, 0.0F);
            this.i.d = afm.g(var14, this.i.d, 0.0F);
            this.j.e = this.a(var15, this.j.e, 3.1415927F);
            this.i.e = afm.g(var14, this.i.e, 3.1415927F);
            this.j.f = this.a(var15, this.j.f, 3.1415927F + 1.8707964F * this.a(var12) / this.a(14.0F));
            this.i.f = afm.g(var14, this.i.f, 3.1415927F - 1.8707964F * this.a(var12) / this.a(14.0F));
         } else if (var12 >= 14.0F && var12 < 22.0F) {
            var16 = (var12 - 14.0F) / 8.0F;
            this.j.d = this.a(var15, this.j.d, 1.5707964F * var16);
            this.i.d = afm.g(var14, this.i.d, 1.5707964F * var16);
            this.j.e = this.a(var15, this.j.e, 3.1415927F);
            this.i.e = afm.g(var14, this.i.e, 3.1415927F);
            this.j.f = this.a(var15, this.j.f, 5.012389F - 1.8707964F * var16);
            this.i.f = afm.g(var14, this.i.f, 1.2707963F + 1.8707964F * var16);
         } else if (var12 >= 22.0F && var12 < 26.0F) {
            var16 = (var12 - 22.0F) / 4.0F;
            this.j.d = this.a(var15, this.j.d, 1.5707964F - 1.5707964F * var16);
            this.i.d = afm.g(var14, this.i.d, 1.5707964F - 1.5707964F * var16);
            this.j.e = this.a(var15, this.j.e, 3.1415927F);
            this.i.e = afm.g(var14, this.i.e, 3.1415927F);
            this.j.f = this.a(var15, this.j.f, 3.1415927F);
            this.i.f = afm.g(var14, this.i.f, 3.1415927F);
         }

         var16 = 0.3F;
         float var17 = 0.33333334F;
         this.l.d = afm.g(this.p, this.l.d, 0.3F * afm.b(var2 * 0.33333334F + 3.1415927F));
         this.k.d = afm.g(this.p, this.k.d, 0.3F * afm.b(var2 * 0.33333334F));
      }

      this.g.a(this.f);
   }

   private void b(T var1) {
      switch(this.n) {
      case a:
         this.i.e = 0.0F;
         break;
      case c:
         this.i.d = this.i.d * 0.5F - 0.9424779F;
         this.i.e = -0.5235988F;
         break;
      case b:
         this.i.d = this.i.d * 0.5F - 0.31415927F;
         this.i.e = 0.0F;
         break;
      case e:
         this.i.d = this.i.d * 0.5F - 3.1415927F;
         this.i.e = 0.0F;
         break;
      case d:
         this.i.e = -0.1F + this.f.e;
         this.j.e = 0.1F + this.f.e + 0.4F;
         this.i.d = -1.5707964F + this.f.d;
         this.j.d = -1.5707964F + this.f.d;
         break;
      case f:
         dtg.a(this.i, this.j, var1, true);
         break;
      case g:
         dtg.a(this.i, this.j, this.f, true);
      }

   }

   private void c(T var1) {
      switch(this.m) {
      case a:
         this.j.e = 0.0F;
         break;
      case c:
         this.j.d = this.j.d * 0.5F - 0.9424779F;
         this.j.e = 0.5235988F;
         break;
      case b:
         this.j.d = this.j.d * 0.5F - 0.31415927F;
         this.j.e = 0.0F;
         break;
      case e:
         this.j.d = this.j.d * 0.5F - 3.1415927F;
         this.j.e = 0.0F;
         break;
      case d:
         this.i.e = -0.1F + this.f.e - 0.4F;
         this.j.e = 0.1F + this.f.e;
         this.i.d = -1.5707964F + this.f.d;
         this.j.d = -1.5707964F + this.f.d;
         break;
      case f:
         dtg.a(this.i, this.j, var1, false);
         break;
      case g:
         dtg.a(this.i, this.j, this.f, false);
      }

   }

   protected void a(T var1, float var2) {
      if (!(this.c <= 0.0F)) {
         aqi var3 = this.a(var1);
         dwn var4 = this.a(var3);
         float var5 = this.c;
         this.h.e = afm.a(afm.c(var5) * 6.2831855F) * 0.2F;
         dwn var10000;
         if (var3 == aqi.a) {
            var10000 = this.h;
            var10000.e *= -1.0F;
         }

         this.i.c = afm.a(this.h.e) * 5.0F;
         this.i.a = -afm.b(this.h.e) * 5.0F;
         this.j.c = -afm.a(this.h.e) * 5.0F;
         this.j.a = afm.b(this.h.e) * 5.0F;
         var10000 = this.i;
         var10000.e += this.h.e;
         var10000 = this.j;
         var10000.e += this.h.e;
         var10000 = this.j;
         var10000.d += this.h.e;
         var5 = 1.0F - this.c;
         var5 *= var5;
         var5 *= var5;
         var5 = 1.0F - var5;
         float var6 = afm.a(var5 * 3.1415927F);
         float var7 = afm.a(this.c * 3.1415927F) * -(this.f.d - 0.7F) * 0.75F;
         var4.d = (float)((double)var4.d - ((double)var6 * 1.2D + (double)var7));
         var4.e += this.h.e * 2.0F;
         var4.f += afm.a(this.c * 3.1415927F) * -0.4F;
      }
   }

   protected float a(float var1, float var2, float var3) {
      float var4 = (var3 - var2) % 6.2831855F;
      if (var4 < -3.1415927F) {
         var4 += 6.2831855F;
      }

      if (var4 >= 3.1415927F) {
         var4 -= 6.2831855F;
      }

      return var2 + var1 * var4;
   }

   private float a(float var1) {
      return -65.0F * var1 + var1 * var1;
   }

   public void a(dum<T> var1) {
      super.a(var1);
      var1.m = this.m;
      var1.n = this.n;
      var1.o = this.o;
      var1.f.a(this.f);
      var1.g.a(this.g);
      var1.h.a(this.h);
      var1.i.a(this.i);
      var1.j.a(this.j);
      var1.k.a(this.k);
      var1.l.a(this.l);
   }

   public void d_(boolean var1) {
      this.f.h = var1;
      this.g.h = var1;
      this.h.h = var1;
      this.i.h = var1;
      this.j.h = var1;
      this.k.h = var1;
      this.l.h = var1;
   }

   public void a(aqi var1, dfm var2) {
      this.a(var1).a(var2);
   }

   protected dwn a(aqi var1) {
      return var1 == aqi.a ? this.j : this.i;
   }

   public dwn c() {
      return this.f;
   }

   protected aqi a(T var1) {
      aqi var2 = var1.dV();
      return var1.aj == aot.a ? var2 : var2.a();
   }

   public static enum a {
      a(false),
      b(false),
      c(false),
      d(true),
      e(false),
      f(true),
      g(true);

      private final boolean h;

      private a(boolean var3) {
         this.h = var3;
      }

      public boolean a() {
         return this.h;
      }
   }
}
