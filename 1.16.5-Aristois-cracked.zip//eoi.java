public class eoi extends eoo {
   private final nr a;
   private final nr b;
   private dlu c;
   private final dot p;
   private int q;

   public eoi(dot var1, nr var2, nr var3) {
      this.c = dlu.a;
      this.p = var1;
      this.a = var2;
      this.b = var3;
   }

   public void b() {
      djz var1 = djz.C();
      var1.d(false);
      var1.P().b();
      eoj.a(this.a.getString() + ": " + this.b.getString());
      this.c = dlu.a(this.o, this.b, this.k - 50);
      int var10001 = this.c.a();
      this.o.getClass();
      this.q = var10001 * 9;
      int var10003 = this.k / 2 - 100;
      int var10004 = this.l / 2 + this.q / 2;
      this.o.getClass();
      this.a(new dlj(var10003, var10004 + 9, 200, 20, nq.h, (var2) -> {
         var1.a(this.p);
      }));
   }

   public void at_() {
      djz.C().a(this.p);
   }

   public void a(dfm var1, int var2, int var3, float var4) {
      this.a(var1);
      dku var10001 = this.o;
      nr var10002 = this.a;
      int var10003 = this.k / 2;
      int var10004 = this.l / 2 - this.q / 2;
      this.o.getClass();
      a(var1, var10001, var10002, var10003, var10004 - 9 * 2, 11184810);
      this.c.a(var1, this.k / 2, this.l / 2 - this.q / 2);
      super.a(var1, var2, var3, var4);
   }
}
