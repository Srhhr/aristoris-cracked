import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableMap.Builder;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.CompletableFuture;
import java.util.function.Supplier;
import javax.annotation.Nullable;

public class edf implements edh.a {
   private final djz a;
   private double b = Double.MIN_VALUE;
   private final int c = 12;
   @Nullable
   private edf.a d;

   public edf(djz var1) {
      this.a = var1;
   }

   public void a(dfm var1, eag var2, double var3, double var5, double var7) {
      double var9 = (double)x.c();
      if (var9 - this.b > 3.0E9D) {
         this.b = var9;
         eng var11 = this.a.H();
         if (var11 != null) {
            this.d = new edf.a(var11, var3, var7);
         } else {
            this.d = null;
         }
      }

      if (this.d != null) {
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         RenderSystem.lineWidth(2.0F);
         RenderSystem.disableTexture();
         RenderSystem.depthMask(false);
         Map<brd, String> var24 = (Map)this.d.c.getNow((Object)null);
         double var12 = this.a.h.k().b().c * 0.85D;
         Iterator var14 = this.d.b.entrySet().iterator();

         while(var14.hasNext()) {
            Entry<brd, String> var15 = (Entry)var14.next();
            brd var16 = (brd)var15.getKey();
            String var17 = (String)var15.getValue();
            if (var24 != null) {
               var17 = var17 + (String)var24.get(var16);
            }

            String[] var18 = var17.split("\n");
            int var19 = 0;
            String[] var20 = var18;
            int var21 = var18.length;

            for(int var22 = 0; var22 < var21; ++var22) {
               String var23 = var20[var22];
               edh.a(var23, (double)((var16.b << 4) + 8), var12 + (double)var19, (double)((var16.c << 4) + 8), -1, 0.15F);
               var19 -= 2;
            }
         }

         RenderSystem.depthMask(true);
         RenderSystem.enableTexture();
         RenderSystem.disableBlend();
      }

   }

   final class a {
      private final Map<brd, String> b;
      private final CompletableFuture<Map<brd, String>> c;

      private a(eng var2, double var3, double var5) {
         dwt var7 = edf.this.a.r;
         vj<brx> var8 = var7.Y();
         int var9 = (int)var3 >> 4;
         int var10 = (int)var5 >> 4;
         Builder<brd, String> var11 = ImmutableMap.builder();
         dwr var12 = var7.n();

         for(int var13 = var9 - 12; var13 <= var9 + 12; ++var13) {
            for(int var14 = var10 - 12; var14 <= var10 + 12; ++var14) {
               brd var15 = new brd(var13, var14);
               String var16 = "";
               cgh var17 = var12.a(var13, var14, false);
               var16 = var16 + "Client: ";
               if (var17 == null) {
                  var16 = var16 + "0n/a\n";
               } else {
                  var16 = var16 + (var17.t() ? " E" : "");
                  var16 = var16 + "\n";
               }

               var11.put(var15, var16);
            }
         }

         this.b = var11.build();
         this.c = var2.a((Supplier)(() -> {
            aag var5 = var2.a((vj)var8);
            if (var5 == null) {
               return ImmutableMap.of();
            } else {
               Builder<brd, String> var6 = ImmutableMap.builder();
               aae var7 = var5.i();

               for(int var8x = var9 - 12; var8x <= var9 + 12; ++var8x) {
                  for(int var9x = var10 - 12; var9x <= var10 + 12; ++var9x) {
                     brd var10x = new brd(var8x, var9x);
                     var6.put(var10x, "Server: " + var7.b(var10x));
                  }
               }

               return var6.build();
            }
         }));
      }

      // $FF: synthetic method
      a(eng var2, double var3, double var5, Object var7) {
         this(var2, var3, var5);
      }
   }
}
