import java.util.function.Function;

public enum eog {
   a("movement", eob::new),
   b("find_tree", eoa::new),
   c("punch_tree", eod::new),
   d("open_inventory", eoc::new),
   e("craft_planks", enz::new),
   f("none", eny::new);

   private final String g;
   private final Function<eoe, ? extends eof> h;

   private <T extends eof> eog(String var3, Function<eoe, T> var4) {
      this.g = var3;
      this.h = var4;
   }

   public eof a(eoe var1) {
      return (eof)this.h.apply(var1);
   }

   public String a() {
      return this.g;
   }

   public static eog a(String var0) {
      eog[] var1 = values();
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         eog var4 = var1[var3];
         if (var4.g.equals(var0)) {
            return var4;
         }
      }

      return f;
   }
}
