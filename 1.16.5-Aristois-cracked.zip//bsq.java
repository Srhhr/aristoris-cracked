public enum bsq {
   a(-3),
   b(-2),
   c(-1),
   d(0),
   e(1),
   f(2),
   g(3);

   private final int h;

   private bsq(int var3) {
      this.h = var3;
   }

   public static bsq a(int var0) {
      bsq[] var1 = values();
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         bsq var4 = var1[var3];
         if (var4.h == var0) {
            return var4;
         }
      }

      if (var0 < a.h) {
         return a;
      } else {
         return g;
      }
   }

   public int a() {
      return this.h;
   }
}
