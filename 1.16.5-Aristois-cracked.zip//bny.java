import javax.annotation.Nullable;

public class bny extends boa {
   private final fx b;
   protected boolean a;

   public bny(bfw var1, aot var2, bmb var3, dcj var4) {
      this(var1.l, var1, var2, var3, var4);
   }

   public bny(boa var1) {
      this(var1.p(), var1.n(), var1.o(), var1.m(), var1.i());
   }

   protected bny(brx var1, @Nullable bfw var2, aot var3, bmb var4, dcj var5) {
      super(var1, var2, var3, var4, var5);
      this.a = true;
      this.b = var5.a().a(var5.b());
      this.a = var1.d_(var5.a()).a(this);
   }

   public static bny a(bny var0, fx var1, gc var2) {
      return new bny(var0.p(), var0.n(), var0.o(), var0.m(), new dcj(new dcn((double)var1.u() + 0.5D + (double)var2.i() * 0.5D, (double)var1.v() + 0.5D + (double)var2.j() * 0.5D, (double)var1.w() + 0.5D + (double)var2.k() * 0.5D), var2, var1, false));
   }

   public fx a() {
      return this.a ? super.a() : this.b;
   }

   public boolean b() {
      return this.a || this.p().d_(this.a()).a(this);
   }

   public boolean c() {
      return this.a;
   }

   public gc d() {
      return gc.a((aqa)this.n())[0];
   }

   public gc[] e() {
      gc[] var1 = gc.a((aqa)this.n());
      if (this.a) {
         return var1;
      } else {
         gc var2 = this.j();

         int var3;
         for(var3 = 0; var3 < var1.length && var1[var3] != var2.f(); ++var3) {
         }

         if (var3 > 0) {
            System.arraycopy(var1, 0, var1, 1, var3);
            var1[0] = var2.f();
         }

         return var1;
      }
   }
}
