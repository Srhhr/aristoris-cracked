import java.util.Random;

public class byi extends cah {
   public byi(ceg.c var1) {
      super(var1);
   }

   public void a(ceh var1, brx var2, fx var3, Random var4) {
      super.a(var1, var2, var3, var4);
      if (var4.nextInt(10) == 0) {
         var2.a(hh.N, (double)var3.u() + var4.nextDouble(), (double)var3.v() + 1.1D, (double)var3.w() + var4.nextDouble(), 0.0D, 0.0D, 0.0D);
      }

   }
}
