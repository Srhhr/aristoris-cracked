import com.google.common.collect.ImmutableList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public interface dlu {
   dlu a = new dlu() {
      public int a(dfm var1, int var2, int var3) {
         return var3;
      }

      public int a(dfm var1, int var2, int var3, int var4, int var5) {
         return var3;
      }

      public int b(dfm var1, int var2, int var3, int var4, int var5) {
         return var3;
      }

      public int c(dfm var1, int var2, int var3, int var4, int var5) {
         return var3;
      }

      public int a() {
         return 0;
      }
   };

   static dlu a(dku var0, nu var1, int var2) {
      return b(var0, (List)var0.b(var1, var2).stream().map((var1x) -> {
         return new dlu.a(var1x, var0.a(var1x));
      }).collect(ImmutableList.toImmutableList()));
   }

   static dlu a(dku var0, nu var1, int var2, int var3) {
      return b(var0, (List)var0.b(var1, var2).stream().limit((long)var3).map((var1x) -> {
         return new dlu.a(var1x, var0.a(var1x));
      }).collect(ImmutableList.toImmutableList()));
   }

   static dlu a(dku var0, nr... var1) {
      return b(var0, (List)Arrays.stream(var1).map(nr::f).map((var1x) -> {
         return new dlu.a(var1x, var0.a(var1x));
      }).collect(ImmutableList.toImmutableList()));
   }

   static dlu b(final dku var0, final List<dlu.a> var1) {
      return var1.isEmpty() ? a : new dlu() {
         public int a(dfm var1x, int var2, int var3) {
            var0.getClass();
            return this.a(var1x, var2, var3, 9, 16777215);
         }

         public int a(dfm var1x, int var2, int var3, int var4, int var5) {
            int var6 = var3;

            for(Iterator var7 = var1.iterator(); var7.hasNext(); var6 += var4) {
               dlu.a var8 = (dlu.a)var7.next();
               var0.a(var1x, var8.a, (float)(var2 - var8.b / 2), (float)var6, var5);
            }

            return var6;
         }

         public int b(dfm var1x, int var2, int var3, int var4, int var5) {
            int var6 = var3;

            for(Iterator var7 = var1.iterator(); var7.hasNext(); var6 += var4) {
               dlu.a var8 = (dlu.a)var7.next();
               var0.a(var1x, var8.a, (float)var2, (float)var6, var5);
            }

            return var6;
         }

         public int c(dfm var1x, int var2, int var3, int var4, int var5) {
            int var6 = var3;

            for(Iterator var7 = var1.iterator(); var7.hasNext(); var6 += var4) {
               dlu.a var8 = (dlu.a)var7.next();
               var0.b(var1x, var8.a, (float)var2, (float)var6, var5);
            }

            return var6;
         }

         public int a() {
            return var1.size();
         }
      };
   }

   int a(dfm var1, int var2, int var3);

   int a(dfm var1, int var2, int var3, int var4, int var5);

   int b(dfm var1, int var2, int var3, int var4, int var5);

   int c(dfm var1, int var2, int var3, int var4, int var5);

   int a();

   public static class a {
      private final afa a;
      private final int b;

      private a(afa var1, int var2) {
         this.a = var1;
         this.b = var2;
      }

      // $FF: synthetic method
      a(afa var1, int var2, Object var3) {
         this(var1, var2);
      }
   }
}
