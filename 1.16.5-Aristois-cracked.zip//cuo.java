import javax.annotation.Nullable;

public class cuo implements cup {
   @Nullable
   private final cul<?, ?> a;
   @Nullable
   private final cul<?, ?> b;

   public cuo(cgj var1, boolean var2, boolean var3) {
      this.a = var2 ? new cug(var1) : null;
      this.b = var3 ? new cuq(var1) : null;
   }

   public void a(fx var1) {
      if (this.a != null) {
         this.a.a(var1);
      }

      if (this.b != null) {
         this.b.a(var1);
      }

   }

   public void a(fx var1, int var2) {
      if (this.a != null) {
         this.a.a(var1, var2);
      }

   }

   public boolean a() {
      if (this.b != null && this.b.a()) {
         return true;
      } else {
         return this.a != null && this.a.a();
      }
   }

   public int a(int var1, boolean var2, boolean var3) {
      if (this.a != null && this.b != null) {
         int var4 = var1 / 2;
         int var5 = this.a.a(var4, var2, var3);
         int var6 = var1 - var4 + var5;
         int var7 = this.b.a(var6, var2, var3);
         return var5 == 0 && var7 > 0 ? this.a.a(var7, var2, var3) : var7;
      } else if (this.a != null) {
         return this.a.a(var1, var2, var3);
      } else {
         return this.b != null ? this.b.a(var1, var2, var3) : var1;
      }
   }

   public void a(gp var1, boolean var2) {
      if (this.a != null) {
         this.a.a(var1, var2);
      }

      if (this.b != null) {
         this.b.a(var1, var2);
      }

   }

   public void a(brd var1, boolean var2) {
      if (this.a != null) {
         this.a.a(var1, var2);
      }

      if (this.b != null) {
         this.b.a(var1, var2);
      }

   }

   public cum a(bsf var1) {
      if (var1 == bsf.b) {
         return (cum)(this.a == null ? cum.a.a : this.a);
      } else {
         return (cum)(this.b == null ? cum.a.a : this.b);
      }
   }

   public String a(bsf var1, gp var2) {
      if (var1 == bsf.b) {
         if (this.a != null) {
            return this.a.b(var2.s());
         }
      } else if (this.b != null) {
         return this.b.b(var2.s());
      }

      return "n/a";
   }

   public void a(bsf var1, gp var2, @Nullable cgb var3, boolean var4) {
      if (var1 == bsf.b) {
         if (this.a != null) {
            this.a.a(var2.s(), var3, var4);
         }
      } else if (this.b != null) {
         this.b.a(var2.s(), var3, var4);
      }

   }

   public void b(brd var1, boolean var2) {
      if (this.a != null) {
         this.a.b(var1, var2);
      }

      if (this.b != null) {
         this.b.b(var1, var2);
      }

   }

   public int b(fx var1, int var2) {
      int var3 = this.b == null ? 0 : this.b.b(var1) - var2;
      int var4 = this.a == null ? 0 : this.a.b(var1);
      return Math.max(var4, var3);
   }
}
