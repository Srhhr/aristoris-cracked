import javax.annotation.Nullable;

public class bxw extends buo implements bzu {
   public static final cey a;
   public static final cey b;
   protected static final ddh c;
   protected static final ddh d;

   public bxw(ceg.c var1) {
      super(var1);
      this.j((ceh)((ceh)((ceh)this.n.b()).a(a, false)).a(b, false));
   }

   @Nullable
   public ceh a(bny var1) {
      cux var2 = var1.p().b(var1.a());
      gc[] var3 = var1.e();
      int var4 = var3.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         gc var6 = var3[var5];
         if (var6.n() == gc.a.b) {
            ceh var7 = (ceh)this.n().a(a, var6 == gc.b);
            if (var7.a(var1.p(), var1.a())) {
               return (ceh)var7.a(b, var2.a() == cuy.c);
            }
         }
      }

      return null;
   }

   public ddh b(ceh var1, brc var2, fx var3, dcs var4) {
      return (Boolean)var1.c(a) ? d : c;
   }

   protected void a(cei.a<buo, ceh> var1) {
      var1.a(a, b);
   }

   public boolean a(ceh var1, brz var2, fx var3) {
      gc var4 = h(var1).f();
      return buo.a(var2, var3.a(var4), var4.f());
   }

   protected static gc h(ceh var0) {
      return (Boolean)var0.c(a) ? gc.a : gc.b;
   }

   public cvc f(ceh var1) {
      return cvc.b;
   }

   public ceh a(ceh var1, gc var2, ceh var3, bry var4, fx var5, fx var6) {
      if ((Boolean)var1.c(b)) {
         var4.I().a(var5, cuy.c, cuy.c.a((brz)var4));
      }

      return h(var1).f() == var2 && !var1.a(var4, var5) ? bup.a.n() : super.a((ceh)var1, (gc)var2, (ceh)var3, (bry)var4, (fx)var5, (fx)var6);
   }

   public cux d(ceh var1) {
      return (Boolean)var1.c(b) ? cuy.c.a(false) : super.d(var1);
   }

   public boolean a(ceh var1, brc var2, fx var3, cxe var4) {
      return false;
   }

   static {
      a = cex.j;
      b = cex.C;
      c = dde.a(buo.a(5.0D, 0.0D, 5.0D, 11.0D, 7.0D, 11.0D), buo.a(6.0D, 7.0D, 6.0D, 10.0D, 9.0D, 10.0D));
      d = dde.a(buo.a(5.0D, 1.0D, 5.0D, 11.0D, 8.0D, 11.0D), buo.a(6.0D, 8.0D, 6.0D, 10.0D, 10.0D, 10.0D));
   }
}
