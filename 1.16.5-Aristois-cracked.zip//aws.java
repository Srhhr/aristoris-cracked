import java.util.EnumSet;

public class aws extends avv {
   private final aqn a;
   private double b;
   private double c;
   private int d;

   public aws(aqn var1) {
      this.a = var1;
      this.a(EnumSet.of(avv.a.a, avv.a.b));
   }

   public boolean a() {
      return this.a.cY().nextFloat() < 0.02F;
   }

   public boolean b() {
      return this.d >= 0;
   }

   public void c() {
      double var1 = 6.283185307179586D * this.a.cY().nextDouble();
      this.b = Math.cos(var1);
      this.c = Math.sin(var1);
      this.d = 20 + this.a.cY().nextInt(20);
   }

   public void e() {
      --this.d;
      this.a.t().a(this.a.cD() + this.b, this.a.cG(), this.a.cH() + this.c);
   }
}
