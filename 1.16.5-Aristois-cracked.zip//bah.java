import com.google.common.collect.Lists;
import java.util.Arrays;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import javax.annotation.Nullable;

public class bah extends azz {
   private static final us<Integer> bo;
   private static final us<Byte> bp;
   private static final us<Optional<UUID>> bq;
   private static final us<Optional<UUID>> br;
   private static final Predicate<bcv> bs;
   private static final Predicate<aqa> bt;
   private static final Predicate<aqa> bu;
   private static final Predicate<aqa> bv;
   private avv bw;
   private avv bx;
   private avv by;
   private float bz;
   private float bA;
   private float bB;
   private float bC;
   private int bD;

   public bah(aqe<? extends bah> var1, brx var2) {
      super(var1, var2);
      this.g = new bah.k();
      this.bh = new bah.m();
      this.a(cwz.p, 0.0F);
      this.a(cwz.q, 0.0F);
      this.p(true);
   }

   protected void e() {
      super.e();
      this.R.a((us)bq, (Object)Optional.empty());
      this.R.a((us)br, (Object)Optional.empty());
      this.R.a((us)bo, (int)0);
      this.R.a((us)bp, (byte)0);
   }

   protected void o() {
      this.bw = new axq(this, azz.class, 10, false, false, (var0) -> {
         return var0 instanceof bac || var0 instanceof baq;
      });
      this.bx = new axq(this, bax.class, 10, false, false, bax.bo);
      this.by = new axq(this, azw.class, 20, false, false, (var0) -> {
         return var0 instanceof azy;
      });
      this.bk.a(0, new bah.g());
      this.bk.a(1, new bah.b());
      this.bk.a(2, new bah.n(2.2D));
      this.bk.a(3, new bah.e(1.0D));
      this.bk.a(4, new avd(this, bfw.class, 16.0F, 1.6D, 1.4D, (var1) -> {
         return bv.test(var1) && !this.c(var1.bS()) && !this.fb();
      }));
      this.bk.a(4, new avd(this, baz.class, 8.0F, 1.6D, 1.4D, (var1) -> {
         return !((baz)var1).eK() && !this.fb();
      }));
      this.bk.a(4, new avd(this, bao.class, 8.0F, 1.6D, 1.4D, (var1) -> {
         return !this.fb();
      }));
      this.bk.a(5, new bah.u());
      this.bk.a(6, new bah.o());
      this.bk.a(6, new bah.s(1.25D));
      this.bk.a(7, new bah.l(1.2000000476837158D, true));
      this.bk.a(7, new bah.t());
      this.bk.a(8, new bah.h(this, 1.25D));
      this.bk.a(9, new bah.q(32, 200));
      this.bk.a(10, new bah.f(1.2000000476837158D, 12, 2));
      this.bk.a(10, new awb(this, 0.4F));
      this.bk.a(11, new axk(this, 1.0D));
      this.bk.a(11, new bah.p());
      this.bk.a(12, new bah.j(this, bfw.class, 24.0F));
      this.bk.a(13, new bah.r());
      this.bl.a(3, new bah.a(aqm.class, false, false, (var1) -> {
         return bt.test(var1) && !this.c(var1.bS());
      }));
   }

   public adp d(bmb var1) {
      return adq.et;
   }

   public void k() {
      if (!this.l.v && this.aX() && this.dS()) {
         ++this.bD;
         bmb var1 = this.b((aqf)aqf.a);
         if (this.l(var1)) {
            if (this.bD > 600) {
               bmb var2 = var1.a((brx)this.l, (aqm)this);
               if (!var2.a()) {
                  this.a((aqf)aqf.a, (bmb)var2);
               }

               this.bD = 0;
            } else if (this.bD > 560 && this.J.nextFloat() < 0.1F) {
               this.a(this.d(var1), 1.0F, 1.0F);
               this.l.a(this, (byte)45);
            }
         }

         aqm var3 = this.A();
         if (var3 == null || !var3.aX()) {
            this.v(false);
            this.w(false);
         }
      }

      if (this.em() || this.dI()) {
         this.aQ = false;
         this.aR = 0.0F;
         this.aT = 0.0F;
      }

      super.k();
      if (this.fb() && this.J.nextFloat() < 0.05F) {
         this.a(adq.ep, 1.0F, 1.0F);
      }

   }

   protected boolean dI() {
      return this.dl();
   }

   private boolean l(bmb var1) {
      return var1.b().s() && this.A() == null && this.t && !this.em();
   }

   protected void a(aos var1) {
      if (this.J.nextFloat() < 0.2F) {
         float var2 = this.J.nextFloat();
         bmb var3;
         if (var2 < 0.05F) {
            var3 = new bmb(bmd.oV);
         } else if (var2 < 0.2F) {
            var3 = new bmb(bmd.mg);
         } else if (var2 < 0.4F) {
            var3 = this.J.nextBoolean() ? new bmb(bmd.pA) : new bmb(bmd.pB);
         } else if (var2 < 0.6F) {
            var3 = new bmb(bmd.kW);
         } else if (var2 < 0.8F) {
            var3 = new bmb(bmd.lS);
         } else {
            var3 = new bmb(bmd.kT);
         }

         this.a((aqf)aqf.a, (bmb)var3);
      }

   }

   public void a(byte var1) {
      if (var1 == 45) {
         bmb var2 = this.b((aqf)aqf.a);
         if (!var2.a()) {
            for(int var3 = 0; var3 < 8; ++var3) {
               dcn var4 = (new dcn(((double)this.J.nextFloat() - 0.5D) * 0.1D, Math.random() * 0.1D + 0.1D, 0.0D)).a(-this.q * 0.017453292F).b(-this.p * 0.017453292F);
               this.l.a(new he(hh.I, var2), this.cD() + this.bh().b / 2.0D, this.cE(), this.cH() + this.bh().d / 2.0D, var4.b, var4.c + 0.05D, var4.d);
            }
         }
      } else {
         super.a(var1);
      }

   }

   public static ark.a eK() {
      return aqn.p().a(arl.d, 0.30000001192092896D).a(arl.a, 10.0D).a(arl.b, 32.0D).a(arl.f, 2.0D);
   }

   public bah b(aag var1, apy var2) {
      bah var3 = (bah)aqe.C.a((brx)var1);
      var3.a(this.J.nextBoolean() ? this.eL() : ((bah)var2).eL());
      return var3;
   }

   @Nullable
   public arc a(bsk var1, aos var2, aqp var3, @Nullable arc var4, @Nullable md var5) {
      Optional<vj<bsv>> var6 = var1.i(this.cB());
      bah.v var7 = bah.v.a(var6);
      boolean var8 = false;
      if (var4 instanceof bah.i) {
         var7 = ((bah.i)var4).a;
         if (((bah.i)var4).a() >= 2) {
            var8 = true;
         }
      } else {
         var4 = new bah.i(var7);
      }

      this.a(var7);
      if (var8) {
         this.c_(-24000);
      }

      if (var1 instanceof aag) {
         this.eZ();
      }

      this.a(var2);
      return super.a(var1, var2, var3, (arc)var4, var5);
   }

   private void eZ() {
      if (this.eL() == bah.v.a) {
         this.bl.a(4, this.bw);
         this.bl.a(4, this.bx);
         this.bl.a(6, this.by);
      } else {
         this.bl.a(4, this.by);
         this.bl.a(6, this.bw);
         this.bl.a(6, this.bx);
      }

   }

   protected void a(bfw var1, bmb var2) {
      if (this.k(var2)) {
         this.a(this.d(var2), 1.0F, 1.0F);
      }

      super.a(var1, var2);
   }

   protected float b(aqx var1, aqb var2) {
      return this.w_() ? var2.b * 0.85F : 0.4F;
   }

   public bah.v eL() {
      return bah.v.a((Integer)this.R.a(bo));
   }

   private void a(bah.v var1) {
      this.R.b(bo, var1.b());
   }

   private List<UUID> fa() {
      List<UUID> var1 = Lists.newArrayList();
      var1.add(((Optional)this.R.a(bq)).orElse((Object)null));
      var1.add(((Optional)this.R.a(br)).orElse((Object)null));
      return var1;
   }

   private void b(@Nullable UUID var1) {
      if (((Optional)this.R.a(bq)).isPresent()) {
         this.R.b(br, Optional.ofNullable(var1));
      } else {
         this.R.b(bq, Optional.ofNullable(var1));
      }

   }

   public void b(md var1) {
      super.b(var1);
      List<UUID> var2 = this.fa();
      mj var3 = new mj();
      Iterator var4 = var2.iterator();

      while(var4.hasNext()) {
         UUID var5 = (UUID)var4.next();
         if (var5 != null) {
            var3.add(mp.a(var5));
         }
      }

      var1.a((String)"Trusted", (mt)var3);
      var1.a("Sleeping", this.em());
      var1.a("Type", this.eL().a());
      var1.a("Sitting", this.eM());
      var1.a("Crouching", this.bz());
   }

   public void a(md var1) {
      super.a(var1);
      mj var2 = var1.d("Trusted", 11);

      for(int var3 = 0; var3 < var2.size(); ++var3) {
         this.b(mp.a(var2.k(var3)));
      }

      this.z(var1.q("Sleeping"));
      this.a(bah.v.a(var1.l("Type")));
      this.t(var1.q("Sitting"));
      this.v(var1.q("Crouching"));
      if (this.l instanceof aag) {
         this.eZ();
      }

   }

   public boolean eM() {
      return this.t(1);
   }

   public void t(boolean var1) {
      this.d(1, var1);
   }

   public boolean eN() {
      return this.t(64);
   }

   private void x(boolean var1) {
      this.d(64, var1);
   }

   private boolean fb() {
      return this.t(128);
   }

   private void y(boolean var1) {
      this.d(128, var1);
   }

   public boolean em() {
      return this.t(32);
   }

   private void z(boolean var1) {
      this.d(32, var1);
   }

   private void d(int var1, boolean var2) {
      if (var2) {
         this.R.b(bp, (byte)((Byte)this.R.a(bp) | var1));
      } else {
         this.R.b(bp, (byte)((Byte)this.R.a(bp) & ~var1));
      }

   }

   private boolean t(int var1) {
      return ((Byte)this.R.a(bp) & var1) != 0;
   }

   public boolean e(bmb var1) {
      aqf var2 = aqn.j(var1);
      if (!this.b((aqf)var2).a()) {
         return false;
      } else {
         return var2 == aqf.a && super.e(var1);
      }
   }

   public boolean h(bmb var1) {
      blx var2 = var1.b();
      bmb var3 = this.b((aqf)aqf.a);
      return var3.a() || this.bD > 0 && var2.s() && !var3.b().s();
   }

   private void m(bmb var1) {
      if (!var1.a() && !this.l.v) {
         bcv var2 = new bcv(this.l, this.cD() + this.bh().b, this.cE() + 1.0D, this.cH() + this.bh().d, var1);
         var2.a(40);
         var2.c(this.bS());
         this.a(adq.ey, 1.0F, 1.0F);
         this.l.c((aqa)var2);
      }
   }

   private void n(bmb var1) {
      bcv var2 = new bcv(this.l, this.cD(), this.cE(), this.cH(), var1);
      this.l.c((aqa)var2);
   }

   protected void b(bcv var1) {
      bmb var2 = var1.g();
      if (this.h(var2)) {
         int var3 = var2.E();
         if (var3 > 1) {
            this.n(var2.a(var3 - 1));
         }

         this.m(this.b((aqf)aqf.a));
         this.a((bcv)var1);
         this.a((aqf)aqf.a, (bmb)var2.a(1));
         this.bm[aqf.a.b()] = 2.0F;
         this.a(var1, var2.E());
         var1.ad();
         this.bD = 0;
      }

   }

   public void j() {
      super.j();
      if (this.dS()) {
         boolean var1 = this.aE();
         if (var1 || this.A() != null || this.l.W()) {
            this.fc();
         }

         if (var1 || this.em()) {
            this.t(false);
         }

         if (this.eN() && this.l.t.nextFloat() < 0.2F) {
            fx var2 = this.cB();
            ceh var3 = this.l.d_(var2);
            this.l.c(2001, var2, buo.i(var3));
         }
      }

      this.bA = this.bz;
      if (this.eW()) {
         this.bz += (1.0F - this.bz) * 0.4F;
      } else {
         this.bz += (0.0F - this.bz) * 0.4F;
      }

      this.bC = this.bB;
      if (this.bz()) {
         this.bB += 0.2F;
         if (this.bB > 3.0F) {
            this.bB = 3.0F;
         }
      } else {
         this.bB = 0.0F;
      }

   }

   public boolean k(bmb var1) {
      return var1.b() == bmd.rm;
   }

   protected void a(bfw var1, aqn var2) {
      ((bah)var2).b(var1.bS());
   }

   public boolean eO() {
      return this.t(16);
   }

   public void u(boolean var1) {
      this.d(16, var1);
   }

   public boolean eV() {
      return this.bB == 3.0F;
   }

   public void v(boolean var1) {
      this.d(4, var1);
   }

   public boolean bz() {
      return this.t(4);
   }

   public void w(boolean var1) {
      this.d(8, var1);
   }

   public boolean eW() {
      return this.t(8);
   }

   public float y(float var1) {
      return afm.g(var1, this.bA, this.bz) * 0.11F * 3.1415927F;
   }

   public float z(float var1) {
      return afm.g(var1, this.bC, this.bB);
   }

   public void h(@Nullable aqm var1) {
      if (this.fb() && var1 == null) {
         this.y(false);
      }

      super.h(var1);
   }

   protected int e(float var1, float var2) {
      return afm.f((var1 - 5.0F) * var2);
   }

   private void fc() {
      this.z(false);
   }

   private void fd() {
      this.w(false);
      this.v(false);
      this.t(false);
      this.z(false);
      this.y(false);
      this.x(false);
   }

   private boolean fe() {
      return !this.em() && !this.eM() && !this.eN();
   }

   public void F() {
      adp var1 = this.I();
      if (var1 == adq.ev) {
         this.a(var1, 2.0F, this.dH());
      } else {
         super.F();
      }

   }

   @Nullable
   protected adp I() {
      if (this.em()) {
         return adq.ew;
      } else {
         if (!this.l.M() && this.J.nextFloat() < 0.1F) {
            List<bfw> var1 = this.l.a(bfw.class, this.cc().c(16.0D, 16.0D, 16.0D), aqd.g);
            if (var1.isEmpty()) {
               return adq.ev;
            }
         }

         return adq.eq;
      }
   }

   @Nullable
   protected adp e(apk var1) {
      return adq.eu;
   }

   @Nullable
   protected adp dq() {
      return adq.es;
   }

   private boolean c(UUID var1) {
      return this.fa().contains(var1);
   }

   protected void d(apk var1) {
      bmb var2 = this.b((aqf)aqf.a);
      if (!var2.a()) {
         this.a((bmb)var2);
         this.a((aqf)aqf.a, (bmb)bmb.b);
      }

      super.d(var1);
   }

   public static boolean a(bah var0, aqm var1) {
      double var2 = var1.cH() - var0.cH();
      double var4 = var1.cD() - var0.cD();
      double var6 = var2 / var4;
      int var8 = true;

      for(int var9 = 0; var9 < 6; ++var9) {
         double var10 = var6 == 0.0D ? 0.0D : var2 * (double)((float)var9 / 6.0F);
         double var12 = var6 == 0.0D ? var4 * (double)((float)var9 / 6.0F) : var10 / var6;

         for(int var14 = 1; var14 < 4; ++var14) {
            if (!var0.l.d_(new fx(var0.cD() + var12, var0.cE() + (double)var14, var0.cH() + var10)).c().e()) {
               return false;
            }
         }
      }

      return true;
   }

   public dcn cf() {
      return new dcn(0.0D, (double)(0.55F * this.ce()), (double)(this.cy() * 0.4F));
   }

   // $FF: synthetic method
   public apy a(aag var1, apy var2) {
      return this.b(var1, var2);
   }

   static {
      bo = uv.a(bah.class, uu.b);
      bp = uv.a(bah.class, uu.a);
      bq = uv.a(bah.class, uu.o);
      br = uv.a(bah.class, uu.o);
      bs = (var0) -> {
         return !var0.p() && var0.aX();
      };
      bt = (var0) -> {
         if (!(var0 instanceof aqm)) {
            return false;
         } else {
            aqm var1 = (aqm)var0;
            return var1.db() != null && var1.dc() < var1.K + 600;
         }
      };
      bu = (var0) -> {
         return var0 instanceof bac || var0 instanceof baq;
      };
      bv = (var0) -> {
         return !var0.bx() && aqd.e.test(var0);
      };
   }

   class j extends awd {
      public j(aqn var2, Class<? extends aqm> var3, float var4) {
         super(var2, var3, var4);
      }

      public boolean a() {
         return super.a() && !bah.this.eN() && !bah.this.eW();
      }

      public boolean b() {
         return super.b() && !bah.this.eN() && !bah.this.eW();
      }
   }

   class h extends avu {
      private final bah b;

      public h(bah var2, double var3) {
         super(var2, var3);
         this.b = var2;
      }

      public boolean a() {
         return !this.b.fb() && super.a();
      }

      public boolean b() {
         return !this.b.fb() && super.b();
      }

      public void c() {
         this.b.fd();
         super.c();
      }
   }

   public class k extends ava {
      public k() {
         super(bah.this);
      }

      public void a() {
         if (!bah.this.em()) {
            super.a();
         }

      }

      protected boolean b() {
         return !bah.this.eO() && !bah.this.bz() && !bah.this.eW() & !bah.this.eN();
      }
   }

   public class o extends avz {
      public boolean a() {
         if (!bah.this.eV()) {
            return false;
         } else {
            aqm var1 = bah.this.A();
            if (var1 != null && var1.aX()) {
               if (var1.ca() != var1.bZ()) {
                  return false;
               } else {
                  boolean var2 = bah.a((bah)bah.this, (aqm)var1);
                  if (!var2) {
                     bah.this.x().a((aqa)var1, 0);
                     bah.this.v(false);
                     bah.this.w(false);
                  }

                  return var2;
               }
            } else {
               return false;
            }
         }
      }

      public boolean b() {
         aqm var1 = bah.this.A();
         if (var1 != null && var1.aX()) {
            double var2 = bah.this.cC().c;
            return (!(var2 * var2 < 0.05000000074505806D) || !(Math.abs(bah.this.q) < 15.0F) || !bah.this.t) && !bah.this.eN();
         } else {
            return false;
         }
      }

      public boolean C_() {
         return false;
      }

      public void c() {
         bah.this.o(true);
         bah.this.u(true);
         bah.this.w(false);
         aqm var1 = bah.this.A();
         bah.this.t().a(var1, 60.0F, 30.0F);
         dcn var2 = (new dcn(var1.cD() - bah.this.cD(), var1.cE() - bah.this.cE(), var1.cH() - bah.this.cH())).d();
         bah.this.f(bah.this.cC().b(var2.b * 0.8D, 0.9D, var2.d * 0.8D));
         bah.this.x().o();
      }

      public void d() {
         bah.this.v(false);
         bah.this.bB = 0.0F;
         bah.this.bC = 0.0F;
         bah.this.w(false);
         bah.this.u(false);
      }

      public void e() {
         aqm var1 = bah.this.A();
         if (var1 != null) {
            bah.this.t().a(var1, 60.0F, 30.0F);
         }

         if (!bah.this.eN()) {
            dcn var2 = bah.this.cC();
            if (var2.c * var2.c < 0.029999999329447746D && bah.this.q != 0.0F) {
               bah.this.q = afm.j(bah.this.q, 0.0F, 0.2F);
            } else {
               double var3 = Math.sqrt(aqa.c(var2));
               double var5 = Math.signum(-var2.c) * Math.acos(var3 / var2.f()) * 57.2957763671875D;
               bah.this.q = (float)var5;
            }
         }

         if (var1 != null && bah.this.g(var1) <= 2.0F) {
            bah.this.B(var1);
         } else if (bah.this.q > 0.0F && bah.this.t && (float)bah.this.cC().c != 0.0F && bah.this.l.d_(bah.this.cB()).a(bup.cC)) {
            bah.this.q = 60.0F;
            bah.this.h((aqm)null);
            bah.this.x(true);
         }

      }
   }

   class g extends avp {
      public g() {
         super(bah.this);
      }

      public void c() {
         super.c();
         bah.this.fd();
      }

      public boolean a() {
         return bah.this.aE() && bah.this.b((ael)aef.b) > 0.25D || bah.this.aQ();
      }
   }

   class q extends axc {
      public q(int var2, int var3) {
         super(bah.this, var3);
      }

      public void c() {
         bah.this.fd();
         super.c();
      }

      public boolean a() {
         return super.a() && this.g();
      }

      public boolean b() {
         return super.b() && this.g();
      }

      private boolean g() {
         return !bah.this.em() && !bah.this.eM() && !bah.this.fb() && bah.this.A() == null;
      }
   }

   class n extends awp {
      public n(double var2) {
         super(bah.this, var2);
      }

      public boolean a() {
         return !bah.this.fb() && super.a();
      }
   }

   class b extends avv {
      int a;

      public b() {
         this.a(EnumSet.of(avv.a.b, avv.a.c, avv.a.a));
      }

      public boolean a() {
         return bah.this.eN();
      }

      public boolean b() {
         return this.a() && this.a > 0;
      }

      public void c() {
         this.a = 40;
      }

      public void d() {
         bah.this.x(false);
      }

      public void e() {
         --this.a;
      }
   }

   public static class i extends apy.a {
      public final bah.v a;

      public i(bah.v var1) {
         super(false);
         this.a = var1;
      }
   }

   public class f extends awj {
      protected int g;

      public f(double var2, int var4, int var5) {
         super(bah.this, var2, var4, var5);
      }

      public double h() {
         return 2.0D;
      }

      public boolean k() {
         return this.d % 100 == 0;
      }

      protected boolean a(brz var1, fx var2) {
         ceh var3 = var1.d_(var2);
         return var3.a(bup.mg) && (Integer)var3.c(cau.a) >= 2;
      }

      public void e() {
         if (this.l()) {
            if (this.g >= 40) {
               this.n();
            } else {
               ++this.g;
            }
         } else if (!this.l() && bah.this.J.nextFloat() < 0.05F) {
            bah.this.a(adq.ex, 1.0F, 1.0F);
         }

         super.e();
      }

      protected void n() {
         if (bah.this.l.V().b(brt.b)) {
            ceh var1 = bah.this.l.d_(this.e);
            if (var1.a(bup.mg)) {
               int var2 = (Integer)var1.c(cau.a);
               var1.a(cau.a, 1);
               int var3 = 1 + bah.this.l.t.nextInt(2) + (var2 == 3 ? 1 : 0);
               bmb var4 = bah.this.b((aqf)aqf.a);
               if (var4.a()) {
                  bah.this.a((aqf)aqf.a, (bmb)(new bmb(bmd.rm)));
                  --var3;
               }

               if (var3 > 0) {
                  buo.a(bah.this.l, this.e, new bmb(bmd.rm, var3));
               }

               bah.this.a(adq.oZ, 1.0F, 1.0F);
               bah.this.l.a(this.e, (ceh)var1.a(cau.a, 1), 2);
            }
         }
      }

      public boolean a() {
         return !bah.this.em() && super.a();
      }

      public void c() {
         this.g = 0;
         bah.this.t(false);
         super.c();
      }
   }

   class r extends bah.d {
      private double c;
      private double d;
      private int e;
      private int f;

      public r() {
         super(null);
         this.a(EnumSet.of(avv.a.a, avv.a.b));
      }

      public boolean a() {
         return bah.this.cZ() == null && bah.this.cY().nextFloat() < 0.02F && !bah.this.em() && bah.this.A() == null && bah.this.x().m() && !this.h() && !bah.this.eO() && !bah.this.bz();
      }

      public boolean b() {
         return this.f > 0;
      }

      public void c() {
         this.j();
         this.f = 2 + bah.this.cY().nextInt(3);
         bah.this.t(true);
         bah.this.x().o();
      }

      public void d() {
         bah.this.t(false);
      }

      public void e() {
         --this.e;
         if (this.e <= 0) {
            --this.f;
            this.j();
         }

         bah.this.t().a(bah.this.cD() + this.c, bah.this.cG(), bah.this.cH() + this.d, (float)bah.this.Q(), (float)bah.this.O());
      }

      private void j() {
         double var1 = 6.283185307179586D * bah.this.cY().nextDouble();
         this.c = Math.cos(var1);
         this.d = Math.sin(var1);
         this.e = 80 + bah.this.cY().nextInt(20);
      }
   }

   class t extends bah.d {
      private int c;

      public t() {
         super(null);
         this.c = bah.this.J.nextInt(140);
         this.a(EnumSet.of(avv.a.a, avv.a.b, avv.a.c));
      }

      public boolean a() {
         if (bah.this.aR == 0.0F && bah.this.aS == 0.0F && bah.this.aT == 0.0F) {
            return this.j() || bah.this.em();
         } else {
            return false;
         }
      }

      public boolean b() {
         return this.j();
      }

      private boolean j() {
         if (this.c > 0) {
            --this.c;
            return false;
         } else {
            return bah.this.l.M() && this.g() && !this.h();
         }
      }

      public void d() {
         this.c = bah.this.J.nextInt(140);
         bah.this.fd();
      }

      public void c() {
         bah.this.t(false);
         bah.this.v(false);
         bah.this.w(false);
         bah.this.o(false);
         bah.this.z(true);
         bah.this.x().o();
         bah.this.u().a(bah.this.cD(), bah.this.cE(), bah.this.cH(), 0.0D);
      }
   }

   abstract class d extends avv {
      private final azg b;

      private d() {
         this.b = (new azg()).a(12.0D).c().a(bah.this.new c());
      }

      protected boolean g() {
         fx var1 = new fx(bah.this.cD(), bah.this.cc().e, bah.this.cH());
         return !bah.this.l.e(var1) && bah.this.f(var1) >= 0.0F;
      }

      protected boolean h() {
         return !bah.this.l.a(aqm.class, this.b, bah.this, bah.this.cc().c(12.0D, 6.0D, 12.0D)).isEmpty();
      }

      // $FF: synthetic method
      d(Object var2) {
         this();
      }
   }

   public class c implements Predicate<aqm> {
      public boolean a(aqm var1) {
         if (var1 instanceof bah) {
            return false;
         } else if (!(var1 instanceof bac) && !(var1 instanceof baq) && !(var1 instanceof bdq)) {
            if (var1 instanceof are) {
               return !((are)var1).eK();
            } else if (var1 instanceof bfw && (var1.a_() || ((bfw)var1).b_())) {
               return false;
            } else if (bah.this.c(var1.bS())) {
               return false;
            } else {
               return !var1.em() && !var1.bx();
            }
         } else {
            return true;
         }
      }

      // $FF: synthetic method
      public boolean test(Object var1) {
         return this.a((aqm)var1);
      }
   }

   class s extends avo {
      private int c = 100;

      public s(double var2) {
         super(bah.this, var2);
      }

      public boolean a() {
         if (!bah.this.em() && this.a.A() == null) {
            if (bah.this.l.W()) {
               return true;
            } else if (this.c > 0) {
               --this.c;
               return false;
            } else {
               this.c = 100;
               fx var1 = this.a.cB();
               return bah.this.l.M() && bah.this.l.e(var1) && !((aag)bah.this.l).a_(var1) && this.g();
            }
         } else {
            return false;
         }
      }

      public void c() {
         bah.this.fd();
         super.c();
      }
   }

   class a extends axq<aqm> {
      @Nullable
      private aqm j;
      private aqm k;
      private int l;

      public a(Class<aqm> var2, boolean var3, boolean var4, Predicate<aqm> var5) {
         super(bah.this, var2, 10, var3, var4, var5);
      }

      public boolean a() {
         if (this.b > 0 && this.e.cY().nextInt(this.b) != 0) {
            return false;
         } else {
            Iterator var1 = bah.this.fa().iterator();

            while(var1.hasNext()) {
               UUID var2 = (UUID)var1.next();
               if (var2 != null && bah.this.l instanceof aag) {
                  aqa var3 = ((aag)bah.this.l).a(var2);
                  if (var3 instanceof aqm) {
                     aqm var4 = (aqm)var3;
                     this.k = var4;
                     this.j = var4.cZ();
                     int var5 = var4.da();
                     return var5 != this.l && this.a(this.j, this.d);
                  }
               }
            }

            return false;
         }
      }

      public void c() {
         this.a(this.j);
         this.c = this.j;
         if (this.k != null) {
            this.l = this.k.da();
         }

         bah.this.a(adq.ep, 1.0F, 1.0F);
         bah.this.y(true);
         bah.this.fc();
         super.c();
      }
   }

   class e extends avi {
      public e(double var2) {
         super(bah.this, var2);
      }

      public void c() {
         ((bah)this.a).fd();
         ((bah)this.c).fd();
         super.c();
      }

      protected void g() {
         aag var1 = (aag)this.b;
         bah var2 = (bah)this.a.a((aag)var1, (apy)this.c);
         if (var2 != null) {
            aah var3 = this.a.eR();
            aah var4 = this.c.eR();
            aah var5 = var3;
            if (var3 != null) {
               var2.b(var3.bS());
            } else {
               var5 = var4;
            }

            if (var4 != null && var3 != var4) {
               var2.b(var4.bS());
            }

            if (var5 != null) {
               var5.a((vk)aea.O);
               ac.o.a((aah)var5, (azz)this.a, (azz)this.c, (apy)var2);
            }

            this.a.c_(6000);
            this.c.c_(6000);
            this.a.eT();
            this.c.eT();
            var2.c_(-24000);
            var2.b(this.a.cD(), this.a.cE(), this.a.cH(), 0.0F, 0.0F);
            var1.l(var2);
            this.b.a(this.a, (byte)18);
            if (this.b.V().b(brt.e)) {
               this.b.c((aqa)(new aqg(this.b, this.a.cD(), this.a.cE(), this.a.cH(), this.a.cY().nextInt(7) + 1)));
            }

         }
      }
   }

   class l extends awf {
      public l(double var2, boolean var4) {
         super(bah.this, var2, var4);
      }

      protected void a(aqm var1, double var2) {
         double var4 = this.a(var1);
         if (var2 <= var4 && this.h()) {
            this.g();
            this.a.B(var1);
            bah.this.a(adq.er, 1.0F, 1.0F);
         }

      }

      public void c() {
         bah.this.w(false);
         super.c();
      }

      public boolean a() {
         return !bah.this.eM() && !bah.this.em() && !bah.this.bz() && !bah.this.eN() && super.a();
      }
   }

   class u extends avv {
      public u() {
         this.a(EnumSet.of(avv.a.a, avv.a.b));
      }

      public boolean a() {
         if (bah.this.em()) {
            return false;
         } else {
            aqm var1 = bah.this.A();
            return var1 != null && var1.aX() && bah.bu.test(var1) && bah.this.h((aqa)var1) > 36.0D && !bah.this.bz() && !bah.this.eW() && !bah.this.aQ;
         }
      }

      public void c() {
         bah.this.t(false);
         bah.this.x(false);
      }

      public void d() {
         aqm var1 = bah.this.A();
         if (var1 != null && bah.a((bah)bah.this, (aqm)var1)) {
            bah.this.w(true);
            bah.this.v(true);
            bah.this.x().o();
            bah.this.t().a(var1, (float)bah.this.Q(), (float)bah.this.O());
         } else {
            bah.this.w(false);
            bah.this.v(false);
         }

      }

      public void e() {
         aqm var1 = bah.this.A();
         bah.this.t().a(var1, (float)bah.this.Q(), (float)bah.this.O());
         if (bah.this.h((aqa)var1) <= 36.0D) {
            bah.this.w(true);
            bah.this.v(true);
            bah.this.x().o();
         } else {
            bah.this.x().a((aqa)var1, 1.5D);
         }

      }
   }

   class m extends avb {
      public m() {
         super(bah.this);
      }

      public void a() {
         if (bah.this.fe()) {
            super.a();
         }

      }
   }

   class p extends avv {
      public p() {
         this.a(EnumSet.of(avv.a.a));
      }

      public boolean a() {
         if (!bah.this.b((aqf)aqf.a).a()) {
            return false;
         } else if (bah.this.A() == null && bah.this.cZ() == null) {
            if (!bah.this.fe()) {
               return false;
            } else if (bah.this.cY().nextInt(10) != 0) {
               return false;
            } else {
               List<bcv> var1 = bah.this.l.a(bcv.class, bah.this.cc().c(8.0D, 8.0D, 8.0D), bah.bs);
               return !var1.isEmpty() && bah.this.b((aqf)aqf.a).a();
            }
         } else {
            return false;
         }
      }

      public void e() {
         List<bcv> var1 = bah.this.l.a(bcv.class, bah.this.cc().c(8.0D, 8.0D, 8.0D), bah.bs);
         bmb var2 = bah.this.b((aqf)aqf.a);
         if (var2.a() && !var1.isEmpty()) {
            bah.this.x().a((aqa)var1.get(0), 1.2000000476837158D);
         }

      }

      public void c() {
         List<bcv> var1 = bah.this.l.a(bcv.class, bah.this.cc().c(8.0D, 8.0D, 8.0D), bah.bs);
         if (!var1.isEmpty()) {
            bah.this.x().a((aqa)var1.get(0), 1.2000000476837158D);
         }

      }
   }

   public static enum v {
      a(0, "red", new vj[]{btb.f, btb.t, btb.ae, btb.G, btb.an, btb.H, btb.ao}),
      b(1, "snow", new vj[]{btb.E, btb.F, btb.am});

      private static final bah.v[] c = (bah.v[])Arrays.stream(values()).sorted(Comparator.comparingInt(bah.v::b)).toArray((var0) -> {
         return new bah.v[var0];
      });
      private static final Map<String, bah.v> d = (Map)Arrays.stream(values()).collect(Collectors.toMap(bah.v::a, (var0) -> {
         return var0;
      }));
      private final int e;
      private final String f;
      private final List<vj<bsv>> g;

      private v(int var3, String var4, vj<bsv>... var5) {
         this.e = var3;
         this.f = var4;
         this.g = Arrays.asList(var5);
      }

      public String a() {
         return this.f;
      }

      public int b() {
         return this.e;
      }

      public static bah.v a(String var0) {
         return (bah.v)d.getOrDefault(var0, a);
      }

      public static bah.v a(int var0) {
         if (var0 < 0 || var0 > c.length) {
            var0 = 0;
         }

         return c[var0];
      }

      public static bah.v a(Optional<vj<bsv>> var0) {
         return var0.isPresent() && b.g.contains(var0.get()) ? b : a;
      }
   }
}
