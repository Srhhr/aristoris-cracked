public interface eke {
   void e();
}
