import javax.annotation.Nullable;

public abstract class ccd extends ccj implements aon, aox, aoy {
   private aow a;
   private nr b;

   protected ccd(cck<?> var1) {
      super(var1);
      this.a = aow.a;
   }

   public void a(ceh var1, md var2) {
      super.a(var1, var2);
      this.a = aow.b(var2);
      if (var2.c("CustomName", 8)) {
         this.b = nr.a.a(var2.l("CustomName"));
      }

   }

   public md a(md var1) {
      super.a(var1);
      this.a.a(var1);
      if (this.b != null) {
         var1.a("CustomName", nr.a.a(this.b));
      }

      return var1;
   }

   public void a(nr var1) {
      this.b = var1;
   }

   public nr R() {
      return this.b != null ? this.b : this.g();
   }

   public nr d() {
      return this.R();
   }

   @Nullable
   public nr T() {
      return this.b;
   }

   protected abstract nr g();

   public boolean e(bfw var1) {
      return a(var1, this.a, this.d());
   }

   public static boolean a(bfw var0, aow var1, nr var2) {
      if (!var0.a_() && !var1.a(var0.dD())) {
         var0.a((nr)(new of("container.isLocked", new Object[]{var2})), true);
         var0.a(adq.bF, adr.e, 1.0F, 1.0F);
         return false;
      } else {
         return true;
      }
   }

   @Nullable
   public bic createMenu(int var1, bfv var2, bfw var3) {
      return this.e(var3) ? this.a(var1, var2) : null;
   }

   protected abstract bic a(int var1, bfv var2);
}
