import com.google.common.collect.Maps;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.PortUnreachableException;
import java.net.SocketAddress;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.Map;
import java.util.Random;
import javax.annotation.Nullable;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class adj extends adi {
   private static final Logger d = LogManager.getLogger();
   private long e;
   private final int f;
   private final int g;
   private final int h;
   private final String i;
   private final String j;
   private DatagramSocket k;
   private final byte[] l = new byte[1460];
   private String m;
   private String n;
   private final Map<SocketAddress, adj.a> o;
   private final ade p;
   private long q;
   private final vy r;

   private adj(vy var1, int var2) {
      super("Query Listener");
      this.r = var1;
      this.f = var2;
      this.n = var1.h_();
      this.g = var1.p();
      this.i = var1.i_();
      this.h = var1.J();
      this.j = var1.k_();
      this.q = 0L;
      this.m = "0.0.0.0";
      if (!this.n.isEmpty() && !this.m.equals(this.n)) {
         this.m = this.n;
      } else {
         this.n = "0.0.0.0";

         try {
            InetAddress var3 = InetAddress.getLocalHost();
            this.m = var3.getHostAddress();
         } catch (UnknownHostException var4) {
            d.warn("Unable to determine local host IP, please set server-ip in server.properties", var4);
         }
      }

      this.p = new ade(1460);
      this.o = Maps.newHashMap();
   }

   @Nullable
   public static adj a(vy var0) {
      int var1 = var0.g_().s;
      if (0 < var1 && 65535 >= var1) {
         adj var2 = new adj(var0, var1);
         return !var2.a() ? null : var2;
      } else {
         d.warn("Invalid query port {} found in server.properties (queries disabled)", var1);
         return null;
      }
   }

   private void a(byte[] var1, DatagramPacket var2) throws IOException {
      this.k.send(new DatagramPacket(var1, var1.length, var2.getSocketAddress()));
   }

   private boolean a(DatagramPacket var1) throws IOException {
      byte[] var2 = var1.getData();
      int var3 = var1.getLength();
      SocketAddress var4 = var1.getSocketAddress();
      d.debug("Packet len {} [{}]", var3, var4);
      if (3 <= var3 && -2 == var2[0] && -3 == var2[1]) {
         d.debug("Packet '{}' [{}]", adf.a(var2[2]), var4);
         switch(var2[2]) {
         case 0:
            if (!this.c(var1)) {
               d.debug("Invalid challenge [{}]", var4);
               return false;
            } else if (15 == var3) {
               this.a(this.b(var1), var1);
               d.debug("Rules [{}]", var4);
            } else {
               ade var5 = new ade(1460);
               var5.a((int)0);
               var5.a(this.a(var1.getSocketAddress()));
               var5.a(this.i);
               var5.a("SMP");
               var5.a(this.j);
               var5.a(Integer.toString(this.r.I()));
               var5.a(Integer.toString(this.h));
               var5.a((short)this.g);
               var5.a(this.m);
               this.a(var5.a(), var1);
               d.debug("Status [{}]", var4);
            }
         default:
            return true;
         case 9:
            this.d(var1);
            d.debug("Challenge [{}]", var4);
            return true;
         }
      } else {
         d.debug("Invalid packet [{}]", var4);
         return false;
      }
   }

   private byte[] b(DatagramPacket var1) throws IOException {
      long var2 = x.b();
      if (var2 < this.q + 5000L) {
         byte[] var9 = this.p.a();
         byte[] var10 = this.a(var1.getSocketAddress());
         var9[1] = var10[0];
         var9[2] = var10[1];
         var9[3] = var10[2];
         var9[4] = var10[3];
         return var9;
      } else {
         this.q = var2;
         this.p.b();
         this.p.a((int)0);
         this.p.a(this.a(var1.getSocketAddress()));
         this.p.a("splitnum");
         this.p.a((int)128);
         this.p.a((int)0);
         this.p.a("hostname");
         this.p.a(this.i);
         this.p.a("gametype");
         this.p.a("SMP");
         this.p.a("game_id");
         this.p.a("MINECRAFT");
         this.p.a("version");
         this.p.a(this.r.H());
         this.p.a("plugins");
         this.p.a(this.r.j_());
         this.p.a("map");
         this.p.a(this.j);
         this.p.a("numplayers");
         this.p.a("" + this.r.I());
         this.p.a("maxplayers");
         this.p.a("" + this.h);
         this.p.a("hostport");
         this.p.a("" + this.g);
         this.p.a("hostip");
         this.p.a(this.m);
         this.p.a((int)0);
         this.p.a((int)1);
         this.p.a("player_");
         this.p.a((int)0);
         String[] var4 = this.r.K();
         String[] var5 = var4;
         int var6 = var4.length;

         for(int var7 = 0; var7 < var6; ++var7) {
            String var8 = var5[var7];
            this.p.a(var8);
         }

         this.p.a((int)0);
         return this.p.a();
      }
   }

   private byte[] a(SocketAddress var1) {
      return ((adj.a)this.o.get(var1)).c();
   }

   private Boolean c(DatagramPacket var1) {
      SocketAddress var2 = var1.getSocketAddress();
      if (!this.o.containsKey(var2)) {
         return false;
      } else {
         byte[] var3 = var1.getData();
         return ((adj.a)this.o.get(var2)).a() == adf.c(var3, 7, var1.getLength());
      }
   }

   private void d(DatagramPacket var1) throws IOException {
      adj.a var2 = new adj.a(var1);
      this.o.put(var1.getSocketAddress(), var2);
      this.a(var2.b(), var1);
   }

   private void d() {
      if (this.a) {
         long var1 = x.b();
         if (var1 >= this.e + 30000L) {
            this.e = var1;
            this.o.values().removeIf((var2) -> {
               return var2.a(var1);
            });
         }
      }
   }

   public void run() {
      d.info("Query running on {}:{}", this.n, this.f);
      this.e = x.b();
      DatagramPacket var1 = new DatagramPacket(this.l, this.l.length);

      try {
         while(this.a) {
            try {
               this.k.receive(var1);
               this.d();
               this.a(var1);
            } catch (SocketTimeoutException var8) {
               this.d();
            } catch (PortUnreachableException var9) {
            } catch (IOException var10) {
               this.a((Exception)var10);
            }
         }
      } finally {
         d.debug("closeSocket: {}:{}", this.n, this.f);
         this.k.close();
      }

   }

   public boolean a() {
      if (this.a) {
         return true;
      } else {
         return !this.e() ? false : super.a();
      }
   }

   private void a(Exception var1) {
      if (this.a) {
         d.warn("Unexpected exception", var1);
         if (!this.e()) {
            d.error("Failed to recover from exception, shutting down!");
            this.a = false;
         }

      }
   }

   private boolean e() {
      try {
         this.k = new DatagramSocket(this.f, InetAddress.getByName(this.n));
         this.k.setSoTimeout(500);
         return true;
      } catch (Exception var2) {
         d.warn("Unable to initialise query system on {}:{}", this.n, this.f, var2);
         return false;
      }
   }

   static class a {
      private final long a = (new Date()).getTime();
      private final int b;
      private final byte[] c;
      private final byte[] d;
      private final String e;

      public a(DatagramPacket var1) {
         byte[] var2 = var1.getData();
         this.c = new byte[4];
         this.c[0] = var2[3];
         this.c[1] = var2[4];
         this.c[2] = var2[5];
         this.c[3] = var2[6];
         this.e = new String(this.c, StandardCharsets.UTF_8);
         this.b = (new Random()).nextInt(16777216);
         this.d = String.format("\t%s%d\u0000", this.e, this.b).getBytes(StandardCharsets.UTF_8);
      }

      public Boolean a(long var1) {
         return this.a < var1;
      }

      public int a() {
         return this.b;
      }

      public byte[] b() {
         return this.d;
      }

      public byte[] c() {
         return this.c;
      }
   }
}
