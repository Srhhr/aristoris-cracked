public class doe extends dnq {
   public doe() {
      super("");
   }

   protected void b() {
      super.b();
      this.a(new dlj(this.k / 2 - 100, this.l - 40, 200, 20, new of("multiplayer.stopSleeping"), (var1) -> {
         this.h();
      }));
   }

   public void at_() {
      this.h();
   }

   public boolean a(int var1, int var2, int var3) {
      if (var1 == 256) {
         this.h();
      } else if (var1 == 257 || var1 == 335) {
         String var4 = this.a.b().trim();
         if (!var4.isEmpty()) {
            this.b_(var4);
         }

         this.a.a("");
         this.i.j.c().c();
         return true;
      }

      return super.a(var1, var2, var3);
   }

   private void h() {
      dwu var1 = this.i.s.e;
      var1.a((oj)(new ta(this.i.s, ta.a.c)));
   }
}
