import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.Map.Entry;
import java.util.function.Consumer;
import javax.annotation.Nullable;

public class cm {
   public static final cm a = new cm(ImmutableList.of());
   private final List<cm.c> b;

   private static cm.c a(String var0, JsonElement var1) {
      if (var1.isJsonPrimitive()) {
         String var5 = var1.getAsString();
         return new cm.b(var0, var5);
      } else {
         JsonObject var2 = afd.m(var1, "value");
         String var3 = var2.has("min") ? b(var2.get("min")) : null;
         String var4 = var2.has("max") ? b(var2.get("max")) : null;
         return (cm.c)(var3 != null && var3.equals(var4) ? new cm.b(var0, var3) : new cm.d(var0, var3, var4));
      }
   }

   @Nullable
   private static String b(JsonElement var0) {
      return var0.isJsonNull() ? null : var0.getAsString();
   }

   private cm(List<cm.c> var1) {
      this.b = ImmutableList.copyOf(var1);
   }

   public <S extends cej<?, S>> boolean a(cei<?, S> var1, S var2) {
      Iterator var3 = this.b.iterator();

      cm.c var4;
      do {
         if (!var3.hasNext()) {
            return true;
         }

         var4 = (cm.c)var3.next();
      } while(var4.a(var1, var2));

      return false;
   }

   public boolean a(ceh var1) {
      return this.a((cei)var1.b().m(), (cej)var1);
   }

   public boolean a(cux var1) {
      return this.a((cei)var1.a().g(), (cej)var1);
   }

   public void a(cei<?, ?> var1, Consumer<String> var2) {
      this.b.forEach((var2x) -> {
         var2x.a(var1, var2);
      });
   }

   public static cm a(@Nullable JsonElement var0) {
      if (var0 != null && !var0.isJsonNull()) {
         JsonObject var1 = afd.m(var0, "properties");
         List<cm.c> var2 = Lists.newArrayList();
         Iterator var3 = var1.entrySet().iterator();

         while(var3.hasNext()) {
            Entry<String, JsonElement> var4 = (Entry)var3.next();
            var2.add(a((String)var4.getKey(), (JsonElement)var4.getValue()));
         }

         return new cm(var2);
      } else {
         return a;
      }
   }

   public JsonElement a() {
      if (this == a) {
         return JsonNull.INSTANCE;
      } else {
         JsonObject var1 = new JsonObject();
         if (!this.b.isEmpty()) {
            this.b.forEach((var1x) -> {
               var1.add(var1x.b(), var1x.a());
            });
         }

         return var1;
      }
   }

   // $FF: synthetic method
   cm(List var1, Object var2) {
      this(var1);
   }

   public static class a {
      private final List<cm.c> a = Lists.newArrayList();

      private a() {
      }

      public static cm.a a() {
         return new cm.a();
      }

      public cm.a a(cfj<?> var1, String var2) {
         this.a.add(new cm.b(var1.f(), var2));
         return this;
      }

      public cm.a a(cfj<Integer> var1, int var2) {
         return this.a(var1, Integer.toString(var2));
      }

      public cm.a a(cfj<Boolean> var1, boolean var2) {
         return this.a(var1, Boolean.toString(var2));
      }

      public <T extends Comparable<T> & afs> cm.a a(cfj<T> var1, T var2) {
         return this.a(var1, ((afs)var2).a());
      }

      public cm b() {
         return new cm(this.a);
      }
   }

   static class d extends cm.c {
      @Nullable
      private final String a;
      @Nullable
      private final String b;

      public d(String var1, @Nullable String var2, @Nullable String var3) {
         super(var1);
         this.a = var2;
         this.b = var3;
      }

      protected <T extends Comparable<T>> boolean a(cej<?, ?> var1, cfj<T> var2) {
         T var3 = var1.c(var2);
         Optional var4;
         if (this.a != null) {
            var4 = var2.b(this.a);
            if (!var4.isPresent() || var3.compareTo(var4.get()) < 0) {
               return false;
            }
         }

         if (this.b != null) {
            var4 = var2.b(this.b);
            if (!var4.isPresent() || var3.compareTo(var4.get()) > 0) {
               return false;
            }
         }

         return true;
      }

      public JsonElement a() {
         JsonObject var1 = new JsonObject();
         if (this.a != null) {
            var1.addProperty("min", this.a);
         }

         if (this.b != null) {
            var1.addProperty("max", this.b);
         }

         return var1;
      }
   }

   static class b extends cm.c {
      private final String a;

      public b(String var1, String var2) {
         super(var1);
         this.a = var2;
      }

      protected <T extends Comparable<T>> boolean a(cej<?, ?> var1, cfj<T> var2) {
         T var3 = var1.c(var2);
         Optional<T> var4 = var2.b(this.a);
         return var4.isPresent() && var3.compareTo(var4.get()) == 0;
      }

      public JsonElement a() {
         return new JsonPrimitive(this.a);
      }
   }

   abstract static class c {
      private final String a;

      public c(String var1) {
         this.a = var1;
      }

      public <S extends cej<?, S>> boolean a(cei<?, S> var1, S var2) {
         cfj<?> var3 = var1.a(this.a);
         return var3 == null ? false : this.a(var2, var3);
      }

      protected abstract <T extends Comparable<T>> boolean a(cej<?, ?> var1, cfj<T> var2);

      public abstract JsonElement a();

      public String b() {
         return this.a;
      }

      public void a(cei<?, ?> var1, Consumer<String> var2) {
         cfj<?> var3 = var1.a(this.a);
         if (var3 == null) {
            var2.accept(this.a);
         }

      }
   }
}
