public class bqo extends bps {
   protected bqo(bps.a var1, aqf... var2) {
      super(var1, bpt.g, var2);
   }

   public int a(int var1) {
      return 15;
   }

   public int b(int var1) {
      return super.a(var1) + 50;
   }

   public int a() {
      return 1;
   }

   public boolean a(bps var1) {
      return super.a(var1) && var1 != bpw.w;
   }
}
