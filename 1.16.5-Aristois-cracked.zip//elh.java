import java.util.Collection;

public class elh {
   public static final eli a = new eli();
   private final Collection<eky> b;

   public elh(Collection<eky> var1) {
      this.b = var1;
   }

   public Collection<eky> a() {
      return this.b;
   }
}
