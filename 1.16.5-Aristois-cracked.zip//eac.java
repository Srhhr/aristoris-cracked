import com.google.common.base.MoreObjects;

public class eac {
   private static final eao a = eao.p(new vk("textures/map/map_background.png"));
   private static final eao b = eao.p(new vk("textures/map/map_background_checkerboard.png"));
   private final djz c;
   private bmb d;
   private bmb e;
   private float f;
   private float g;
   private float h;
   private float i;
   private final eet j;
   private final efo k;

   public eac(djz var1) {
      this.d = bmb.b;
      this.e = bmb.b;
      this.c = var1;
      this.j = var1.ac();
      this.k = var1.ad();
   }

   public void a(aqm var1, bmb var2, ebm.b var3, boolean var4, dfm var5, eag var6, int var7) {
      if (!var2.a()) {
         this.k.a(var1, var2, var3, var4, var5, var6, var1.l, var7, ejw.a);
      }
   }

   private float a(float var1) {
      float var2 = 1.0F - var1 / 45.0F + 0.1F;
      var2 = afm.a(var2, 0.0F, 1.0F);
      var2 = -afm.b(var2 * 3.1415927F) * 0.5F + 0.5F;
      return var2;
   }

   private void a(dfm var1, eag var2, int var3, aqi var4) {
      this.c.M().a(this.c.s.o());
      ejk var5 = (ejk)this.j.a((aqa)this.c.s);
      var1.a();
      float var6 = var4 == aqi.b ? 1.0F : -1.0F;
      var1.a(g.d.a(92.0F));
      var1.a(g.b.a(45.0F));
      var1.a(g.f.a(var6 * -41.0F));
      var1.a((double)(var6 * 0.3F), -1.100000023841858D, 0.44999998807907104D);
      if (var4 == aqi.b) {
         var5.a(var1, var2, var3, this.c.s);
      } else {
         var5.b(var1, var2, var3, this.c.s);
      }

      var1.b();
   }

   private void a(dfm var1, eag var2, int var3, float var4, aqi var5, float var6, bmb var7) {
      float var8 = var5 == aqi.b ? 1.0F : -1.0F;
      var1.a((double)(var8 * 0.125F), -0.125D, 0.0D);
      if (!this.c.s.bF()) {
         var1.a();
         var1.a(g.f.a(var8 * 10.0F));
         this.a(var1, var2, var3, var4, var6, var5);
         var1.b();
      }

      var1.a();
      var1.a((double)(var8 * 0.51F), (double)(-0.08F + var4 * -1.2F), -0.75D);
      float var9 = afm.c(var6);
      float var10 = afm.a(var9 * 3.1415927F);
      float var11 = -0.5F * var10;
      float var12 = 0.4F * afm.a(var9 * 6.2831855F);
      float var13 = -0.3F * afm.a(var6 * 3.1415927F);
      var1.a((double)(var8 * var11), (double)(var12 - 0.3F * var10), (double)var13);
      var1.a(g.b.a(var10 * -45.0F));
      var1.a(g.d.a(var8 * var10 * -30.0F));
      this.a(var1, var2, var3, var7);
      var1.b();
   }

   private void a(dfm var1, eag var2, int var3, float var4, float var5, float var6) {
      float var7 = afm.c(var6);
      float var8 = -0.2F * afm.a(var6 * 3.1415927F);
      float var9 = -0.4F * afm.a(var7 * 3.1415927F);
      var1.a(0.0D, (double)(-var8 / 2.0F), (double)var9);
      float var10 = this.a(var4);
      var1.a(0.0D, (double)(0.04F + var5 * -1.2F + var10 * -0.5F), -0.7200000286102295D);
      var1.a(g.b.a(var10 * -85.0F));
      if (!this.c.s.bF()) {
         var1.a();
         var1.a(g.d.a(90.0F));
         this.a(var1, var2, var3, aqi.b);
         this.a(var1, var2, var3, aqi.a);
         var1.b();
      }

      float var11 = afm.a(var7 * 3.1415927F);
      var1.a(g.b.a(var11 * 20.0F));
      var1.a(2.0F, 2.0F, 2.0F);
      this.a(var1, var2, var3, this.d);
   }

   private void a(dfm var1, eag var2, int var3, bmb var4) {
      var1.a(g.d.a(180.0F));
      var1.a(g.f.a(180.0F));
      var1.a(0.38F, 0.38F, 0.38F);
      var1.a(-0.5D, -0.5D, 0.0D);
      var1.a(0.0078125F, 0.0078125F, 0.0078125F);
      cxx var5 = bmh.b(var4, this.c.r);
      dfq var6 = var2.getBuffer(var5 == null ? a : b);
      b var7 = var1.c().a();
      var6.a(var7, -7.0F, 135.0F, 0.0F).a(255, 255, 255, 255).a(0.0F, 1.0F).a(var3).d();
      var6.a(var7, 135.0F, 135.0F, 0.0F).a(255, 255, 255, 255).a(1.0F, 1.0F).a(var3).d();
      var6.a(var7, 135.0F, -7.0F, 0.0F).a(255, 255, 255, 255).a(1.0F, 0.0F).a(var3).d();
      var6.a(var7, -7.0F, -7.0F, 0.0F).a(255, 255, 255, 255).a(0.0F, 0.0F).a(var3).d();
      if (var5 != null) {
         this.c.h.h().a(var1, var2, var5, false, var3);
      }

   }

   private void a(dfm var1, eag var2, int var3, float var4, float var5, aqi var6) {
      boolean var7 = var6 != aqi.a;
      float var8 = var7 ? 1.0F : -1.0F;
      float var9 = afm.c(var5);
      float var10 = -0.3F * afm.a(var9 * 3.1415927F);
      float var11 = 0.4F * afm.a(var9 * 6.2831855F);
      float var12 = -0.4F * afm.a(var5 * 3.1415927F);
      var1.a((double)(var8 * (var10 + 0.64000005F)), (double)(var11 + -0.6F + var4 * -0.6F), (double)(var12 + -0.71999997F));
      var1.a(g.d.a(var8 * 45.0F));
      float var13 = afm.a(var5 * var5 * 3.1415927F);
      float var14 = afm.a(var9 * 3.1415927F);
      var1.a(g.d.a(var8 * var14 * 70.0F));
      var1.a(g.f.a(var8 * var13 * -20.0F));
      dzj var15 = this.c.s;
      this.c.M().a(var15.o());
      var1.a((double)(var8 * -1.0F), 3.5999999046325684D, 3.5D);
      var1.a(g.f.a(var8 * 120.0F));
      var1.a(g.b.a(200.0F));
      var1.a(g.d.a(var8 * -135.0F));
      var1.a((double)(var8 * 5.6F), 0.0D, 0.0D);
      ejk var16 = (ejk)this.j.a((aqa)var15);
      if (var7) {
         var16.a(var1, var2, var3, var15);
      } else {
         var16.b(var1, var2, var3, var15);
      }

   }

   private void a(dfm var1, float var2, aqi var3, bmb var4) {
      float var5 = (float)this.c.s.dZ() - var2 + 1.0F;
      float var6 = var5 / (float)var4.k();
      float var7;
      if (var6 < 0.8F) {
         var7 = afm.e(afm.b(var5 / 4.0F * 3.1415927F) * 0.1F);
         var1.a(0.0D, (double)var7, 0.0D);
      }

      var7 = 1.0F - (float)Math.pow((double)var6, 27.0D);
      int var8 = var3 == aqi.b ? 1 : -1;
      var1.a((double)(var7 * 0.6F * (float)var8), (double)(var7 * -0.5F), (double)(var7 * 0.0F));
      var1.a(g.d.a((float)var8 * var7 * 90.0F));
      var1.a(g.b.a(var7 * 10.0F));
      var1.a(g.f.a((float)var8 * var7 * 30.0F));
   }

   private void a(dfm var1, aqi var2, float var3) {
      int var4 = var2 == aqi.b ? 1 : -1;
      float var5 = afm.a(var3 * var3 * 3.1415927F);
      var1.a(g.d.a((float)var4 * (45.0F + var5 * -20.0F)));
      float var6 = afm.a(afm.c(var3) * 3.1415927F);
      var1.a(g.f.a((float)var4 * var6 * -20.0F));
      var1.a(g.b.a(var6 * -80.0F));
      var1.a(g.d.a((float)var4 * -45.0F));
   }

   private void b(dfm var1, aqi var2, float var3) {
      int var4 = var2 == aqi.b ? 1 : -1;
      var1.a((double)((float)var4 * 0.56F), (double)(-0.52F + var3 * -0.6F), -0.7200000286102295D);
   }

   public void a(float var1, dfm var2, eag.a var3, dzm var4, int var5) {
      float var6 = var4.r(var1);
      aot var7 = (aot)MoreObjects.firstNonNull(var4.aj, aot.a);
      float var8 = afm.g(var1, var4.s, var4.q);
      boolean var9 = true;
      boolean var10 = true;
      bmb var11;
      if (var4.dW()) {
         var11 = var4.dY();
         if (var11.b() == bmd.kc || var11.b() == bmd.qQ) {
            var9 = var4.dX() == aot.a;
            var10 = !var9;
         }

         aot var12 = var4.dX();
         if (var12 == aot.a) {
            bmb var13 = var4.dE();
            if (var13.b() == bmd.qQ && bkt.d(var13)) {
               var10 = false;
            }
         }
      } else {
         var11 = var4.dD();
         bmb var16 = var4.dE();
         if (var11.b() == bmd.qQ && bkt.d(var11)) {
            var10 = !var9;
         }

         if (var16.b() == bmd.qQ && bkt.d(var16)) {
            var9 = !var11.a();
            var10 = !var9;
         }
      }

      float var15 = afm.g(var1, var4.bO, var4.bM);
      float var17 = afm.g(var1, var4.bN, var4.bL);
      var2.a(g.b.a((var4.g(var1) - var15) * 0.1F));
      var2.a(g.d.a((var4.h(var1) - var17) * 0.1F));
      float var14;
      float var18;
      if (var9) {
         var18 = var7 == aot.a ? var6 : 0.0F;
         var14 = 1.0F - afm.g(var1, this.g, this.f);
         this.a(var4, var1, var8, aot.a, var18, this.d, var14, var2, var3, var5);
      }

      if (var10) {
         var18 = var7 == aot.b ? var6 : 0.0F;
         var14 = 1.0F - afm.g(var1, this.i, this.h);
         this.a(var4, var1, var8, aot.b, var18, this.e, var14, var2, var3, var5);
      }

      var3.a();
   }

   private void a(dzj var1, float var2, float var3, aot var4, float var5, bmb var6, float var7, dfm var8, eag var9, int var10) {
      boolean var11 = var4 == aot.a;
      aqi var12 = var11 ? var1.dV() : var1.dV().a();
      var8.a();
      if (var6.a()) {
         if (var11 && !var1.bF()) {
            this.a(var8, var9, var10, var7, var5, var12);
         }
      } else if (var6.b() == bmd.nf) {
         if (var11 && this.e.a()) {
            this.a(var8, var9, var10, var3, var7, var5);
         } else {
            this.a(var8, var9, var10, var7, var12, var5, var6);
         }
      } else {
         boolean var13;
         float var16;
         float var17;
         float var18;
         float var19;
         if (var6.b() == bmd.qQ) {
            var13 = bkt.d(var6);
            boolean var14 = var12 == aqi.b;
            int var15 = var14 ? 1 : -1;
            if (var1.dW() && var1.dZ() > 0 && var1.dX() == var4) {
               this.b(var8, var12, var7);
               var8.a((double)((float)var15 * -0.4785682F), -0.0943870022892952D, 0.05731530860066414D);
               var8.a(g.b.a(-11.935F));
               var8.a(g.d.a((float)var15 * 65.3F));
               var8.a(g.f.a((float)var15 * -9.785F));
               var16 = (float)var6.k() - ((float)this.c.s.dZ() - var2 + 1.0F);
               var17 = var16 / (float)bkt.g(var6);
               if (var17 > 1.0F) {
                  var17 = 1.0F;
               }

               if (var17 > 0.1F) {
                  var18 = afm.a((var16 - 0.1F) * 1.3F);
                  var19 = var17 - 0.1F;
                  float var20 = var18 * var19;
                  var8.a((double)(var20 * 0.0F), (double)(var20 * 0.004F), (double)(var20 * 0.0F));
               }

               var8.a((double)(var17 * 0.0F), (double)(var17 * 0.0F), (double)(var17 * 0.04F));
               var8.a(1.0F, 1.0F, 1.0F + var17 * 0.2F);
               var8.a(g.c.a((float)var15 * 45.0F));
            } else {
               var16 = -0.4F * afm.a(afm.c(var5) * 3.1415927F);
               var17 = 0.2F * afm.a(afm.c(var5) * 6.2831855F);
               var18 = -0.2F * afm.a(var5 * 3.1415927F);
               var8.a((double)((float)var15 * var16), (double)var17, (double)var18);
               this.b(var8, var12, var7);
               this.a(var8, var12, var5);
               if (var13 && var5 < 0.001F) {
                  var8.a((double)((float)var15 * -0.641864F), 0.0D, 0.0D);
                  var8.a(g.d.a((float)var15 * 10.0F));
               }
            }

            this.a(var1, var6, var14 ? ebm.b.e : ebm.b.d, !var14, var8, var9, var10);
         } else {
            var13 = var12 == aqi.b;
            int var21;
            float var23;
            if (var1.dW() && var1.dZ() > 0 && var1.dX() == var4) {
               var21 = var13 ? 1 : -1;
               switch(var6.l()) {
               case a:
                  this.b(var8, var12, var7);
                  break;
               case b:
               case c:
                  this.a(var8, var2, var12, var6);
                  this.b(var8, var12, var7);
                  break;
               case d:
                  this.b(var8, var12, var7);
                  break;
               case e:
                  this.b(var8, var12, var7);
                  var8.a((double)((float)var21 * -0.2785682F), 0.18344387412071228D, 0.15731531381607056D);
                  var8.a(g.b.a(-13.935F));
                  var8.a(g.d.a((float)var21 * 35.3F));
                  var8.a(g.f.a((float)var21 * -9.785F));
                  var23 = (float)var6.k() - ((float)this.c.s.dZ() - var2 + 1.0F);
                  var16 = var23 / 20.0F;
                  var16 = (var16 * var16 + var16 * 2.0F) / 3.0F;
                  if (var16 > 1.0F) {
                     var16 = 1.0F;
                  }

                  if (var16 > 0.1F) {
                     var17 = afm.a((var23 - 0.1F) * 1.3F);
                     var18 = var16 - 0.1F;
                     var19 = var17 * var18;
                     var8.a((double)(var19 * 0.0F), (double)(var19 * 0.004F), (double)(var19 * 0.0F));
                  }

                  var8.a((double)(var16 * 0.0F), (double)(var16 * 0.0F), (double)(var16 * 0.04F));
                  var8.a(1.0F, 1.0F, 1.0F + var16 * 0.2F);
                  var8.a(g.c.a((float)var21 * 45.0F));
                  break;
               case f:
                  this.b(var8, var12, var7);
                  var8.a((double)((float)var21 * -0.5F), 0.699999988079071D, 0.10000000149011612D);
                  var8.a(g.b.a(-55.0F));
                  var8.a(g.d.a((float)var21 * 35.3F));
                  var8.a(g.f.a((float)var21 * -9.785F));
                  var23 = (float)var6.k() - ((float)this.c.s.dZ() - var2 + 1.0F);
                  var16 = var23 / 10.0F;
                  if (var16 > 1.0F) {
                     var16 = 1.0F;
                  }

                  if (var16 > 0.1F) {
                     var17 = afm.a((var23 - 0.1F) * 1.3F);
                     var18 = var16 - 0.1F;
                     var19 = var17 * var18;
                     var8.a((double)(var19 * 0.0F), (double)(var19 * 0.004F), (double)(var19 * 0.0F));
                  }

                  var8.a(0.0D, 0.0D, (double)(var16 * 0.2F));
                  var8.a(1.0F, 1.0F, 1.0F + var16 * 0.2F);
                  var8.a(g.c.a((float)var21 * 45.0F));
               }
            } else if (var1.dR()) {
               this.b(var8, var12, var7);
               var21 = var13 ? 1 : -1;
               var8.a((double)((float)var21 * -0.4F), 0.800000011920929D, 0.30000001192092896D);
               var8.a(g.d.a((float)var21 * 65.0F));
               var8.a(g.f.a((float)var21 * -85.0F));
            } else {
               float var22 = -0.4F * afm.a(afm.c(var5) * 3.1415927F);
               var23 = 0.2F * afm.a(afm.c(var5) * 6.2831855F);
               var16 = -0.2F * afm.a(var5 * 3.1415927F);
               int var24 = var13 ? 1 : -1;
               var8.a((double)((float)var24 * var22), (double)var23, (double)var16);
               this.b(var8, var12, var7);
               this.a(var8, var12, var5);
            }

            this.a(var1, var6, var13 ? ebm.b.e : ebm.b.d, !var13, var8, var9, var10);
         }
      }

      var8.b();
   }

   public void a() {
      this.g = this.f;
      this.i = this.h;
      dzm var1 = this.c.s;
      bmb var2 = var1.dD();
      bmb var3 = var1.dE();
      if (bmb.b(this.d, var2)) {
         this.d = var2;
      }

      if (bmb.b(this.e, var3)) {
         this.e = var3;
      }

      if (var1.L()) {
         this.f = afm.a(this.f - 0.4F, 0.0F, 1.0F);
         this.h = afm.a(this.h - 0.4F, 0.0F, 1.0F);
      } else {
         float var4 = var1.u(1.0F);
         this.f += afm.a((this.d == var2 ? var4 * var4 * var4 : 0.0F) - this.f, -0.4F, 0.4F);
         this.h += afm.a((float)(this.e == var3 ? 1 : 0) - this.h, -0.4F, 0.4F);
      }

      if (this.f < 0.1F) {
         this.d = var2;
      }

      if (this.h < 0.1F) {
         this.e = var3;
      }

   }

   public void a(aot var1) {
      if (var1 == aot.a) {
         this.f = 0.0F;
      } else {
         this.h = 0.0F;
      }

   }
}
