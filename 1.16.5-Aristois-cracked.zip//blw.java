public class blw extends blx {
   private final int a;
   private final String b;

   public blw(int var1, String var2, blx.a var3) {
      super(var3);
      this.a = var1;
      this.b = "textures/entity/horse/armor/horse_armor_" + var2 + ".png";
   }

   public vk f() {
      return new vk(this.b);
   }

   public int g() {
      return this.a;
   }
}
