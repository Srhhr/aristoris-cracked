import com.google.common.collect.Lists;
import com.google.common.collect.Queues;
import com.google.common.collect.Sets;
import com.google.common.primitives.Doubles;
import it.unimi.dsi.fastutil.objects.ObjectArraySet;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.annotation.Nullable;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ecu {
   private static final Logger a = LogManager.getLogger();
   private final PriorityQueue<ecu.c.a> b = Queues.newPriorityQueue();
   private final Queue<dzt> c;
   private final Queue<Runnable> d = Queues.newConcurrentLinkedQueue();
   private volatile int e;
   private volatile int f;
   private final dzt g;
   private final aoe<Runnable> h;
   private final Executor i;
   private brx j;
   private final eae k;
   private dcn l;

   public ecu(brx var1, eae var2, Executor var3, boolean var4, dzt var5) {
      this.l = dcn.a;
      this.j = var1;
      this.k = var2;
      int var6 = Math.max(1, (int)((double)Runtime.getRuntime().maxMemory() * 0.3D) / (eao.u().stream().mapToInt(eao::v).sum() * 4) - 1);
      int var7 = Runtime.getRuntime().availableProcessors();
      int var8 = var4 ? var7 : Math.min(var7, 4);
      int var9 = Math.max(1, Math.min(var8, var6));
      this.g = var5;
      ArrayList var10 = Lists.newArrayListWithExpectedSize(var9);

      try {
         for(int var11 = 0; var11 < var9; ++var11) {
            var10.add(new dzt());
         }
      } catch (OutOfMemoryError var14) {
         a.warn("Allocated only {}/{} buffers", var10.size(), var9);
         int var12 = Math.min(var10.size() * 2 / 3, var10.size() - 1);

         for(int var13 = 0; var13 < var12; ++var13) {
            var10.remove(var10.size() - 1);
         }

         System.gc();
      }

      this.c = Queues.newArrayDeque(var10);
      this.f = this.c.size();
      this.i = var3;
      this.h = aoe.a(var3, "Chunk Renderer");
      this.h.a((Object)(this::h));
   }

   public void a(brx var1) {
      this.j = var1;
   }

   private void h() {
      if (!this.c.isEmpty()) {
         ecu.c.a var1 = (ecu.c.a)this.b.poll();
         if (var1 != null) {
            dzt var2 = (dzt)this.c.poll();
            this.e = this.b.size();
            this.f = this.c.size();
            CompletableFuture.runAsync(() -> {
            }, this.i).thenCompose((var2x) -> {
               return var1.a(var2);
            }).whenComplete((var2x, var3) -> {
               if (var3 != null) {
                  l var4 = l.a(var3, "Batching chunks");
                  djz.C().a(djz.C().c(var4));
               } else {
                  this.h.a((Object)(() -> {
                     if (var2x == ecu.a.a) {
                        var2.a();
                     } else {
                        var2.b();
                     }

                     this.c.add(var2);
                     this.f = this.c.size();
                     this.h();
                  }));
               }
            });
         }
      }
   }

   public String b() {
      return String.format("pC: %03d, pU: %02d, aB: %02d", this.e, this.d.size(), this.f);
   }

   public void a(dcn var1) {
      this.l = var1;
   }

   public dcn c() {
      return this.l;
   }

   public boolean d() {
      boolean var1;
      Runnable var2;
      for(var1 = false; (var2 = (Runnable)this.d.poll()) != null; var1 = true) {
         var2.run();
      }

      return var1;
   }

   public void a(ecu.c var1) {
      var1.k();
   }

   public void e() {
      this.i();
   }

   public void a(ecu.c.a var1) {
      this.h.a((Object)(() -> {
         this.b.offer(var1);
         this.e = this.b.size();
         this.h();
      }));
   }

   public CompletableFuture<Void> a(dfh var1, dfp var2) {
      Runnable var10000 = () -> {
      };
      Queue var10001 = this.d;
      var10001.getClass();
      return CompletableFuture.runAsync(var10000, var10001::add).thenCompose((var3) -> {
         return this.b(var1, var2);
      });
   }

   private CompletableFuture<Void> b(dfh var1, dfp var2) {
      return var2.b(var1);
   }

   private void i() {
      while(!this.b.isEmpty()) {
         ecu.c.a var1 = (ecu.c.a)this.b.poll();
         if (var1 != null) {
            var1.a();
         }
      }

      this.e = 0;
   }

   public boolean f() {
      return this.e == 0 && this.d.isEmpty();
   }

   public void g() {
      this.i();
      this.h.close();
      this.c.clear();
   }

   public static class b {
      public static final ecu.b a = new ecu.b() {
         public boolean a(gc var1, gc var2) {
            return false;
         }
      };
      private final Set<eao> b = new ObjectArraySet();
      private final Set<eao> c = new ObjectArraySet();
      private boolean d = true;
      private final List<ccj> e = Lists.newArrayList();
      private ecx f = new ecx();
      @Nullable
      private dfh.b g;

      public boolean a() {
         return this.d;
      }

      public boolean a(eao var1) {
         return !this.b.contains(var1);
      }

      public List<ccj> b() {
         return this.e;
      }

      public boolean a(gc var1, gc var2) {
         return this.f.a(var1, var2);
      }
   }

   static enum a {
      a,
      b;
   }

   public class c {
      public final AtomicReference<ecu.b> a;
      @Nullable
      private ecu.c.b d;
      @Nullable
      private ecu.c.c e;
      private final Set<ccj> f;
      private final Map<eao, dfp> g;
      public dci b;
      private int h;
      private boolean i;
      private final fx.a j;
      private final fx.a[] k;
      private boolean l;

      public c() {
         this.a = new AtomicReference(ecu.b.a);
         this.f = Sets.newHashSet();
         this.g = (Map)eao.u().stream().collect(Collectors.toMap((var0) -> {
            return var0;
         }, (var0) -> {
            return new dfp(dfk.h);
         }));
         this.h = -1;
         this.i = true;
         this.j = new fx.a(-1, -1, -1);
         this.k = (fx.a[])x.a((Object)(new fx.a[6]), (Consumer)((var0) -> {
            for(int var1 = 0; var1 < var0.length; ++var1) {
               var0[var1] = new fx.a();
            }

         }));
      }

      private boolean a(fx var1) {
         return ecu.this.j.a(var1.u() >> 4, var1.w() >> 4, cga.m, false) != null;
      }

      public boolean a() {
         int var1 = true;
         if (!(this.b() > 576.0D)) {
            return true;
         } else {
            return this.a((fx)this.k[gc.e.ordinal()]) && this.a((fx)this.k[gc.c.ordinal()]) && this.a((fx)this.k[gc.f.ordinal()]) && this.a((fx)this.k[gc.d.ordinal()]);
         }
      }

      public boolean a(int var1) {
         if (this.h == var1) {
            return false;
         } else {
            this.h = var1;
            return true;
         }
      }

      public dfp a(eao var1) {
         return (dfp)this.g.get(var1);
      }

      public void a(int var1, int var2, int var3) {
         if (var1 != this.j.u() || var2 != this.j.v() || var3 != this.j.w()) {
            this.l();
            this.j.d(var1, var2, var3);
            this.b = new dci((double)var1, (double)var2, (double)var3, (double)(var1 + 16), (double)(var2 + 16), (double)(var3 + 16));
            gc[] var4 = gc.values();
            int var5 = var4.length;

            for(int var6 = 0; var6 < var5; ++var6) {
               gc var7 = var4[var6];
               this.k[var7.ordinal()].g(this.j).c(var7, 16);
            }

         }
      }

      protected double b() {
         djk var1 = djz.C().h.k();
         double var2 = this.b.a + 8.0D - var1.b().b;
         double var4 = this.b.b + 8.0D - var1.b().c;
         double var6 = this.b.c + 8.0D - var1.b().d;
         return var2 * var2 + var4 * var4 + var6 * var6;
      }

      private void a(dfh var1) {
         var1.a(7, dfk.h);
      }

      public ecu.b c() {
         return (ecu.b)this.a.get();
      }

      private void l() {
         this.i();
         this.a.set(ecu.b.a);
         this.i = true;
      }

      public void d() {
         this.l();
         this.g.values().forEach(dfp::close);
      }

      public fx e() {
         return this.j;
      }

      public void a(boolean var1) {
         boolean var2 = this.i;
         this.i = true;
         this.l = var1 | (var2 && this.l);
      }

      public void f() {
         this.i = false;
         this.l = false;
      }

      public boolean g() {
         return this.i;
      }

      public boolean h() {
         return this.i && this.l;
      }

      public fx a(gc var1) {
         return this.k[var1.ordinal()];
      }

      public boolean a(eao var1, ecu var2) {
         ecu.b var3 = this.c();
         if (this.e != null) {
            this.e.a();
         }

         if (!var3.c.contains(var1)) {
            return false;
         } else {
            this.e = new ecu.c.c(this.b(), var3);
            var2.a((ecu.c.a)this.e);
            return true;
         }
      }

      protected void i() {
         if (this.d != null) {
            this.d.a();
            this.d = null;
         }

         if (this.e != null) {
            this.e.a();
            this.e = null;
         }

      }

      public ecu.c.a j() {
         this.i();
         fx var1 = this.j.h();
         int var2 = true;
         ecv var3 = ecv.a(ecu.this.j, var1.b(-1, -1, -1), var1.b(16, 16, 16), 1);
         this.d = new ecu.c.b(this.b(), var3);
         return this.d;
      }

      public void a(ecu var1) {
         ecu.c.a var2 = this.j();
         var1.a(var2);
      }

      private void a(Set<ccj> var1) {
         Set<ccj> var2 = Sets.newHashSet(var1);
         Set<ccj> var3 = Sets.newHashSet(this.f);
         var2.removeAll(this.f);
         var3.removeAll(var1);
         this.f.clear();
         this.f.addAll(var1);
         ecu.this.k.a((Collection)var3, (Collection)var2);
      }

      public void k() {
         ecu.c.a var1 = this.j();
         var1.a(ecu.this.g);
      }

      abstract class a implements Comparable<ecu.c.a> {
         protected final double a;
         protected final AtomicBoolean b = new AtomicBoolean(false);

         public a(double var2) {
            this.a = var2;
         }

         public abstract CompletableFuture<ecu.a> a(dzt var1);

         public abstract void a();

         public int a(ecu.c.a var1) {
            return Doubles.compare(this.a, var1.a);
         }

         // $FF: synthetic method
         public int compareTo(Object var1) {
            return this.a((ecu.c.a)var1);
         }
      }

      class c extends ecu.c.a {
         private final ecu.b e;

         public c(double var2, ecu.b var4) {
            super(var2);
            this.e = var4;
         }

         public CompletableFuture<ecu.a> a(dzt var1) {
            if (this.b.get()) {
               return CompletableFuture.completedFuture(ecu.a.b);
            } else if (!c.this.a()) {
               this.b.set(true);
               return CompletableFuture.completedFuture(ecu.a.b);
            } else if (this.b.get()) {
               return CompletableFuture.completedFuture(ecu.a.b);
            } else {
               dcn var2 = ecu.this.c();
               float var3 = (float)var2.b;
               float var4 = (float)var2.c;
               float var5 = (float)var2.d;
               dfh.b var6 = this.e.g;
               if (var6 != null && this.e.b.contains(eao.f())) {
                  dfh var7 = var1.a(eao.f());
                  c.this.a(var7);
                  var7.a(var6);
                  var7.a(var3 - (float)c.this.j.u(), var4 - (float)c.this.j.v(), var5 - (float)c.this.j.w());
                  this.e.g = var7.b();
                  var7.c();
                  if (this.b.get()) {
                     return CompletableFuture.completedFuture(ecu.a.b);
                  } else {
                     CompletableFuture<ecu.a> var8 = ecu.this.a(var1.a(eao.f()), c.this.a(eao.f())).thenApply((var0) -> {
                        return ecu.a.b;
                     });
                     return var8.handle((var1x, var2x) -> {
                        if (var2x != null && !(var2x instanceof CancellationException) && !(var2x instanceof InterruptedException)) {
                           djz.C().a(l.a(var2x, "Rendering chunk"));
                        }

                        return this.b.get() ? ecu.a.b : ecu.a.a;
                     });
                  }
               } else {
                  return CompletableFuture.completedFuture(ecu.a.b);
               }
            }
         }

         public void a() {
            this.b.set(true);
         }
      }

      class b extends ecu.c.a {
         @Nullable
         protected ecv d;

         public b(double var2, ecv var4) {
            super(var2);
            this.d = var4;
         }

         public CompletableFuture<ecu.a> a(dzt var1) {
            if (this.b.get()) {
               return CompletableFuture.completedFuture(ecu.a.b);
            } else if (!c.this.a()) {
               this.d = null;
               c.this.a(false);
               this.b.set(true);
               return CompletableFuture.completedFuture(ecu.a.b);
            } else if (this.b.get()) {
               return CompletableFuture.completedFuture(ecu.a.b);
            } else {
               dcn var2 = ecu.this.c();
               float var3 = (float)var2.b;
               float var4 = (float)var2.c;
               float var5 = (float)var2.d;
               ecu.b var6 = new ecu.b();
               Set<ccj> var7 = this.a(var3, var4, var5, var6, var1);
               c.this.a(var7);
               if (this.b.get()) {
                  return CompletableFuture.completedFuture(ecu.a.b);
               } else {
                  List<CompletableFuture<Void>> var8 = Lists.newArrayList();
                  var6.c.forEach((var3x) -> {
                     var8.add(ecu.this.a(var1.a(var3x), c.this.a(var3x)));
                  });
                  return x.b((List)var8).handle((var2x, var3x) -> {
                     if (var3x != null && !(var3x instanceof CancellationException) && !(var3x instanceof InterruptedException)) {
                        djz.C().a(l.a(var3x, "Rendering chunk"));
                     }

                     if (this.b.get()) {
                        return ecu.a.b;
                     } else {
                        c.this.a.set(var6);
                        return ecu.a.a;
                     }
                  });
               }
            }
         }

         private Set<ccj> a(float var1, float var2, float var3, ecu.b var4, dzt var5) {
            int var6 = true;
            fx var7 = c.this.j.h();
            fx var8 = var7.b(15, 15, 15);
            ecw var9 = new ecw();
            Set<ccj> var10 = Sets.newHashSet();
            ecv var11 = this.d;
            this.d = null;
            dfm var12 = new dfm();
            if (var11 != null) {
               eaz.a();
               Random var13 = new Random();
               eax var14 = djz.C().ab();
               Iterator var15 = fx.a(var7, var8).iterator();

               while(var15.hasNext()) {
                  fx var16 = (fx)var15.next();
                  ceh var17 = var11.d_(var16);
                  buo var18 = var17.b();
                  if (var17.i(var11, var16)) {
                     var9.a(var16);
                  }

                  if (var18.q()) {
                     ccj var19 = var11.a(var16, cgh.a.c);
                     if (var19 != null) {
                        this.a((ecu.b)var4, (Set)var10, (ccj)var19);
                     }
                  }

                  cux var23 = var11.b(var16);
                  eao var20;
                  dfh var21;
                  if (!var23.c()) {
                     var20 = eab.a(var23);
                     var21 = var5.a(var20);
                     if (var4.c.add(var20)) {
                        c.this.a(var21);
                     }

                     if (var14.a(var16, var11, var21, var23)) {
                        var4.d = false;
                        var4.b.add(var20);
                     }
                  }

                  if (var17.h() != bzh.a) {
                     var20 = eab.a(var17);
                     var21 = var5.a(var20);
                     if (var4.c.add(var20)) {
                        c.this.a(var21);
                     }

                     var12.a();
                     var12.a((double)(var16.u() & 15), (double)(var16.v() & 15), (double)(var16.w() & 15));
                     if (var14.a(var17, var16, var11, var12, var21, true, var13)) {
                        var4.d = false;
                        var4.b.add(var20);
                     }

                     var12.b();
                  }
               }

               if (var4.b.contains(eao.f())) {
                  dfh var22 = var5.a(eao.f());
                  var22.a(var1 - (float)var7.u(), var2 - (float)var7.v(), var3 - (float)var7.w());
                  var4.g = var22.b();
               }

               Stream var10000 = var4.c.stream();
               var5.getClass();
               var10000.map(var5::a).forEach(dfh::c);
               eaz.b();
            }

            var4.f = var9.a();
            return var10;
         }

         private <E extends ccj> void a(ecu.b var1, Set<ccj> var2, E var3) {
            ece<E> var4 = ecd.a.a(var3);
            if (var4 != null) {
               var1.e.add(var3);
               if (var4.a(var3)) {
                  var2.add(var3);
               }
            }

         }

         public void a() {
            this.d = null;
            if (this.b.compareAndSet(false, true)) {
               c.this.a(false);
            }

         }
      }
   }
}
