public class ehn extends eeu<bgz> {
   private static final vk a = new vk("textures/entity/wither/wither_invulnerable.png");
   private static final vk e = new vk("textures/entity/wither/wither.png");
   private final dvt f = new dvt();

   public ehn(eet var1) {
      super(var1);
   }

   protected int a(bgz var1, fx var2) {
      return 15;
   }

   public void a(bgz var1, float var2, float var3, dfm var4, eag var5, int var6) {
      var4.a();
      var4.a(-1.0F, -1.0F, 1.0F);
      float var7 = afm.j(var1.r, var1.p, var3);
      float var8 = afm.g(var3, var1.s, var1.q);
      dfq var9 = var5.getBuffer(this.f.a(this.a(var1)));
      this.f.a(0.0F, var7, var8);
      this.f.a(var4, var9, var6, ejw.a, 1.0F, 1.0F, 1.0F, 1.0F);
      var4.b();
      super.a(var1, var2, var3, var4, var5, var6);
   }

   public vk a(bgz var1) {
      return var1.k() ? a : e;
   }
}
