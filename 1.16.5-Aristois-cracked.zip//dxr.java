public class dxr extends dzb {
   private final double a;
   private final double b;
   private final double D;

   private dxr(dwt var1, double var2, double var4, double var6, double var8, double var10, double var12) {
      super(var1, var2, var4, var6);
      this.j = var8;
      this.k = var10;
      this.l = var12;
      this.a = var2;
      this.b = var4;
      this.D = var6;
      this.d = var2 + var8;
      this.e = var4 + var10;
      this.f = var6 + var12;
      this.g = this.d;
      this.h = this.e;
      this.i = this.f;
      this.B = 0.1F * (this.r.nextFloat() * 0.5F + 0.2F);
      float var14 = this.r.nextFloat() * 0.6F + 0.4F;
      this.v = 0.9F * var14;
      this.w = 0.9F * var14;
      this.x = var14;
      this.n = false;
      this.t = (int)(Math.random() * 10.0D) + 30;
   }

   public dyk b() {
      return dyk.b;
   }

   public void a(double var1, double var3, double var5) {
      this.a(this.m().d(var1, var3, var5));
      this.k();
   }

   public int a(float var1) {
      int var2 = super.a(var1);
      float var3 = (float)this.s / (float)this.t;
      var3 *= var3;
      var3 *= var3;
      int var4 = var2 & 255;
      int var5 = var2 >> 16 & 255;
      var5 += (int)(var3 * 15.0F * 16.0F);
      if (var5 > 240) {
         var5 = 240;
      }

      return var4 | var5 << 16;
   }

   public void a() {
      this.d = this.g;
      this.e = this.h;
      this.f = this.i;
      if (this.s++ >= this.t) {
         this.j();
      } else {
         float var1 = (float)this.s / (float)this.t;
         var1 = 1.0F - var1;
         float var2 = 1.0F - var1;
         var2 *= var2;
         var2 *= var2;
         this.g = this.a + this.j * (double)var1;
         this.h = this.b + this.k * (double)var1 - (double)(var2 * 1.2F);
         this.i = this.D + this.l * (double)var1;
      }
   }

   // $FF: synthetic method
   dxr(dwt var1, double var2, double var4, double var6, double var8, double var10, double var12, Object var14) {
      this(var1, var2, var4, var6, var8, var10, var12);
   }

   public static class a implements dyj<hi> {
      private final dyw a;

      public a(dyw var1) {
         this.a = var1;
      }

      public dyg a(hi var1, dwt var2, double var3, double var5, double var7, double var9, double var11, double var13) {
         dxr var15 = new dxr(var2, var3, var5, var7, var9, var11, var13);
         var15.a(this.a);
         return var15;
      }
   }

   public static class b implements dyj<hi> {
      private final dyw a;

      public b(dyw var1) {
         this.a = var1;
      }

      public dyg a(hi var1, dwt var2, double var3, double var5, double var7, double var9, double var11, double var13) {
         dxr var15 = new dxr(var2, var3, var5, var7, var9, var11, var13);
         var15.a(this.a);
         return var15;
      }
   }
}
