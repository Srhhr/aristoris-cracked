import javax.annotation.Nullable;

public abstract class azx extends aqu {
   protected azx(aqe<? extends azx> var1, brx var2) {
      super(var1, var2);
   }

   public boolean b(float var1, float var2) {
      return false;
   }

   @Nullable
   protected adp I() {
      return null;
   }

   @Nullable
   protected adp e(apk var1) {
      return null;
   }

   @Nullable
   protected adp dq() {
      return null;
   }

   public int D() {
      return 120;
   }

   public boolean h(double var1) {
      return false;
   }
}
