import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import it.unimi.dsi.fastutil.objects.Object2IntMap.Entry;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;

public abstract class cbz extends ccd implements ape, bjl, bju, cdm {
   private static final int[] g = new int[]{0};
   private static final int[] h = new int[]{2, 1};
   private static final int[] i = new int[]{1};
   protected gj<bmb> a;
   private int j;
   private int k;
   private int l;
   private int m;
   protected final bil b;
   private final Object2IntOpenHashMap<vk> n;
   protected final bot<? extends boc> c;

   protected cbz(cck<?> var1, bot<? extends boc> var2) {
      super(var1);
      this.a = gj.a(3, bmb.b);
      this.b = new bil() {
         public int a(int var1) {
            switch(var1) {
            case 0:
               return cbz.this.j;
            case 1:
               return cbz.this.k;
            case 2:
               return cbz.this.l;
            case 3:
               return cbz.this.m;
            default:
               return 0;
            }
         }

         public void a(int var1, int var2) {
            switch(var1) {
            case 0:
               cbz.this.j = var2;
               break;
            case 1:
               cbz.this.k = var2;
               break;
            case 2:
               cbz.this.l = var2;
               break;
            case 3:
               cbz.this.m = var2;
            }

         }

         public int a() {
            return 4;
         }
      };
      this.n = new Object2IntOpenHashMap();
      this.c = var2;
   }

   public static Map<blx, Integer> f() {
      Map<blx, Integer> var0 = Maps.newLinkedHashMap();
      a(var0, (brw)bmd.lM, 20000);
      a(var0, (brw)bup.gS, 16000);
      a(var0, (brw)bmd.nr, 2400);
      a(var0, (brw)bmd.ke, 1600);
      a(var0, (brw)bmd.kf, 1600);
      a(var0, (ael)aeg.q, 300);
      a(var0, (ael)aeg.c, 300);
      a(var0, (ael)aeg.i, 300);
      a(var0, (ael)aeg.j, 150);
      a(var0, (ael)aeg.m, 300);
      a(var0, (ael)aeg.l, 300);
      a(var0, (brw)bup.cJ, 300);
      a(var0, (brw)bup.in, 300);
      a(var0, (brw)bup.im, 300);
      a(var0, (brw)bup.io, 300);
      a(var0, (brw)bup.iq, 300);
      a(var0, (brw)bup.ip, 300);
      a(var0, (brw)bup.dQ, 300);
      a(var0, (brw)bup.ii, 300);
      a(var0, (brw)bup.ih, 300);
      a(var0, (brw)bup.ij, 300);
      a(var0, (brw)bup.il, 300);
      a(var0, (brw)bup.ik, 300);
      a(var0, (brw)bup.aw, 300);
      a(var0, (brw)bup.bI, 300);
      a(var0, (brw)bup.lY, 300);
      a(var0, (brw)bup.cI, 300);
      a(var0, (brw)bup.bR, 300);
      a(var0, (brw)bup.fr, 300);
      a(var0, (brw)bup.bV, 300);
      a(var0, (brw)bup.fv, 300);
      a(var0, (ael)aeg.z, 300);
      a(var0, (brw)bmd.kc, 300);
      a(var0, (brw)bmd.mi, 300);
      a(var0, (brw)bup.cg, 300);
      a(var0, (ael)aeg.U, 200);
      a(var0, (brw)bmd.km, 200);
      a(var0, (brw)bmd.kl, 200);
      a(var0, (brw)bmd.kp, 200);
      a(var0, (brw)bmd.ko, 200);
      a(var0, (brw)bmd.kn, 200);
      a(var0, (ael)aeg.h, 200);
      a(var0, (ael)aeg.S, 1200);
      a(var0, (ael)aeg.b, 100);
      a(var0, (ael)aeg.e, 100);
      a(var0, (brw)bmd.kP, 100);
      a(var0, (ael)aeg.o, 100);
      a(var0, (brw)bmd.kQ, 100);
      a(var0, (ael)aeg.g, 67);
      a(var0, (brw)bup.ke, 4001);
      a(var0, (brw)bmd.qQ, 300);
      a(var0, (brw)bup.kY, 50);
      a(var0, (brw)bup.aT, 100);
      a(var0, (brw)bup.lQ, 400);
      a(var0, (brw)bup.lR, 300);
      a(var0, (brw)bup.lS, 300);
      a(var0, (brw)bup.lV, 300);
      a(var0, (brw)bup.lW, 300);
      a(var0, (brw)bup.lZ, 300);
      a(var0, (brw)bup.na, 300);
      return var0;
   }

   private static boolean b(blx var0) {
      return aeg.Q.a(var0);
   }

   private static void a(Map<blx, Integer> var0, ael<blx> var1, int var2) {
      Iterator var3 = var1.b().iterator();

      while(var3.hasNext()) {
         blx var4 = (blx)var3.next();
         if (!b(var4)) {
            var0.put(var4, var2);
         }
      }

   }

   private static void a(Map<blx, Integer> var0, brw var1, int var2) {
      blx var3 = var1.h();
      if (b(var3)) {
         if (w.d) {
            throw (IllegalStateException)x.c((Throwable)(new IllegalStateException("A developer tried to explicitly make fire resistant item " + var3.h((bmb)null).getString() + " a furnace fuel. That will not work!")));
         }
      } else {
         var0.put(var3, var2);
      }
   }

   private boolean j() {
      return this.j > 0;
   }

   public void a(ceh var1, md var2) {
      super.a(var1, var2);
      this.a = gj.a(this.Z_(), bmb.b);
      aoo.b(var2, this.a);
      this.j = var2.g("BurnTime");
      this.l = var2.g("CookTime");
      this.m = var2.g("CookTimeTotal");
      this.k = this.a((bmb)this.a.get(1));
      md var3 = var2.p("RecipesUsed");
      Iterator var4 = var3.d().iterator();

      while(var4.hasNext()) {
         String var5 = (String)var4.next();
         this.n.put(new vk(var5), var3.h(var5));
      }

   }

   public md a(md var1) {
      super.a(var1);
      var1.a("BurnTime", (short)this.j);
      var1.a("CookTime", (short)this.l);
      var1.a("CookTimeTotal", (short)this.m);
      aoo.a(var1, this.a);
      md var2 = new md();
      this.n.forEach((var1x, var2x) -> {
         var2.b(var1x.toString(), var2x);
      });
      var1.a((String)"RecipesUsed", (mt)var2);
      return var1;
   }

   public void aj_() {
      boolean var1 = this.j();
      boolean var2 = false;
      if (this.j()) {
         --this.j;
      }

      if (!this.d.v) {
         bmb var3 = (bmb)this.a.get(1);
         if (!this.j() && (var3.a() || ((bmb)this.a.get(0)).a())) {
            if (!this.j() && this.l > 0) {
               this.l = afm.a(this.l - 2, 0, this.m);
            }
         } else {
            boq<?> var4 = (boq)this.d.o().a((bot)this.c, (aon)this, (brx)this.d).orElse((Object)null);
            if (!this.j() && this.b(var4)) {
               this.j = this.a(var3);
               this.k = this.j;
               if (this.j()) {
                  var2 = true;
                  if (!var3.a()) {
                     blx var5 = var3.b();
                     var3.g(1);
                     if (var3.a()) {
                        blx var6 = var5.o();
                        this.a.set(1, var6 == null ? bmb.b : new bmb(var6));
                     }
                  }
               }
            }

            if (this.j() && this.b(var4)) {
               ++this.l;
               if (this.l == this.m) {
                  this.l = 0;
                  this.m = this.h();
                  this.c(var4);
                  var2 = true;
               }
            } else {
               this.l = 0;
            }
         }

         if (var1 != this.j()) {
            var2 = true;
            this.d.a(this.e, (ceh)this.d.d_(this.e).a(bto.b, this.j()), 3);
         }
      }

      if (var2) {
         this.X_();
      }

   }

   protected boolean b(@Nullable boq<?> var1) {
      if (!((bmb)this.a.get(0)).a() && var1 != null) {
         bmb var2 = var1.c();
         if (var2.a()) {
            return false;
         } else {
            bmb var3 = (bmb)this.a.get(2);
            if (var3.a()) {
               return true;
            } else if (!var3.a(var2)) {
               return false;
            } else if (var3.E() < this.V_() && var3.E() < var3.c()) {
               return true;
            } else {
               return var3.E() < var2.c();
            }
         }
      } else {
         return false;
      }
   }

   private void c(@Nullable boq<?> var1) {
      if (var1 != null && this.b(var1)) {
         bmb var2 = (bmb)this.a.get(0);
         bmb var3 = var1.c();
         bmb var4 = (bmb)this.a.get(2);
         if (var4.a()) {
            this.a.set(2, var3.i());
         } else if (var4.b() == var3.b()) {
            var4.f(1);
         }

         if (!this.d.v) {
            this.a(var1);
         }

         if (var2.b() == bup.ao.h() && !((bmb)this.a.get(1)).a() && ((bmb)this.a.get(1)).b() == bmd.lK) {
            this.a.set(1, new bmb(bmd.lL));
         }

         var2.g(1);
      }
   }

   protected int a(bmb var1) {
      if (var1.a()) {
         return 0;
      } else {
         blx var2 = var1.b();
         return (Integer)f().getOrDefault(var2, 0);
      }
   }

   protected int h() {
      return (Integer)this.d.o().a((bot)this.c, (aon)this, (brx)this.d).map(boc::e).orElse(200);
   }

   public static boolean b(bmb var0) {
      return f().containsKey(var0.b());
   }

   public int[] a(gc var1) {
      if (var1 == gc.a) {
         return h;
      } else {
         return var1 == gc.b ? g : i;
      }
   }

   public boolean a(int var1, bmb var2, @Nullable gc var3) {
      return this.b(var1, var2);
   }

   public boolean b(int var1, bmb var2, gc var3) {
      if (var3 == gc.a && var1 == 1) {
         blx var4 = var2.b();
         if (var4 != bmd.lL && var4 != bmd.lK) {
            return false;
         }
      }

      return true;
   }

   public int Z_() {
      return this.a.size();
   }

   public boolean c() {
      Iterator var1 = this.a.iterator();

      bmb var2;
      do {
         if (!var1.hasNext()) {
            return true;
         }

         var2 = (bmb)var1.next();
      } while(var2.a());

      return false;
   }

   public bmb a(int var1) {
      return (bmb)this.a.get(var1);
   }

   public bmb a(int var1, int var2) {
      return aoo.a(this.a, var1, var2);
   }

   public bmb b(int var1) {
      return aoo.a(this.a, var1);
   }

   public void a(int var1, bmb var2) {
      bmb var3 = (bmb)this.a.get(var1);
      boolean var4 = !var2.a() && var2.a(var3) && bmb.a(var2, var3);
      this.a.set(var1, var2);
      if (var2.E() > this.V_()) {
         var2.e(this.V_());
      }

      if (var1 == 0 && !var4) {
         this.m = this.h();
         this.l = 0;
         this.X_();
      }

   }

   public boolean a(bfw var1) {
      if (this.d.c(this.e) != this) {
         return false;
      } else {
         return var1.h((double)this.e.u() + 0.5D, (double)this.e.v() + 0.5D, (double)this.e.w() + 0.5D) <= 64.0D;
      }
   }

   public boolean b(int var1, bmb var2) {
      if (var1 == 2) {
         return false;
      } else if (var1 != 1) {
         return true;
      } else {
         bmb var3 = (bmb)this.a.get(1);
         return b(var2) || var2.b() == bmd.lK && var3.b() != bmd.lK;
      }
   }

   public void Y_() {
      this.a.clear();
   }

   public void a(@Nullable boq<?> var1) {
      if (var1 != null) {
         vk var2 = var1.f();
         this.n.addTo(var2, 1);
      }

   }

   @Nullable
   public boq<?> ak_() {
      return null;
   }

   public void b(bfw var1) {
   }

   public void d(bfw var1) {
      List<boq<?>> var2 = this.a(var1.l, var1.cA());
      var1.a((Collection)var2);
      this.n.clear();
   }

   public List<boq<?>> a(brx var1, dcn var2) {
      List<boq<?>> var3 = Lists.newArrayList();
      ObjectIterator var4 = this.n.object2IntEntrySet().iterator();

      while(var4.hasNext()) {
         Entry<vk> var5 = (Entry)var4.next();
         var1.o().a((vk)var5.getKey()).ifPresent((var4x) -> {
            var3.add(var4x);
            a(var1, var2, var5.getIntValue(), ((boc)var4x).b());
         });
      }

      return var3;
   }

   private static void a(brx var0, dcn var1, int var2, float var3) {
      int var4 = afm.d((float)var2 * var3);
      float var5 = afm.h((float)var2 * var3);
      if (var5 != 0.0F && Math.random() < (double)var5) {
         ++var4;
      }

      while(var4 > 0) {
         int var6 = aqg.a(var4);
         var4 -= var6;
         var0.c((aqa)(new aqg(var0, var1.b, var1.c, var1.d, var6)));
      }

   }

   public void a(bfy var1) {
      Iterator var2 = this.a.iterator();

      while(var2.hasNext()) {
         bmb var3 = (bmb)var2.next();
         var1.b(var3);
      }

   }
}
