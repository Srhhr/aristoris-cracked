import java.util.concurrent.CompletableFuture;

public interface ace {
   CompletableFuture<afx> a();

   float b();

   boolean c();

   boolean d();

   void e();
}
