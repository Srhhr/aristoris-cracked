import com.google.common.collect.ImmutableMap;
import java.util.function.BiPredicate;

public class atx extends arv<aqm> {
   private final int b;
   private final BiPredicate<aqm, aqm> c;

   public atx(int var1, BiPredicate<aqm, aqm> var2) {
      super(ImmutableMap.of(ayd.o, aye.a, ayd.L, aye.c, ayd.S, aye.b, ayd.T, aye.c));
      this.b = var1;
      this.c = var2;
   }

   protected boolean a(aag var1, aqm var2) {
      return this.a(var2).dl();
   }

   protected void a(aag var1, aqm var2, long var3) {
      aqm var5 = this.a(var2);
      if (this.c.test(var2, var5)) {
         var2.cJ().a(ayd.T, true, (long)this.b);
      }

      var2.cJ().a(ayd.S, var5.cB(), (long)this.b);
      if (var5.X() != aqe.bc || var1.V().b(brt.F)) {
         var2.cJ().b(ayd.o);
         var2.cJ().b(ayd.L);
      }

   }

   private aqm a(aqm var1) {
      return (aqm)var1.cJ().c(ayd.o).get();
   }
}
