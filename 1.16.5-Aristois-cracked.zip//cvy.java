public enum cvy implements cwl {
   a;

   public int a(cvk var1, int var2, int var3) {
      ctz var4 = var1.b();
      double var5 = var4.a((double)var2 / 8.0D, (double)var3 / 8.0D, 0.0D, 0.0D, 0.0D);
      if (var5 > 0.4D) {
         return 44;
      } else if (var5 > 0.2D) {
         return 45;
      } else if (var5 < -0.4D) {
         return 10;
      } else {
         return var5 < -0.2D ? 46 : 0;
      }
   }
}
