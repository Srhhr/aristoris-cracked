import java.util.Objects;
import javax.annotation.Nullable;

public class cxu {
   private final cxu.a a;
   private byte b;
   private byte c;
   private byte d;
   private final nr e;

   public cxu(cxu.a var1, byte var2, byte var3, byte var4, @Nullable nr var5) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
      this.e = var5;
   }

   public byte a() {
      return this.a.a();
   }

   public cxu.a b() {
      return this.a;
   }

   public byte c() {
      return this.b;
   }

   public byte d() {
      return this.c;
   }

   public byte e() {
      return this.d;
   }

   public boolean f() {
      return this.a.b();
   }

   @Nullable
   public nr g() {
      return this.e;
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof cxu)) {
         return false;
      } else {
         cxu var2 = (cxu)var1;
         if (this.a != var2.a) {
            return false;
         } else if (this.d != var2.d) {
            return false;
         } else if (this.b != var2.b) {
            return false;
         } else if (this.c != var2.c) {
            return false;
         } else {
            return Objects.equals(this.e, var2.e);
         }
      }
   }

   public int hashCode() {
      int var1 = this.a.a();
      int var2 = 31 * var1 + this.b;
      var2 = 31 * var2 + this.c;
      var2 = 31 * var2 + this.d;
      var2 = 31 * var2 + Objects.hashCode(this.e);
      return var2;
   }

   public static enum a {
      a(false),
      b(true),
      c(false),
      d(false),
      e(true),
      f(true),
      g(false),
      h(false),
      i(true, 5393476),
      j(true, 3830373),
      k(true),
      l(true),
      m(true),
      n(true),
      o(true),
      p(true),
      q(true),
      r(true),
      s(true),
      t(true),
      u(true),
      v(true),
      w(true),
      x(true),
      y(true),
      z(true),
      A(true);

      private final byte B;
      private final boolean C;
      private final int D;

      private a(boolean var3) {
         this(var3, -1);
      }

      private a(boolean var3, int var4) {
         this.B = (byte)this.ordinal();
         this.C = var3;
         this.D = var4;
      }

      public byte a() {
         return this.B;
      }

      public boolean b() {
         return this.C;
      }

      public boolean c() {
         return this.D >= 0;
      }

      public int d() {
         return this.D;
      }

      public static cxu.a a(byte var0) {
         return values()[afm.a(var0, 0, values().length - 1)];
      }
   }
}
