import com.mojang.blaze3d.systems.RenderSystem;
import java.util.Objects;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Predicate;
import javax.annotation.Nullable;

public class dlq extends dlh implements dmf, dmi {
   private final dku a;
   private String b;
   private int c;
   private int d;
   private boolean e;
   private boolean s;
   private boolean t;
   private boolean u;
   private int v;
   private int w;
   private int x;
   private int y;
   private int z;
   private String A;
   private Consumer<String> B;
   private Predicate<String> C;
   private BiFunction<String, Integer, afa> D;

   public dlq(dku var1, int var2, int var3, int var4, int var5, nr var6) {
      this(var1, var2, var3, var4, var5, (dlq)null, var6);
   }

   public dlq(dku var1, int var2, int var3, int var4, int var5, @Nullable dlq var6, nr var7) {
      super(var2, var3, var4, var5, var7);
      this.b = "";
      this.c = 32;
      this.e = true;
      this.s = true;
      this.t = true;
      this.y = 14737632;
      this.z = 7368816;
      this.C = Objects::nonNull;
      this.D = (var0, var1x) -> {
         return afa.a(var0, ob.a);
      };
      this.a = var1;
      if (var6 != null) {
         this.a(var6.b());
      }

   }

   public void a(Consumer<String> var1) {
      this.B = var1;
   }

   public void a(BiFunction<String, Integer, afa> var1) {
      this.D = var1;
   }

   public void a() {
      ++this.d;
   }

   protected nx c() {
      nr var1 = this.i();
      return new of("gui.narrate.editBox", new Object[]{var1, this.b});
   }

   public void a(String var1) {
      if (this.C.test(var1)) {
         if (var1.length() > this.c) {
            this.b = var1.substring(0, this.c);
         } else {
            this.b = var1;
         }

         this.l();
         this.n(this.w);
         this.d(var1);
      }
   }

   public String b() {
      return this.b;
   }

   public String d() {
      int var1 = this.w < this.x ? this.w : this.x;
      int var2 = this.w < this.x ? this.x : this.w;
      return this.b.substring(var1, var2);
   }

   public void a(Predicate<String> var1) {
      this.C = var1;
   }

   public void b(String var1) {
      int var2 = this.w < this.x ? this.w : this.x;
      int var3 = this.w < this.x ? this.x : this.w;
      int var4 = this.c - this.b.length() - (var2 - var3);
      String var5 = w.a(var1);
      int var6 = var5.length();
      if (var4 < var6) {
         var5 = var5.substring(0, var4);
         var6 = var4;
      }

      String var7 = (new StringBuilder(this.b)).replace(var2, var3, var5).toString();
      if (this.C.test(var7)) {
         this.b = var7;
         this.j(var2 + var6);
         this.n(this.w);
         this.d(this.b);
      }
   }

   private void d(String var1) {
      if (this.B != null) {
         this.B.accept(var1);
      }

      this.r = x.b() + 500L;
   }

   private void q(int var1) {
      if (dot.x()) {
         this.e(var1);
      } else {
         this.f(var1);
      }

   }

   public void e(int var1) {
      if (!this.b.isEmpty()) {
         if (this.x != this.w) {
            this.b("");
         } else {
            this.f(this.g(var1) - this.w);
         }
      }
   }

   public void f(int var1) {
      if (!this.b.isEmpty()) {
         if (this.x != this.w) {
            this.b("");
         } else {
            int var2 = this.r(var1);
            int var3 = Math.min(var2, this.w);
            int var4 = Math.max(var2, this.w);
            if (var3 != var4) {
               String var5 = (new StringBuilder(this.b)).delete(var3, var4).toString();
               if (this.C.test(var5)) {
                  this.b = var5;
                  this.i(var3);
               }
            }
         }
      }
   }

   public int g(int var1) {
      return this.a(var1, this.n());
   }

   private int a(int var1, int var2) {
      return this.a(var1, var2, true);
   }

   private int a(int var1, int var2, boolean var3) {
      int var4 = var2;
      boolean var5 = var1 < 0;
      int var6 = Math.abs(var1);

      for(int var7 = 0; var7 < var6; ++var7) {
         if (!var5) {
            int var8 = this.b.length();
            var4 = this.b.indexOf(32, var4);
            if (var4 == -1) {
               var4 = var8;
            } else {
               while(var3 && var4 < var8 && this.b.charAt(var4) == ' ') {
                  ++var4;
               }
            }
         } else {
            while(var3 && var4 > 0 && this.b.charAt(var4 - 1) == ' ') {
               --var4;
            }

            while(var4 > 0 && this.b.charAt(var4 - 1) != ' ') {
               --var4;
            }
         }
      }

      return var4;
   }

   public void h(int var1) {
      this.i(this.r(var1));
   }

   private int r(int var1) {
      return x.a(this.b, this.w, var1);
   }

   public void i(int var1) {
      this.j(var1);
      if (!this.u) {
         this.n(this.w);
      }

      this.d(this.b);
   }

   public void j(int var1) {
      this.w = afm.a(var1, 0, this.b.length());
   }

   public void k() {
      this.i(0);
   }

   public void l() {
      this.i(this.b.length());
   }

   public boolean a(int var1, int var2, int var3) {
      if (!this.m()) {
         return false;
      } else {
         this.u = dot.y();
         if (dot.i(var1)) {
            this.l();
            this.n(0);
            return true;
         } else if (dot.h(var1)) {
            djz.C().m.a(this.d());
            return true;
         } else if (dot.g(var1)) {
            if (this.t) {
               this.b(djz.C().m.a());
            }

            return true;
         } else if (dot.f(var1)) {
            djz.C().m.a(this.d());
            if (this.t) {
               this.b("");
            }

            return true;
         } else {
            switch(var1) {
            case 259:
               if (this.t) {
                  this.u = false;
                  this.q(-1);
                  this.u = dot.y();
               }

               return true;
            case 260:
            case 264:
            case 265:
            case 266:
            case 267:
            default:
               return false;
            case 261:
               if (this.t) {
                  this.u = false;
                  this.q(1);
                  this.u = dot.y();
               }

               return true;
            case 262:
               if (dot.x()) {
                  this.i(this.g(1));
               } else {
                  this.h(1);
               }

               return true;
            case 263:
               if (dot.x()) {
                  this.i(this.g(-1));
               } else {
                  this.h(-1);
               }

               return true;
            case 268:
               this.k();
               return true;
            case 269:
               this.l();
               return true;
            }
         }
      }
   }

   public boolean m() {
      return this.p() && this.j() && this.s();
   }

   public boolean a(char var1, int var2) {
      if (!this.m()) {
         return false;
      } else if (w.a(var1)) {
         if (this.t) {
            this.b(Character.toString(var1));
         }

         return true;
      } else {
         return false;
      }
   }

   public boolean a(double var1, double var3, int var5) {
      if (!this.p()) {
         return false;
      } else {
         boolean var6 = var1 >= (double)this.l && var1 < (double)(this.l + this.j) && var3 >= (double)this.m && var3 < (double)(this.m + this.k);
         if (this.s) {
            this.e(var6);
         }

         if (this.j() && var6 && var5 == 0) {
            int var7 = afm.c(var1) - this.l;
            if (this.e) {
               var7 -= 4;
            }

            String var8 = this.a.a(this.b.substring(this.v), this.o());
            this.i(this.a.a(var8, var7).length() + this.v);
            return true;
         } else {
            return false;
         }
      }
   }

   public void e(boolean var1) {
      super.d(var1);
   }

   public void b(dfm var1, int var2, int var3, float var4) {
      if (this.p()) {
         int var5;
         if (this.r()) {
            var5 = this.j() ? -1 : -6250336;
            a(var1, this.l - 1, this.m - 1, this.l + this.j + 1, this.m + this.k + 1, var5);
            a(var1, this.l, this.m, this.l + this.j, this.m + this.k, -16777216);
         }

         var5 = this.t ? this.y : this.z;
         int var6 = this.w - this.v;
         int var7 = this.x - this.v;
         String var8 = this.a.a(this.b.substring(this.v), this.o());
         boolean var9 = var6 >= 0 && var6 <= var8.length();
         boolean var10 = this.j() && this.d / 6 % 2 == 0 && var9;
         int var11 = this.e ? this.l + 4 : this.l;
         int var12 = this.e ? this.m + (this.k - 8) / 2 : this.m;
         int var13 = var11;
         if (var7 > var8.length()) {
            var7 = var8.length();
         }

         if (!var8.isEmpty()) {
            String var14 = var9 ? var8.substring(0, var6) : var8;
            var13 = this.a.a(var1, (afa)this.D.apply(var14, this.v), (float)var11, (float)var12, var5);
         }

         boolean var17 = this.w < this.b.length() || this.b.length() >= this.q();
         int var15 = var13;
         if (!var9) {
            var15 = var6 > 0 ? var11 + this.j : var11;
         } else if (var17) {
            var15 = var13 - 1;
            --var13;
         }

         if (!var8.isEmpty() && var9 && var6 < var8.length()) {
            this.a.a(var1, (afa)this.D.apply(var8.substring(var6), this.w), (float)var13, (float)var12, var5);
         }

         if (!var17 && this.A != null) {
            this.a.a(var1, this.A, (float)(var15 - 1), (float)var12, -8355712);
         }

         int var10002;
         int var10003;
         int var10004;
         if (var10) {
            if (var17) {
               var10002 = var12 - 1;
               var10003 = var15 + 1;
               var10004 = var12 + 1;
               this.a.getClass();
               dkw.a(var1, var15, var10002, var10003, var10004 + 9, -3092272);
            } else {
               this.a.a(var1, "_", (float)var15, (float)var12, var5);
            }
         }

         if (var7 != var6) {
            int var16 = var11 + this.a.b(var8.substring(0, var7));
            var10002 = var12 - 1;
            var10003 = var16 - 1;
            var10004 = var12 + 1;
            this.a.getClass();
            this.a(var15, var10002, var10003, var10004 + 9);
         }

      }
   }

   private void a(int var1, int var2, int var3, int var4) {
      int var5;
      if (var1 < var3) {
         var5 = var1;
         var1 = var3;
         var3 = var5;
      }

      if (var2 < var4) {
         var5 = var2;
         var2 = var4;
         var4 = var5;
      }

      if (var3 > this.l + this.j) {
         var3 = this.l + this.j;
      }

      if (var1 > this.l + this.j) {
         var1 = this.l + this.j;
      }

      dfo var7 = dfo.a();
      dfh var6 = var7.c();
      RenderSystem.color4f(0.0F, 0.0F, 255.0F, 255.0F);
      RenderSystem.disableTexture();
      RenderSystem.enableColorLogicOp();
      RenderSystem.logicOp(dem.o.n);
      var6.a(7, dfk.k);
      var6.a((double)var1, (double)var4, 0.0D).d();
      var6.a((double)var3, (double)var4, 0.0D).d();
      var6.a((double)var3, (double)var2, 0.0D).d();
      var6.a((double)var1, (double)var2, 0.0D).d();
      var7.b();
      RenderSystem.disableColorLogicOp();
      RenderSystem.enableTexture();
   }

   public void k(int var1) {
      this.c = var1;
      if (this.b.length() > var1) {
         this.b = this.b.substring(0, var1);
         this.d(this.b);
      }

   }

   private int q() {
      return this.c;
   }

   public int n() {
      return this.w;
   }

   private boolean r() {
      return this.e;
   }

   public void f(boolean var1) {
      this.e = var1;
   }

   public void l(int var1) {
      this.y = var1;
   }

   public void m(int var1) {
      this.z = var1;
   }

   public boolean c_(boolean var1) {
      return this.p && this.t ? super.c_(var1) : false;
   }

   public boolean b(double var1, double var3) {
      return this.p && var1 >= (double)this.l && var1 < (double)(this.l + this.j) && var3 >= (double)this.m && var3 < (double)(this.m + this.k);
   }

   protected void c(boolean var1) {
      if (var1) {
         this.d = 0;
      }

   }

   private boolean s() {
      return this.t;
   }

   public void g(boolean var1) {
      this.t = var1;
   }

   public int o() {
      return this.r() ? this.j - 8 : this.j;
   }

   public void n(int var1) {
      int var2 = this.b.length();
      this.x = afm.a(var1, 0, var2);
      if (this.a != null) {
         if (this.v > var2) {
            this.v = var2;
         }

         int var3 = this.o();
         String var4 = this.a.a(this.b.substring(this.v), var3);
         int var5 = var4.length() + this.v;
         if (this.x == this.v) {
            this.v -= this.a.a(this.b, var3, true).length();
         }

         if (this.x > var5) {
            this.v += this.x - var5;
         } else if (this.x <= this.v) {
            this.v -= this.v - this.x;
         }

         this.v = afm.a(this.v, 0, var2);
      }

   }

   public void h(boolean var1) {
      this.s = var1;
   }

   public boolean p() {
      return this.p;
   }

   public void i(boolean var1) {
      this.p = var1;
   }

   public void c(@Nullable String var1) {
      this.A = var1;
   }

   public int o(int var1) {
      return var1 > this.b.length() ? this.l : this.l + this.a.b(this.b.substring(0, var1));
   }

   public void p(int var1) {
      this.l = var1;
   }
}
