public class ehk extends efw<beg, dwg<beg>> {
   private static final vk a = new vk("textures/entity/witch.png");

   public ehk(eet var1) {
      super(var1, new dwg(0.0F), 0.5F);
      this.a((eit)(new ejf(this)));
   }

   public void a(beg var1, float var2, float var3, dfm var4, eag var5, int var6) {
      ((dwg)this.e).b(!var1.dD().a());
      super.a((aqn)var1, var2, var3, var4, var5, var6);
   }

   public vk a(beg var1) {
      return a;
   }

   protected void a(beg var1, dfm var2, float var3) {
      float var4 = 0.9375F;
      var2.a(0.9375F, 0.9375F, 0.9375F);
   }
}
