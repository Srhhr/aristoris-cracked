import java.io.IOException;

public class ov implements oj<om> {
   private int a;
   private fx b;
   private int c;

   public ov() {
   }

   public ov(int var1, fx var2, int var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
   }

   public void a(nf var1) throws IOException {
      this.a = var1.i();
      this.b = var1.e();
      this.c = var1.readUnsignedByte();
   }

   public void b(nf var1) throws IOException {
      var1.d(this.a);
      var1.a(this.b);
      var1.writeByte(this.c);
   }

   public void a(om var1) {
      var1.a(this);
   }

   public int b() {
      return this.a;
   }

   public fx c() {
      return this.b;
   }

   public int d() {
      return this.c;
   }
}
