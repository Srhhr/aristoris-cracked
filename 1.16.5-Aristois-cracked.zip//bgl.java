import java.util.function.Predicate;

public class bgl extends bgm {
   public bgl(aqe<? extends bgl> var1, brx var2) {
      super(var1, var2);
   }

   public bgl(brx var1, bbe var2) {
      this(aqe.R, var1);
      super.b((aqa)var2);
      this.d(var2.cD() - (double)(var2.cy() + 1.0F) * 0.5D * (double)afm.a(var2.aA * 0.017453292F), var2.cG() - 0.10000000149011612D, var2.cH() + (double)(var2.cy() + 1.0F) * 0.5D * (double)afm.b(var2.aA * 0.017453292F));
   }

   public bgl(brx var1, double var2, double var4, double var6, double var8, double var10, double var12) {
      this(aqe.R, var1);
      this.d(var2, var4, var6);

      for(int var14 = 0; var14 < 7; ++var14) {
         double var15 = 0.4D + 0.1D * (double)var14;
         var1.a(hh.U, var2, var4, var6, var8 * var15, var10, var12 * var15);
      }

      this.n(var8, var10, var12);
   }

   public void j() {
      super.j();
      dcn var1 = this.cC();
      dcl var2 = bgn.a((aqa)this, (Predicate)(this::a));
      if (var2 != null) {
         this.a((dcl)var2);
      }

      double var3 = this.cD() + var1.b;
      double var5 = this.cE() + var1.c;
      double var7 = this.cH() + var1.d;
      this.x();
      float var9 = 0.99F;
      float var10 = 0.06F;
      if (this.l.a((dci)this.cc()).noneMatch(ceg.a::g)) {
         this.ad();
      } else if (this.aH()) {
         this.ad();
      } else {
         this.f(var1.a(0.9900000095367432D));
         if (!this.aB()) {
            this.f(this.cC().b(0.0D, -0.05999999865889549D, 0.0D));
         }

         this.d(var3, var5, var7);
      }
   }

   protected void a(dck var1) {
      super.a(var1);
      aqa var2 = this.v();
      if (var2 instanceof aqm) {
         var1.a().a(apk.a((aqa)this, (aqm)((aqm)var2)).c(), 1.0F);
      }

   }

   protected void a(dcj var1) {
      super.a(var1);
      if (!this.l.v) {
         this.ad();
      }

   }

   protected void e() {
   }

   public oj<?> P() {
      return new on(this);
   }
}
