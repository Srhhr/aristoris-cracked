import java.util.concurrent.locks.ReentrantLock;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class dim extends eoo {
   private static final Logger a = LogManager.getLogger();
   private static final nr b = new of("mco.terms.title");
   private static final nr c = new of("mco.terms.sentence.1");
   private static final nr p;
   private final dot q;
   private final dfw r;
   private final dgq s;
   private boolean t;
   private final String u = "https://aka.ms/MinecraftRealmsTerms";

   public dim(dot var1, dfw var2, dgq var3) {
      this.q = var1;
      this.r = var2;
      this.s = var3;
   }

   public void b() {
      this.i.m.a(true);
      int var1 = this.k / 4 - 2;
      this.a(new dlj(this.k / 4, j(12), var1, 20, new of("mco.terms.buttons.agree"), (var1x) -> {
         this.h();
      }));
      this.a(new dlj(this.k / 2 + 4, j(12), var1, 20, new of("mco.terms.buttons.disagree"), (var1x) -> {
         this.i.a(this.q);
      }));
   }

   public void e() {
      this.i.m.a(false);
   }

   public boolean a(int var1, int var2, int var3) {
      if (var1 == 256) {
         this.i.a(this.q);
         return true;
      } else {
         return super.a(var1, var2, var3);
      }
   }

   private void h() {
      dgb var1 = dgb.a();

      try {
         var1.l();
         this.i.a((dot)(new dhz(this.q, new diz(this.r, this.q, this.s, new ReentrantLock()))));
      } catch (dhi var3) {
         a.error("Couldn't agree to TOS");
      }

   }

   public boolean a(double var1, double var3, int var5) {
      if (this.t) {
         this.i.m.a("https://aka.ms/MinecraftRealmsTerms");
         x.i().a("https://aka.ms/MinecraftRealmsTerms");
         return true;
      } else {
         return super.a(var1, var3, var5);
      }
   }

   public String ax_() {
      return super.ax_() + ". " + c.getString() + " " + p.getString();
   }

   public void a(dfm var1, int var2, int var3, float var4) {
      this.a(var1);
      a(var1, this.o, b, this.k / 2, 17, 16777215);
      this.o.b(var1, c, (float)(this.k / 2 - 120), (float)j(5), 16777215);
      int var5 = this.o.a((nu)c);
      int var6 = this.k / 2 - 121 + var5;
      int var7 = j(5);
      int var8 = var6 + this.o.a((nu)p) + 1;
      int var10000 = var7 + 1;
      this.o.getClass();
      int var9 = var10000 + 9;
      this.t = var6 <= var2 && var2 <= var8 && var7 <= var3 && var3 <= var9;
      this.o.b(var1, p, (float)(this.k / 2 - 120 + var5), (float)j(5), this.t ? 7107012 : 3368635);
      super.a(var1, var2, var3, var4);
   }

   static {
      p = (new oe(" ")).a((new of("mco.terms.sentence.2")).c(ob.a.c(true)));
   }
}
