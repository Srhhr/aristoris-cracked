import java.io.IOException;

public class sh implements oj<sa> {
   private int a;
   private String b;

   public sh() {
   }

   public sh(int var1, String var2) {
      this.a = var1;
      this.b = var2;
   }

   public void a(nf var1) throws IOException {
      this.a = var1.i();
      this.b = var1.e(32500);
   }

   public void b(nf var1) throws IOException {
      var1.d(this.a);
      var1.a((String)this.b, 32500);
   }

   public void a(sa var1) {
      var1.a(this);
   }

   public int b() {
      return this.a;
   }

   public String c() {
      return this.b;
   }
}
