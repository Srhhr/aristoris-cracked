import java.util.function.Predicate;

public class brf {
   private final dcn a;
   private final dcn b;
   private final brf.a c;
   private final brf.b d;
   private final dcs e;

   public brf(dcn var1, dcn var2, brf.a var3, brf.b var4, aqa var5) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
      this.e = dcs.a(var5);
   }

   public dcn a() {
      return this.b;
   }

   public dcn b() {
      return this.a;
   }

   public ddh a(ceh var1, brc var2, fx var3) {
      return this.c.get(var1, var2, var3, this.e);
   }

   public ddh a(cux var1, brc var2, fx var3) {
      return this.d.a(var1) ? var1.d(var2, var3) : dde.a();
   }

   public static enum b {
      a((var0) -> {
         return false;
      }),
      b(cux::b),
      c((var0) -> {
         return !var0.c();
      });

      private final Predicate<cux> d;

      private b(Predicate<cux> var3) {
         this.d = var3;
      }

      public boolean a(cux var1) {
         return this.d.test(var1);
      }
   }

   public interface c {
      ddh get(ceh var1, brc var2, fx var3, dcs var4);
   }

   public static enum a implements brf.c {
      a(ceg.a::b),
      b(ceg.a::a),
      c(ceg.a::c);

      private final brf.c d;

      private a(brf.c var3) {
         this.d = var3;
      }

      public ddh get(ceh var1, brc var2, fx var3, dcs var4) {
         return this.d.get(var1, var2, var3, var4);
      }
   }
}
