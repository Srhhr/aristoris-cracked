import it.unimi.dsi.fastutil.booleans.BooleanConsumer;

public class dnz extends dot {
   private static final nr a = new of("addServer.enterIp");
   private dlj b;
   private final dwz c;
   private dlq p;
   private final BooleanConsumer q;
   private final dot r;

   public dnz(dot var1, BooleanConsumer var2, dwz var3) {
      super(new of("selectServer.direct"));
      this.r = var1;
      this.c = var3;
      this.q = var2;
   }

   public void d() {
      this.p.a();
   }

   public boolean a(int var1, int var2, int var3) {
      if (this.aw_() != this.p || var1 != 257 && var1 != 335) {
         return super.a(var1, var2, var3);
      } else {
         this.h();
         return true;
      }
   }

   protected void b() {
      this.i.m.a(true);
      this.b = (dlj)this.a(new dlj(this.k / 2 - 100, this.l / 4 + 96 + 12, 200, 20, new of("selectServer.select"), (var1) -> {
         this.h();
      }));
      this.a(new dlj(this.k / 2 - 100, this.l / 4 + 120 + 12, 200, 20, nq.d, (var1) -> {
         this.q.accept(false);
      }));
      this.p = new dlq(this.o, this.k / 2 - 100, 116, 200, 20, new of("addServer.enterIp"));
      this.p.k(128);
      this.p.e(true);
      this.p.a(this.i.k.aM);
      this.p.a((var1) -> {
         this.i();
      });
      this.e.add(this.p);
      this.b((dmi)this.p);
      this.i();
   }

   public void a(djz var1, int var2, int var3) {
      String var4 = this.p.b();
      this.b(var1, var2, var3);
      this.p.a(var4);
   }

   private void h() {
      this.c.b = this.p.b();
      this.q.accept(true);
   }

   public void at_() {
      this.i.a(this.r);
   }

   public void e() {
      this.i.m.a(false);
      this.i.k.aM = this.p.b();
      this.i.k.b();
   }

   private void i() {
      String var1 = this.p.b();
      this.b.o = !var1.isEmpty() && var1.split(":").length > 0 && var1.indexOf(32) == -1;
   }

   public void a(dfm var1, int var2, int var3, float var4) {
      this.a(var1);
      a(var1, this.o, this.d, this.k / 2, 20, 16777215);
      b(var1, this.o, a, this.k / 2 - 100, 100, 10526880);
      this.p.a(var1, var2, var3, var4);
      super.a(var1, var2, var3, var4);
   }
}
