import com.google.common.collect.ImmutableMap;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Stream;
import javax.annotation.Nullable;

public final class od {
   private static final Map<k, od> a = (Map)Stream.of(k.values()).filter(k::d).collect(ImmutableMap.toImmutableMap(Function.identity(), (var0) -> {
      return new od(var0.e(), var0.f());
   }));
   private static final Map<String, od> b;
   private final int c;
   @Nullable
   private final String d;

   private od(int var1, String var2) {
      this.c = var1;
      this.d = var2;
   }

   private od(int var1) {
      this.c = var1;
      this.d = null;
   }

   public int a() {
      return this.c;
   }

   public String b() {
      return this.d != null ? this.d : this.c();
   }

   private String c() {
      return String.format("#%06X", this.c);
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 != null && this.getClass() == var1.getClass()) {
         od var2 = (od)var1;
         return this.c == var2.c;
      } else {
         return false;
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.c, this.d});
   }

   public String toString() {
      return this.d != null ? this.d : this.c();
   }

   @Nullable
   public static od a(k var0) {
      return (od)a.get(var0);
   }

   public static od a(int var0) {
      return new od(var0);
   }

   @Nullable
   public static od a(String var0) {
      if (var0.startsWith("#")) {
         try {
            int var1 = Integer.parseInt(var0.substring(1), 16);
            return a(var1);
         } catch (NumberFormatException var2) {
            return null;
         }
      } else {
         return (od)b.get(var0);
      }
   }

   static {
      b = (Map)a.values().stream().collect(ImmutableMap.toImmutableMap((var0) -> {
         return var0.d;
      }, Function.identity()));
   }
}
