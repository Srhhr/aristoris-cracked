import java.io.IOException;
import java.security.PublicKey;

public class ub implements oj<ty> {
   private String a;
   private byte[] b;
   private byte[] c;

   public ub() {
   }

   public ub(String var1, byte[] var2, byte[] var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
   }

   public void a(nf var1) throws IOException {
      this.a = var1.e(20);
      this.b = var1.a();
      this.c = var1.a();
   }

   public void b(nf var1) throws IOException {
      var1.a(this.a);
      var1.a(this.b);
      var1.a(this.c);
   }

   public void a(ty var1) {
      var1.a(this);
   }

   public String b() {
      return this.a;
   }

   public PublicKey c() throws aev {
      return aeu.a(this.b);
   }

   public byte[] d() {
      return this.c;
   }
}
