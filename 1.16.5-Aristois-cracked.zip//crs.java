import com.google.common.collect.Lists;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;

public class crs {
   private static final crs.f[] a = new crs.f[]{new crs.f(crs.n.class, 40, 0), new crs.f(crs.h.class, 5, 5), new crs.f(crs.d.class, 20, 0), new crs.f(crs.i.class, 20, 0), new crs.f(crs.j.class, 10, 6), new crs.f(crs.o.class, 5, 5), new crs.f(crs.l.class, 5, 5), new crs.f(crs.c.class, 5, 4), new crs.f(crs.a.class, 5, 4), new crs.f(crs.e.class, 10, 2) {
      public boolean a(int var1) {
         return super.a(var1) && var1 > 4;
      }
   }, new crs.f(crs.g.class, 20, 1) {
      public boolean a(int var1) {
         return super.a(var1) && var1 > 5;
      }
   }};
   private static List<crs.f> b;
   private static Class<? extends crs.p> c;
   private static int d;
   private static final crs.k e = new crs.k();

   public static void a() {
      b = Lists.newArrayList();
      crs.f[] var0 = a;
      int var1 = var0.length;

      for(int var2 = 0; var2 < var1; ++var2) {
         crs.f var3 = var0[var2];
         var3.c = 0;
         b.add(var3);
      }

      c = null;
   }

   private static boolean c() {
      boolean var0 = false;
      d = 0;

      crs.f var2;
      for(Iterator var1 = b.iterator(); var1.hasNext(); d += var2.b) {
         var2 = (crs.f)var1.next();
         if (var2.d > 0 && var2.c < var2.d) {
            var0 = true;
         }
      }

      return var0;
   }

   private static crs.p a(Class<? extends crs.p> var0, List<cru> var1, Random var2, int var3, int var4, int var5, @Nullable gc var6, int var7) {
      crs.p var8 = null;
      if (var0 == crs.n.class) {
         var8 = crs.n.a(var1, var2, var3, var4, var5, var6, var7);
      } else if (var0 == crs.h.class) {
         var8 = crs.h.a(var1, var2, var3, var4, var5, var6, var7);
      } else if (var0 == crs.d.class) {
         var8 = crs.d.a(var1, var2, var3, var4, var5, var6, var7);
      } else if (var0 == crs.i.class) {
         var8 = crs.i.a(var1, var2, var3, var4, var5, var6, var7);
      } else if (var0 == crs.j.class) {
         var8 = crs.j.a(var1, var2, var3, var4, var5, var6, var7);
      } else if (var0 == crs.o.class) {
         var8 = crs.o.a(var1, var2, var3, var4, var5, var6, var7);
      } else if (var0 == crs.l.class) {
         var8 = crs.l.a(var1, var2, var3, var4, var5, var6, var7);
      } else if (var0 == crs.c.class) {
         var8 = crs.c.a(var1, var2, var3, var4, var5, var6, var7);
      } else if (var0 == crs.a.class) {
         var8 = crs.a.a(var1, var2, var3, var4, var5, var6, var7);
      } else if (var0 == crs.e.class) {
         var8 = crs.e.a(var1, var2, var3, var4, var5, var6, var7);
      } else if (var0 == crs.g.class) {
         var8 = crs.g.a(var1, var3, var4, var5, var6, var7);
      }

      return (crs.p)var8;
   }

   private static crs.p b(crs.m var0, List<cru> var1, Random var2, int var3, int var4, int var5, gc var6, int var7) {
      if (!c()) {
         return null;
      } else {
         if (c != null) {
            crs.p var8 = a(c, var1, var2, var3, var4, var5, var6, var7);
            c = null;
            if (var8 != null) {
               return var8;
            }
         }

         int var13 = 0;

         while(var13 < 5) {
            ++var13;
            int var9 = var2.nextInt(d);
            Iterator var10 = b.iterator();

            while(var10.hasNext()) {
               crs.f var11 = (crs.f)var10.next();
               var9 -= var11.b;
               if (var9 < 0) {
                  if (!var11.a(var7) || var11 == var0.a) {
                     break;
                  }

                  crs.p var12 = a(var11.a, var1, var2, var3, var4, var5, var6, var7);
                  if (var12 != null) {
                     ++var11.c;
                     var0.a = var11;
                     if (!var11.a()) {
                        b.remove(var11);
                     }

                     return var12;
                  }
               }
            }
         }

         cra var14 = crs.b.a(var1, var2, var3, var4, var5, var6);
         if (var14 != null && var14.b > 1) {
            return new crs.b(var7, var14, var6);
         } else {
            return null;
         }
      }
   }

   private static cru c(crs.m var0, List<cru> var1, Random var2, int var3, int var4, int var5, @Nullable gc var6, int var7) {
      if (var7 > 50) {
         return null;
      } else if (Math.abs(var3 - var0.g().a) <= 112 && Math.abs(var5 - var0.g().c) <= 112) {
         cru var8 = b(var0, var1, var2, var3, var4, var5, var6, var7 + 1);
         if (var8 != null) {
            var1.add(var8);
            var0.c.add(var8);
         }

         return var8;
      } else {
         return null;
      }
   }

   static class k extends cru.a {
      private k() {
      }

      public void a(Random var1, int var2, int var3, int var4, boolean var5) {
         if (var5) {
            float var6 = var1.nextFloat();
            if (var6 < 0.2F) {
               this.a = bup.dw.n();
            } else if (var6 < 0.5F) {
               this.a = bup.dv.n();
            } else if (var6 < 0.55F) {
               this.a = bup.dA.n();
            } else {
               this.a = bup.du.n();
            }
         } else {
            this.a = bup.lb.n();
         }

      }

      // $FF: synthetic method
      k(Object var1) {
         this();
      }
   }

   public static class g extends crs.p {
      private boolean a;

      public g(int var1, cra var2, gc var3) {
         super(clb.y, var1);
         this.a(var3);
         this.n = var2;
      }

      public g(csw var1, md var2) {
         super(clb.y, var2);
         this.a = var2.q("Mob");
      }

      protected void a(md var1) {
         super.a(var1);
         var1.a("Mob", this.a);
      }

      public void a(cru var1, List<cru> var2, Random var3) {
         if (var1 != null) {
            ((crs.m)var1).b = this;
         }

      }

      public static crs.g a(List<cru> var0, int var1, int var2, int var3, gc var4, int var5) {
         cra var6 = cra.a(var1, var2, var3, -4, -1, 0, 11, 8, 16, var4);
         return a(var6) && cru.a(var0, var6) == null ? new crs.g(var5, var6, var4) : null;
      }

      public boolean a(bsr var1, bsn var2, cfy var3, Random var4, cra var5, brd var6, fx var7) {
         this.a(var1, var5, 0, 0, 0, 10, 7, 15, false, var4, crs.e);
         this.a(var1, var4, var5, crs.p.a.c, 4, 1, 0);
         int var8 = 6;
         this.a(var1, var5, 1, var8, 1, 1, var8, 14, false, var4, crs.e);
         this.a(var1, var5, 9, var8, 1, 9, var8, 14, false, var4, crs.e);
         this.a(var1, var5, 2, var8, 1, 8, var8, 2, false, var4, crs.e);
         this.a(var1, var5, 2, var8, 14, 8, var8, 14, false, var4, crs.e);
         this.a(var1, var5, 1, 1, 1, 2, 1, 4, false, var4, crs.e);
         this.a(var1, var5, 8, 1, 1, 9, 1, 4, false, var4, crs.e);
         this.a(var1, var5, 1, 1, 1, 1, 1, 3, bup.B.n(), bup.B.n(), false);
         this.a(var1, var5, 9, 1, 1, 9, 1, 3, bup.B.n(), bup.B.n(), false);
         this.a(var1, var5, 3, 1, 8, 7, 1, 12, false, var4, crs.e);
         this.a(var1, var5, 4, 1, 9, 6, 1, 11, bup.B.n(), bup.B.n(), false);
         ceh var9 = (ceh)((ceh)bup.dH.n().a(bxq.a, true)).a(bxq.c, true);
         ceh var10 = (ceh)((ceh)bup.dH.n().a(bxq.d, true)).a(bxq.b, true);

         int var11;
         for(var11 = 3; var11 < 14; var11 += 2) {
            this.a(var1, var5, 0, 3, var11, 0, 4, var11, var9, var9, false);
            this.a(var1, var5, 10, 3, var11, 10, 4, var11, var9, var9, false);
         }

         for(var11 = 2; var11 < 9; var11 += 2) {
            this.a(var1, var5, var11, 3, 15, var11, 4, 15, var10, var10, false);
         }

         ceh var21 = (ceh)bup.dS.n().a(cak.a, gc.c);
         this.a(var1, var5, 4, 1, 5, 6, 1, 7, false, var4, crs.e);
         this.a(var1, var5, 4, 2, 6, 6, 2, 7, false, var4, crs.e);
         this.a(var1, var5, 4, 3, 7, 6, 3, 7, false, var4, crs.e);

         for(int var12 = 4; var12 <= 6; ++var12) {
            this.a(var1, var21, var12, 1, 4, var5);
            this.a(var1, var21, var12, 2, 5, var5);
            this.a(var1, var21, var12, 3, 6, var5);
         }

         ceh var22 = (ceh)bup.ed.n().a(bwj.a, gc.c);
         ceh var13 = (ceh)bup.ed.n().a(bwj.a, gc.d);
         ceh var14 = (ceh)bup.ed.n().a(bwj.a, gc.f);
         ceh var15 = (ceh)bup.ed.n().a(bwj.a, gc.e);
         boolean var16 = true;
         boolean[] var17 = new boolean[12];

         for(int var18 = 0; var18 < var17.length; ++var18) {
            var17[var18] = var4.nextFloat() > 0.9F;
            var16 &= var17[var18];
         }

         this.a(var1, (ceh)var22.a(bwj.b, var17[0]), 4, 3, 8, var5);
         this.a(var1, (ceh)var22.a(bwj.b, var17[1]), 5, 3, 8, var5);
         this.a(var1, (ceh)var22.a(bwj.b, var17[2]), 6, 3, 8, var5);
         this.a(var1, (ceh)var13.a(bwj.b, var17[3]), 4, 3, 12, var5);
         this.a(var1, (ceh)var13.a(bwj.b, var17[4]), 5, 3, 12, var5);
         this.a(var1, (ceh)var13.a(bwj.b, var17[5]), 6, 3, 12, var5);
         this.a(var1, (ceh)var14.a(bwj.b, var17[6]), 3, 3, 9, var5);
         this.a(var1, (ceh)var14.a(bwj.b, var17[7]), 3, 3, 10, var5);
         this.a(var1, (ceh)var14.a(bwj.b, var17[8]), 3, 3, 11, var5);
         this.a(var1, (ceh)var15.a(bwj.b, var17[9]), 7, 3, 9, var5);
         this.a(var1, (ceh)var15.a(bwj.b, var17[10]), 7, 3, 10, var5);
         this.a(var1, (ceh)var15.a(bwj.b, var17[11]), 7, 3, 11, var5);
         if (var16) {
            ceh var23 = bup.ec.n();
            this.a(var1, var23, 4, 3, 9, var5);
            this.a(var1, var23, 5, 3, 9, var5);
            this.a(var1, var23, 6, 3, 9, var5);
            this.a(var1, var23, 4, 3, 10, var5);
            this.a(var1, var23, 5, 3, 10, var5);
            this.a(var1, var23, 6, 3, 10, var5);
            this.a(var1, var23, 4, 3, 11, var5);
            this.a(var1, var23, 5, 3, 11, var5);
            this.a(var1, var23, 6, 3, 11, var5);
         }

         if (!this.a) {
            int var20 = this.d(3);
            fx var24 = new fx(this.a(5, 6), var20, this.b(5, 6));
            if (var5.b((gr)var24)) {
               this.a = true;
               var1.a(var24, bup.bP.n(), 2);
               ccj var19 = var1.c(var24);
               if (var19 instanceof cdi) {
                  ((cdi)var19).d().a(aqe.au);
               }
            }
         }

         return true;
      }
   }

   public static class c extends crs.p {
      private final boolean a;
      private final boolean b;
      private final boolean c;
      private final boolean e;

      public c(int var1, Random var2, cra var3, gc var4) {
         super(clb.v, var1);
         this.a(var4);
         this.d = this.a(var2);
         this.n = var3;
         this.a = var2.nextBoolean();
         this.b = var2.nextBoolean();
         this.c = var2.nextBoolean();
         this.e = var2.nextInt(3) > 0;
      }

      public c(csw var1, md var2) {
         super(clb.v, var2);
         this.a = var2.q("leftLow");
         this.b = var2.q("leftHigh");
         this.c = var2.q("rightLow");
         this.e = var2.q("rightHigh");
      }

      protected void a(md var1) {
         super.a(var1);
         var1.a("leftLow", this.a);
         var1.a("leftHigh", this.b);
         var1.a("rightLow", this.c);
         var1.a("rightHigh", this.e);
      }

      public void a(cru var1, List<cru> var2, Random var3) {
         int var4 = 3;
         int var5 = 5;
         gc var6 = this.i();
         if (var6 == gc.e || var6 == gc.c) {
            var4 = 8 - var4;
            var5 = 8 - var5;
         }

         this.a((crs.m)var1, var2, var3, 5, 1);
         if (this.a) {
            this.b((crs.m)var1, var2, var3, var4, 1);
         }

         if (this.b) {
            this.b((crs.m)var1, var2, var3, var5, 7);
         }

         if (this.c) {
            this.c((crs.m)var1, var2, var3, var4, 1);
         }

         if (this.e) {
            this.c((crs.m)var1, var2, var3, var5, 7);
         }

      }

      public static crs.c a(List<cru> var0, Random var1, int var2, int var3, int var4, gc var5, int var6) {
         cra var7 = cra.a(var2, var3, var4, -4, -3, 0, 10, 9, 11, var5);
         return a(var7) && cru.a(var0, var7) == null ? new crs.c(var6, var1, var7, var5) : null;
      }

      public boolean a(bsr var1, bsn var2, cfy var3, Random var4, cra var5, brd var6, fx var7) {
         this.a(var1, var5, 0, 0, 0, 9, 8, 10, true, var4, crs.e);
         this.a(var1, var4, var5, this.d, 4, 3, 0);
         if (this.a) {
            this.a(var1, var5, 0, 3, 1, 0, 5, 3, m, m, false);
         }

         if (this.c) {
            this.a(var1, var5, 9, 3, 1, 9, 5, 3, m, m, false);
         }

         if (this.b) {
            this.a(var1, var5, 0, 5, 7, 0, 7, 9, m, m, false);
         }

         if (this.e) {
            this.a(var1, var5, 9, 5, 7, 9, 7, 9, m, m, false);
         }

         this.a(var1, var5, 5, 1, 10, 7, 3, 10, m, m, false);
         this.a(var1, var5, 1, 2, 1, 8, 2, 6, false, var4, crs.e);
         this.a(var1, var5, 4, 1, 5, 4, 4, 9, false, var4, crs.e);
         this.a(var1, var5, 8, 1, 5, 8, 4, 9, false, var4, crs.e);
         this.a(var1, var5, 1, 4, 7, 3, 4, 9, false, var4, crs.e);
         this.a(var1, var5, 1, 3, 5, 3, 3, 6, false, var4, crs.e);
         this.a(var1, var5, 1, 3, 4, 3, 3, 4, bup.hR.n(), bup.hR.n(), false);
         this.a(var1, var5, 1, 4, 6, 3, 4, 6, bup.hR.n(), bup.hR.n(), false);
         this.a(var1, var5, 5, 1, 7, 7, 1, 8, false, var4, crs.e);
         this.a(var1, var5, 5, 1, 9, 7, 1, 9, bup.hR.n(), bup.hR.n(), false);
         this.a(var1, var5, 5, 2, 7, 7, 2, 7, bup.hR.n(), bup.hR.n(), false);
         this.a(var1, var5, 4, 5, 7, 4, 5, 9, bup.hR.n(), bup.hR.n(), false);
         this.a(var1, var5, 8, 5, 7, 8, 5, 9, bup.hR.n(), bup.hR.n(), false);
         this.a(var1, var5, 5, 5, 7, 7, 5, 9, (ceh)bup.hR.n().a(bzw.a, cfm.c), (ceh)bup.hR.n().a(bzw.a, cfm.c), false);
         this.a(var1, (ceh)bup.bM.n().a(cbn.a, gc.d), 6, 5, 6, var5);
         return true;
      }
   }

   public static class e extends crs.p {
      private final boolean a;

      public e(int var1, Random var2, cra var3, gc var4) {
         super(clb.x, var1);
         this.a(var4);
         this.d = this.a(var2);
         this.n = var3;
         this.a = var3.e() > 6;
      }

      public e(csw var1, md var2) {
         super(clb.x, var2);
         this.a = var2.q("Tall");
      }

      protected void a(md var1) {
         super.a(var1);
         var1.a("Tall", this.a);
      }

      public static crs.e a(List<cru> var0, Random var1, int var2, int var3, int var4, gc var5, int var6) {
         cra var7 = cra.a(var2, var3, var4, -4, -1, 0, 14, 11, 15, var5);
         if (!a(var7) || cru.a(var0, var7) != null) {
            var7 = cra.a(var2, var3, var4, -4, -1, 0, 14, 6, 15, var5);
            if (!a(var7) || cru.a(var0, var7) != null) {
               return null;
            }
         }

         return new crs.e(var6, var1, var7, var5);
      }

      public boolean a(bsr var1, bsn var2, cfy var3, Random var4, cra var5, brd var6, fx var7) {
         int var8 = 11;
         if (!this.a) {
            var8 = 6;
         }

         this.a(var1, var5, 0, 0, 0, 13, var8 - 1, 14, true, var4, crs.e);
         this.a(var1, var4, var5, this.d, 4, 1, 0);
         this.a(var1, var5, var4, 0.07F, 2, 1, 1, 11, 4, 13, bup.aQ.n(), bup.aQ.n(), false, false);
         int var9 = true;
         int var10 = true;

         int var11;
         for(var11 = 1; var11 <= 13; ++var11) {
            if ((var11 - 1) % 4 == 0) {
               this.a(var1, var5, 1, 1, var11, 1, 4, var11, bup.n.n(), bup.n.n(), false);
               this.a(var1, var5, 12, 1, var11, 12, 4, var11, bup.n.n(), bup.n.n(), false);
               this.a(var1, (ceh)bup.bM.n().a(cbn.a, gc.f), 2, 3, var11, var5);
               this.a(var1, (ceh)bup.bM.n().a(cbn.a, gc.e), 11, 3, var11, var5);
               if (this.a) {
                  this.a(var1, var5, 1, 6, var11, 1, 9, var11, bup.n.n(), bup.n.n(), false);
                  this.a(var1, var5, 12, 6, var11, 12, 9, var11, bup.n.n(), bup.n.n(), false);
               }
            } else {
               this.a(var1, var5, 1, 1, var11, 1, 4, var11, bup.bI.n(), bup.bI.n(), false);
               this.a(var1, var5, 12, 1, var11, 12, 4, var11, bup.bI.n(), bup.bI.n(), false);
               if (this.a) {
                  this.a(var1, var5, 1, 6, var11, 1, 9, var11, bup.bI.n(), bup.bI.n(), false);
                  this.a(var1, var5, 12, 6, var11, 12, 9, var11, bup.bI.n(), bup.bI.n(), false);
               }
            }
         }

         for(var11 = 3; var11 < 12; var11 += 2) {
            this.a(var1, var5, 3, 1, var11, 4, 3, var11, bup.bI.n(), bup.bI.n(), false);
            this.a(var1, var5, 6, 1, var11, 7, 3, var11, bup.bI.n(), bup.bI.n(), false);
            this.a(var1, var5, 9, 1, var11, 10, 3, var11, bup.bI.n(), bup.bI.n(), false);
         }

         if (this.a) {
            this.a(var1, var5, 1, 5, 1, 3, 5, 13, bup.n.n(), bup.n.n(), false);
            this.a(var1, var5, 10, 5, 1, 12, 5, 13, bup.n.n(), bup.n.n(), false);
            this.a(var1, var5, 4, 5, 1, 9, 5, 2, bup.n.n(), bup.n.n(), false);
            this.a(var1, var5, 4, 5, 12, 9, 5, 13, bup.n.n(), bup.n.n(), false);
            this.a(var1, bup.n.n(), 9, 5, 11, var5);
            this.a(var1, bup.n.n(), 8, 5, 11, var5);
            this.a(var1, bup.n.n(), 9, 5, 10, var5);
            ceh var20 = (ceh)((ceh)bup.cJ.n().a(bwq.d, true)).a(bwq.b, true);
            ceh var12 = (ceh)((ceh)bup.cJ.n().a(bwq.a, true)).a(bwq.c, true);
            this.a(var1, var5, 3, 6, 3, 3, 6, 11, var12, var12, false);
            this.a(var1, var5, 10, 6, 3, 10, 6, 9, var12, var12, false);
            this.a(var1, var5, 4, 6, 2, 9, 6, 2, var20, var20, false);
            this.a(var1, var5, 4, 6, 12, 7, 6, 12, var20, var20, false);
            this.a(var1, (ceh)((ceh)bup.cJ.n().a(bwq.a, true)).a(bwq.b, true), 3, 6, 2, var5);
            this.a(var1, (ceh)((ceh)bup.cJ.n().a(bwq.c, true)).a(bwq.b, true), 3, 6, 12, var5);
            this.a(var1, (ceh)((ceh)bup.cJ.n().a(bwq.a, true)).a(bwq.d, true), 10, 6, 2, var5);

            for(int var13 = 0; var13 <= 2; ++var13) {
               this.a(var1, (ceh)((ceh)bup.cJ.n().a(bwq.c, true)).a(bwq.d, true), 8 + var13, 6, 12 - var13, var5);
               if (var13 != 2) {
                  this.a(var1, (ceh)((ceh)bup.cJ.n().a(bwq.a, true)).a(bwq.b, true), 8 + var13, 6, 11 - var13, var5);
               }
            }

            ceh var21 = (ceh)bup.cg.n().a(bxv.a, gc.d);
            this.a(var1, var21, 10, 1, 13, var5);
            this.a(var1, var21, 10, 2, 13, var5);
            this.a(var1, var21, 10, 3, 13, var5);
            this.a(var1, var21, 10, 4, 13, var5);
            this.a(var1, var21, 10, 5, 13, var5);
            this.a(var1, var21, 10, 6, 13, var5);
            this.a(var1, var21, 10, 7, 13, var5);
            int var14 = true;
            int var15 = true;
            ceh var16 = (ceh)bup.cJ.n().a(bwq.b, true);
            this.a(var1, var16, 6, 9, 7, var5);
            ceh var17 = (ceh)bup.cJ.n().a(bwq.d, true);
            this.a(var1, var17, 7, 9, 7, var5);
            this.a(var1, var16, 6, 8, 7, var5);
            this.a(var1, var17, 7, 8, 7, var5);
            ceh var18 = (ceh)((ceh)var12.a(bwq.d, true)).a(bwq.b, true);
            this.a(var1, var18, 6, 7, 7, var5);
            this.a(var1, var18, 7, 7, 7, var5);
            this.a(var1, var16, 5, 7, 7, var5);
            this.a(var1, var17, 8, 7, 7, var5);
            this.a(var1, (ceh)var16.a(bwq.a, true), 6, 7, 6, var5);
            this.a(var1, (ceh)var16.a(bwq.c, true), 6, 7, 8, var5);
            this.a(var1, (ceh)var17.a(bwq.a, true), 7, 7, 6, var5);
            this.a(var1, (ceh)var17.a(bwq.c, true), 7, 7, 8, var5);
            ceh var19 = bup.bL.n();
            this.a(var1, var19, 5, 8, 7, var5);
            this.a(var1, var19, 8, 8, 7, var5);
            this.a(var1, var19, 6, 8, 6, var5);
            this.a(var1, var19, 6, 8, 8, var5);
            this.a(var1, var19, 7, 8, 6, var5);
            this.a(var1, var19, 7, 8, 8, var5);
         }

         this.a(var1, var5, var4, 3, 3, 5, cyq.w);
         if (this.a) {
            this.a(var1, m, 12, 9, 1, var5);
            this.a(var1, var5, var4, 12, 8, 1, cyq.w);
         }

         return true;
      }
   }

   public static class h extends crs.p {
      public h(int var1, Random var2, cra var3, gc var4) {
         super(clb.z, var1);
         this.a(var4);
         this.d = this.a(var2);
         this.n = var3;
      }

      public h(csw var1, md var2) {
         super(clb.z, var2);
      }

      public void a(cru var1, List<cru> var2, Random var3) {
         this.a((crs.m)var1, var2, var3, 1, 1);
      }

      public static crs.h a(List<cru> var0, Random var1, int var2, int var3, int var4, gc var5, int var6) {
         cra var7 = cra.a(var2, var3, var4, -1, -1, 0, 9, 5, 11, var5);
         return a(var7) && cru.a(var0, var7) == null ? new crs.h(var6, var1, var7, var5) : null;
      }

      public boolean a(bsr var1, bsn var2, cfy var3, Random var4, cra var5, brd var6, fx var7) {
         this.a(var1, var5, 0, 0, 0, 8, 4, 10, true, var4, crs.e);
         this.a(var1, var4, var5, this.d, 1, 1, 0);
         this.a(var1, var5, 1, 1, 10, 3, 3, 10, m, m, false);
         this.a(var1, var5, 4, 1, 1, 4, 3, 1, false, var4, crs.e);
         this.a(var1, var5, 4, 1, 3, 4, 3, 3, false, var4, crs.e);
         this.a(var1, var5, 4, 1, 7, 4, 3, 7, false, var4, crs.e);
         this.a(var1, var5, 4, 1, 9, 4, 3, 9, false, var4, crs.e);

         for(int var8 = 1; var8 <= 3; ++var8) {
            this.a(var1, (ceh)((ceh)bup.dH.n().a(bxq.a, true)).a(bxq.c, true), 4, var8, 4, var5);
            this.a(var1, (ceh)((ceh)((ceh)bup.dH.n().a(bxq.a, true)).a(bxq.c, true)).a(bxq.b, true), 4, var8, 5, var5);
            this.a(var1, (ceh)((ceh)bup.dH.n().a(bxq.a, true)).a(bxq.c, true), 4, var8, 6, var5);
            this.a(var1, (ceh)((ceh)bup.dH.n().a(bxq.d, true)).a(bxq.b, true), 5, var8, 5, var5);
            this.a(var1, (ceh)((ceh)bup.dH.n().a(bxq.d, true)).a(bxq.b, true), 6, var8, 5, var5);
            this.a(var1, (ceh)((ceh)bup.dH.n().a(bxq.d, true)).a(bxq.b, true), 7, var8, 5, var5);
         }

         this.a(var1, (ceh)((ceh)bup.dH.n().a(bxq.a, true)).a(bxq.c, true), 4, 3, 2, var5);
         this.a(var1, (ceh)((ceh)bup.dH.n().a(bxq.a, true)).a(bxq.c, true), 4, 3, 8, var5);
         ceh var10 = (ceh)bup.cr.n().a(bwb.a, gc.e);
         ceh var9 = (ceh)((ceh)bup.cr.n().a(bwb.a, gc.e)).a(bwb.e, cfd.a);
         this.a(var1, var10, 4, 1, 2, var5);
         this.a(var1, var9, 4, 2, 2, var5);
         this.a(var1, var10, 4, 1, 8, var5);
         this.a(var1, var9, 4, 2, 8, var5);
         return true;
      }
   }

   public static class j extends crs.p {
      protected final int a;

      public j(int var1, Random var2, cra var3, gc var4) {
         super(clb.B, var1);
         this.a(var4);
         this.d = this.a(var2);
         this.n = var3;
         this.a = var2.nextInt(5);
      }

      public j(csw var1, md var2) {
         super(clb.B, var2);
         this.a = var2.h("Type");
      }

      protected void a(md var1) {
         super.a(var1);
         var1.b("Type", this.a);
      }

      public void a(cru var1, List<cru> var2, Random var3) {
         this.a((crs.m)var1, var2, var3, 4, 1);
         this.b((crs.m)var1, var2, var3, 1, 4);
         this.c((crs.m)var1, var2, var3, 1, 4);
      }

      public static crs.j a(List<cru> var0, Random var1, int var2, int var3, int var4, gc var5, int var6) {
         cra var7 = cra.a(var2, var3, var4, -4, -1, 0, 11, 7, 11, var5);
         return a(var7) && cru.a(var0, var7) == null ? new crs.j(var6, var1, var7, var5) : null;
      }

      public boolean a(bsr var1, bsn var2, cfy var3, Random var4, cra var5, brd var6, fx var7) {
         this.a(var1, var5, 0, 0, 0, 10, 6, 10, true, var4, crs.e);
         this.a(var1, var4, var5, this.d, 4, 1, 0);
         this.a(var1, var5, 4, 1, 10, 6, 3, 10, m, m, false);
         this.a(var1, var5, 0, 1, 4, 0, 3, 6, m, m, false);
         this.a(var1, var5, 10, 1, 4, 10, 3, 6, m, m, false);
         int var8;
         switch(this.a) {
         case 0:
            this.a(var1, bup.du.n(), 5, 1, 5, var5);
            this.a(var1, bup.du.n(), 5, 2, 5, var5);
            this.a(var1, bup.du.n(), 5, 3, 5, var5);
            this.a(var1, (ceh)bup.bM.n().a(cbn.a, gc.e), 4, 3, 5, var5);
            this.a(var1, (ceh)bup.bM.n().a(cbn.a, gc.f), 6, 3, 5, var5);
            this.a(var1, (ceh)bup.bM.n().a(cbn.a, gc.d), 5, 3, 4, var5);
            this.a(var1, (ceh)bup.bM.n().a(cbn.a, gc.c), 5, 3, 6, var5);
            this.a(var1, bup.hR.n(), 4, 1, 4, var5);
            this.a(var1, bup.hR.n(), 4, 1, 5, var5);
            this.a(var1, bup.hR.n(), 4, 1, 6, var5);
            this.a(var1, bup.hR.n(), 6, 1, 4, var5);
            this.a(var1, bup.hR.n(), 6, 1, 5, var5);
            this.a(var1, bup.hR.n(), 6, 1, 6, var5);
            this.a(var1, bup.hR.n(), 5, 1, 4, var5);
            this.a(var1, bup.hR.n(), 5, 1, 6, var5);
            break;
         case 1:
            for(var8 = 0; var8 < 5; ++var8) {
               this.a(var1, bup.du.n(), 3, 1, 3 + var8, var5);
               this.a(var1, bup.du.n(), 7, 1, 3 + var8, var5);
               this.a(var1, bup.du.n(), 3 + var8, 1, 3, var5);
               this.a(var1, bup.du.n(), 3 + var8, 1, 7, var5);
            }

            this.a(var1, bup.du.n(), 5, 1, 5, var5);
            this.a(var1, bup.du.n(), 5, 2, 5, var5);
            this.a(var1, bup.du.n(), 5, 3, 5, var5);
            this.a(var1, bup.A.n(), 5, 4, 5, var5);
            break;
         case 2:
            for(var8 = 1; var8 <= 9; ++var8) {
               this.a(var1, bup.m.n(), 1, 3, var8, var5);
               this.a(var1, bup.m.n(), 9, 3, var8, var5);
            }

            for(var8 = 1; var8 <= 9; ++var8) {
               this.a(var1, bup.m.n(), var8, 3, 1, var5);
               this.a(var1, bup.m.n(), var8, 3, 9, var5);
            }

            this.a(var1, bup.m.n(), 5, 1, 4, var5);
            this.a(var1, bup.m.n(), 5, 1, 6, var5);
            this.a(var1, bup.m.n(), 5, 3, 4, var5);
            this.a(var1, bup.m.n(), 5, 3, 6, var5);
            this.a(var1, bup.m.n(), 4, 1, 5, var5);
            this.a(var1, bup.m.n(), 6, 1, 5, var5);
            this.a(var1, bup.m.n(), 4, 3, 5, var5);
            this.a(var1, bup.m.n(), 6, 3, 5, var5);

            for(var8 = 1; var8 <= 3; ++var8) {
               this.a(var1, bup.m.n(), 4, var8, 4, var5);
               this.a(var1, bup.m.n(), 6, var8, 4, var5);
               this.a(var1, bup.m.n(), 4, var8, 6, var5);
               this.a(var1, bup.m.n(), 6, var8, 6, var5);
            }

            this.a(var1, bup.bL.n(), 5, 3, 5, var5);

            for(var8 = 2; var8 <= 8; ++var8) {
               this.a(var1, bup.n.n(), 2, 3, var8, var5);
               this.a(var1, bup.n.n(), 3, 3, var8, var5);
               if (var8 <= 3 || var8 >= 7) {
                  this.a(var1, bup.n.n(), 4, 3, var8, var5);
                  this.a(var1, bup.n.n(), 5, 3, var8, var5);
                  this.a(var1, bup.n.n(), 6, 3, var8, var5);
               }

               this.a(var1, bup.n.n(), 7, 3, var8, var5);
               this.a(var1, bup.n.n(), 8, 3, var8, var5);
            }

            ceh var9 = (ceh)bup.cg.n().a(bxv.a, gc.e);
            this.a(var1, var9, 9, 1, 3, var5);
            this.a(var1, var9, 9, 2, 3, var5);
            this.a(var1, var9, 9, 3, 3, var5);
            this.a(var1, var5, var4, 3, 4, 8, cyq.x);
         }

         return true;
      }
   }

   public static class i extends crs.q {
      public i(int var1, Random var2, cra var3, gc var4) {
         super(clb.A, var1);
         this.a(var4);
         this.d = this.a(var2);
         this.n = var3;
      }

      public i(csw var1, md var2) {
         super(clb.A, var2);
      }

      public void a(cru var1, List<cru> var2, Random var3) {
         gc var4 = this.i();
         if (var4 != gc.c && var4 != gc.f) {
            this.b((crs.m)var1, var2, var3, 1, 1);
         } else {
            this.c((crs.m)var1, var2, var3, 1, 1);
         }

      }

      public static crs.i a(List<cru> var0, Random var1, int var2, int var3, int var4, gc var5, int var6) {
         cra var7 = cra.a(var2, var3, var4, -1, -1, 0, 5, 5, 5, var5);
         return a(var7) && cru.a(var0, var7) == null ? new crs.i(var6, var1, var7, var5) : null;
      }

      public boolean a(bsr var1, bsn var2, cfy var3, Random var4, cra var5, brd var6, fx var7) {
         this.a(var1, var5, 0, 0, 0, 4, 4, 4, true, var4, crs.e);
         this.a(var1, var4, var5, this.d, 1, 1, 0);
         gc var8 = this.i();
         if (var8 != gc.c && var8 != gc.f) {
            this.a(var1, var5, 0, 1, 1, 0, 3, 3, m, m, false);
         } else {
            this.a(var1, var5, 4, 1, 1, 4, 3, 3, m, m, false);
         }

         return true;
      }
   }

   public static class d extends crs.q {
      public d(int var1, Random var2, cra var3, gc var4) {
         super(clb.w, var1);
         this.a(var4);
         this.d = this.a(var2);
         this.n = var3;
      }

      public d(csw var1, md var2) {
         super(clb.w, var2);
      }

      public void a(cru var1, List<cru> var2, Random var3) {
         gc var4 = this.i();
         if (var4 != gc.c && var4 != gc.f) {
            this.c((crs.m)var1, var2, var3, 1, 1);
         } else {
            this.b((crs.m)var1, var2, var3, 1, 1);
         }

      }

      public static crs.d a(List<cru> var0, Random var1, int var2, int var3, int var4, gc var5, int var6) {
         cra var7 = cra.a(var2, var3, var4, -1, -1, 0, 5, 5, 5, var5);
         return a(var7) && cru.a(var0, var7) == null ? new crs.d(var6, var1, var7, var5) : null;
      }

      public boolean a(bsr var1, bsn var2, cfy var3, Random var4, cra var5, brd var6, fx var7) {
         this.a(var1, var5, 0, 0, 0, 4, 4, 4, true, var4, crs.e);
         this.a(var1, var4, var5, this.d, 1, 1, 0);
         gc var8 = this.i();
         if (var8 != gc.c && var8 != gc.f) {
            this.a(var1, var5, 4, 1, 1, 4, 3, 3, m, m, false);
         } else {
            this.a(var1, var5, 0, 1, 1, 0, 3, 3, m, m, false);
         }

         return true;
      }
   }

   public abstract static class q extends crs.p {
      protected q(clb var1, int var2) {
         super(var1, var2);
      }

      public q(clb var1, md var2) {
         super(var1, var2);
      }
   }

   public static class o extends crs.p {
      public o(int var1, Random var2, cra var3, gc var4) {
         super(clb.F, var1);
         this.a(var4);
         this.d = this.a(var2);
         this.n = var3;
      }

      public o(csw var1, md var2) {
         super(clb.F, var2);
      }

      public void a(cru var1, List<cru> var2, Random var3) {
         this.a((crs.m)var1, var2, var3, 1, 1);
      }

      public static crs.o a(List<cru> var0, Random var1, int var2, int var3, int var4, gc var5, int var6) {
         cra var7 = cra.a(var2, var3, var4, -1, -7, 0, 5, 11, 8, var5);
         return a(var7) && cru.a(var0, var7) == null ? new crs.o(var6, var1, var7, var5) : null;
      }

      public boolean a(bsr var1, bsn var2, cfy var3, Random var4, cra var5, brd var6, fx var7) {
         this.a(var1, var5, 0, 0, 0, 4, 10, 7, true, var4, crs.e);
         this.a(var1, var4, var5, this.d, 1, 7, 0);
         this.a(var1, var4, var5, crs.p.a.a, 1, 1, 7);
         ceh var8 = (ceh)bup.ci.n().a(cak.a, gc.d);

         for(int var9 = 0; var9 < 6; ++var9) {
            this.a(var1, var8, 1, 6 - var9, 1 + var9, var5);
            this.a(var1, var8, 2, 6 - var9, 1 + var9, var5);
            this.a(var1, var8, 3, 6 - var9, 1 + var9, var5);
            if (var9 < 5) {
               this.a(var1, bup.du.n(), 1, 5 - var9, 1 + var9, var5);
               this.a(var1, bup.du.n(), 2, 5 - var9, 1 + var9, var5);
               this.a(var1, bup.du.n(), 3, 5 - var9, 1 + var9, var5);
            }
         }

         return true;
      }
   }

   public static class a extends crs.p {
      private boolean a;

      public a(int var1, Random var2, cra var3, gc var4) {
         super(clb.t, var1);
         this.a(var4);
         this.d = this.a(var2);
         this.n = var3;
      }

      public a(csw var1, md var2) {
         super(clb.t, var2);
         this.a = var2.q("Chest");
      }

      protected void a(md var1) {
         super.a(var1);
         var1.a("Chest", this.a);
      }

      public void a(cru var1, List<cru> var2, Random var3) {
         this.a((crs.m)var1, var2, var3, 1, 1);
      }

      public static crs.a a(List<cru> var0, Random var1, int var2, int var3, int var4, gc var5, int var6) {
         cra var7 = cra.a(var2, var3, var4, -1, -1, 0, 5, 5, 7, var5);
         return a(var7) && cru.a(var0, var7) == null ? new crs.a(var6, var1, var7, var5) : null;
      }

      public boolean a(bsr var1, bsn var2, cfy var3, Random var4, cra var5, brd var6, fx var7) {
         this.a(var1, var5, 0, 0, 0, 4, 4, 6, true, var4, crs.e);
         this.a(var1, var4, var5, this.d, 1, 1, 0);
         this.a(var1, var4, var5, crs.p.a.a, 1, 1, 6);
         this.a(var1, var5, 3, 1, 2, 3, 1, 4, bup.du.n(), bup.du.n(), false);
         this.a(var1, bup.hX.n(), 3, 1, 1, var5);
         this.a(var1, bup.hX.n(), 3, 1, 5, var5);
         this.a(var1, bup.hX.n(), 3, 2, 2, var5);
         this.a(var1, bup.hX.n(), 3, 2, 4, var5);

         for(int var8 = 2; var8 <= 4; ++var8) {
            this.a(var1, bup.hX.n(), 2, 1, var8, var5);
         }

         if (!this.a && var5.b((gr)(new fx(this.a(3, 3), this.d(2), this.b(3, 3))))) {
            this.a = true;
            this.a(var1, var5, var4, 3, 2, 3, cyq.y);
         }

         return true;
      }
   }

   public static class n extends crs.p {
      private final boolean a;
      private final boolean b;

      public n(int var1, Random var2, cra var3, gc var4) {
         super(clb.E, var1);
         this.a(var4);
         this.d = this.a(var2);
         this.n = var3;
         this.a = var2.nextInt(2) == 0;
         this.b = var2.nextInt(2) == 0;
      }

      public n(csw var1, md var2) {
         super(clb.E, var2);
         this.a = var2.q("Left");
         this.b = var2.q("Right");
      }

      protected void a(md var1) {
         super.a(var1);
         var1.a("Left", this.a);
         var1.a("Right", this.b);
      }

      public void a(cru var1, List<cru> var2, Random var3) {
         this.a((crs.m)var1, var2, var3, 1, 1);
         if (this.a) {
            this.b((crs.m)var1, var2, var3, 1, 2);
         }

         if (this.b) {
            this.c((crs.m)var1, var2, var3, 1, 2);
         }

      }

      public static crs.n a(List<cru> var0, Random var1, int var2, int var3, int var4, gc var5, int var6) {
         cra var7 = cra.a(var2, var3, var4, -1, -1, 0, 5, 5, 7, var5);
         return a(var7) && cru.a(var0, var7) == null ? new crs.n(var6, var1, var7, var5) : null;
      }

      public boolean a(bsr var1, bsn var2, cfy var3, Random var4, cra var5, brd var6, fx var7) {
         this.a(var1, var5, 0, 0, 0, 4, 4, 6, true, var4, crs.e);
         this.a(var1, var4, var5, this.d, 1, 1, 0);
         this.a(var1, var4, var5, crs.p.a.a, 1, 1, 6);
         ceh var8 = (ceh)bup.bM.n().a(cbn.a, gc.f);
         ceh var9 = (ceh)bup.bM.n().a(cbn.a, gc.e);
         this.a(var1, var5, var4, 0.1F, 1, 2, 1, var8);
         this.a(var1, var5, var4, 0.1F, 3, 2, 1, var9);
         this.a(var1, var5, var4, 0.1F, 1, 2, 5, var8);
         this.a(var1, var5, var4, 0.1F, 3, 2, 5, var9);
         if (this.a) {
            this.a(var1, var5, 0, 1, 2, 0, 3, 4, m, m, false);
         }

         if (this.b) {
            this.a(var1, var5, 4, 1, 2, 4, 3, 4, m, m, false);
         }

         return true;
      }
   }

   public static class m extends crs.l {
      public crs.f a;
      @Nullable
      public crs.g b;
      public final List<cru> c = Lists.newArrayList();

      public m(Random var1, int var2, int var3) {
         super(clb.D, 0, var1, var2, var3);
      }

      public m(csw var1, md var2) {
         super(clb.D, var2);
      }
   }

   public static class l extends crs.p {
      private final boolean a;

      public l(clb var1, int var2, Random var3, int var4, int var5) {
         super(var1, var2);
         this.a = true;
         this.a(gc.c.a.a(var3));
         this.d = crs.p.a.a;
         if (this.i().n() == gc.a.c) {
            this.n = new cra(var4, 64, var5, var4 + 5 - 1, 74, var5 + 5 - 1);
         } else {
            this.n = new cra(var4, 64, var5, var4 + 5 - 1, 74, var5 + 5 - 1);
         }

      }

      public l(int var1, Random var2, cra var3, gc var4) {
         super(clb.C, var1);
         this.a = false;
         this.a(var4);
         this.d = this.a(var2);
         this.n = var3;
      }

      public l(clb var1, md var2) {
         super(var1, var2);
         this.a = var2.q("Source");
      }

      public l(csw var1, md var2) {
         this(clb.C, var2);
      }

      protected void a(md var1) {
         super.a(var1);
         var1.a("Source", this.a);
      }

      public void a(cru var1, List<cru> var2, Random var3) {
         if (this.a) {
            crs.c = crs.c.class;
         }

         this.a((crs.m)var1, var2, var3, 1, 1);
      }

      public static crs.l a(List<cru> var0, Random var1, int var2, int var3, int var4, gc var5, int var6) {
         cra var7 = cra.a(var2, var3, var4, -1, -7, 0, 5, 11, 5, var5);
         return a(var7) && cru.a(var0, var7) == null ? new crs.l(var6, var1, var7, var5) : null;
      }

      public boolean a(bsr var1, bsn var2, cfy var3, Random var4, cra var5, brd var6, fx var7) {
         this.a(var1, var5, 0, 0, 0, 4, 10, 4, true, var4, crs.e);
         this.a(var1, var4, var5, this.d, 1, 7, 0);
         this.a(var1, var4, var5, crs.p.a.a, 1, 1, 4);
         this.a(var1, bup.du.n(), 2, 6, 1, var5);
         this.a(var1, bup.du.n(), 1, 5, 1, var5);
         this.a(var1, bup.hR.n(), 1, 6, 1, var5);
         this.a(var1, bup.du.n(), 1, 5, 2, var5);
         this.a(var1, bup.du.n(), 1, 4, 3, var5);
         this.a(var1, bup.hR.n(), 1, 5, 3, var5);
         this.a(var1, bup.du.n(), 2, 4, 3, var5);
         this.a(var1, bup.du.n(), 3, 3, 3, var5);
         this.a(var1, bup.hR.n(), 3, 4, 3, var5);
         this.a(var1, bup.du.n(), 3, 3, 2, var5);
         this.a(var1, bup.du.n(), 3, 2, 1, var5);
         this.a(var1, bup.hR.n(), 3, 3, 1, var5);
         this.a(var1, bup.du.n(), 2, 2, 1, var5);
         this.a(var1, bup.du.n(), 1, 1, 1, var5);
         this.a(var1, bup.hR.n(), 1, 2, 1, var5);
         this.a(var1, bup.du.n(), 1, 1, 2, var5);
         this.a(var1, bup.hR.n(), 1, 1, 3, var5);
         return true;
      }
   }

   public static class b extends crs.p {
      private final int a;

      public b(int var1, cra var2, gc var3) {
         super(clb.u, var1);
         this.a(var3);
         this.n = var2;
         this.a = var3 != gc.c && var3 != gc.d ? var2.d() : var2.f();
      }

      public b(csw var1, md var2) {
         super(clb.u, var2);
         this.a = var2.h("Steps");
      }

      protected void a(md var1) {
         super.a(var1);
         var1.b("Steps", this.a);
      }

      public static cra a(List<cru> var0, Random var1, int var2, int var3, int var4, gc var5) {
         int var6 = true;
         cra var7 = cra.a(var2, var3, var4, -1, -1, 0, 5, 5, 4, var5);
         cru var8 = cru.a(var0, var7);
         if (var8 == null) {
            return null;
         } else {
            if (var8.g().b == var7.b) {
               for(int var9 = 3; var9 >= 1; --var9) {
                  var7 = cra.a(var2, var3, var4, -1, -1, 0, 5, 5, var9 - 1, var5);
                  if (!var8.g().b(var7)) {
                     return cra.a(var2, var3, var4, -1, -1, 0, 5, 5, var9, var5);
                  }
               }
            }

            return null;
         }
      }

      public boolean a(bsr var1, bsn var2, cfy var3, Random var4, cra var5, brd var6, fx var7) {
         for(int var8 = 0; var8 < this.a; ++var8) {
            this.a(var1, bup.du.n(), 0, 0, var8, var5);
            this.a(var1, bup.du.n(), 1, 0, var8, var5);
            this.a(var1, bup.du.n(), 2, 0, var8, var5);
            this.a(var1, bup.du.n(), 3, 0, var8, var5);
            this.a(var1, bup.du.n(), 4, 0, var8, var5);

            for(int var9 = 1; var9 <= 3; ++var9) {
               this.a(var1, bup.du.n(), 0, var9, var8, var5);
               this.a(var1, bup.lb.n(), 1, var9, var8, var5);
               this.a(var1, bup.lb.n(), 2, var9, var8, var5);
               this.a(var1, bup.lb.n(), 3, var9, var8, var5);
               this.a(var1, bup.du.n(), 4, var9, var8, var5);
            }

            this.a(var1, bup.du.n(), 0, 4, var8, var5);
            this.a(var1, bup.du.n(), 1, 4, var8, var5);
            this.a(var1, bup.du.n(), 2, 4, var8, var5);
            this.a(var1, bup.du.n(), 3, 4, var8, var5);
            this.a(var1, bup.du.n(), 4, 4, var8, var5);
         }

         return true;
      }
   }

   abstract static class p extends cru {
      protected crs.p.a d;

      protected p(clb var1, int var2) {
         super(var1, var2);
         this.d = crs.p.a.a;
      }

      public p(clb var1, md var2) {
         super(var1, var2);
         this.d = crs.p.a.a;
         this.d = crs.p.a.valueOf(var2.l("EntryDoor"));
      }

      protected void a(md var1) {
         var1.a("EntryDoor", this.d.name());
      }

      protected void a(bsr var1, Random var2, cra var3, crs.p.a var4, int var5, int var6, int var7) {
         switch(var4) {
         case a:
            this.a(var1, var3, var5, var6, var7, var5 + 3 - 1, var6 + 3 - 1, var7, m, m, false);
            break;
         case b:
            this.a(var1, bup.du.n(), var5, var6, var7, var3);
            this.a(var1, bup.du.n(), var5, var6 + 1, var7, var3);
            this.a(var1, bup.du.n(), var5, var6 + 2, var7, var3);
            this.a(var1, bup.du.n(), var5 + 1, var6 + 2, var7, var3);
            this.a(var1, bup.du.n(), var5 + 2, var6 + 2, var7, var3);
            this.a(var1, bup.du.n(), var5 + 2, var6 + 1, var7, var3);
            this.a(var1, bup.du.n(), var5 + 2, var6, var7, var3);
            this.a(var1, bup.cf.n(), var5 + 1, var6, var7, var3);
            this.a(var1, (ceh)bup.cf.n().a(bwb.e, cfd.a), var5 + 1, var6 + 1, var7, var3);
            break;
         case c:
            this.a(var1, bup.lb.n(), var5 + 1, var6, var7, var3);
            this.a(var1, bup.lb.n(), var5 + 1, var6 + 1, var7, var3);
            this.a(var1, (ceh)bup.dH.n().a(bxq.d, true), var5, var6, var7, var3);
            this.a(var1, (ceh)bup.dH.n().a(bxq.d, true), var5, var6 + 1, var7, var3);
            this.a(var1, (ceh)((ceh)bup.dH.n().a(bxq.b, true)).a(bxq.d, true), var5, var6 + 2, var7, var3);
            this.a(var1, (ceh)((ceh)bup.dH.n().a(bxq.b, true)).a(bxq.d, true), var5 + 1, var6 + 2, var7, var3);
            this.a(var1, (ceh)((ceh)bup.dH.n().a(bxq.b, true)).a(bxq.d, true), var5 + 2, var6 + 2, var7, var3);
            this.a(var1, (ceh)bup.dH.n().a(bxq.b, true), var5 + 2, var6 + 1, var7, var3);
            this.a(var1, (ceh)bup.dH.n().a(bxq.b, true), var5 + 2, var6, var7, var3);
            break;
         case d:
            this.a(var1, bup.du.n(), var5, var6, var7, var3);
            this.a(var1, bup.du.n(), var5, var6 + 1, var7, var3);
            this.a(var1, bup.du.n(), var5, var6 + 2, var7, var3);
            this.a(var1, bup.du.n(), var5 + 1, var6 + 2, var7, var3);
            this.a(var1, bup.du.n(), var5 + 2, var6 + 2, var7, var3);
            this.a(var1, bup.du.n(), var5 + 2, var6 + 1, var7, var3);
            this.a(var1, bup.du.n(), var5 + 2, var6, var7, var3);
            this.a(var1, bup.cr.n(), var5 + 1, var6, var7, var3);
            this.a(var1, (ceh)bup.cr.n().a(bwb.e, cfd.a), var5 + 1, var6 + 1, var7, var3);
            this.a(var1, (ceh)bup.cB.n().a(buv.aq, gc.c), var5 + 2, var6 + 1, var7 + 1, var3);
            this.a(var1, (ceh)bup.cB.n().a(buv.aq, gc.d), var5 + 2, var6 + 1, var7 - 1, var3);
         }

      }

      protected crs.p.a a(Random var1) {
         int var2 = var1.nextInt(5);
         switch(var2) {
         case 0:
         case 1:
         default:
            return crs.p.a.a;
         case 2:
            return crs.p.a.b;
         case 3:
            return crs.p.a.c;
         case 4:
            return crs.p.a.d;
         }
      }

      @Nullable
      protected cru a(crs.m var1, List<cru> var2, Random var3, int var4, int var5) {
         gc var6 = this.i();
         if (var6 != null) {
            switch(var6) {
            case c:
               return crs.c(var1, var2, var3, this.n.a + var4, this.n.b + var5, this.n.c - 1, var6, this.h());
            case d:
               return crs.c(var1, var2, var3, this.n.a + var4, this.n.b + var5, this.n.f + 1, var6, this.h());
            case e:
               return crs.c(var1, var2, var3, this.n.a - 1, this.n.b + var5, this.n.c + var4, var6, this.h());
            case f:
               return crs.c(var1, var2, var3, this.n.d + 1, this.n.b + var5, this.n.c + var4, var6, this.h());
            }
         }

         return null;
      }

      @Nullable
      protected cru b(crs.m var1, List<cru> var2, Random var3, int var4, int var5) {
         gc var6 = this.i();
         if (var6 != null) {
            switch(var6) {
            case c:
               return crs.c(var1, var2, var3, this.n.a - 1, this.n.b + var4, this.n.c + var5, gc.e, this.h());
            case d:
               return crs.c(var1, var2, var3, this.n.a - 1, this.n.b + var4, this.n.c + var5, gc.e, this.h());
            case e:
               return crs.c(var1, var2, var3, this.n.a + var5, this.n.b + var4, this.n.c - 1, gc.c, this.h());
            case f:
               return crs.c(var1, var2, var3, this.n.a + var5, this.n.b + var4, this.n.c - 1, gc.c, this.h());
            }
         }

         return null;
      }

      @Nullable
      protected cru c(crs.m var1, List<cru> var2, Random var3, int var4, int var5) {
         gc var6 = this.i();
         if (var6 != null) {
            switch(var6) {
            case c:
               return crs.c(var1, var2, var3, this.n.d + 1, this.n.b + var4, this.n.c + var5, gc.f, this.h());
            case d:
               return crs.c(var1, var2, var3, this.n.d + 1, this.n.b + var4, this.n.c + var5, gc.f, this.h());
            case e:
               return crs.c(var1, var2, var3, this.n.a + var5, this.n.b + var4, this.n.f + 1, gc.d, this.h());
            case f:
               return crs.c(var1, var2, var3, this.n.a + var5, this.n.b + var4, this.n.f + 1, gc.d, this.h());
            }
         }

         return null;
      }

      protected static boolean a(cra var0) {
         return var0 != null && var0.b > 10;
      }

      public static enum a {
         a,
         b,
         c,
         d;
      }
   }

   static class f {
      public final Class<? extends crs.p> a;
      public final int b;
      public int c;
      public final int d;

      public f(Class<? extends crs.p> var1, int var2, int var3) {
         this.a = var1;
         this.b = var2;
         this.d = var3;
      }

      public boolean a(int var1) {
         return this.d == 0 || this.c < this.d;
      }

      public boolean a() {
         return this.d == 0 || this.c < this.d;
      }
   }
}
