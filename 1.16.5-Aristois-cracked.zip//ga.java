public class ga {
   private int a;
   private int b;
   private int c;
   private int d;
   private int e;
   private int f;
   private int g;
   private int h;
   private int i;
   private int j;
   private int k;

   public ga(int var1, int var2, int var3, int var4, int var5, int var6) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4 - var1 + 1;
      this.e = var5 - var2 + 1;
      this.f = var6 - var3 + 1;
      this.g = this.d * this.e * this.f;
   }

   public boolean a() {
      if (this.h == this.g) {
         return false;
      } else {
         this.i = this.h % this.d;
         int var1 = this.h / this.d;
         this.j = var1 % this.e;
         this.k = var1 / this.e;
         ++this.h;
         return true;
      }
   }

   public int b() {
      return this.a + this.i;
   }

   public int c() {
      return this.b + this.j;
   }

   public int d() {
      return this.c + this.k;
   }

   public int e() {
      int var1 = 0;
      if (this.i == 0 || this.i == this.d - 1) {
         ++var1;
      }

      if (this.j == 0 || this.j == this.e - 1) {
         ++var1;
      }

      if (this.k == 0 || this.k == this.f - 1) {
         ++var1;
      }

      return var1;
   }
}
