import java.util.UUID;
import net.minecraft.server.MinecraftServer;

public class adg implements da {
   private static final oe b = new oe("Rcon");
   private final StringBuffer c = new StringBuffer();
   private final MinecraftServer d;

   public adg(MinecraftServer var1) {
      this.d = var1;
   }

   public void d() {
      this.c.setLength(0);
   }

   public String e() {
      return this.c.toString();
   }

   public db f() {
      aag var1 = this.d.E();
      return new db(this, dcn.b((gr)var1.u()), dcm.a, var1, 4, "Rcon", b, this.d, (aqa)null);
   }

   public void a(nr var1, UUID var2) {
      this.c.append(var1.getString());
   }

   public boolean a() {
      return true;
   }

   public boolean b() {
      return true;
   }

   public boolean R_() {
      return this.d.i();
   }
}
