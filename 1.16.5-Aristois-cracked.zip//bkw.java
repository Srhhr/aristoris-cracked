public class bkw extends bkh {
   public bkw(buo var1, blx.a var2) {
      super(var1, var2);
   }

   protected boolean a(bny var1, ceh var2) {
      var1.p().a(var1.a().b(), bup.a.n(), 27);
      return super.a(var1, var2);
   }
}
