import com.google.gson.JsonObject;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;

public class fq implements fj<IntegerArgumentType> {
   public void a(IntegerArgumentType var1, nf var2) {
      boolean var3 = var1.getMinimum() != Integer.MIN_VALUE;
      boolean var4 = var1.getMaximum() != Integer.MAX_VALUE;
      var2.writeByte(fn.a(var3, var4));
      if (var3) {
         var2.writeInt(var1.getMinimum());
      }

      if (var4) {
         var2.writeInt(var1.getMaximum());
      }

   }

   public IntegerArgumentType a(nf var1) {
      byte var2 = var1.readByte();
      int var3 = fn.a(var2) ? var1.readInt() : Integer.MIN_VALUE;
      int var4 = fn.b(var2) ? var1.readInt() : Integer.MAX_VALUE;
      return IntegerArgumentType.integer(var3, var4);
   }

   public void a(IntegerArgumentType var1, JsonObject var2) {
      if (var1.getMinimum() != Integer.MIN_VALUE) {
         var2.addProperty("min", var1.getMinimum());
      }

      if (var1.getMaximum() != Integer.MAX_VALUE) {
         var2.addProperty("max", var1.getMaximum());
      }

   }

   // $FF: synthetic method
   public ArgumentType b(nf var1) {
      return this.a(var1);
   }
}
