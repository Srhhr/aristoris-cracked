import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.annotation.Nullable;

public class wh {
   public static final Pattern a = Pattern.compile("^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])$");
   private static final SimpleCommandExceptionType b = new SimpleCommandExceptionType(new of("commands.banip.invalid"));
   private static final SimpleCommandExceptionType c = new SimpleCommandExceptionType(new of("commands.banip.failed"));

   public static void a(CommandDispatcher<db> var0) {
      var0.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)dc.a("ban-ip").requires((var0x) -> {
         return var0x.c(3);
      })).then(((RequiredArgumentBuilder)dc.a((String)"target", (ArgumentType)StringArgumentType.word()).executes((var0x) -> {
         return a((db)var0x.getSource(), StringArgumentType.getString(var0x, "target"), (nr)null);
      })).then(dc.a((String)"reason", (ArgumentType)dp.a()).executes((var0x) -> {
         return a((db)var0x.getSource(), StringArgumentType.getString(var0x, "target"), dp.a(var0x, "reason"));
      }))));
   }

   private static int a(db var0, String var1, @Nullable nr var2) throws CommandSyntaxException {
      Matcher var3 = a.matcher(var1);
      if (var3.matches()) {
         return b(var0, var1, var2);
      } else {
         aah var4 = var0.j().ae().a(var1);
         if (var4 != null) {
            return b(var0, var4.v(), var2);
         } else {
            throw b.create();
         }
      }
   }

   private static int b(db var0, String var1, @Nullable nr var2) throws CommandSyntaxException {
      acr var3 = var0.j().ae().g();
      if (var3.a(var1)) {
         throw c.create();
      } else {
         List<aah> var4 = var0.j().ae().b(var1);
         acs var5 = new acs(var1, (Date)null, var0.c(), (Date)null, var2 == null ? null : var2.getString());
         var3.a((acx)var5);
         var0.a(new of("commands.banip.success", new Object[]{var1, var5.d()}), true);
         if (!var4.isEmpty()) {
            var0.a(new of("commands.banip.info", new Object[]{var4.size(), fc.a(var4)}), true);
         }

         Iterator var6 = var4.iterator();

         while(var6.hasNext()) {
            aah var7 = (aah)var6.next();
            var7.b.b((nr)(new of("multiplayer.disconnect.ip_banned")));
         }

         return var4.size();
      }
   }
}
