import com.mojang.serialization.Codec;

public abstract class cpy<DC extends clw> extends cqc<DC> {
   public cpy(Codec<DC> var1) {
      super(var1);
   }

   protected abstract chn.a a(DC var1);
}
