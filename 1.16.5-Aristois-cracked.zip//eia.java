public class eia extends eit<dzj, dvd<dzj>> {
   public eia(egk<dzj, dvd<dzj>> var1) {
      super(var1);
   }

   public void a(dfm var1, eag var2, int var3, dzj var4, float var5, float var6, float var7, float var8, float var9, float var10) {
      if ("deadmau5".equals(var4.R().getString()) && var4.n() && !var4.bF()) {
         dfq var11 = var2.getBuffer(eao.b(var4.o()));
         int var12 = efr.c(var4, 0.0F);

         for(int var13 = 0; var13 < 2; ++var13) {
            float var14 = afm.g(var7, var4.r, var4.p) - afm.g(var7, var4.aB, var4.aA);
            float var15 = afm.g(var7, var4.s, var4.q);
            var1.a();
            var1.a(g.d.a(var14));
            var1.a(g.b.a(var15));
            var1.a((double)(0.375F * (float)(var13 * 2 - 1)), 0.0D, 0.0D);
            var1.a(0.0D, -0.375D, 0.0D);
            var1.a(g.b.a(-var15));
            var1.a(g.d.a(-var14));
            float var16 = 1.3333334F;
            var1.a(1.3333334F, 1.3333334F, 1.3333334F);
            ((dvd)this.aC_()).a(var1, var11, var3, var12);
            var1.b();
         }

      }
   }
}
