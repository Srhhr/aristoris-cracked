public class dtq<T extends bba> extends duk<T> {
   private final dwn f = new dwn(this, 26, 21);
   private final dwn g;

   public dtq(float var1) {
      super(var1);
      this.f.a(-4.0F, 0.0F, -2.0F, 8.0F, 8.0F, 3.0F);
      this.g = new dwn(this, 26, 21);
      this.g.a(-4.0F, 0.0F, -2.0F, 8.0F, 8.0F, 3.0F);
      this.f.e = -1.5707964F;
      this.g.e = 1.5707964F;
      this.f.a(6.0F, -8.0F, 0.0F);
      this.g.a(-6.0F, -8.0F, 0.0F);
      this.a.b(this.f);
      this.a.b(this.g);
   }

   protected void a(dwn var1) {
      dwn var2 = new dwn(this, 0, 12);
      var2.a(-1.0F, -7.0F, 0.0F, 2.0F, 7.0F, 1.0F);
      var2.a(1.25F, -10.0F, 4.0F);
      dwn var3 = new dwn(this, 0, 12);
      var3.a(-1.0F, -7.0F, 0.0F, 2.0F, 7.0F, 1.0F);
      var3.a(-1.25F, -10.0F, 4.0F);
      var2.d = 0.2617994F;
      var2.f = 0.2617994F;
      var3.d = 0.2617994F;
      var3.f = -0.2617994F;
      var1.b(var2);
      var1.b(var3);
   }

   public void a(T var1, float var2, float var3, float var4, float var5, float var6) {
      super.a((bbb)var1, var2, var3, var4, var5, var6);
      if (var1.eM()) {
         this.f.h = true;
         this.g.h = true;
      } else {
         this.f.h = false;
         this.g.h = false;
      }

   }
}
