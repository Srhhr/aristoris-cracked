import javax.annotation.Nullable;

public class cco extends ccj {
   private boolean a;
   private boolean b;
   private boolean c;
   private boolean g;
   private final bqy h = new bqy() {
      public void a(String var1) {
         super.a(var1);
         cco.this.X_();
      }

      public aag d() {
         return (aag)cco.this.d;
      }

      public void e() {
         ceh var1 = cco.this.d.d_(cco.this.e);
         this.d().a(cco.this.e, var1, var1, 3);
      }

      public dcn f() {
         return dcn.a((gr)cco.this.e);
      }

      public db h() {
         return new db(this, dcn.a((gr)cco.this.e), dcm.a, this.d(), 2, this.l().getString(), this.l(), this.d().l(), (aqa)null);
      }
   };

   public cco() {
      super(cck.v);
   }

   public md a(md var1) {
      super.a(var1);
      this.h.a(var1);
      var1.a("powered", this.f());
      var1.a("conditionMet", this.j());
      var1.a("auto", this.g());
      return var1;
   }

   public void a(ceh var1, md var2) {
      super.a(var1, var2);
      this.h.b(var2);
      this.a = var2.q("powered");
      this.c = var2.q("conditionMet");
      this.b(var2.q("auto"));
   }

   @Nullable
   public ow a() {
      if (this.l()) {
         this.c(false);
         md var1 = this.a(new md());
         return new ow(this.e, 2, var1);
      } else {
         return null;
      }
   }

   public boolean t() {
      return true;
   }

   public bqy d() {
      return this.h;
   }

   public void a(boolean var1) {
      this.a = var1;
   }

   public boolean f() {
      return this.a;
   }

   public boolean g() {
      return this.b;
   }

   public void b(boolean var1) {
      boolean var2 = this.b;
      this.b = var1;
      if (!var2 && var1 && !this.a && this.d != null && this.m() != cco.a.a) {
         this.y();
      }

   }

   public void h() {
      cco.a var1 = this.m();
      if (var1 == cco.a.b && (this.a || this.b) && this.d != null) {
         this.y();
      }

   }

   private void y() {
      buo var1 = this.p().b();
      if (var1 instanceof bvi) {
         this.k();
         this.d.J().a(this.e, var1, 1);
      }

   }

   public boolean j() {
      return this.c;
   }

   public boolean k() {
      this.c = true;
      if (this.x()) {
         fx var1 = this.e.a(((gc)this.d.d_(this.e).c(bvi.a)).f());
         if (this.d.d_(var1).b() instanceof bvi) {
            ccj var2 = this.d.c(var1);
            this.c = var2 instanceof cco && ((cco)var2).d().i() > 0;
         } else {
            this.c = false;
         }
      }

      return this.c;
   }

   public boolean l() {
      return this.g;
   }

   public void c(boolean var1) {
      this.g = var1;
   }

   public cco.a m() {
      ceh var1 = this.p();
      if (var1.a(bup.er)) {
         return cco.a.c;
      } else if (var1.a(bup.iG)) {
         return cco.a.b;
      } else {
         return var1.a(bup.iH) ? cco.a.a : cco.a.c;
      }
   }

   public boolean x() {
      ceh var1 = this.d.d_(this.o());
      return var1.b() instanceof bvi ? (Boolean)var1.c(bvi.b) : false;
   }

   public void r() {
      this.s();
      super.r();
   }

   public static enum a {
      a,
      b,
      c;
   }
}
