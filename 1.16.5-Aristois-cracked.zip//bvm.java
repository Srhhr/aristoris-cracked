import javax.annotation.Nullable;

public class bvm extends bud implements bzu {
   public static final cey a;
   protected static final ddh b;

   public bvm(ceg.c var1) {
      super(var1);
      this.j((ceh)((ceh)this.n.b()).a(a, true));
   }

   protected void a(cei.a<buo, ceh> var1) {
      var1.a(a);
   }

   public ccj a(brc var1) {
      return new ccq();
   }

   public bzh b(ceh var1) {
      return bzh.b;
   }

   public cux d(ceh var1) {
      return (Boolean)var1.c(a) ? cuy.c.a(false) : super.d(var1);
   }

   public ceh a(ceh var1, gc var2, ceh var3, bry var4, fx var5, fx var6) {
      if ((Boolean)var1.c(a)) {
         var4.I().a(var5, cuy.c, cuy.c.a((brz)var4));
      }

      return super.a(var1, var2, var3, var4, var5, var6);
   }

   public ddh b(ceh var1, brc var2, fx var3, dcs var4) {
      return b;
   }

   public void a(brx var1, fx var2, ceh var3, @Nullable aqm var4, bmb var5) {
      if (var5.t()) {
         ccj var6 = var1.c(var2);
         if (var6 instanceof cce) {
            ((cce)var6).a(var5.r());
         }
      }

   }

   @Nullable
   public ceh a(bny var1) {
      cux var2 = var1.p().b(var1.a());
      return (ceh)this.n().a(a, var2.a(aef.b) && var2.e() == 8);
   }

   public boolean a(ceh var1, brc var2, fx var3, cxe var4) {
      return false;
   }

   static {
      a = cex.C;
      b = buo.a(5.0D, 5.0D, 5.0D, 11.0D, 11.0D, 11.0D);
   }
}
