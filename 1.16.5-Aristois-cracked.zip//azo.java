import com.mojang.datafixers.DataFixer;
import com.mojang.datafixers.util.Pair;
import it.unimi.dsi.fastutil.longs.Long2ByteMap;
import it.unimi.dsi.fastutil.longs.Long2ByteOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import it.unimi.dsi.fastutil.longs.LongSet;
import java.io.File;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.BooleanSupplier;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class azo extends chb<azq> {
   private final azo.a a = new azo.a();
   private final LongSet b = new LongOpenHashSet();

   public azo(File var1, DataFixer var2, boolean var3) {
      super(var1, azq::a, azq::new, var2, aga.j, var3);
   }

   public void a(fx var1, azr var2) {
      ((azq)this.e(gp.a(var1).s())).a(var1, var2);
   }

   public void a(fx var1) {
      ((azq)this.e(gp.a(var1).s())).a(var1);
   }

   public long a(Predicate<azr> var1, fx var2, int var3, azo.b var4) {
      return this.c(var1, var2, var3, var4).count();
   }

   public boolean a(azr var1, fx var2) {
      Optional<azr> var3 = ((azq)this.e(gp.a(var2).s())).d(var2);
      return var3.isPresent() && ((azr)var3.get()).equals(var1);
   }

   public Stream<azp> b(Predicate<azr> var1, fx var2, int var3, azo.b var4) {
      int var5 = Math.floorDiv(var3, 16) + 1;
      return brd.a(new brd(var2), var5).flatMap((var3x) -> {
         return this.a(var1, var3x, var4);
      }).filter((var2x) -> {
         fx var3x = var2x.f();
         return Math.abs(var3x.u() - var2.u()) <= var3 && Math.abs(var3x.w() - var2.w()) <= var3;
      });
   }

   public Stream<azp> c(Predicate<azr> var1, fx var2, int var3, azo.b var4) {
      int var5 = var3 * var3;
      return this.b(var1, var2, var3, var4).filter((var2x) -> {
         return var2x.f().j(var2) <= (double)var5;
      });
   }

   public Stream<azp> a(Predicate<azr> var1, brd var2, azo.b var3) {
      return IntStream.range(0, 16).boxed().map((var2x) -> {
         return this.d(gp.a(var2, var2x).s());
      }).filter(Optional::isPresent).flatMap((var2x) -> {
         return ((azq)var2x.get()).a(var1, var3);
      });
   }

   public Stream<fx> a(Predicate<azr> var1, Predicate<fx> var2, fx var3, int var4, azo.b var5) {
      return this.c(var1, var3, var4, var5).map(azp::f).filter(var2);
   }

   public Stream<fx> b(Predicate<azr> var1, Predicate<fx> var2, fx var3, int var4, azo.b var5) {
      return this.a(var1, var2, var3, var4, var5).sorted(Comparator.comparingDouble((var1x) -> {
         return var1x.j(var3);
      }));
   }

   public Optional<fx> c(Predicate<azr> var1, Predicate<fx> var2, fx var3, int var4, azo.b var5) {
      return this.a(var1, var2, var3, var4, var5).findFirst();
   }

   public Optional<fx> d(Predicate<azr> var1, fx var2, int var3, azo.b var4) {
      return this.c(var1, var2, var3, var4).map(azp::f).min(Comparator.comparingDouble((var1x) -> {
         return var1x.j(var2);
      }));
   }

   public Optional<fx> a(Predicate<azr> var1, Predicate<fx> var2, fx var3, int var4) {
      return this.c(var1, var3, var4, azo.b.a).filter((var1x) -> {
         return var2.test(var1x.f());
      }).findFirst().map((var0) -> {
         var0.b();
         return var0.f();
      });
   }

   public Optional<fx> a(Predicate<azr> var1, Predicate<fx> var2, azo.b var3, fx var4, int var5, Random var6) {
      List<azp> var7 = (List)this.c(var1, var4, var5, var3).collect(Collectors.toList());
      Collections.shuffle(var7, var6);
      return var7.stream().filter((var1x) -> {
         return var2.test(var1x.f());
      }).findFirst().map(azp::f);
   }

   public boolean b(fx var1) {
      return ((azq)this.e(gp.a(var1).s())).c(var1);
   }

   public boolean a(fx var1, Predicate<azr> var2) {
      return (Boolean)this.d(gp.a(var1).s()).map((var2x) -> {
         return var2x.a(var1, var2);
      }).orElse(false);
   }

   public Optional<azr> c(fx var1) {
      azq var2 = (azq)this.e(gp.a(var1).s());
      return var2.d(var1);
   }

   public int a(gp var1) {
      this.a.a();
      return this.a.c(var1.s());
   }

   private boolean f(long var1) {
      Optional<azq> var3 = this.c(var1);
      return var3 == null ? false : (Boolean)var3.map((var0) -> {
         return var0.a(azr.b, azo.b.b).count() > 0L;
      }).orElse(false);
   }

   public void a(BooleanSupplier var1) {
      super.a(var1);
      this.a.a();
   }

   protected void a(long var1) {
      super.a(var1);
      this.a.b(var1, this.a.b(var1), false);
   }

   protected void b(long var1) {
      this.a.b(var1, this.a.b(var1), false);
   }

   public void a(brd var1, cgi var2) {
      gp var3 = gp.a(var1, var2.g() >> 4);
      x.a(this.d(var3.s()), (var3x) -> {
         var3x.a((var3xx) -> {
            if (a(var2)) {
               this.a(var2, var3, var3xx);
            }

         });
      }, () -> {
         if (a(var2)) {
            azq var3x = (azq)this.e(var3.s());
            this.a(var2, var3, var3x::a);
         }

      });
   }

   private static boolean a(cgi var0) {
      Set var10001 = azr.x;
      var10001.getClass();
      return var0.a(var10001::contains);
   }

   private void a(cgi var1, gp var2, BiConsumer<fx, azr> var3) {
      var2.t().forEach((var2x) -> {
         ceh var3x = var1.a(gp.b(var2x.u()), gp.b(var2x.v()), gp.b(var2x.w()));
         azr.b(var3x).ifPresent((var2) -> {
            var3.accept(var2x, var2);
         });
      });
   }

   public void a(brz var1, fx var2, int var3) {
      gp.b(new brd(var2), Math.floorDiv(var3, 16)).map((var1x) -> {
         return Pair.of(var1x, this.d(var1x.s()));
      }).filter((var0) -> {
         return !(Boolean)((Optional)var0.getSecond()).map(azq::a).orElse(false);
      }).map((var0) -> {
         return ((gp)var0.getFirst()).r();
      }).filter((var1x) -> {
         return this.b.add(var1x.a());
      }).forEach((var1x) -> {
         var1.a(var1x.b, var1x.c, cga.a);
      });
   }

   final class a extends aac {
      private final Long2ByteMap b = new Long2ByteOpenHashMap();

      protected a() {
         super(7, 16, 256);
         this.b.defaultReturnValue((byte)7);
      }

      protected int b(long var1) {
         return azo.this.f(var1) ? 0 : 7;
      }

      protected int c(long var1) {
         return this.b.get(var1);
      }

      protected void a(long var1, int var3) {
         if (var3 > 6) {
            this.b.remove(var1);
         } else {
            this.b.put(var1, (byte)var3);
         }

      }

      public void a() {
         super.b(Integer.MAX_VALUE);
      }
   }

   public static enum b {
      a(azp::d),
      b(azp::e),
      c((var0) -> {
         return true;
      });

      private final Predicate<? super azp> d;

      private b(Predicate<? super azp> var3) {
         this.d = var3;
      }

      public Predicate<? super azp> a() {
         return this.d;
      }
   }
}
