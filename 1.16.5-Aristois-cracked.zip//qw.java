import java.io.IOException;

public class qw implements oj<om> {
   private int a;
   private int b;

   public qw() {
   }

   public qw(int var1, int var2) {
      this.a = var1;
      this.b = var2;
   }

   public void a(nf var1) throws IOException {
      this.a = var1.i();
      this.b = var1.i();
   }

   public void b(nf var1) throws IOException {
      var1.d(this.a);
      var1.d(this.b);
   }

   public void a(om var1) {
      var1.a(this);
   }

   public int b() {
      return this.a;
   }

   public int c() {
      return this.b;
   }
}
