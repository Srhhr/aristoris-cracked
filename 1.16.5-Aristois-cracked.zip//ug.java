import com.mojang.authlib.GameProfile;
import java.io.IOException;
import java.util.UUID;

public class ug implements oj<ue> {
   private GameProfile a;

   public ug() {
   }

   public ug(GameProfile var1) {
      this.a = var1;
   }

   public void a(nf var1) throws IOException {
      this.a = new GameProfile((UUID)null, var1.e(16));
   }

   public void b(nf var1) throws IOException {
      var1.a(this.a.getName());
   }

   public void a(ue var1) {
      var1.a(this);
   }

   public GameProfile b() {
      return this.a;
   }
}
