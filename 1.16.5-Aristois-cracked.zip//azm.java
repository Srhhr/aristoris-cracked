import java.util.Iterator;
import javax.annotation.Nullable;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class azm implements brj {
   private static final Logger a = LogManager.getLogger();
   private boolean b;
   private azm.a c;
   private int d;
   private int e;
   private int f;
   private int g;
   private int h;

   public azm() {
      this.c = azm.a.c;
   }

   public int a(aag var1, boolean var2, boolean var3) {
      if (!var1.M() && var2) {
         float var4 = var1.f(0.0F);
         if ((double)var4 == 0.5D) {
            this.c = var1.t.nextInt(10) == 0 ? azm.a.b : azm.a.c;
         }

         if (this.c == azm.a.c) {
            return 0;
         } else {
            if (!this.b) {
               if (!this.a(var1)) {
                  return 0;
               }

               this.b = true;
            }

            if (this.e > 0) {
               --this.e;
               return 0;
            } else {
               this.e = 2;
               if (this.d > 0) {
                  this.b(var1);
                  --this.d;
               } else {
                  this.c = azm.a.c;
               }

               return 1;
            }
         }
      } else {
         this.c = azm.a.c;
         this.b = false;
         return 0;
      }
   }

   private boolean a(aag var1) {
      Iterator var2 = var1.x().iterator();

      while(var2.hasNext()) {
         bfw var3 = (bfw)var2.next();
         if (!var3.a_()) {
            fx var4 = var3.cB();
            if (var1.a_(var4) && var1.v(var4).t() != bsv.b.p) {
               for(int var5 = 0; var5 < 10; ++var5) {
                  float var6 = var1.t.nextFloat() * 6.2831855F;
                  this.f = var4.u() + afm.d(afm.b(var6) * 32.0F);
                  this.g = var4.v();
                  this.h = var4.w() + afm.d(afm.a(var6) * 32.0F);
                  if (this.a(var1, new fx(this.f, this.g, this.h)) != null) {
                     this.e = 0;
                     this.d = 20;
                     break;
                  }
               }

               return true;
            }
         }
      }

      return false;
   }

   private void b(aag var1) {
      dcn var2 = this.a(var1, new fx(this.f, this.g, this.h));
      if (var2 != null) {
         bej var3;
         try {
            var3 = new bej(var1);
            var3.a(var1, var1.d((fx)var3.cB()), aqp.h, (arc)null, (md)null);
         } catch (Exception var5) {
            a.warn("Failed to create zombie for village siege at {}", var2, var5);
            return;
         }

         var3.b(var2.b, var2.c, var2.d, var1.t.nextFloat() * 360.0F, 0.0F);
         var1.l(var3);
      }
   }

   @Nullable
   private dcn a(aag var1, fx var2) {
      for(int var3 = 0; var3 < 10; ++var3) {
         int var4 = var2.u() + var1.t.nextInt(16) - 8;
         int var5 = var2.w() + var1.t.nextInt(16) - 8;
         int var6 = var1.a(chn.a.b, var4, var5);
         fx var7 = new fx(var4, var6, var5);
         if (var1.a_(var7) && bdq.b(aqe.aY, var1, aqp.h, var7, var1.t)) {
            return dcn.c((gr)var7);
         }
      }

      return null;
   }

   static enum a {
      a,
      b,
      c;
   }
}
