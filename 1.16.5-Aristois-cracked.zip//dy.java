import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import java.util.Arrays;
import java.util.Collection;

public class dy implements ArgumentType<vk> {
   private static final Collection<String> a = Arrays.asList("foo", "foo:bar", "012");
   private static final DynamicCommandExceptionType b = new DynamicCommandExceptionType((var0) -> {
      return new of("advancement.advancementNotFound", new Object[]{var0});
   });
   private static final DynamicCommandExceptionType c = new DynamicCommandExceptionType((var0) -> {
      return new of("recipe.notFound", new Object[]{var0});
   });
   private static final DynamicCommandExceptionType d = new DynamicCommandExceptionType((var0) -> {
      return new of("predicate.unknown", new Object[]{var0});
   });
   private static final DynamicCommandExceptionType e = new DynamicCommandExceptionType((var0) -> {
      return new of("attribute.unknown", new Object[]{var0});
   });

   public static dy a() {
      return new dy();
   }

   public static y a(CommandContext<db> var0, String var1) throws CommandSyntaxException {
      vk var2 = (vk)var0.getArgument(var1, vk.class);
      y var3 = ((db)var0.getSource()).j().aA().a(var2);
      if (var3 == null) {
         throw b.create(var2);
      } else {
         return var3;
      }
   }

   public static boq<?> b(CommandContext<db> var0, String var1) throws CommandSyntaxException {
      bor var2 = ((db)var0.getSource()).j().aF();
      vk var3 = (vk)var0.getArgument(var1, vk.class);
      return (boq)var2.a(var3).orElseThrow(() -> {
         return c.create(var3);
      });
   }

   public static dbo c(CommandContext<db> var0, String var1) throws CommandSyntaxException {
      vk var2 = (vk)var0.getArgument(var1, vk.class);
      cza var3 = ((db)var0.getSource()).j().aK();
      dbo var4 = var3.a(var2);
      if (var4 == null) {
         throw d.create(var2);
      } else {
         return var4;
      }
   }

   public static arg d(CommandContext<db> var0, String var1) throws CommandSyntaxException {
      vk var2 = (vk)var0.getArgument(var1, vk.class);
      return (arg)gm.af.b(var2).orElseThrow(() -> {
         return e.create(var2);
      });
   }

   public static vk e(CommandContext<db> var0, String var1) {
      return (vk)var0.getArgument(var1, vk.class);
   }

   public vk a(StringReader var1) throws CommandSyntaxException {
      return vk.a(var1);
   }

   public Collection<String> getExamples() {
      return a;
   }

   // $FF: synthetic method
   public Object parse(StringReader var1) throws CommandSyntaxException {
      return this.a(var1);
   }
}
