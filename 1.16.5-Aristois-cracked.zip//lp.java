import com.google.common.collect.Lists;
import java.util.Collection;
import java.util.function.Consumer;
import javax.annotation.Nullable;

public class lp {
   private final Collection<lf> a = Lists.newArrayList();
   @Nullable
   private Collection<lg> b = Lists.newArrayList();

   public lp() {
   }

   public lp(Collection<lf> var1) {
      this.a.addAll(var1);
   }

   public void a(lf var1) {
      this.a.add(var1);
      this.b.forEach(var1::a);
   }

   public void a(lg var1) {
      this.b.add(var1);
      this.a.forEach((var1x) -> {
         var1x.a(var1);
      });
   }

   public void a(final Consumer<lf> var1) {
      this.a(new lg() {
         public void a(lf var1x) {
         }

         public void c(lf var1x) {
            var1.accept(var1x);
         }
      });
   }

   public int a() {
      return (int)this.a.stream().filter(lf::i).filter(lf::q).count();
   }

   public int b() {
      return (int)this.a.stream().filter(lf::i).filter(lf::r).count();
   }

   public int c() {
      return (int)this.a.stream().filter(lf::k).count();
   }

   public boolean d() {
      return this.a() > 0;
   }

   public boolean e() {
      return this.b() > 0;
   }

   public int h() {
      return this.a.size();
   }

   public boolean i() {
      return this.c() == this.h();
   }

   public String j() {
      StringBuffer var1 = new StringBuffer();
      var1.append('[');
      this.a.forEach((var1x) -> {
         if (!var1x.j()) {
            var1.append(' ');
         } else if (var1x.h()) {
            var1.append('+');
         } else if (var1x.i()) {
            var1.append((char)(var1x.q() ? 'X' : 'x'));
         } else {
            var1.append('_');
         }

      });
      var1.append(']');
      return var1.toString();
   }

   public String toString() {
      return this.j();
   }
}
