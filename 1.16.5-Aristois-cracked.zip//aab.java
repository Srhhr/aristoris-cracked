import javax.annotation.Nullable;

public class aab {
   @Nullable
   protected static fx a(aag var0, int var1, int var2, boolean var3) {
      fx.a var4 = new fx.a(var1, 0, var2);
      bsv var5 = var0.v(var4);
      boolean var6 = var0.k().c();
      ceh var7 = var5.e().e().a();
      if (var3 && !var7.b().a((ael)aed.V)) {
         return null;
      } else {
         cgh var8 = var0.d(var1 >> 4, var2 >> 4);
         int var9 = var6 ? var0.i().g().c() : var8.a(chn.a.e, var1 & 15, var2 & 15);
         if (var9 < 0) {
            return null;
         } else {
            int var10 = var8.a(chn.a.b, var1 & 15, var2 & 15);
            if (var10 <= var9 && var10 > var8.a(chn.a.d, var1 & 15, var2 & 15)) {
               return null;
            } else {
               for(int var11 = var9 + 1; var11 >= 0; --var11) {
                  var4.d(var1, var11, var2);
                  ceh var12 = var0.d_(var4);
                  if (!var12.m().c()) {
                     break;
                  }

                  if (var12.equals(var7)) {
                     return var4.b().h();
                  }
               }

               return null;
            }
         }
      }
   }

   @Nullable
   public static fx a(aag var0, brd var1, boolean var2) {
      for(int var3 = var1.d(); var3 <= var1.f(); ++var3) {
         for(int var4 = var1.e(); var4 <= var1.g(); ++var4) {
            fx var5 = a(var0, var3, var4, var2);
            if (var5 != null) {
               return var5;
            }
         }
      }

      return null;
   }
}
