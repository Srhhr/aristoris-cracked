import com.google.common.collect.ImmutableList;
import com.google.common.collect.UnmodifiableIterator;
import com.google.common.collect.ImmutableList.Builder;
import java.util.Optional;
import java.util.Random;
import java.util.stream.Stream;

public class bzj extends buo {
   public static final cfg a;
   private static final ImmutableList<gr> b;
   private static final ImmutableList<gr> c;

   public bzj(ceg.c var1) {
      super(var1);
      this.j((ceh)((ceh)this.n.b()).a(a, 0));
   }

   public aou a(ceh var1, brx var2, fx var3, bfw var4, aot var5, dcj var6) {
      bmb var7 = var4.b((aot)var5);
      if (var5 == aot.a && !a(var7) && a(var4.b((aot)aot.b))) {
         return aou.c;
      } else if (a(var7) && h(var1)) {
         a(var2, var3, var1);
         if (!var4.bC.d) {
            var7.g(1);
         }

         return aou.a(var2.v);
      } else if ((Integer)var1.c(a) == 0) {
         return aou.c;
      } else if (!a(var2)) {
         if (!var2.v) {
            this.d(var1, var2, var3);
         }

         return aou.a(var2.v);
      } else {
         if (!var2.v) {
            aah var8 = (aah)var4;
            if (var8.M() != var2.Y() || !var8.K().equals(var3)) {
               var8.a(var2.Y(), var3, 0.0F, false, true);
               var2.a((bfw)null, (double)var3.u() + 0.5D, (double)var3.v() + 0.5D, (double)var3.w() + 0.5D, adq.mA, adr.e, 1.0F, 1.0F);
               return aou.a;
            }
         }

         return aou.b;
      }
   }

   private static boolean a(bmb var0) {
      return var0.b() == bmd.dq;
   }

   private static boolean h(ceh var0) {
      return (Integer)var0.c(a) < 4;
   }

   private static boolean a(fx var0, brx var1) {
      cux var2 = var1.b(var0);
      if (!var2.a(aef.b)) {
         return false;
      } else if (var2.b()) {
         return true;
      } else {
         float var3 = (float)var2.e();
         if (var3 < 2.0F) {
            return false;
         } else {
            cux var4 = var1.b(var0.c());
            return !var4.a(aef.b);
         }
      }
   }

   private void d(ceh var1, brx var2, final fx var3) {
      var2.a(var3, false);
      Stream var10000 = gc.c.a.a();
      var3.getClass();
      boolean var4 = var10000.map(var3::a).anyMatch((var1x) -> {
         return a(var1x, var2);
      });
      final boolean var5 = var4 || var2.b(var3.b()).a(aef.b);
      brq var6 = new brq() {
         public Optional<Float> a(brp var1, brc var2, fx var3x, ceh var4, cux var5x) {
            return var3x.equals(var3) && var5 ? Optional.of(bup.A.f()) : super.a(var1, var2, var3x, var4, var5x);
         }
      };
      var2.a((aqa)null, apk.a(), var6, (double)var3.u() + 0.5D, (double)var3.v() + 0.5D, (double)var3.w() + 0.5D, 5.0F, true, brp.a.c);
   }

   public static boolean a(brx var0) {
      return var0.k().i();
   }

   public static void a(brx var0, fx var1, ceh var2) {
      var0.a(var1, (ceh)var2.a(a, (Integer)var2.c(a) + 1), 3);
      var0.a((bfw)null, (double)var1.u() + 0.5D, (double)var1.v() + 0.5D, (double)var1.w() + 0.5D, adq.my, adr.e, 1.0F, 1.0F);
   }

   public void a(ceh var1, brx var2, fx var3, Random var4) {
      if ((Integer)var1.c(a) != 0) {
         if (var4.nextInt(100) == 0) {
            var2.a((bfw)null, (double)var3.u() + 0.5D, (double)var3.v() + 0.5D, (double)var3.w() + 0.5D, adq.mx, adr.e, 1.0F, 1.0F);
         }

         double var5 = (double)var3.u() + 0.5D + (0.5D - var4.nextDouble());
         double var7 = (double)var3.v() + 1.0D;
         double var9 = (double)var3.w() + 0.5D + (0.5D - var4.nextDouble());
         double var11 = (double)var4.nextFloat() * 0.04D;
         var2.a(hh.as, var5, var7, var9, 0.0D, var11, 0.0D);
      }
   }

   protected void a(cei.a<buo, ceh> var1) {
      var1.a(a);
   }

   public boolean a(ceh var1) {
      return true;
   }

   public static int a(ceh var0, int var1) {
      return afm.d((float)((Integer)var0.c(a) - 0) / 4.0F * (float)var1);
   }

   public int a(ceh var1, brx var2, fx var3) {
      return a(var1, 15);
   }

   public static Optional<dcn> a(aqe<?> var0, brg var1, fx var2) {
      Optional<dcn> var3 = a(var0, var1, var2, true);
      return var3.isPresent() ? var3 : a(var0, var1, var2, false);
   }

   private static Optional<dcn> a(aqe<?> var0, brg var1, fx var2, boolean var3) {
      fx.a var4 = new fx.a();
      UnmodifiableIterator var5 = c.iterator();

      dcn var7;
      do {
         if (!var5.hasNext()) {
            return Optional.empty();
         }

         gr var6 = (gr)var5.next();
         var4.g(var2).h(var6);
         var7 = bho.a(var0, var1, var4, var3);
      } while(var7 == null);

      return Optional.of(var7);
   }

   public boolean a(ceh var1, brc var2, fx var3, cxe var4) {
      return false;
   }

   static {
      a = cex.aC;
      b = ImmutableList.of(new gr(0, 0, -1), new gr(-1, 0, 0), new gr(0, 0, 1), new gr(1, 0, 0), new gr(-1, 0, -1), new gr(1, 0, -1), new gr(-1, 0, 1), new gr(1, 0, 1));
      c = (new Builder()).addAll(b).addAll(b.stream().map(gr::n).iterator()).addAll(b.stream().map(gr::o).iterator()).add(new gr(0, 1, 0)).build();
   }
}
