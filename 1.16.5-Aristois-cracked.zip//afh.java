import java.util.Random;

public class afh {
   private final int a;
   private final int b;

   public afh(int var1, int var2) {
      if (var2 < var1) {
         throw new IllegalArgumentException("max must be >= minInclusive! Given minInclusive: " + var1 + ", Given max: " + var2);
      } else {
         this.a = var1;
         this.b = var2;
      }
   }

   public static afh a(int var0, int var1) {
      return new afh(var0, var1);
   }

   public int a(Random var1) {
      return this.a == this.b ? this.a : var1.nextInt(this.b - this.a + 1) + this.a;
   }

   public int a() {
      return this.a;
   }

   public int b() {
      return this.b;
   }

   public String toString() {
      return "IntRange[" + this.a + "-" + this.b + "]";
   }
}
