public class daz<T> {
   private final vk a;

   public daz(vk var1) {
      this.a = var1;
   }

   public vk a() {
      return this.a;
   }

   public String toString() {
      return "<parameter " + this.a + ">";
   }
}
