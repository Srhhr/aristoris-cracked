import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;

public class div {
   private static final Long2ObjectMap<String> a = new Long2ObjectOpenHashMap();

   public static String a(long var0) {
      return (String)a.get(var0);
   }

   public static void b(long var0) {
      a.remove(var0);
   }

   public static void a(long var0, String var2) {
      a.put(var0, var2);
   }
}
