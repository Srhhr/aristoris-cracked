import com.google.common.collect.ImmutableList;

public class dvi<T extends aqa> extends dtf<T> {
   protected dwn a = new dwn(this, 0, 0);
   protected dwn b;
   protected dwn f;
   protected dwn g;
   protected dwn h;
   protected dwn i;

   public dvi(int var1, float var2, boolean var3, float var4, float var5, float var6, float var7, int var8) {
      super(var3, var4, var5, var6, var7, (float)var8);
      this.a.a(-4.0F, -4.0F, -8.0F, 8.0F, 8.0F, 8.0F, var2);
      this.a.a(0.0F, (float)(18 - var1), -6.0F);
      this.b = new dwn(this, 28, 8);
      this.b.a(-5.0F, -10.0F, -7.0F, 10.0F, 16.0F, 8.0F, var2);
      this.b.a(0.0F, (float)(17 - var1), 2.0F);
      this.f = new dwn(this, 0, 16);
      this.f.a(-2.0F, 0.0F, -2.0F, 4.0F, (float)var1, 4.0F, var2);
      this.f.a(-3.0F, (float)(24 - var1), 7.0F);
      this.g = new dwn(this, 0, 16);
      this.g.a(-2.0F, 0.0F, -2.0F, 4.0F, (float)var1, 4.0F, var2);
      this.g.a(3.0F, (float)(24 - var1), 7.0F);
      this.h = new dwn(this, 0, 16);
      this.h.a(-2.0F, 0.0F, -2.0F, 4.0F, (float)var1, 4.0F, var2);
      this.h.a(-3.0F, (float)(24 - var1), -5.0F);
      this.i = new dwn(this, 0, 16);
      this.i.a(-2.0F, 0.0F, -2.0F, 4.0F, (float)var1, 4.0F, var2);
      this.i.a(3.0F, (float)(24 - var1), -5.0F);
   }

   protected Iterable<dwn> a() {
      return ImmutableList.of(this.a);
   }

   protected Iterable<dwn> b() {
      return ImmutableList.of(this.b, this.f, this.g, this.h, this.i);
   }

   public void a(T var1, float var2, float var3, float var4, float var5, float var6) {
      this.a.d = var6 * 0.017453292F;
      this.a.e = var5 * 0.017453292F;
      this.b.d = 1.5707964F;
      this.f.d = afm.b(var2 * 0.6662F) * 1.4F * var3;
      this.g.d = afm.b(var2 * 0.6662F + 3.1415927F) * 1.4F * var3;
      this.h.d = afm.b(var2 * 0.6662F + 3.1415927F) * 1.4F * var3;
      this.i.d = afm.b(var2 * 0.6662F) * 1.4F * var3;
   }
}
