import java.util.Random;

public class aqj {
   private final uv d;
   private final us<Integer> e;
   private final us<Boolean> f;
   public boolean a;
   public int b;
   public int c;

   public aqj(uv var1, us<Integer> var2, us<Boolean> var3) {
      this.d = var1;
      this.e = var2;
      this.f = var3;
   }

   public void a() {
      this.a = true;
      this.b = 0;
      this.c = (Integer)this.d.a(this.e);
   }

   public boolean a(Random var1) {
      if (this.a) {
         return false;
      } else {
         this.a = true;
         this.b = 0;
         this.c = var1.nextInt(841) + 140;
         this.d.b(this.e, this.c);
         return true;
      }
   }

   public void a(md var1) {
      var1.a("Saddle", this.b());
   }

   public void b(md var1) {
      this.a(var1.q("Saddle"));
   }

   public void a(boolean var1) {
      this.d.b(this.f, var1);
   }

   public boolean b() {
      return (Boolean)this.d.a(this.f);
   }
}
