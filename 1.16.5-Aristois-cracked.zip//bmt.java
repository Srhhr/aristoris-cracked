public class bmt extends bly {
   private final aah a;

   public bmt(aah var1) {
      this.a = var1;
   }

   protected void b(blx var1, int var2) {
      super.b(var1, var2);
      this.a.b.a((oj)(new pj(var1, var2)));
   }

   protected void c(blx var1) {
      super.c(var1);
      this.a.b.a((oj)(new pj(var1, 0)));
   }
}
