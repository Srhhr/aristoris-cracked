public class bla extends blw implements blb {
   public bla(int var1, String var2, blx.a var3) {
      super(var1, var2, var3);
   }
}
