import java.util.EnumSet;
import java.util.function.Predicate;

public class avd<T extends aqm> extends avv {
   protected final aqu a;
   private final double i;
   private final double j;
   protected T b;
   protected final float c;
   protected cxd d;
   protected final ayj e;
   protected final Class<T> f;
   protected final Predicate<aqm> g;
   protected final Predicate<aqm> h;
   private final azg k;

   public avd(aqu var1, Class<T> var2, float var3, double var4, double var6) {
      Predicate var10003 = (var0) -> {
         return true;
      };
      Predicate var10007 = aqd.e;
      this(var1, var2, var10003, var3, var4, var6, var10007::test);
   }

   public avd(aqu var1, Class<T> var2, Predicate<aqm> var3, float var4, double var5, double var7, Predicate<aqm> var9) {
      this.a = var1;
      this.f = var2;
      this.g = var3;
      this.c = var4;
      this.i = var5;
      this.j = var7;
      this.h = var9;
      this.e = var1.x();
      this.a(EnumSet.of(avv.a.a));
      this.k = (new azg()).a((double)var4).a(var9.and(var3));
   }

   public avd(aqu var1, Class<T> var2, float var3, double var4, double var6, Predicate<aqm> var8) {
      this(var1, var2, (var0) -> {
         return true;
      }, var3, var4, var6, var8);
   }

   public boolean a() {
      this.b = this.a.l.b(this.f, this.k, this.a, this.a.cD(), this.a.cE(), this.a.cH(), this.a.cc().c((double)this.c, 3.0D, (double)this.c));
      if (this.b == null) {
         return false;
      } else {
         dcn var1 = azj.c(this.a, 16, 7, this.b.cA());
         if (var1 == null) {
            return false;
         } else if (this.b.h(var1.b, var1.c, var1.d) < this.b.h((aqa)this.a)) {
            return false;
         } else {
            this.d = this.e.a(var1.b, var1.c, var1.d, 0);
            return this.d != null;
         }
      }
   }

   public boolean b() {
      return !this.e.m();
   }

   public void c() {
      this.e.a(this.d, this.i);
   }

   public void d() {
      this.b = null;
   }

   public void e() {
      if (this.a.h(this.b) < 49.0D) {
         this.a.x().a(this.j);
      } else {
         this.a.x().a(this.i);
      }

   }
}
