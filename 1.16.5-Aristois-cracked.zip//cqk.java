import com.mojang.serialization.Codec;
import java.util.Random;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class cqk extends cqo<cql> {
   public cqk(Codec<cql> var1) {
      super(var1);
   }

   public Stream<fx> a(Random var1, cql var2, fx var3) {
      double var4 = bsv.f.a((double)var3.u() / var2.d, (double)var3.w() / var2.d, false);
      int var6 = (int)Math.ceil((var4 + var2.e) * (double)var2.c);
      return IntStream.range(0, var6).mapToObj((var1x) -> {
         return var3;
      });
   }
}
