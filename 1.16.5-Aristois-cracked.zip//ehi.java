public class ehi extends efj<bef> {
   private static final vk a = new vk("textures/entity/illager/vindicator.png");

   public ehi(eet var1) {
      super(var1, new dun(0.0F, 0.0F, 64, 64), 0.5F);
      this.a((eit)(new ein<bef, dun<bef>>(this) {
         public void a(dfm var1, eag var2, int var3, bef var4, float var5, float var6, float var7, float var8, float var9, float var10) {
            if (var4.eF()) {
               super.a(var1, var2, var3, (aqm)var4, var5, var6, var7, var8, var9, var10);
            }

         }
      }));
   }

   public vk a(bef var1) {
      return a;
   }
}
