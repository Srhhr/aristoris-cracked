import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;

public interface elo {
   List<eba> a(@Nullable ceh var1, @Nullable gc var2, Random var3);

   boolean a();

   boolean b();

   boolean c();

   boolean d();

   ekc e();

   ebm f();

   ebk g();
}
