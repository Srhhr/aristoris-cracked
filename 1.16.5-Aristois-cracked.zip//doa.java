public class doa extends dot {
   private final nr a;
   private dlu b;
   private final dot c;
   private int p;

   public doa(dot var1, nr var2, nr var3) {
      super(var2);
      this.b = dlu.a;
      this.c = var1;
      this.a = var3;
   }

   public boolean as_() {
      return false;
   }

   protected void b() {
      this.b = dlu.a(this.o, this.a, this.k - 50);
      int var10001 = this.b.a();
      this.o.getClass();
      this.p = var10001 * 9;
      int var10003 = this.k / 2 - 100;
      int var10004 = this.l / 2 + this.p / 2;
      this.o.getClass();
      this.a(new dlj(var10003, Math.min(var10004 + 9, this.l - 30), 200, 20, new of("gui.toMenu"), (var1) -> {
         this.i.a(this.c);
      }));
   }

   public void a(dfm var1, int var2, int var3, float var4) {
      this.a(var1);
      dku var10001 = this.o;
      nr var10002 = this.d;
      int var10003 = this.k / 2;
      int var10004 = this.l / 2 - this.p / 2;
      this.o.getClass();
      a(var1, var10001, var10002, var10003, var10004 - 9 * 2, 11184810);
      this.b.a(var1, this.k / 2, this.l / 2 - this.p / 2);
      super.a(var1, var2, var3, var4);
   }
}
