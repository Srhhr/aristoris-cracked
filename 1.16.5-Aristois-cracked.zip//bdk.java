import java.util.EnumSet;
import java.util.Random;

public class bdk extends aqh implements bdi {
   private static final us<Boolean> b;
   private int c = 1;

   public bdk(aqe<? extends bdk> var1, brx var2) {
      super(var1, var2);
      this.f = 5;
      this.bh = new bdk.b(this);
   }

   protected void o() {
      this.bk.a(5, new bdk.d(this));
      this.bk.a(7, new bdk.a(this));
      this.bk.a(7, new bdk.c(this));
      this.bl.a(1, new axq(this, bfw.class, 10, true, false, (var1) -> {
         return Math.abs(var1.cE() - this.cE()) <= 4.0D;
      }));
   }

   public boolean m() {
      return (Boolean)this.R.a(b);
   }

   public void t(boolean var1) {
      this.R.b(b, var1);
   }

   public int eI() {
      return this.c;
   }

   protected boolean L() {
      return true;
   }

   public boolean a(apk var1, float var2) {
      if (this.b(var1)) {
         return false;
      } else if (var1.j() instanceof bgk && var1.k() instanceof bfw) {
         super.a(var1, 1000.0F);
         return true;
      } else {
         return super.a(var1, var2);
      }
   }

   protected void e() {
      super.e();
      this.R.a((us)b, (Object)false);
   }

   public static ark.a eJ() {
      return aqn.p().a(arl.a, 10.0D).a(arl.b, 100.0D);
   }

   public adr cu() {
      return adr.f;
   }

   protected adp I() {
      return adq.eR;
   }

   protected adp e(apk var1) {
      return adq.eT;
   }

   protected adp dq() {
      return adq.eS;
   }

   protected float dG() {
      return 5.0F;
   }

   public static boolean b(aqe<bdk> var0, bry var1, aqp var2, fx var3, Random var4) {
      return var1.ad() != aor.a && var4.nextInt(20) == 0 && a(var0, var1, var2, var3, var4);
   }

   public int eq() {
      return 1;
   }

   public void b(md var1) {
      super.b(var1);
      var1.b("ExplosionPower", this.c);
   }

   public void a(md var1) {
      super.a(var1);
      if (var1.c("ExplosionPower", 99)) {
         this.c = var1.h("ExplosionPower");
      }

   }

   protected float b(aqx var1, aqb var2) {
      return 2.6F;
   }

   static {
      b = uv.a(bdk.class, uu.i);
   }

   static class c extends avv {
      private final bdk b;
      public int a;

      public c(bdk var1) {
         this.b = var1;
      }

      public boolean a() {
         return this.b.A() != null;
      }

      public void c() {
         this.a = 0;
      }

      public void d() {
         this.b.t(false);
      }

      public void e() {
         aqm var1 = this.b.A();
         double var2 = 64.0D;
         if (var1.h((aqa)this.b) < 4096.0D && this.b.D(var1)) {
            brx var4 = this.b.l;
            ++this.a;
            if (this.a == 10 && !this.b.aA()) {
               var4.a((bfw)null, 1015, this.b.cB(), 0);
            }

            if (this.a == 20) {
               double var5 = 4.0D;
               dcn var7 = this.b.f(1.0F);
               double var8 = var1.cD() - (this.b.cD() + var7.b * 4.0D);
               double var10 = var1.e(0.5D) - (0.5D + this.b.e(0.5D));
               double var12 = var1.cH() - (this.b.cH() + var7.d * 4.0D);
               if (!this.b.aA()) {
                  var4.a((bfw)null, 1016, this.b.cB(), 0);
               }

               bgk var14 = new bgk(var4, this.b, var8, var10, var12);
               var14.e = this.b.eI();
               var14.d(this.b.cD() + var7.b * 4.0D, this.b.e(0.5D) + 0.5D, var14.cH() + var7.d * 4.0D);
               var4.c((aqa)var14);
               this.a = -40;
            }
         } else if (this.a > 0) {
            --this.a;
         }

         this.b.t(this.a > 10);
      }
   }

   static class a extends avv {
      private final bdk a;

      public a(bdk var1) {
         this.a = var1;
         this.a(EnumSet.of(avv.a.b));
      }

      public boolean a() {
         return true;
      }

      public void e() {
         if (this.a.A() == null) {
            dcn var1 = this.a.cC();
            this.a.p = -((float)afm.d(var1.b, var1.d)) * 57.295776F;
            this.a.aA = this.a.p;
         } else {
            aqm var8 = this.a.A();
            double var2 = 64.0D;
            if (var8.h((aqa)this.a) < 4096.0D) {
               double var4 = var8.cD() - this.a.cD();
               double var6 = var8.cH() - this.a.cH();
               this.a.p = -((float)afm.d(var4, var6)) * 57.295776F;
               this.a.aA = this.a.p;
            }
         }

      }
   }

   static class d extends avv {
      private final bdk a;

      public d(bdk var1) {
         this.a = var1;
         this.a(EnumSet.of(avv.a.a));
      }

      public boolean a() {
         avb var1 = this.a.u();
         if (!var1.b()) {
            return true;
         } else {
            double var2 = var1.d() - this.a.cD();
            double var4 = var1.e() - this.a.cE();
            double var6 = var1.f() - this.a.cH();
            double var8 = var2 * var2 + var4 * var4 + var6 * var6;
            return var8 < 1.0D || var8 > 3600.0D;
         }
      }

      public boolean b() {
         return false;
      }

      public void c() {
         Random var1 = this.a.cY();
         double var2 = this.a.cD() + (double)((var1.nextFloat() * 2.0F - 1.0F) * 16.0F);
         double var4 = this.a.cE() + (double)((var1.nextFloat() * 2.0F - 1.0F) * 16.0F);
         double var6 = this.a.cH() + (double)((var1.nextFloat() * 2.0F - 1.0F) * 16.0F);
         this.a.u().a(var2, var4, var6, 1.0D);
      }
   }

   static class b extends avb {
      private final bdk i;
      private int j;

      public b(bdk var1) {
         super(var1);
         this.i = var1;
      }

      public void a() {
         if (this.h == avb.a.b) {
            if (this.j-- <= 0) {
               this.j += this.i.cY().nextInt(5) + 2;
               dcn var1 = new dcn(this.b - this.i.cD(), this.c - this.i.cE(), this.d - this.i.cH());
               double var2 = var1.f();
               var1 = var1.d();
               if (this.a(var1, afm.f(var2))) {
                  this.i.f(this.i.cC().e(var1.a(0.1D)));
               } else {
                  this.h = avb.a.a;
               }
            }

         }
      }

      private boolean a(dcn var1, int var2) {
         dci var3 = this.i.cc();

         for(int var4 = 1; var4 < var2; ++var4) {
            var3 = var3.c(var1);
            if (!this.i.l.a_(this.i, var3)) {
               return false;
            }
         }

         return true;
      }
   }
}
