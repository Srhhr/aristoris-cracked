import javax.annotation.Nullable;

public interface ape extends aon {
   int[] a(gc var1);

   boolean a(int var1, bmb var2, @Nullable gc var3);

   boolean b(int var1, bmb var2, gc var3);
}
