import com.google.common.collect.Maps;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.function.Consumer;
import java.util.function.Predicate;
import javax.annotation.Nullable;

public class bab extends are {
   private static final bon br;
   private static final us<Integer> bs;
   private static final us<Boolean> bt;
   private static final us<Boolean> bu;
   private static final us<Integer> bv;
   public static final Map<Integer, vk> bq;
   private bab.a<bfw> bw;
   private axf bx;
   private float by;
   private float bz;
   private float bA;
   private float bB;
   private float bC;
   private float bD;

   public bab(aqe<? extends bab> var1, brx var2) {
      super(var1, var2);
   }

   public vk eU() {
      return (vk)bq.getOrDefault(this.eV(), bq.get(0));
   }

   protected void o() {
      this.bx = new bab.c(this, 0.6D, br, true);
      this.bk.a(1, new avp(this));
      this.bk.a(1, new axb(this));
      this.bk.a(2, new bab.b(this));
      this.bk.a(3, this.bx);
      this.bk.a(5, new avj(this, 1.1D, 8));
      this.bk.a(6, new avt(this, 1.0D, 10.0F, 5.0F, false));
      this.bk.a(7, new avk(this, 0.8D));
      this.bk.a(8, new awb(this, 0.3F));
      this.bk.a(9, new awm(this));
      this.bk.a(10, new avi(this, 0.8D));
      this.bk.a(11, new axk(this, 0.8D, 1.0000001E-5F));
      this.bk.a(12, new awd(this, bfw.class, 10.0F));
      this.bl.a(1, new axt(this, baq.class, false, (Predicate)null));
      this.bl.a(1, new axt(this, bax.class, false, bax.bo));
   }

   public int eV() {
      return (Integer)this.R.a(bs);
   }

   public void t(int var1) {
      if (var1 < 0 || var1 >= 11) {
         var1 = this.J.nextInt(10);
      }

      this.R.b(bs, var1);
   }

   public void x(boolean var1) {
      this.R.b(bt, var1);
   }

   public boolean eW() {
      return (Boolean)this.R.a(bt);
   }

   public void y(boolean var1) {
      this.R.b(bu, var1);
   }

   public boolean eX() {
      return (Boolean)this.R.a(bu);
   }

   public bkx eY() {
      return bkx.a((Integer)this.R.a(bv));
   }

   public void a(bkx var1) {
      this.R.b(bv, var1.b());
   }

   protected void e() {
      super.e();
      this.R.a((us)bs, (int)1);
      this.R.a((us)bt, (Object)false);
      this.R.a((us)bu, (Object)false);
      this.R.a((us)bv, (Object)bkx.o.b());
   }

   public void b(md var1) {
      super.b(var1);
      var1.b("CatType", this.eV());
      var1.a("CollarColor", (byte)this.eY().b());
   }

   public void a(md var1) {
      super.a(var1);
      this.t(var1.h("CatType"));
      if (var1.c("CollarColor", 99)) {
         this.a(bkx.a(var1.h("CollarColor")));
      }

   }

   public void N() {
      if (this.u().b()) {
         double var1 = this.u().c();
         if (var1 == 0.6D) {
            this.b(aqx.f);
            this.g(false);
         } else if (var1 == 1.33D) {
            this.b(aqx.a);
            this.g(true);
         } else {
            this.b(aqx.a);
            this.g(false);
         }
      } else {
         this.b(aqx.a);
         this.g(false);
      }

   }

   @Nullable
   protected adp I() {
      if (this.eK()) {
         if (this.eS()) {
            return adq.bx;
         } else {
            return this.J.nextInt(4) == 0 ? adq.by : adq.bq;
         }
      } else {
         return adq.br;
      }
   }

   public int D() {
      return 120;
   }

   public void eZ() {
      this.a(adq.bu, this.dG(), this.dH());
   }

   protected adp e(apk var1) {
      return adq.bw;
   }

   protected adp dq() {
      return adq.bs;
   }

   public static ark.a fa() {
      return aqn.p().a(arl.a, 10.0D).a(arl.d, 0.30000001192092896D).a(arl.f, 3.0D);
   }

   public boolean b(float var1, float var2) {
      return false;
   }

   protected void a(bfw var1, bmb var2) {
      if (this.k(var2)) {
         this.a(adq.bt, 1.0F, 1.0F);
      }

      super.a(var1, var2);
   }

   private float fb() {
      return (float)this.b(arl.f);
   }

   public boolean B(aqa var1) {
      return var1.a(apk.c(this), this.fb());
   }

   public void j() {
      super.j();
      if (this.bx != null && this.bx.h() && !this.eK() && this.K % 100 == 0) {
         this.a(adq.bv, 1.0F, 1.0F);
      }

      this.fc();
   }

   private void fc() {
      if ((this.eW() || this.eX()) && this.K % 5 == 0) {
         this.a(adq.bx, 0.6F + 0.4F * (this.J.nextFloat() - this.J.nextFloat()), 1.0F);
      }

      this.fd();
      this.fe();
   }

   private void fd() {
      this.bz = this.by;
      this.bB = this.bA;
      if (this.eW()) {
         this.by = Math.min(1.0F, this.by + 0.15F);
         this.bA = Math.min(1.0F, this.bA + 0.08F);
      } else {
         this.by = Math.max(0.0F, this.by - 0.22F);
         this.bA = Math.max(0.0F, this.bA - 0.13F);
      }

   }

   private void fe() {
      this.bD = this.bC;
      if (this.eX()) {
         this.bC = Math.min(1.0F, this.bC + 0.1F);
      } else {
         this.bC = Math.max(0.0F, this.bC - 0.13F);
      }

   }

   public float y(float var1) {
      return afm.g(var1, this.bz, this.by);
   }

   public float z(float var1) {
      return afm.g(var1, this.bB, this.bA);
   }

   public float A(float var1) {
      return afm.g(var1, this.bD, this.bC);
   }

   public bab b(aag var1, apy var2) {
      bab var3 = (bab)aqe.h.a((brx)var1);
      if (var2 instanceof bab) {
         if (this.J.nextBoolean()) {
            var3.t(this.eV());
         } else {
            var3.t(((bab)var2).eV());
         }

         if (this.eK()) {
            var3.b(this.A_());
            var3.u(true);
            if (this.J.nextBoolean()) {
               var3.a(this.eY());
            } else {
               var3.a(((bab)var2).eY());
            }
         }
      }

      return var3;
   }

   public boolean a(azz var1) {
      if (!this.eK()) {
         return false;
      } else if (!(var1 instanceof bab)) {
         return false;
      } else {
         bab var2 = (bab)var1;
         return var2.eK() && super.a((azz)var1);
      }
   }

   @Nullable
   public arc a(bsk var1, aos var2, aqp var3, @Nullable arc var4, @Nullable md var5) {
      var4 = super.a(var1, var2, var3, var4, var5);
      if (var1.af() > 0.9F) {
         this.t(this.J.nextInt(11));
      } else {
         this.t(this.J.nextInt(10));
      }

      brx var6 = var1.E();
      if (var6 instanceof aag && ((aag)var6).a().a(this.cB(), true, cla.j).e()) {
         this.t(10);
         this.es();
      }

      return var4;
   }

   public aou b(bfw var1, aot var2) {
      bmb var3 = var1.b((aot)var2);
      blx var4 = var3.b();
      if (this.l.v) {
         if (this.eK() && this.i(var1)) {
            return aou.a;
         } else {
            return !this.k(var3) || !(this.dk() < this.dx()) && this.eK() ? aou.c : aou.a;
         }
      } else {
         aou var6;
         if (this.eK()) {
            if (this.i(var1)) {
               if (!(var4 instanceof bky)) {
                  if (var4.s() && this.k(var3) && this.dk() < this.dx()) {
                     this.a(var1, var3);
                     this.b((float)var4.t().a());
                     return aou.b;
                  }

                  var6 = super.b(var1, var2);
                  if (!var6.a() || this.w_()) {
                     this.w(!this.eO());
                  }

                  return var6;
               }

               bkx var5 = ((bky)var4).d();
               if (var5 != this.eY()) {
                  this.a(var5);
                  if (!var1.bC.d) {
                     var3.g(1);
                  }

                  this.es();
                  return aou.b;
               }
            }
         } else if (this.k(var3)) {
            this.a(var1, var3);
            if (this.J.nextInt(3) == 0) {
               this.f(var1);
               this.w(true);
               this.l.a(this, (byte)7);
            } else {
               this.l.a(this, (byte)6);
            }

            this.es();
            return aou.b;
         }

         var6 = super.b(var1, var2);
         if (var6.a()) {
            this.es();
         }

         return var6;
      }
   }

   public boolean k(bmb var1) {
      return br.a(var1);
   }

   protected float b(aqx var1, aqb var2) {
      return var2.b * 0.5F;
   }

   public boolean h(double var1) {
      return !this.eK() && this.K > 2400;
   }

   protected void eL() {
      if (this.bw == null) {
         this.bw = new bab.a(this, bfw.class, 16.0F, 0.8D, 1.33D);
      }

      this.bk.a((avv)this.bw);
      if (!this.eK()) {
         this.bk.a(4, this.bw);
      }

   }

   // $FF: synthetic method
   public apy a(aag var1, apy var2) {
      return this.b(var1, var2);
   }

   static {
      br = bon.a(bmd.ml, bmd.mm);
      bs = uv.a(bab.class, uu.b);
      bt = uv.a(bab.class, uu.i);
      bu = uv.a(bab.class, uu.i);
      bv = uv.a(bab.class, uu.b);
      bq = (Map)x.a((Object)Maps.newHashMap(), (Consumer)((var0) -> {
         var0.put(0, new vk("textures/entity/cat/tabby.png"));
         var0.put(1, new vk("textures/entity/cat/black.png"));
         var0.put(2, new vk("textures/entity/cat/red.png"));
         var0.put(3, new vk("textures/entity/cat/siamese.png"));
         var0.put(4, new vk("textures/entity/cat/british_shorthair.png"));
         var0.put(5, new vk("textures/entity/cat/calico.png"));
         var0.put(6, new vk("textures/entity/cat/persian.png"));
         var0.put(7, new vk("textures/entity/cat/ragdoll.png"));
         var0.put(8, new vk("textures/entity/cat/white.png"));
         var0.put(9, new vk("textures/entity/cat/jellie.png"));
         var0.put(10, new vk("textures/entity/cat/all_black.png"));
      }));
   }

   static class b extends avv {
      private final bab a;
      private bfw b;
      private fx c;
      private int d;

      public b(bab var1) {
         this.a = var1;
      }

      public boolean a() {
         if (!this.a.eK()) {
            return false;
         } else if (this.a.eO()) {
            return false;
         } else {
            aqm var1 = this.a.eN();
            if (var1 instanceof bfw) {
               this.b = (bfw)var1;
               if (!var1.em()) {
                  return false;
               }

               if (this.a.h(this.b) > 100.0D) {
                  return false;
               }

               fx var2 = this.b.cB();
               ceh var3 = this.a.l.d_(var2);
               if (var3.b().a((ael)aed.L)) {
                  this.c = (fx)var3.d(buj.aq).map((var1x) -> {
                     return var2.a(var1x.f());
                  }).orElseGet(() -> {
                     return new fx(var2);
                  });
                  return !this.g();
               }
            }

            return false;
         }
      }

      private boolean g() {
         List<bab> var1 = this.a.l.a((Class)bab.class, (dci)(new dci(this.c)).g(2.0D));
         Iterator var2 = var1.iterator();

         bab var3;
         do {
            do {
               if (!var2.hasNext()) {
                  return false;
               }

               var3 = (bab)var2.next();
            } while(var3 == this.a);
         } while(!var3.eW() && !var3.eX());

         return true;
      }

      public boolean b() {
         return this.a.eK() && !this.a.eO() && this.b != null && this.b.em() && this.c != null && !this.g();
      }

      public void c() {
         if (this.c != null) {
            this.a.v(false);
            this.a.x().a((double)this.c.u(), (double)this.c.v(), (double)this.c.w(), 1.100000023841858D);
         }

      }

      public void d() {
         this.a.x(false);
         float var1 = this.a.l.f(1.0F);
         if (this.b.eC() >= 100 && (double)var1 > 0.77D && (double)var1 < 0.8D && (double)this.a.l.u_().nextFloat() < 0.7D) {
            this.h();
         }

         this.d = 0;
         this.a.y(false);
         this.a.x().o();
      }

      private void h() {
         Random var1 = this.a.cY();
         fx.a var2 = new fx.a();
         var2.g(this.a.cB());
         this.a.a((double)(var2.u() + var1.nextInt(11) - 5), (double)(var2.v() + var1.nextInt(5) - 2), (double)(var2.w() + var1.nextInt(11) - 5), false);
         var2.g(this.a.cB());
         cyy var3 = this.a.l.l().aJ().a(cyq.ak);
         cyv.a var4 = (new cyv.a((aag)this.a.l)).a((daz)dbc.f, (Object)this.a.cA()).a((daz)dbc.a, (Object)this.a).a(var1);
         List<bmb> var5 = var3.a(var4.a(dbb.g));
         Iterator var6 = var5.iterator();

         while(var6.hasNext()) {
            bmb var7 = (bmb)var6.next();
            this.a.l.c((aqa)(new bcv(this.a.l, (double)var2.u() - (double)afm.a(this.a.aA * 0.017453292F), (double)var2.v(), (double)var2.w() + (double)afm.b(this.a.aA * 0.017453292F), var7)));
         }

      }

      public void e() {
         if (this.b != null && this.c != null) {
            this.a.v(false);
            this.a.x().a((double)this.c.u(), (double)this.c.v(), (double)this.c.w(), 1.100000023841858D);
            if (this.a.h(this.b) < 2.5D) {
               ++this.d;
               if (this.d > 16) {
                  this.a.x(true);
                  this.a.y(false);
               } else {
                  this.a.a(this.b, 45.0F, 45.0F);
                  this.a.y(true);
               }
            } else {
               this.a.x(false);
            }
         }

      }
   }

   static class c extends axf {
      @Nullable
      private bfw c;
      private final bab d;

      public c(bab var1, double var2, bon var4, boolean var5) {
         super(var1, var2, var4, var5);
         this.d = var1;
      }

      public void e() {
         super.e();
         if (this.c == null && this.a.cY().nextInt(600) == 0) {
            this.c = this.b;
         } else if (this.a.cY().nextInt(500) == 0) {
            this.c = null;
         }

      }

      protected boolean g() {
         return this.c != null && this.c.equals(this.b) ? false : super.g();
      }

      public boolean a() {
         return super.a() && !this.d.eK();
      }
   }

   static class a<T extends aqm> extends avd<T> {
      private final bab i;

      public a(bab var1, Class<T> var2, float var3, double var4, double var6) {
         Predicate var10006 = aqd.e;
         super(var1, var2, var3, var4, var6, var10006::test);
         this.i = var1;
      }

      public boolean a() {
         return !this.i.eK() && super.a();
      }

      public boolean b() {
         return !this.i.eK() && super.b();
      }
   }
}
