import com.google.common.collect.ImmutableList;
import java.util.Collection;
import java.util.Locale;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.annotation.Nullable;

public class dsc extends dot {
   protected static final vk a = new vk("textures/gui/social_interactions.png");
   private static final nr b = new of("gui.socialInteractions.tab_all");
   private static final nr c = new of("gui.socialInteractions.tab_hidden");
   private static final nr p = new of("gui.socialInteractions.tab_blocked");
   private static final nr q;
   private static final nr r;
   private static final nr s;
   private static final nr t;
   private static final nr u;
   private static final nr v;
   private static final nr w;
   private static final nr x;
   private dsb y;
   private dlq z;
   private String A = "";
   private dsc.a B;
   private dlj C;
   private dlj D;
   private dlj E;
   private dlj F;
   @Nullable
   private nr G;
   private int H;
   private boolean I;
   @Nullable
   private Runnable J;

   public dsc() {
      super(new of("gui.socialInteractions.title"));
      this.B = dsc.a.a;
      this.a(djz.C());
   }

   private int i() {
      return Math.max(52, this.l - 128 - 16);
   }

   private int k() {
      return this.i() / 16;
   }

   private int l() {
      return 80 + this.k() * 16 - 8;
   }

   private int m() {
      return (this.k - 238) / 2;
   }

   public String ax_() {
      return super.ax_() + ". " + this.G.getString();
   }

   public void d() {
      super.d();
      this.z.a();
   }

   protected void b() {
      this.i.m.a(true);
      if (this.I) {
         this.y.a(this.k, this.l, 88, this.l());
      } else {
         this.y = new dsb(this, this.i, this.k, this.l, 88, this.l(), 36);
      }

      int var1 = this.y.d() / 3;
      int var2 = this.y.q();
      int var3 = this.y.r();
      int var4 = this.o.a((nu)x) + 40;
      int var5 = 64 + 16 * this.k();
      int var6 = (this.k - var4) / 2;
      this.C = (dlj)this.a((dlh)(new dlj(var2, 45, var1, 20, b, (var1x) -> {
         this.a(dsc.a.a);
      })));
      this.D = (dlj)this.a((dlh)(new dlj((var2 + var3 - var1) / 2 + 1, 45, var1, 20, c, (var1x) -> {
         this.a(dsc.a.b);
      })));
      this.E = (dlj)this.a((dlh)(new dlj(var3 - var1 + 1, 45, var1, 20, p, (var1x) -> {
         this.a(dsc.a.c);
      })));
      this.F = (dlj)this.a((dlh)(new dlj(var6, var5, var4, 20, x, (var1x) -> {
         this.i.a((dot)(new dnr((var1) -> {
            if (var1) {
               x.i().a("https://aka.ms/javablocking");
            }

            this.i.a((dot)this);
         }, "https://aka.ms/javablocking", true)));
      })));
      String var7 = this.z != null ? this.z.b() : "";
      this.z = new dlq(this.o, this.m() + 28, 78, 196, 16, t) {
         protected nx c() {
            return !dsc.this.z.b().isEmpty() && dsc.this.y.f() ? super.c().c(", ").a(dsc.u) : super.c();
         }
      };
      this.z.k(16);
      this.z.f(false);
      this.z.i(true);
      this.z.l(16777215);
      this.z.a(var7);
      this.z.a(this::b);
      this.e.add(this.z);
      this.e.add(this.y);
      this.I = true;
      this.a(this.B);
   }

   private void a(dsc.a var1) {
      this.B = var1;
      this.C.a(b);
      this.D.a(c);
      this.E.a(p);
      Object var2;
      switch(var1) {
      case a:
         this.C.a(q);
         var2 = this.i.s.e.f();
         break;
      case b:
         this.D.a(r);
         var2 = this.i.aB().a();
         break;
      case c:
         this.E.a(s);
         dsa var3 = this.i.aB();
         Stream var10000 = this.i.s.e.f().stream();
         var3.getClass();
         var2 = (Collection)var10000.filter(var3::e).collect(Collectors.toSet());
         break;
      default:
         var2 = ImmutableList.of();
      }

      this.B = var1;
      this.y.a((Collection)var2, this.y.m());
      if (!this.z.b().isEmpty() && this.y.f() && !this.z.j()) {
         dkz.b.a(u.getString());
      } else if (((Collection)var2).isEmpty()) {
         if (var1 == dsc.a.b) {
            dkz.b.a(v.getString());
         } else if (var1 == dsc.a.c) {
            dkz.b.a(w.getString());
         }
      }

   }

   public void e() {
      this.i.m.a(false);
   }

   public void a(dfm var1) {
      int var2 = this.m() + 3;
      super.a(var1);
      this.i.M().a(a);
      this.b(var1, var2, 64, 1, 1, 236, 8);
      int var3 = this.k();

      for(int var4 = 0; var4 < var3; ++var4) {
         this.b(var1, var2, 72 + 16 * var4, 1, 10, 236, 16);
      }

      this.b(var1, var2, 72 + 16 * var3, 1, 27, 236, 8);
      this.b(var1, var2 + 10, 76, 243, 1, 12, 12);
   }

   public void a(dfm var1, int var2, int var3, float var4) {
      this.a(this.i);
      this.a(var1);
      if (this.G != null) {
         b(var1, this.i.g, this.G, this.m() + 8, 35, -1);
      }

      if (!this.y.f()) {
         this.y.a(var1, var2, var3, var4);
      } else if (!this.z.b().isEmpty()) {
         a(var1, this.i.g, u, this.k / 2, (78 + this.l()) / 2, -1);
      } else {
         switch(this.B) {
         case b:
            a(var1, this.i.g, v, this.k / 2, (78 + this.l()) / 2, -1);
            break;
         case c:
            a(var1, this.i.g, w, this.k / 2, (78 + this.l()) / 2, -1);
         }
      }

      if (!this.z.j() && this.z.b().isEmpty()) {
         b(var1, this.i.g, t, this.z.l, this.z.m, -1);
      } else {
         this.z.a(var1, var2, var3, var4);
      }

      this.F.p = this.B == dsc.a.c;
      super.a(var1, var2, var3, var4);
      if (this.J != null) {
         this.J.run();
      }

   }

   public boolean a(double var1, double var3, int var5) {
      if (this.z.j()) {
         this.z.a(var1, var3, var5);
      }

      return super.a(var1, var3, var5) || this.y.a(var1, var3, var5);
   }

   public boolean a(int var1, int var2, int var3) {
      if (!this.z.j() && this.i.k.av.a(var1, var2)) {
         this.i.a((dot)null);
         return true;
      } else {
         return super.a(var1, var2, var3);
      }
   }

   public boolean ay_() {
      return false;
   }

   private void b(String var1) {
      var1 = var1.toLowerCase(Locale.ROOT);
      if (!var1.equals(this.A)) {
         this.y.a(var1);
         this.A = var1;
         this.a(this.B);
      }

   }

   private void a(djz var1) {
      int var2 = var1.w().e().size();
      if (this.H != var2) {
         String var3 = "";
         dwz var4 = var1.E();
         if (var1.F()) {
            var3 = var1.H().ab();
         } else if (var4 != null) {
            var3 = var4.a;
         }

         if (var2 > 1) {
            this.G = new of("gui.socialInteractions.server_label.multiple", new Object[]{var3, var2});
         } else {
            this.G = new of("gui.socialInteractions.server_label.single", new Object[]{var3, var2});
         }

         this.H = var2;
      }

   }

   public void a(dwx var1) {
      this.y.a(var1, this.B);
   }

   public void a(UUID var1) {
      this.y.a(var1);
   }

   public void a(@Nullable Runnable var1) {
      this.J = var1;
   }

   static {
      q = b.g().a(k.t);
      r = c.g().a(k.t);
      s = p.g().a(k.t);
      t = (new of("gui.socialInteractions.search_hint")).a(k.u).a(k.h);
      u = (new of("gui.socialInteractions.search_empty")).a(k.h);
      v = (new of("gui.socialInteractions.empty_hidden")).a(k.h);
      w = (new of("gui.socialInteractions.empty_blocked")).a(k.h);
      x = new of("gui.socialInteractions.blocking_hint");
   }

   public static enum a {
      a,
      b,
      c;
   }
}
