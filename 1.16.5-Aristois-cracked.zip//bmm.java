import com.mojang.authlib.GameProfile;
import java.util.UUID;
import org.apache.commons.lang3.StringUtils;

public class bmm extends bnd {
   public bmm(buo var1, buo var2, blx.a var3) {
      super(var1, var2, var3);
   }

   public nr h(bmb var1) {
      if (var1.b() == bmd.pg && var1.n()) {
         String var2 = null;
         md var3 = var1.o();
         if (var3.c("SkullOwner", 8)) {
            var2 = var3.l("SkullOwner");
         } else if (var3.c("SkullOwner", 10)) {
            md var4 = var3.p("SkullOwner");
            if (var4.c("Name", 8)) {
               var2 = var4.l("Name");
            }
         }

         if (var2 != null) {
            return new of(this.a() + ".named", new Object[]{var2});
         }
      }

      return super.h(var1);
   }

   public boolean b(md var1) {
      super.b(var1);
      if (var1.c("SkullOwner", 8) && !StringUtils.isBlank(var1.l("SkullOwner"))) {
         GameProfile var2 = new GameProfile((UUID)null, var1.l("SkullOwner"));
         var2 = cdg.b(var2);
         var1.a((String)"SkullOwner", (mt)mp.a(new md(), var2));
         return true;
      } else {
         return false;
      }
   }
}
