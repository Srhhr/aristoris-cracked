import com.google.common.math.IntMath;
import it.unimi.dsi.fastutil.doubles.DoubleList;

public final class dcv implements dcz {
   private final dct a;
   private final int b;
   private final int c;
   private final int d;

   dcv(int var1, int var2) {
      this.a = new dct((int)dde.a(var1, var2));
      this.b = var1;
      this.c = var2;
      this.d = IntMath.gcd(var1, var2);
   }

   public boolean a(dcz.a var1) {
      int var2 = this.b / this.d;
      int var3 = this.c / this.d;

      for(int var4 = 0; var4 <= this.a.size(); ++var4) {
         if (!var1.merge(var4 / var3, var4 / var2, var4)) {
            return false;
         }
      }

      return true;
   }

   public DoubleList a() {
      return this.a;
   }
}
