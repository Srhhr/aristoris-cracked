import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSyntaxException;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class dac extends dai {
   private static final Logger a = LogManager.getLogger();
   private final List<bps> b;

   private dac(dbo[] var1, Collection<bps> var2) {
      super(var1);
      this.b = ImmutableList.copyOf(var2);
   }

   public dak b() {
      return dal.d;
   }

   public bmb a(bmb var1, cyv var2) {
      Random var4 = var2.a();
      bps var3;
      if (this.b.isEmpty()) {
         boolean var5 = var1.b() == bmd.mc;
         List<bps> var6 = (List)gm.R.g().filter(bps::i).filter((var2x) -> {
            return var5 || var2x.a(var1);
         }).collect(Collectors.toList());
         if (var6.isEmpty()) {
            a.warn("Couldn't find a compatible enchantment for {}", var1);
            return var1;
         }

         var3 = (bps)var6.get(var4.nextInt(var6.size()));
      } else {
         var3 = (bps)this.b.get(var4.nextInt(this.b.size()));
      }

      return a(var1, var3, var4);
   }

   private static bmb a(bmb var0, bps var1, Random var2) {
      int var3 = afm.a(var2, var1.e(), var1.a());
      if (var0.b() == bmd.mc) {
         var0 = new bmb(bmd.pq);
         blf.a(var0, new bpv(var1, var3));
      } else {
         var0.a(var1, var3);
      }

      return var0;
   }

   public static dai.a<?> d() {
      return a((Function)((var0) -> {
         return new dac(var0, ImmutableList.of());
      }));
   }

   // $FF: synthetic method
   dac(dbo[] var1, Collection var2, Object var3) {
      this(var1, var2);
   }

   public static class b extends dai.c<dac> {
      public void a(JsonObject var1, dac var2, JsonSerializationContext var3) {
         super.a(var1, (dai)var2, var3);
         if (!var2.b.isEmpty()) {
            JsonArray var4 = new JsonArray();
            Iterator var5 = var2.b.iterator();

            while(var5.hasNext()) {
               bps var6 = (bps)var5.next();
               vk var7 = gm.R.b((Object)var6);
               if (var7 == null) {
                  throw new IllegalArgumentException("Don't know how to serialize enchantment " + var6);
               }

               var4.add(new JsonPrimitive(var7.toString()));
            }

            var1.add("enchantments", var4);
         }

      }

      public dac a(JsonObject var1, JsonDeserializationContext var2, dbo[] var3) {
         List<bps> var4 = Lists.newArrayList();
         if (var1.has("enchantments")) {
            JsonArray var5 = afd.u(var1, "enchantments");
            Iterator var6 = var5.iterator();

            while(var6.hasNext()) {
               JsonElement var7 = (JsonElement)var6.next();
               String var8 = afd.a(var7, "enchantment");
               bps var9 = (bps)gm.R.b(new vk(var8)).orElseThrow(() -> {
                  return new JsonSyntaxException("Unknown enchantment '" + var8 + "'");
               });
               var4.add(var9);
            }
         }

         return new dac(var3, var4);
      }

      // $FF: synthetic method
      public dai b(JsonObject var1, JsonDeserializationContext var2, dbo[] var3) {
         return this.a(var1, var2, var3);
      }
   }

   public static class a extends dai.a<dac.a> {
      private final Set<bps> a = Sets.newHashSet();

      protected dac.a a() {
         return this;
      }

      public dac.a a(bps var1) {
         this.a.add(var1);
         return this;
      }

      public daj b() {
         return new dac(this.g(), this.a);
      }

      // $FF: synthetic method
      protected dai.a d() {
         return this.a();
      }
   }
}
