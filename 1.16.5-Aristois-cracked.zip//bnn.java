public enum bnn {
   a,
   b,
   c,
   d,
   e,
   f,
   g;
}
