import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import javax.annotation.Nullable;

public class dbw implements dbo {
   @Nullable
   private final Long a;
   private final czd b;

   private dbw(@Nullable Long var1, czd var2) {
      this.a = var1;
      this.b = var2;
   }

   public dbp b() {
      return dbq.p;
   }

   public boolean a(cyv var1) {
      aag var2 = var1.c();
      long var3 = var2.U();
      if (this.a != null) {
         var3 %= this.a;
      }

      return this.b.a((int)var3);
   }

   // $FF: synthetic method
   public boolean test(Object var1) {
      return this.a((cyv)var1);
   }

   // $FF: synthetic method
   dbw(Long var1, czd var2, Object var3) {
      this(var1, var2);
   }

   public static class b implements cze<dbw> {
      public void a(JsonObject var1, dbw var2, JsonSerializationContext var3) {
         var1.addProperty("period", var2.a);
         var1.add("value", var3.serialize(var2.b));
      }

      public dbw b(JsonObject var1, JsonDeserializationContext var2) {
         Long var3 = var1.has("period") ? afd.m(var1, "period") : null;
         czd var4 = (czd)afd.a(var1, "value", var2, czd.class);
         return new dbw(var3, var4);
      }

      // $FF: synthetic method
      public Object a(JsonObject var1, JsonDeserializationContext var2) {
         return this.b(var1, var2);
      }
   }
}
