import java.util.List;

public interface dsr {
   List<dss> a();

   nr b();
}
