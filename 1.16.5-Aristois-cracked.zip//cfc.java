public enum cfc implements afs {
   a,
   b;

   public String toString() {
      return this.a();
   }

   public String a() {
      return this == a ? "left" : "right";
   }
}
