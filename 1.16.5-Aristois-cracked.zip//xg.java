import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import java.util.Collection;
import java.util.Iterator;

public class xg {
   public static void a(CommandDispatcher<db> var0) {
      var0.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)dc.a("kick").requires((var0x) -> {
         return var0x.c(3);
      })).then(((RequiredArgumentBuilder)dc.a((String)"targets", (ArgumentType)dk.d()).executes((var0x) -> {
         return a((db)var0x.getSource(), dk.f(var0x, "targets"), new of("multiplayer.disconnect.kicked"));
      })).then(dc.a((String)"reason", (ArgumentType)dp.a()).executes((var0x) -> {
         return a((db)var0x.getSource(), dk.f(var0x, "targets"), dp.a(var0x, "reason"));
      }))));
   }

   private static int a(db var0, Collection<aah> var1, nr var2) {
      Iterator var3 = var1.iterator();

      while(var3.hasNext()) {
         aah var4 = (aah)var3.next();
         var4.b.b(var2);
         var0.a(new of("commands.kick.success", new Object[]{var4.d(), var2}), true);
      }

      return var1.size();
   }
}
