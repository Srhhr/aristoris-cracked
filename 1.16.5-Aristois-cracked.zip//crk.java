import java.util.List;
import java.util.Random;

public class crk {
   private static final vk[] a = new vk[]{new vk("nether_fossils/fossil_1"), new vk("nether_fossils/fossil_2"), new vk("nether_fossils/fossil_3"), new vk("nether_fossils/fossil_4"), new vk("nether_fossils/fossil_5"), new vk("nether_fossils/fossil_6"), new vk("nether_fossils/fossil_7"), new vk("nether_fossils/fossil_8"), new vk("nether_fossils/fossil_9"), new vk("nether_fossils/fossil_10"), new vk("nether_fossils/fossil_11"), new vk("nether_fossils/fossil_12"), new vk("nether_fossils/fossil_13"), new vk("nether_fossils/fossil_14")};

   public static void a(csw var0, List<cru> var1, Random var2, fx var3) {
      bzm var4 = bzm.a(var2);
      var1.add(new crk.a(var0, (vk)x.a((Object[])a, (Random)var2), var3, var4));
   }

   public static class a extends crx {
      private final vk d;
      private final bzm e;

      public a(csw var1, vk var2, fx var3, bzm var4) {
         super(clb.ac, 0);
         this.d = var2;
         this.c = var3;
         this.e = var4;
         this.a(var1);
      }

      public a(csw var1, md var2) {
         super(clb.ac, var2);
         this.d = new vk(var2.l("Template"));
         this.e = bzm.valueOf(var2.l("Rot"));
         this.a(var1);
      }

      private void a(csw var1) {
         ctb var2 = var1.a(this.d);
         csx var3 = (new csx()).a(this.e).a(byg.a).a((csy)cse.d);
         this.a(var2, this.c, var3);
      }

      protected void a(md var1) {
         super.a(var1);
         var1.a("Template", this.d.toString());
         var1.a("Rot", this.e.name());
      }

      protected void a(String var1, fx var2, bsk var3, Random var4, cra var5) {
      }

      public boolean a(bsr var1, bsn var2, cfy var3, Random var4, cra var5, brd var6, fx var7) {
         var5.c(this.a.b(this.b, this.c));
         return super.a(var1, var2, var3, var4, var5, var6, var7);
      }
   }
}
