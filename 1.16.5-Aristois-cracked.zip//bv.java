import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import javax.annotation.Nullable;

public class bv {
   public static final bv a;
   private final bz.d b;

   private bv(bz.d var1) {
      this.b = var1;
   }

   public boolean a(aag var1, fx var2) {
      if (this == a) {
         return true;
      } else if (!var1.p(var2)) {
         return false;
      } else {
         return this.b.d(var1.B(var2));
      }
   }

   public JsonElement a() {
      if (this == a) {
         return JsonNull.INSTANCE;
      } else {
         JsonObject var1 = new JsonObject();
         var1.add("light", this.b.d());
         return var1;
      }
   }

   public static bv a(@Nullable JsonElement var0) {
      if (var0 != null && !var0.isJsonNull()) {
         JsonObject var1 = afd.m(var0, "light");
         bz.d var2 = bz.d.a(var1.get("light"));
         return new bv(var2);
      } else {
         return a;
      }
   }

   static {
      a = new bv(bz.d.e);
   }
}
