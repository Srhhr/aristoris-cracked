import com.mojang.serialization.Codec;
import java.util.Random;
import java.util.stream.Stream;

public class cqa extends cqc<cmg> {
   public cqa(Codec<cmg> var1) {
      super(var1);
   }

   public Stream<fx> a(cpv var1, Random var2, cmg var3, fx var4) {
      if (var2.nextInt(700) == 0) {
         int var5 = var2.nextInt(16) + var4.u();
         int var6 = var2.nextInt(16) + var4.w();
         int var7 = var1.a(chn.a.e, var5, var6);
         if (var7 > 0) {
            int var8 = var7 + 3 + var2.nextInt(7);
            return Stream.of(new fx(var5, var8, var6));
         }
      }

      return Stream.empty();
   }
}
