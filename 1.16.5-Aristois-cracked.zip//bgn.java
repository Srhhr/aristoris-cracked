import java.util.Iterator;
import java.util.Optional;
import java.util.function.Predicate;
import javax.annotation.Nullable;

public final class bgn {
   public static dcl a(aqa var0, Predicate<aqa> var1) {
      dcn var2 = var0.cC();
      brx var3 = var0.l;
      dcn var4 = var0.cA();
      dcn var5 = var4.e(var2);
      dcl var6 = var3.a((brf)(new brf(var4, var5, brf.a.a, brf.b.a, var0)));
      if (((dcl)var6).c() != dcl.a.a) {
         var5 = ((dcl)var6).e();
      }

      dcl var7 = a(var3, var0, var4, var5, var0.cc().b(var0.cC()).g(1.0D), var1);
      if (var7 != null) {
         var6 = var7;
      }

      return (dcl)var6;
   }

   @Nullable
   public static dck a(aqa var0, dcn var1, dcn var2, dci var3, Predicate<aqa> var4, double var5) {
      brx var7 = var0.l;
      double var8 = var5;
      aqa var10 = null;
      dcn var11 = null;
      Iterator var12 = var7.a(var0, var3, var4).iterator();

      while(true) {
         while(var12.hasNext()) {
            aqa var13 = (aqa)var12.next();
            dci var14 = var13.cc().g((double)var13.bg());
            Optional<dcn> var15 = var14.b(var1, var2);
            if (var14.d(var1)) {
               if (var8 >= 0.0D) {
                  var10 = var13;
                  var11 = (dcn)var15.orElse(var1);
                  var8 = 0.0D;
               }
            } else if (var15.isPresent()) {
               dcn var16 = (dcn)var15.get();
               double var17 = var1.g(var16);
               if (var17 < var8 || var8 == 0.0D) {
                  if (var13.cr() == var0.cr()) {
                     if (var8 == 0.0D) {
                        var10 = var13;
                        var11 = var16;
                     }
                  } else {
                     var10 = var13;
                     var11 = var16;
                     var8 = var17;
                  }
               }
            }
         }

         if (var10 == null) {
            return null;
         }

         return new dck(var10, var11);
      }
   }

   @Nullable
   public static dck a(brx var0, aqa var1, dcn var2, dcn var3, dci var4, Predicate<aqa> var5) {
      double var6 = Double.MAX_VALUE;
      aqa var8 = null;
      Iterator var9 = var0.a(var1, var4, var5).iterator();

      while(var9.hasNext()) {
         aqa var10 = (aqa)var9.next();
         dci var11 = var10.cc().g(0.30000001192092896D);
         Optional<dcn> var12 = var11.b(var2, var3);
         if (var12.isPresent()) {
            double var13 = var2.g((dcn)var12.get());
            if (var13 < var6) {
               var8 = var10;
               var6 = var13;
            }
         }
      }

      if (var8 == null) {
         return null;
      } else {
         return new dck(var8);
      }
   }

   public static final void a(aqa var0, float var1) {
      dcn var2 = var0.cC();
      if (var2.g() != 0.0D) {
         float var3 = afm.a(aqa.c(var2));
         var0.p = (float)(afm.d(var2.d, var2.b) * 57.2957763671875D) + 90.0F;

         for(var0.q = (float)(afm.d((double)var3, var2.c) * 57.2957763671875D) - 90.0F; var0.q - var0.s < -180.0F; var0.s -= 360.0F) {
         }

         while(var0.q - var0.s >= 180.0F) {
            var0.s += 360.0F;
         }

         while(var0.p - var0.r < -180.0F) {
            var0.r -= 360.0F;
         }

         while(var0.p - var0.r >= 180.0F) {
            var0.r += 360.0F;
         }

         var0.q = afm.g(var1, var0.s, var0.q);
         var0.p = afm.g(var1, var0.r, var0.p);
      }
   }

   public static aot a(aqm var0, blx var1) {
      return var0.dD().b() == var1 ? aot.a : aot.b;
   }

   public static bga a(aqm var0, bmb var1, float var2) {
      bkc var3 = (bkc)((bkc)(var1.b() instanceof bkc ? var1.b() : bmd.kd));
      bga var4 = var3.a(var0.l, var1, var0);
      var4.a(var0, var2);
      if (var1.b() == bmd.ql && var4 instanceof bgc) {
         ((bgc)var4).b(var1);
      }

      return var4;
   }
}
