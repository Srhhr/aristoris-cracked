import com.google.common.collect.Lists;
import javax.annotation.Nullable;

public final class ejv extends ekc {
   private static final vk b = new vk("missingno");
   @Nullable
   private static ejs c;
   private static final afi<det> d = new afi(() -> {
      det var0 = new det(16, 16, false);
      int var1 = -16777216;
      int var2 = -524040;

      for(int var3 = 0; var3 < 16; ++var3) {
         for(int var4 = 0; var4 < 16; ++var4) {
            if (var3 < 8 ^ var4 < 8) {
               var0.a(var4, var3, -524040);
            } else {
               var0.a(var4, var3, -16777216);
            }
         }
      }

      var0.g();
      return var0;
   });
   private static final ekc.a e;

   private ejv(ekb var1, int var2, int var3, int var4, int var5, int var6) {
      super(var1, e, var2, var3, var4, var5, var6, (det)d.a());
   }

   public static ejv a(ekb var0, int var1, int var2, int var3, int var4, int var5) {
      return new ejv(var0, var1, var2, var3, var4, var5);
   }

   public static vk a() {
      return b;
   }

   public static ekc.a b() {
      return e;
   }

   public void close() {
      for(int var1 = 1; var1 < this.a.length; ++var1) {
         this.a[var1].close();
      }

   }

   public static ejs c() {
      if (c == null) {
         c = new ejs((det)d.a());
         djz.C().M().a((vk)b, (ejq)c);
      }

      return c;
   }

   static {
      e = new ekc.a(b, 16, 16, new elc(Lists.newArrayList(new elb[]{new elb(0, -1)}), 16, 16, 1, false));
   }
}
