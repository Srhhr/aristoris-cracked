import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public class mf implements mt {
   public static final mv<mf> a = new mv<mf>() {
      public mf a(DataInput var1, int var2, mm var3) {
         var3.a(64L);
         return mf.b;
      }

      public String a() {
         return "END";
      }

      public String b() {
         return "TAG_End";
      }

      public boolean c() {
         return true;
      }

      // $FF: synthetic method
      public mt b(DataInput var1, int var2, mm var3) throws IOException {
         return this.a(var1, var2, var3);
      }
   };
   public static final mf b = new mf();

   private mf() {
   }

   public void a(DataOutput var1) throws IOException {
   }

   public byte a() {
      return 0;
   }

   public mv<mf> b() {
      return a;
   }

   public String toString() {
      return "END";
   }

   public mf d() {
      return this;
   }

   public nr a(String var1, int var2) {
      return oe.d;
   }

   // $FF: synthetic method
   public mt c() {
      return this.d();
   }
}
