public class blk extends blx {
   public blk(blx.a var1) {
      super(var1);
   }

   public boolean e(bmb var1) {
      return true;
   }

   public aov<bmb> a(brx var1, bfw var2, aot var3) {
      bmb var4 = var2.b((aot)var3);
      var1.a((bfw)null, var2.cD(), var2.cE(), var2.cH(), adq.dV, adr.g, 0.5F, 0.4F / (h.nextFloat() * 0.4F + 0.8F));
      if (!var1.v) {
         bgw var5 = new bgw(var1, var2);
         var5.b(var4);
         var5.a(var2, var2.q, var2.p, -20.0F, 0.7F, 1.0F);
         var1.c((aqa)var5);
      }

      var2.b(aea.c.b(this));
      if (!var2.bC.d) {
         var4.g(1);
      }

      return aov.a(var4, var1.s_());
   }
}
