import java.util.UUID;

public class dlb implements dky {
   private final djz a;

   public dlb(djz var1) {
      this.a = var1;
   }

   public void a(no var1, nr var2, UUID var3) {
      if (var1 != no.a) {
         this.a.j.c().a(var2);
      } else {
         this.a.j.c().b(var2);
      }

   }
}
