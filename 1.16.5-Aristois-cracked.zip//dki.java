import com.mojang.bridge.game.GameSession;
import java.util.UUID;

public class dki implements GameSession {
   private final int a;
   private final boolean b;
   private final String c;
   private final String d;
   private final UUID e;

   public dki(dwt var1, dzm var2, dwu var3) {
      this.a = var3.e().size();
      this.b = !var3.a().d();
      this.c = var1.ad().c();
      dwx var4 = var3.a(var2.bS());
      if (var4 != null) {
         this.d = var4.b().b();
      } else {
         this.d = "unknown";
      }

      this.e = var3.m();
   }

   public int getPlayerCount() {
      return this.a;
   }

   public boolean isRemoteServer() {
      return this.b;
   }

   public String getDifficulty() {
      return this.c;
   }

   public String getGameMode() {
      return this.d;
   }

   public UUID getSessionId() {
      return this.e;
   }
}
