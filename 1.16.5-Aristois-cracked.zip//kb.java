import com.google.common.collect.ImmutableList;
import com.mojang.datafixers.util.Pair;

public class kb {
   public static final cok a;

   public static void a() {
      ka.a();
      jz.a();
      kd.a();
      jy.a();
      kc.a();
   }

   static {
      a = kk.a(new cok(new vk("bastion/starts"), new vk("empty"), ImmutableList.of(Pair.of(coi.b("bastion/units/air_base", kl.x), 1), Pair.of(coi.b("bastion/hoglin_stable/air_base", kl.x), 1), Pair.of(coi.b("bastion/treasure/big_air_full", kl.x), 1), Pair.of(coi.b("bastion/bridge/starting_pieces/entrance_base", kl.x), 1)), cok.a.b));
   }
}
