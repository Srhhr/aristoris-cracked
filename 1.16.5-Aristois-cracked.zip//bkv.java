import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import com.google.common.collect.ImmutableMultimap.Builder;
import java.util.Set;
import java.util.function.Consumer;

public class bkv extends bni implements bno {
   private final Set<buo> a;
   protected final float b;
   private final float c;
   private final Multimap<arg, arj> d;

   protected bkv(float var1, float var2, bnh var3, Set<buo> var4, blx.a var5) {
      super(var3, var5);
      this.a = var4;
      this.b = var3.b();
      this.c = var1 + var3.c();
      Builder<arg, arj> var6 = ImmutableMultimap.builder();
      var6.put(arl.f, new arj(f, "Tool modifier", (double)this.c, arj.a.a));
      var6.put(arl.h, new arj(g, "Tool modifier", (double)var2, arj.a.a));
      this.d = var6.build();
   }

   public float a(bmb var1, ceh var2) {
      return this.a.contains(var2.b()) ? this.b : 1.0F;
   }

   public boolean a(bmb var1, aqm var2, aqm var3) {
      var1.a(2, (aqm)var3, (Consumer)((var0) -> {
         var0.c(aqf.a);
      }));
      return true;
   }

   public boolean a(bmb var1, brx var2, ceh var3, fx var4, aqm var5) {
      if (!var2.v && var3.h(var2, var4) != 0.0F) {
         var1.a(1, (aqm)var5, (Consumer)((var0) -> {
            var0.c(aqf.a);
         }));
      }

      return true;
   }

   public Multimap<arg, arj> a(aqf var1) {
      return var1 == aqf.a ? this.d : super.a(var1);
   }

   public float d() {
      return this.c;
   }
}
