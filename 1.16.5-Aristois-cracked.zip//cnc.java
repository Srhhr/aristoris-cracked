import com.mojang.serialization.Codec;

public class cnc<P extends cnb> {
   public static final cnc<cne> a;
   public static final cnc<cnd> b;
   private final Codec<P> c;

   private static <P extends cnb> cnc<P> a(String var0, Codec<P> var1) {
      return (cnc)gm.a((gm)gm.ba, (String)var0, (Object)(new cnc(var1)));
   }

   private cnc(Codec<P> var1) {
      this.c = var1;
   }

   public Codec<P> a() {
      return this.c;
   }

   static {
      a = a("two_layers_feature_size", cne.c);
      b = a("three_layers_feature_size", cnd.c);
   }
}
