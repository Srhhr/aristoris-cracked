import java.util.function.Consumer;
import javax.annotation.Nullable;

public class caz extends buo {
   public static final cey a;

   public caz(ceg.c var1) {
      super(var1);
      this.j((ceh)this.n().a(a, false));
   }

   public void b(ceh var1, brx var2, fx var3, ceh var4, boolean var5) {
      if (!var4.a(var1.b())) {
         if (var2.r(var3)) {
            a(var2, var3);
            var2.a(var3, false);
         }

      }
   }

   public void a(ceh var1, brx var2, fx var3, buo var4, fx var5, boolean var6) {
      if (var2.r(var3)) {
         a(var2, var3);
         var2.a(var3, false);
      }

   }

   public void a(brx var1, fx var2, ceh var3, bfw var4) {
      if (!var1.s_() && !var4.b_() && (Boolean)var3.c(a)) {
         a(var1, var2);
      }

      super.a(var1, var2, var3, var4);
   }

   public void a(brx var1, fx var2, brp var3) {
      if (!var1.v) {
         bcw var4 = new bcw(var1, (double)var2.u() + 0.5D, (double)var2.v(), (double)var2.w() + 0.5D, var3.d());
         var4.a((short)(var1.t.nextInt(var4.i() / 4) + var4.i() / 8));
         var1.c((aqa)var4);
      }
   }

   public static void a(brx var0, fx var1) {
      a(var0, var1, (aqm)null);
   }

   private static void a(brx var0, fx var1, @Nullable aqm var2) {
      if (!var0.v) {
         bcw var3 = new bcw(var0, (double)var1.u() + 0.5D, (double)var1.v(), (double)var1.w() + 0.5D, var2);
         var0.c((aqa)var3);
         var0.a((bfw)null, var3.cD(), var3.cE(), var3.cH(), adq.pb, adr.e, 1.0F, 1.0F);
      }
   }

   public aou a(ceh var1, brx var2, fx var3, bfw var4, aot var5, dcj var6) {
      bmb var7 = var4.b((aot)var5);
      blx var8 = var7.b();
      if (var8 != bmd.ka && var8 != bmd.oS) {
         return super.a((ceh)var1, (brx)var2, var3, (bfw)var4, (aot)var5, (dcj)var6);
      } else {
         a(var2, var3, (aqm)var4);
         var2.a(var3, bup.a.n(), 11);
         if (!var4.b_()) {
            if (var8 == bmd.ka) {
               var7.a(1, (aqm)var4, (Consumer)((var1x) -> {
                  var1x.d((aot)var5);
               }));
            } else {
               var7.g(1);
            }
         }

         return aou.a(var2.v);
      }
   }

   public void a(brx var1, ceh var2, dcj var3, bgm var4) {
      if (!var1.v) {
         aqa var5 = var4.v();
         if (var4.bq()) {
            fx var6 = var3.a();
            a(var1, var6, var5 instanceof aqm ? (aqm)var5 : null);
            var1.a(var6, false);
         }
      }

   }

   public boolean a(brp var1) {
      return false;
   }

   protected void a(cei.a<buo, ceh> var1) {
      var1.a(a);
   }

   static {
      a = cex.B;
   }
}
