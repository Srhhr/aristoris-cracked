import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public class mb extends mq {
   public static final mv<mb> a = new mv<mb>() {
      public mb a(DataInput var1, int var2, mm var3) throws IOException {
         var3.a(72L);
         return mb.a(var1.readByte());
      }

      public String a() {
         return "BYTE";
      }

      public String b() {
         return "TAG_Byte";
      }

      public boolean c() {
         return true;
      }

      // $FF: synthetic method
      public mt b(DataInput var1, int var2, mm var3) throws IOException {
         return this.a(var1, var2, var3);
      }
   };
   public static final mb b = a((byte)0);
   public static final mb c = a((byte)1);
   private final byte h;

   private mb(byte var1) {
      this.h = var1;
   }

   public static mb a(byte var0) {
      return mb.a.a[128 + var0];
   }

   public static mb a(boolean var0) {
      return var0 ? c : b;
   }

   public void a(DataOutput var1) throws IOException {
      var1.writeByte(this.h);
   }

   public byte a() {
      return 1;
   }

   public mv<mb> b() {
      return a;
   }

   public String toString() {
      return this.h + "b";
   }

   public mb d() {
      return this;
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else {
         return var1 instanceof mb && this.h == ((mb)var1).h;
      }
   }

   public int hashCode() {
      return this.h;
   }

   public nr a(String var1, int var2) {
      nr var3 = (new oe("b")).a(g);
      return (new oe(String.valueOf(this.h))).a(var3).a(f);
   }

   public long e() {
      return (long)this.h;
   }

   public int f() {
      return this.h;
   }

   public short g() {
      return (short)this.h;
   }

   public byte h() {
      return this.h;
   }

   public double i() {
      return (double)this.h;
   }

   public float j() {
      return (float)this.h;
   }

   public Number k() {
      return this.h;
   }

   // $FF: synthetic method
   public mt c() {
      return this.d();
   }

   // $FF: synthetic method
   mb(byte var1, Object var2) {
      this(var1);
   }

   static class a {
      private static final mb[] a = new mb[256];

      static {
         for(int var0 = 0; var0 < a.length; ++var0) {
            a[var0] = new mb((byte)(var0 - 128));
         }

      }
   }
}
