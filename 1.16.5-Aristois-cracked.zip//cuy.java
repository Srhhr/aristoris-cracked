import com.google.common.collect.UnmodifiableIterator;
import java.util.Iterator;

public class cuy {
   public static final cuw a = a("empty", new cuu());
   public static final cuv b = (cuv)a("flowing_water", new cvd.a());
   public static final cuv c = (cuv)a("water", new cvd.b());
   public static final cuv d = (cuv)a("flowing_lava", new cuz.a());
   public static final cuv e = (cuv)a("lava", new cuz.b());

   private static <T extends cuw> T a(String var0, T var1) {
      return (cuw)gm.a((gm)gm.O, (String)var0, (Object)var1);
   }

   static {
      Iterator var0 = gm.O.iterator();

      while(var0.hasNext()) {
         cuw var1 = (cuw)var0.next();
         UnmodifiableIterator var2 = var1.g().a().iterator();

         while(var2.hasNext()) {
            cux var3 = (cux)var2.next();
            cuw.c.b(var3);
         }
      }

   }
}
