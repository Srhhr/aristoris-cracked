public class dzd extends dye {
   private final aqa a;
   private int b;
   private final int B;
   private final hf C;

   public dzd(dwt var1, aqa var2, hf var3) {
      this(var1, var2, var3, 3);
   }

   public dzd(dwt var1, aqa var2, hf var3, int var4) {
      this(var1, var2, var3, var4, var2.cC());
   }

   private dzd(dwt var1, aqa var2, hf var3, int var4, dcn var5) {
      super(var1, var2.cD(), var2.e(0.5D), var2.cH(), var5.b, var5.c, var5.d);
      this.a = var2;
      this.B = var4;
      this.C = var3;
      this.a();
   }

   public void a() {
      for(int var1 = 0; var1 < 16; ++var1) {
         double var2 = (double)(this.r.nextFloat() * 2.0F - 1.0F);
         double var4 = (double)(this.r.nextFloat() * 2.0F - 1.0F);
         double var6 = (double)(this.r.nextFloat() * 2.0F - 1.0F);
         if (!(var2 * var2 + var4 * var4 + var6 * var6 > 1.0D)) {
            double var8 = this.a.c(var2 / 4.0D);
            double var10 = this.a.e(0.5D + var4 / 4.0D);
            double var12 = this.a.f(var6 / 4.0D);
            this.c.a(this.C, false, var8, var10, var12, var2, var4 + 0.2D, var6);
         }
      }

      ++this.b;
      if (this.b >= this.B) {
         this.j();
      }

   }
}
