public class eff extends efw<bem, duj<bem>> {
   private static final vk a = new vk("textures/entity/hoglin/hoglin.png");

   public eff(eet var1) {
      super(var1, new duj(), 0.7F);
   }

   public vk a(bem var1) {
      return a;
   }

   protected boolean b(bem var1) {
      return var1.eN();
   }

   // $FF: synthetic method
   protected boolean a(aqm var1) {
      return this.b((bem)var1);
   }
}
