import com.google.common.collect.ImmutableMap;

public class auk extends arv<bfj> {
   public auk() {
      super(ImmutableMap.of());
   }

   protected void a(aag var1, bfj var2, long var3) {
      boolean var5 = aun.b(var2) || aun.a(var2) || a(var2);
      if (!var5) {
         var2.cJ().b(ayd.x);
         var2.cJ().b(ayd.y);
         var2.cJ().a(var1.U(), var1.T());
      }

   }

   private static boolean a(bfj var0) {
      return var0.cJ().c(ayd.y).filter((var1) -> {
         return var1.h((aqa)var0) <= 36.0D;
      }).isPresent();
   }
}
