public class dqb implements bin {
   private final djz a;

   public dqb(djz var1) {
      this.a = var1;
   }

   public void a(bic var1, gj<bmb> var2) {
   }

   public void a(bic var1, int var2, bmb var3) {
      this.a.q.a(var3, var2);
   }

   public void a(bic var1, int var2, int var3) {
   }
}
