import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import javax.annotation.Nullable;

public class cd extends ck<cd.a> {
   private static final vk a = new vk("placed_block");

   public vk a() {
      return a;
   }

   public cd.a a(JsonObject var1, bg.b var2, ax var3) {
      buo var4 = a(var1);
      cm var5 = cm.a(var1.get("state"));
      if (var4 != null) {
         var5.a(var4.m(), (var1x) -> {
            throw new JsonSyntaxException("Block " + var4 + " has no property " + var1x + ":");
         });
      }

      bw var6 = bw.a(var1.get("location"));
      bq var7 = bq.a(var1.get("item"));
      return new cd.a(var2, var4, var5, var6, var7);
   }

   @Nullable
   private static buo a(JsonObject var0) {
      if (var0.has("block")) {
         vk var1 = new vk(afd.h(var0, "block"));
         return (buo)gm.Q.b(var1).orElseThrow(() -> {
            return new JsonSyntaxException("Unknown block type '" + var1 + "'");
         });
      } else {
         return null;
      }
   }

   public void a(aah var1, fx var2, bmb var3) {
      ceh var4 = var1.u().d_(var2);
      this.a(var1, (var4x) -> {
         return var4x.a(var4, var2, var1.u(), var3);
      });
   }

   // $FF: synthetic method
   public al b(JsonObject var1, bg.b var2, ax var3) {
      return this.a(var1, var2, var3);
   }

   public static class a extends al {
      private final buo a;
      private final cm b;
      private final bw c;
      private final bq d;

      public a(bg.b var1, @Nullable buo var2, cm var3, bw var4, bq var5) {
         super(cd.a, var1);
         this.a = var2;
         this.b = var3;
         this.c = var4;
         this.d = var5;
      }

      public static cd.a a(buo var0) {
         return new cd.a(bg.b.a, var0, cm.a, bw.a, bq.a);
      }

      public boolean a(ceh var1, fx var2, aag var3, bmb var4) {
         if (this.a != null && !var1.a(this.a)) {
            return false;
         } else if (!this.b.a(var1)) {
            return false;
         } else if (!this.c.a(var3, (float)var2.u(), (float)var2.v(), (float)var2.w())) {
            return false;
         } else {
            return this.d.a(var4);
         }
      }

      public JsonObject a(ci var1) {
         JsonObject var2 = super.a(var1);
         if (this.a != null) {
            var2.addProperty("block", gm.Q.b((Object)this.a).toString());
         }

         var2.add("state", this.b.a());
         var2.add("location", this.c.a());
         var2.add("item", this.d.a());
         return var2;
      }
   }
}
