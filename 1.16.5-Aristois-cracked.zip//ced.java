import java.util.Iterator;
import java.util.List;

public class ced extends ccj implements cdm {
   private ceh a;
   private gc b;
   private boolean c;
   private boolean g;
   private static final ThreadLocal<gc> h = ThreadLocal.withInitial(() -> {
      return null;
   });
   private float i;
   private float j;
   private long k;
   private int l;

   public ced() {
      super(cck.j);
   }

   public ced(ceh var1, gc var2, boolean var3, boolean var4) {
      this();
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.g = var4;
   }

   public md b() {
      return this.a(new md());
   }

   public boolean d() {
      return this.c;
   }

   public gc f() {
      return this.b;
   }

   public boolean h() {
      return this.g;
   }

   public float a(float var1) {
      if (var1 > 1.0F) {
         var1 = 1.0F;
      }

      return afm.g(var1, this.j, this.i);
   }

   public float b(float var1) {
      return (float)this.b.i() * this.e(this.a(var1));
   }

   public float c(float var1) {
      return (float)this.b.j() * this.e(this.a(var1));
   }

   public float d(float var1) {
      return (float)this.b.k() * this.e(this.a(var1));
   }

   private float e(float var1) {
      return this.c ? var1 - 1.0F : 1.0F - var1;
   }

   private ceh x() {
      return !this.d() && this.h() && this.a.b() instanceof cea ? (ceh)((ceh)((ceh)bup.aX.n().a(ceb.c, this.i > 0.25F)).a(ceb.b, this.a.a(bup.aP) ? cfi.b : cfi.a)).a(ceb.a, this.a.c(cea.a)) : this.a;
   }

   private void f(float var1) {
      gc var2 = this.j();
      double var3 = (double)(var1 - this.i);
      ddh var5 = this.x().k(this.d, this.o());
      if (!var5.b()) {
         dci var6 = this.a(var5.a());
         List<aqa> var7 = this.d.a((aqa)null, (dci)cec.a(var6, var2, var3).b(var6));
         if (!var7.isEmpty()) {
            List<dci> var8 = var5.d();
            boolean var9 = this.a.a(bup.gn);
            Iterator var10 = var7.iterator();

            while(true) {
               aqa var11;
               while(true) {
                  do {
                     if (!var10.hasNext()) {
                        return;
                     }

                     var11 = (aqa)var10.next();
                  } while(var11.y_() == cvc.d);

                  if (!var9) {
                     break;
                  }

                  if (!(var11 instanceof aah)) {
                     dcn var12 = var11.cC();
                     double var13 = var12.b;
                     double var15 = var12.c;
                     double var17 = var12.d;
                     switch(var2.n()) {
                     case a:
                        var13 = (double)var2.i();
                        break;
                     case b:
                        var15 = (double)var2.j();
                        break;
                     case c:
                        var17 = (double)var2.k();
                     }

                     var11.n(var13, var15, var17);
                     break;
                  }
               }

               double var19 = 0.0D;
               Iterator var14 = var8.iterator();

               while(var14.hasNext()) {
                  dci var20 = (dci)var14.next();
                  dci var16 = cec.a(this.a(var20), var2, var3);
                  dci var21 = var11.cc();
                  if (var16.c(var21)) {
                     var19 = Math.max(var19, a(var16, var2, var21));
                     if (var19 >= var3) {
                        break;
                     }
                  }
               }

               if (!(var19 <= 0.0D)) {
                  var19 = Math.min(var19, var3) + 0.01D;
                  a(var2, var11, var19, var2);
                  if (!this.c && this.g) {
                     this.a(var11, var2, var3);
                  }
               }
            }
         }
      }
   }

   private static void a(gc var0, aqa var1, double var2, gc var4) {
      h.set(var0);
      var1.a(aqr.c, new dcn(var2 * (double)var4.i(), var2 * (double)var4.j(), var2 * (double)var4.k()));
      h.set((Object)null);
   }

   private void g(float var1) {
      if (this.y()) {
         gc var2 = this.j();
         if (var2.n().d()) {
            double var3 = this.a.k(this.d, this.e).c(gc.a.b);
            dci var5 = this.a(new dci(0.0D, var3, 0.0D, 1.0D, 1.5000000999999998D, 1.0D));
            double var6 = (double)(var1 - this.i);
            List<aqa> var8 = this.d.a((aqa)null, var5, (var1x) -> {
               return a(var5, var1x);
            });
            Iterator var9 = var8.iterator();

            while(var9.hasNext()) {
               aqa var10 = (aqa)var9.next();
               a(var2, var10, var6, var2);
            }

         }
      }
   }

   private static boolean a(dci var0, aqa var1) {
      return var1.y_() == cvc.a && var1.ao() && var1.cD() >= var0.a && var1.cD() <= var0.d && var1.cH() >= var0.c && var1.cH() <= var0.f;
   }

   private boolean y() {
      return this.a.a(bup.ne);
   }

   public gc j() {
      return this.c ? this.b : this.b.f();
   }

   private static double a(dci var0, gc var1, dci var2) {
      switch(var1) {
      case f:
         return var0.d - var2.a;
      case e:
         return var2.d - var0.a;
      case b:
      default:
         return var0.e - var2.b;
      case a:
         return var2.e - var0.b;
      case d:
         return var0.f - var2.c;
      case c:
         return var2.f - var0.c;
      }
   }

   private dci a(dci var1) {
      double var2 = (double)this.e(this.i);
      return var1.d((double)this.e.u() + var2 * (double)this.b.i(), (double)this.e.v() + var2 * (double)this.b.j(), (double)this.e.w() + var2 * (double)this.b.k());
   }

   private void a(aqa var1, gc var2, double var3) {
      dci var5 = var1.cc();
      dci var6 = dde.b().a().a(this.e);
      if (var5.c(var6)) {
         gc var7 = var2.f();
         double var8 = a(var6, var7, var5) + 0.01D;
         double var10 = a(var6, var7, var5.a(var6)) + 0.01D;
         if (Math.abs(var8 - var10) < 0.01D) {
            var8 = Math.min(var8, var3) + 0.01D;
            a(var2, var1, var8, var7);
         }
      }

   }

   public ceh k() {
      return this.a;
   }

   public void l() {
      if (this.d != null && (this.j < 1.0F || this.d.v)) {
         this.i = 1.0F;
         this.j = this.i;
         this.d.o(this.e);
         this.al_();
         if (this.d.d_(this.e).a(bup.bo)) {
            ceh var1;
            if (this.g) {
               var1 = bup.a.n();
            } else {
               var1 = buo.b((ceh)this.a, (bry)this.d, (fx)this.e);
            }

            this.d.a(this.e, var1, 3);
            this.d.a(this.e, var1.b(), this.e);
         }
      }

   }

   public void aj_() {
      this.k = this.d.T();
      this.j = this.i;
      if (this.j >= 1.0F) {
         if (this.d.v && this.l < 5) {
            ++this.l;
         } else {
            this.d.o(this.e);
            this.al_();
            if (this.a != null && this.d.d_(this.e).a(bup.bo)) {
               ceh var2 = buo.b((ceh)this.a, (bry)this.d, (fx)this.e);
               if (var2.g()) {
                  this.d.a(this.e, this.a, 84);
                  buo.a(this.a, var2, this.d, this.e, 3);
               } else {
                  if (var2.b(cex.C) && (Boolean)var2.c(cex.C)) {
                     var2 = (ceh)var2.a(cex.C, false);
                  }

                  this.d.a(this.e, var2, 67);
                  this.d.a(this.e, var2.b(), this.e);
               }
            }

         }
      } else {
         float var1 = this.i + 0.5F;
         this.f(var1);
         this.g(var1);
         this.i = var1;
         if (this.i >= 1.0F) {
            this.i = 1.0F;
         }

      }
   }

   public void a(ceh var1, md var2) {
      super.a(var1, var2);
      this.a = mp.c(var2.p("blockState"));
      this.b = gc.a(var2.h("facing"));
      this.i = var2.j("progress");
      this.j = this.i;
      this.c = var2.q("extending");
      this.g = var2.q("source");
   }

   public md a(md var1) {
      super.a(var1);
      var1.a((String)"blockState", (mt)mp.a(this.a));
      var1.b("facing", this.b.c());
      var1.a("progress", this.j);
      var1.a("extending", this.c);
      var1.a("source", this.g);
      return var1;
   }

   public ddh a(brc var1, fx var2) {
      ddh var3;
      if (!this.c && this.g) {
         var3 = ((ceh)this.a.a(cea.b, true)).k(var1, var2);
      } else {
         var3 = dde.a();
      }

      gc var4 = (gc)h.get();
      if ((double)this.i < 1.0D && var4 == this.j()) {
         return var3;
      } else {
         ceh var5;
         if (this.h()) {
            var5 = (ceh)((ceh)bup.aX.n().a(ceb.a, this.b)).a(ceb.c, this.c != 1.0F - this.i < 0.25F);
         } else {
            var5 = this.a;
         }

         float var6 = this.e(this.i);
         double var7 = (double)((float)this.b.i() * var6);
         double var9 = (double)((float)this.b.j() * var6);
         double var11 = (double)((float)this.b.k() * var6);
         return dde.a(var3, var5.k(var1, var2).a(var7, var9, var11));
      }
   }

   public long m() {
      return this.k;
   }

   public double i() {
      return 68.0D;
   }
}
