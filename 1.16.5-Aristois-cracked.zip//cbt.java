import java.util.Random;

public class cbt extends buo {
   protected cbt(ceg.c var1) {
      super(var1);
   }

   public void b(ceh var1, brx var2, fx var3, ceh var4, boolean var5) {
      if (var2.k().d()) {
         var2.a(var3, bup.an.n(), 3);
         var2.c(2009, var3, 0);
         var2.a((bfw)null, (fx)var3, adq.ej, adr.e, 1.0F, (1.0F + var2.u_().nextFloat() * 0.2F) * 0.7F);
      }

   }

   public void a(ceh var1, brx var2, fx var3, Random var4) {
      gc var5 = gc.a(var4);
      if (var5 != gc.b) {
         fx var6 = var3.a(var5);
         ceh var7 = var2.d_(var6);
         if (!var1.l() || !var7.d(var2, var6, var5.f())) {
            double var8 = (double)var3.u();
            double var10 = (double)var3.v();
            double var12 = (double)var3.w();
            if (var5 == gc.a) {
               var10 -= 0.05D;
               var8 += var4.nextDouble();
               var12 += var4.nextDouble();
            } else {
               var10 += var4.nextDouble() * 0.8D;
               if (var5.n() == gc.a.a) {
                  var12 += var4.nextDouble();
                  if (var5 == gc.f) {
                     ++var8;
                  } else {
                     var8 += 0.05D;
                  }
               } else {
                  var8 += var4.nextDouble();
                  if (var5 == gc.d) {
                     ++var12;
                  } else {
                     var12 += 0.05D;
                  }
               }
            }

            var2.a(hh.m, var8, var10, var12, 0.0D, 0.0D, 0.0D);
         }
      }
   }
}
