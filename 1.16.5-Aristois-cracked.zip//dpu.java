import com.google.common.collect.Lists;
import com.mojang.blaze3d.systems.RenderSystem;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntList;
import java.util.Arrays;
import java.util.List;
import java.util.ListIterator;
import javax.annotation.Nullable;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.mutable.MutableBoolean;
import org.apache.commons.lang3.mutable.MutableInt;

public class dpu extends dot {
   private static final nr a = new of("book.editTitle");
   private static final nr b = new of("book.finalizeWarning");
   private static final afa c;
   private static final afa p;
   private final bfw q;
   private final bmb r;
   private boolean s;
   private boolean t;
   private int u;
   private int v;
   private final List<String> w = Lists.newArrayList();
   private String x = "";
   private final dmy y = new dmy(this::u, this::c, this::h, this::b, (var1x) -> {
      return var1x.length() < 1024 && this.o.b((String)var1x, 114) <= 128;
   });
   private final dmy z = new dmy(() -> {
      return this.x;
   }, (var1x) -> {
      this.x = var1x;
   }, this::h, this::b, (var0) -> {
      return var0.length() < 16;
   });
   private long A;
   private int B = -1;
   private dqt C;
   private dqt D;
   private dlj E;
   private dlj F;
   private dlj G;
   private dlj H;
   private final aot I;
   @Nullable
   private dpu.a J;
   private nr K;
   private final nr L;

   public dpu(bfw var1, bmb var2, aot var3) {
      super(dkz.a);
      this.J = dpu.a.a;
      this.K = oe.d;
      this.q = var1;
      this.r = var2;
      this.I = var3;
      md var4 = var2.o();
      if (var4 != null) {
         mj var5 = var4.d("pages", 8).d();

         for(int var6 = 0; var6 < var5.size(); ++var6) {
            this.w.add(var5.j(var6));
         }
      }

      if (this.w.isEmpty()) {
         this.w.add("");
      }

      this.L = (new of("book.byAuthor", new Object[]{var1.R()})).a(k.i);
   }

   private void b(String var1) {
      if (this.i != null) {
         dmy.a(this.i, var1);
      }

   }

   private String h() {
      return this.i != null ? dmy.b(this.i) : "";
   }

   private int i() {
      return this.w.size();
   }

   public void d() {
      super.d();
      ++this.u;
   }

   protected void b() {
      this.B();
      this.i.m.a(true);
      this.F = (dlj)this.a((dlh)(new dlj(this.k / 2 - 100, 196, 98, 20, new of("book.signButton"), (var1x) -> {
         this.t = true;
         this.m();
      })));
      this.E = (dlj)this.a((dlh)(new dlj(this.k / 2 + 2, 196, 98, 20, nq.c, (var1x) -> {
         this.i.a((dot)null);
         this.c(false);
      })));
      this.G = (dlj)this.a((dlh)(new dlj(this.k / 2 - 100, 196, 98, 20, new of("book.finalizeButton"), (var1x) -> {
         if (this.t) {
            this.c(true);
            this.i.a((dot)null);
         }

      })));
      this.H = (dlj)this.a((dlh)(new dlj(this.k / 2 + 2, 196, 98, 20, nq.d, (var1x) -> {
         if (this.t) {
            this.t = false;
         }

         this.m();
      })));
      int var1 = (this.k - 192) / 2;
      int var2 = true;
      this.C = (dqt)this.a((dlh)(new dqt(var1 + 116, 159, true, (var1x) -> {
         this.l();
      }, true)));
      this.D = (dqt)this.a((dlh)(new dqt(var1 + 43, 159, false, (var1x) -> {
         this.k();
      }, true)));
      this.m();
   }

   private void k() {
      if (this.v > 0) {
         --this.v;
      }

      this.m();
      this.C();
   }

   private void l() {
      if (this.v < this.i() - 1) {
         ++this.v;
      } else {
         this.o();
         if (this.v < this.i() - 1) {
            ++this.v;
         }
      }

      this.m();
      this.C();
   }

   public void e() {
      this.i.m.a(false);
   }

   private void m() {
      this.D.p = !this.t && this.v > 0;
      this.C.p = !this.t;
      this.E.p = !this.t;
      this.F.p = !this.t;
      this.H.p = this.t;
      this.G.p = this.t;
      this.G.o = !this.x.trim().isEmpty();
   }

   private void n() {
      ListIterator var1 = this.w.listIterator(this.w.size());

      while(var1.hasPrevious() && ((String)var1.previous()).isEmpty()) {
         var1.remove();
      }

   }

   private void c(boolean var1) {
      if (this.s) {
         this.n();
         mj var2 = new mj();
         this.w.stream().map(ms::a).forEach(var2::add);
         if (!this.w.isEmpty()) {
            this.r.a((String)"pages", (mt)var2);
         }

         if (var1) {
            this.r.a((String)"author", (mt)ms.a(this.q.eA().getName()));
            this.r.a((String)"title", (mt)ms.a(this.x.trim()));
         }

         int var3 = this.I == aot.a ? this.q.bm.d : 40;
         this.i.w().a((oj)(new sn(this.r, var1, var3)));
      }
   }

   private void o() {
      if (this.i() < 100) {
         this.w.add("");
         this.s = true;
      }
   }

   public boolean a(int var1, int var2, int var3) {
      if (super.a(var1, var2, var3)) {
         return true;
      } else if (this.t) {
         return this.d(var1, var2, var3);
      } else {
         boolean var4 = this.c(var1, var2, var3);
         if (var4) {
            this.B();
            return true;
         } else {
            return false;
         }
      }
   }

   public boolean a(char var1, int var2) {
      if (super.a(var1, var2)) {
         return true;
      } else if (this.t) {
         boolean var3 = this.z.a(var1);
         if (var3) {
            this.m();
            this.s = true;
            return true;
         } else {
            return false;
         }
      } else if (w.a(var1)) {
         this.y.a(Character.toString(var1));
         this.B();
         return true;
      } else {
         return false;
      }
   }

   private boolean c(int var1, int var2, int var3) {
      if (dot.i(var1)) {
         this.y.d();
         return true;
      } else if (dot.h(var1)) {
         this.y.c();
         return true;
      } else if (dot.g(var1)) {
         this.y.b();
         return true;
      } else if (dot.f(var1)) {
         this.y.a();
         return true;
      } else {
         switch(var1) {
         case 257:
         case 335:
            this.y.a("\n");
            return true;
         case 259:
            this.y.d(-1);
            return true;
         case 261:
            this.y.d(1);
            return true;
         case 262:
            this.y.a(1, dot.y());
            return true;
         case 263:
            this.y.a(-1, dot.y());
            return true;
         case 264:
            this.q();
            return true;
         case 265:
            this.p();
            return true;
         case 266:
            this.D.b();
            return true;
         case 267:
            this.C.b();
            return true;
         case 268:
            this.r();
            return true;
         case 269:
            this.t();
            return true;
         default:
            return false;
         }
      }
   }

   private void p() {
      this.a(-1);
   }

   private void q() {
      this.a(1);
   }

   private void a(int var1) {
      int var2 = this.y.g();
      int var3 = this.A().a(var2, var1);
      this.y.c(var3, dot.y());
   }

   private void r() {
      int var1 = this.y.g();
      int var2 = this.A().a(var1);
      this.y.c(var2, dot.y());
   }

   private void t() {
      dpu.a var1 = this.A();
      int var2 = this.y.g();
      int var3 = var1.b(var2);
      this.y.c(var3, dot.y());
   }

   private boolean d(int var1, int var2, int var3) {
      switch(var1) {
      case 257:
      case 335:
         if (!this.x.isEmpty()) {
            this.c(true);
            this.i.a((dot)null);
         }

         return true;
      case 259:
         this.z.d(-1);
         this.m();
         this.s = true;
         return true;
      default:
         return false;
      }
   }

   private String u() {
      return this.v >= 0 && this.v < this.w.size() ? (String)this.w.get(this.v) : "";
   }

   private void c(String var1) {
      if (this.v >= 0 && this.v < this.w.size()) {
         this.w.set(this.v, var1);
         this.s = true;
         this.B();
      }

   }

   public void a(dfm var1, int var2, int var3, float var4) {
      this.a((dfm)var1);
      this.a((dmi)null);
      RenderSystem.color4f(1.0F, 1.0F, 1.0F, 1.0F);
      this.i.M().a(dpv.b);
      int var5 = (this.k - 192) / 2;
      int var6 = true;
      this.b(var1, var5, 2, 0, 0, 192, 192);
      int var10;
      int var11;
      if (this.t) {
         boolean var7 = this.u / 6 % 2 == 0;
         afa var8 = afa.a(afa.a(this.x, ob.a), var7 ? c : p);
         int var9 = this.o.a((nu)a);
         this.o.b(var1, (nr)a, (float)(var5 + 36 + (114 - var9) / 2), 34.0F, 0);
         var10 = this.o.a(var8);
         this.o.b(var1, (afa)var8, (float)(var5 + 36 + (114 - var10) / 2), 50.0F, 0);
         var11 = this.o.a((nu)this.L);
         this.o.b(var1, (nr)this.L, (float)(var5 + 36 + (114 - var11) / 2), 60.0F, 0);
         this.o.a(b, var5 + 36, 82, 114, 0);
      } else {
         int var13 = this.o.a((nu)this.K);
         this.o.b(var1, (nr)this.K, (float)(var5 - var13 + 192 - 44), 18.0F, 0);
         dpu.a var14 = this.A();
         dpu.b[] var15 = var14.f;
         var10 = var15.length;

         for(var11 = 0; var11 < var10; ++var11) {
            dpu.b var12 = var15[var11];
            this.o.b(var1, var12.c, (float)var12.d, (float)var12.e, -16777216);
         }

         this.a(var14.g);
         this.a(var1, var14.c, var14.d);
      }

      super.a(var1, var2, var3, var4);
   }

   private void a(dfm var1, dpu.c var2, boolean var3) {
      if (this.u / 6 % 2 == 0) {
         var2 = this.b(var2);
         if (!var3) {
            int var10001 = var2.a;
            int var10002 = var2.b - 1;
            int var10003 = var2.a + 1;
            int var10004 = var2.b;
            this.o.getClass();
            dkw.a(var1, var10001, var10002, var10003, var10004 + 9, -16777216);
         } else {
            this.o.b(var1, (String)"_", (float)var2.a, (float)var2.b, 0);
         }
      }

   }

   private void a(eal[] var1) {
      dfo var2 = dfo.a();
      dfh var3 = var2.c();
      RenderSystem.color4f(0.0F, 0.0F, 255.0F, 255.0F);
      RenderSystem.disableTexture();
      RenderSystem.enableColorLogicOp();
      RenderSystem.logicOp(dem.o.n);
      var3.a(7, dfk.k);
      eal[] var4 = var1;
      int var5 = var1.length;

      for(int var6 = 0; var6 < var5; ++var6) {
         eal var7 = var4[var6];
         int var8 = var7.a();
         int var9 = var7.b();
         int var10 = var8 + var7.c();
         int var11 = var9 + var7.d();
         var3.a((double)var8, (double)var11, 0.0D).d();
         var3.a((double)var10, (double)var11, 0.0D).d();
         var3.a((double)var10, (double)var9, 0.0D).d();
         var3.a((double)var8, (double)var9, 0.0D).d();
      }

      var2.b();
      RenderSystem.disableColorLogicOp();
      RenderSystem.enableTexture();
   }

   private dpu.c a(dpu.c var1) {
      return new dpu.c(var1.a - (this.k - 192) / 2 - 36, var1.b - 32);
   }

   private dpu.c b(dpu.c var1) {
      return new dpu.c(var1.a + (this.k - 192) / 2 + 36, var1.b + 32);
   }

   public boolean a(double var1, double var3, int var5) {
      if (super.a(var1, var3, var5)) {
         return true;
      } else {
         if (var5 == 0) {
            long var6 = x.b();
            dpu.a var8 = this.A();
            int var9 = var8.a(this.o, this.a(new dpu.c((int)var1, (int)var3)));
            if (var9 >= 0) {
               if (var9 == this.B && var6 - this.A < 250L) {
                  if (!this.y.i()) {
                     this.b(var9);
                  } else {
                     this.y.d();
                  }
               } else {
                  this.y.c(var9, dot.y());
               }

               this.B();
            }

            this.B = var9;
            this.A = var6;
         }

         return true;
      }
   }

   private void b(int var1) {
      String var2 = this.u();
      this.y.a(dkj.a(var2, -1, var1, false), dkj.a(var2, 1, var1, false));
   }

   public boolean a(double var1, double var3, int var5, double var6, double var8) {
      if (super.a(var1, var3, var5, var6, var8)) {
         return true;
      } else {
         if (var5 == 0) {
            dpu.a var10 = this.A();
            int var11 = var10.a(this.o, this.a(new dpu.c((int)var1, (int)var3)));
            this.y.c(var11, true);
            this.B();
         }

         return true;
      }
   }

   private dpu.a A() {
      if (this.J == null) {
         this.J = this.D();
         this.K = new of("book.pageIndicator", new Object[]{this.v + 1, this.i()});
      }

      return this.J;
   }

   private void B() {
      this.J = null;
   }

   private void C() {
      this.y.f();
      this.B();
   }

   private dpu.a D() {
      String var1 = this.u();
      if (var1.isEmpty()) {
         return dpu.a.a;
      } else {
         int var2 = this.y.g();
         int var3 = this.y.h();
         IntList var4 = new IntArrayList();
         List<dpu.b> var5 = Lists.newArrayList();
         MutableInt var6 = new MutableInt();
         MutableBoolean var7 = new MutableBoolean();
         dkj var8 = this.o.b();
         var8.a(var1, 114, ob.a, true, (var6x, var7x, var8x) -> {
            int var9 = var6.getAndIncrement();
            String var10 = var1.substring(var7x, var8x);
            var7.setValue(var10.endsWith("\n"));
            String var11 = StringUtils.stripEnd(var10, " \n");
            this.o.getClass();
            int var12 = var9 * 9;
            dpu.c var13 = this.b(new dpu.c(0, var12));
            var4.add(var7x);
            var5.add(new dpu.b(var6x, var11, var13.a, var13.b));
         });
         int[] var9 = var4.toIntArray();
         boolean var10 = var2 == var1.length();
         dpu.c var11;
         int var13;
         if (var10 && var7.isTrue()) {
            int var10003 = var5.size();
            this.o.getClass();
            var11 = new dpu.c(0, var10003 * 9);
         } else {
            int var12 = b(var9, var2);
            var13 = this.o.b(var1.substring(var9[var12], var2));
            this.o.getClass();
            var11 = new dpu.c(var13, var12 * 9);
         }

         List<eal> var22 = Lists.newArrayList();
         if (var2 != var3) {
            var13 = Math.min(var2, var3);
            int var14 = Math.max(var2, var3);
            int var15 = b(var9, var13);
            int var16 = b(var9, var14);
            int var17;
            int var18;
            if (var15 == var16) {
               this.o.getClass();
               var17 = var15 * 9;
               var18 = var9[var15];
               var22.add(this.a(var1, var8, var13, var14, var17, var18));
            } else {
               var17 = var15 + 1 > var9.length ? var1.length() : var9[var15 + 1];
               this.o.getClass();
               var22.add(this.a(var1, var8, var13, var17, var15 * 9, var9[var15]));

               for(var18 = var15 + 1; var18 < var16; ++var18) {
                  this.o.getClass();
                  int var19 = var18 * 9;
                  String var20 = var1.substring(var9[var18], var9[var18 + 1]);
                  int var21 = (int)var8.a(var20);
                  dpu.c var10002 = new dpu.c(0, var19);
                  this.o.getClass();
                  var22.add(this.a(var10002, new dpu.c(var21, var19 + 9)));
               }

               int var10004 = var9[var16];
               this.o.getClass();
               var22.add(this.a(var1, var8, var10004, var14, var16 * 9, var9[var16]));
            }
         }

         return new dpu.a(var1, var11, var10, var9, (dpu.b[])var5.toArray(new dpu.b[0]), (eal[])var22.toArray(new eal[0]));
      }
   }

   private static int b(int[] var0, int var1) {
      int var2 = Arrays.binarySearch(var0, var1);
      return var2 < 0 ? -(var2 + 2) : var2;
   }

   private eal a(String var1, dkj var2, int var3, int var4, int var5, int var6) {
      String var7 = var1.substring(var6, var3);
      String var8 = var1.substring(var6, var4);
      dpu.c var9 = new dpu.c((int)var2.a(var7), var5);
      int var10002 = (int)var2.a(var8);
      this.o.getClass();
      dpu.c var10 = new dpu.c(var10002, var5 + 9);
      return this.a(var9, var10);
   }

   private eal a(dpu.c var1, dpu.c var2) {
      dpu.c var3 = this.b(var1);
      dpu.c var4 = this.b(var2);
      int var5 = Math.min(var3.a, var4.a);
      int var6 = Math.max(var3.a, var4.a);
      int var7 = Math.min(var3.b, var4.b);
      int var8 = Math.max(var3.b, var4.b);
      return new eal(var5, var7, var6 - var5, var8 - var7);
   }

   static {
      c = afa.a("_", ob.a.a(k.a));
      p = afa.a("_", ob.a.a(k.h));
   }

   static class a {
      private static final dpu.a a;
      private final String b;
      private final dpu.c c;
      private final boolean d;
      private final int[] e;
      private final dpu.b[] f;
      private final eal[] g;

      public a(String var1, dpu.c var2, boolean var3, int[] var4, dpu.b[] var5, eal[] var6) {
         this.b = var1;
         this.c = var2;
         this.d = var3;
         this.e = var4;
         this.f = var5;
         this.g = var6;
      }

      public int a(dku var1, dpu.c var2) {
         int var10000 = var2.b;
         var1.getClass();
         int var3 = var10000 / 9;
         if (var3 < 0) {
            return 0;
         } else if (var3 >= this.f.length) {
            return this.b.length();
         } else {
            dpu.b var4 = this.f[var3];
            return this.e[var3] + var1.b().a(var4.b, var2.a, var4.a);
         }
      }

      public int a(int var1, int var2) {
         int var3 = dpu.b(this.e, var1);
         int var4 = var3 + var2;
         int var5;
         if (0 <= var4 && var4 < this.e.length) {
            int var6 = var1 - this.e[var3];
            int var7 = this.f[var4].b.length();
            var5 = this.e[var4] + Math.min(var6, var7);
         } else {
            var5 = var1;
         }

         return var5;
      }

      public int a(int var1) {
         int var2 = dpu.b(this.e, var1);
         return this.e[var2];
      }

      public int b(int var1) {
         int var2 = dpu.b(this.e, var1);
         return this.e[var2] + this.f[var2].b.length();
      }

      static {
         a = new dpu.a("", new dpu.c(0, 0), true, new int[]{0}, new dpu.b[]{new dpu.b(ob.a, "", 0, 0)}, new eal[0]);
      }
   }

   static class b {
      private final ob a;
      private final String b;
      private final nr c;
      private final int d;
      private final int e;

      public b(ob var1, String var2, int var3, int var4) {
         this.a = var1;
         this.b = var2;
         this.d = var3;
         this.e = var4;
         this.c = (new oe(var2)).a(var1);
      }
   }

   static class c {
      public final int a;
      public final int b;

      c(int var1, int var2) {
         this.a = var1;
         this.b = var2;
      }
   }
}
