import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import java.util.Arrays;
import java.util.Collection;
import java.util.concurrent.CompletableFuture;

public class ed implements ArgumentType<Integer> {
   private static final Collection<String> a = Arrays.asList("0d", "0s", "0t", "0");
   private static final SimpleCommandExceptionType b = new SimpleCommandExceptionType(new of("argument.time.invalid_unit"));
   private static final DynamicCommandExceptionType c = new DynamicCommandExceptionType((var0) -> {
      return new of("argument.time.invalid_tick_count", new Object[]{var0});
   });
   private static final Object2IntMap<String> d = new Object2IntOpenHashMap();

   public static ed a() {
      return new ed();
   }

   public Integer a(StringReader var1) throws CommandSyntaxException {
      float var2 = var1.readFloat();
      String var3 = var1.readUnquotedString();
      int var4 = d.getOrDefault(var3, 0);
      if (var4 == 0) {
         throw b.create();
      } else {
         int var5 = Math.round(var2 * (float)var4);
         if (var5 < 0) {
            throw c.create(var5);
         } else {
            return var5;
         }
      }
   }

   public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> var1, SuggestionsBuilder var2) {
      StringReader var3 = new StringReader(var2.getRemaining());

      try {
         var3.readFloat();
      } catch (CommandSyntaxException var5) {
         return var2.buildFuture();
      }

      return dd.b((Iterable)d.keySet(), (SuggestionsBuilder)var2.createOffset(var2.getStart() + var3.getCursor()));
   }

   public Collection<String> getExamples() {
      return a;
   }

   // $FF: synthetic method
   public Object parse(StringReader var1) throws CommandSyntaxException {
      return this.a(var1);
   }

   static {
      d.put("d", 24000);
      d.put("s", 20);
      d.put("t", 1);
      d.put("", 1);
   }
}
