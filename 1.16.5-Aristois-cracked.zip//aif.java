import com.google.common.collect.ImmutableList;
import com.mojang.datafixers.DSL;
import com.mojang.datafixers.DataFix;
import com.mojang.datafixers.DataFixUtils;
import com.mojang.datafixers.OpticFinder;
import com.mojang.datafixers.TypeRewriteRule;
import com.mojang.datafixers.Typed;
import com.mojang.datafixers.schemas.Schema;
import com.mojang.datafixers.types.Type;
import com.mojang.datafixers.util.Either;
import com.mojang.datafixers.util.Pair;
import com.mojang.datafixers.util.Unit;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public class aif extends DataFix {
   public aif(Schema var1, boolean var2) {
      super(var1, var2);
   }

   public TypeRewriteRule makeRule() {
      Schema var1 = this.getInputSchema();
      Schema var2 = this.getOutputSchema();
      Type<?> var3 = var1.getTypeRaw(akn.o);
      Type<?> var4 = var2.getTypeRaw(akn.o);
      Type<?> var5 = var1.getTypeRaw(akn.p);
      return this.a(var1, var2, var3, var4, var5);
   }

   private <OldEntityTree, NewEntityTree, Entity> TypeRewriteRule a(Schema var1, Schema var2, Type<OldEntityTree> var3, Type<NewEntityTree> var4, Type<Entity> var5) {
      Type<Pair<String, Pair<Either<OldEntityTree, Unit>, Entity>>> var6 = DSL.named(akn.o.typeName(), DSL.and(DSL.optional(DSL.field("Riding", var3)), var5));
      Type<Pair<String, Pair<Either<List<NewEntityTree>, Unit>, Entity>>> var7 = DSL.named(akn.o.typeName(), DSL.and(DSL.optional(DSL.field("Passengers", DSL.list(var4))), var5));
      Type<?> var8 = var1.getType(akn.o);
      Type<?> var9 = var2.getType(akn.o);
      if (!Objects.equals(var8, var6)) {
         throw new IllegalStateException("Old entity type is not what was expected.");
      } else if (!var9.equals(var7, true, true)) {
         throw new IllegalStateException("New entity type is not what was expected.");
      } else {
         OpticFinder<Pair<String, Pair<Either<OldEntityTree, Unit>, Entity>>> var10 = DSL.typeFinder(var6);
         OpticFinder<Pair<String, Pair<Either<List<NewEntityTree>, Unit>, Entity>>> var11 = DSL.typeFinder(var7);
         OpticFinder<NewEntityTree> var12 = DSL.typeFinder(var4);
         Type<?> var13 = var1.getType(akn.b);
         Type<?> var14 = var2.getType(akn.b);
         return TypeRewriteRule.seq(this.fixTypeEverywhere("EntityRidingToPassengerFix", var6, var7, (var5x) -> {
            return (var6) -> {
               Optional<Pair<String, Pair<Either<List<NewEntityTree>, Unit>, Entity>>> var7 = Optional.empty();
               Pair var8 = var6;

               while(true) {
                  Either<List<NewEntityTree>, Unit> var9 = (Either)DataFixUtils.orElse(var7.map((var4x) -> {
                     Typed<NewEntityTree> var5 = (Typed)var4.pointTyped(var5x).orElseThrow(() -> {
                        return new IllegalStateException("Could not create new entity tree");
                     });
                     NewEntityTree var6 = var5.set(var11, var4x).getOptional(var12).orElseThrow(() -> {
                        return new IllegalStateException("Should always have an entity tree here");
                     });
                     return Either.left(ImmutableList.of(var6));
                  }), Either.right(DSL.unit()));
                  var7 = Optional.of(Pair.of(akn.o.typeName(), Pair.of(var9, ((Pair)var8.getSecond()).getSecond())));
                  Optional<OldEntityTree> var10x = ((Either)((Pair)var8.getSecond()).getFirst()).left();
                  if (!var10x.isPresent()) {
                     return (Pair)var7.orElseThrow(() -> {
                        return new IllegalStateException("Should always have an entity tree here");
                     });
                  }

                  var8 = (Pair)(new Typed(var3, var5x, var10x.get())).getOptional(var10).orElseThrow(() -> {
                     return new IllegalStateException("Should always have an entity here");
                  });
               }
            };
         }), this.writeAndRead("player RootVehicle injecter", var13, var14));
      }
   }
}
