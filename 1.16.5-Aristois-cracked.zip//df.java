import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.Arrays;
import java.util.Collection;
import java.util.concurrent.CompletableFuture;

public class df implements ArgumentType<k> {
   private static final Collection<String> b = Arrays.asList("red", "green");
   public static final DynamicCommandExceptionType a = new DynamicCommandExceptionType((var0) -> {
      return new of("argument.color.invalid", new Object[]{var0});
   });

   private df() {
   }

   public static df a() {
      return new df();
   }

   public static k a(CommandContext<db> var0, String var1) {
      return (k)var0.getArgument(var1, k.class);
   }

   public k a(StringReader var1) throws CommandSyntaxException {
      String var2 = var1.readUnquotedString();
      k var3 = k.b(var2);
      if (var3 != null && !var3.c()) {
         return var3;
      } else {
         throw a.create(var2);
      }
   }

   public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> var1, SuggestionsBuilder var2) {
      return dd.b((Iterable)k.a(true, false), (SuggestionsBuilder)var2);
   }

   public Collection<String> getExamples() {
      return b;
   }

   // $FF: synthetic method
   public Object parse(StringReader var1) throws CommandSyntaxException {
      return this.a(var1);
   }
}
