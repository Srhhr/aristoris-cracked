public enum cfa implements afs {
   a("compare"),
   b("subtract");

   private final String c;

   private cfa(String var3) {
      this.c = var3;
   }

   public String toString() {
      return this.c;
   }

   public String a() {
      return this.c;
   }
}
