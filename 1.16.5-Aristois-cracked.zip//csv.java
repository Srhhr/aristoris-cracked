import com.mojang.serialization.Codec;

public interface csv<P extends csu> {
   csv<csa> a = a("always_true", csa.a);
   csv<csf> b = a("block_match", csf.a);
   csv<csh> c = a("blockstate_match", csh.a);
   csv<ctc> d = a("tag_match", ctc.a);
   csv<csr> e = a("random_block_match", csr.a);
   csv<css> f = a("random_blockstate_match", css.a);

   Codec<P> codec();

   static <P extends csu> csv<P> a(String var0, Codec<P> var1) {
      return (csv)gm.a((gm)gm.aa, (String)var0, (Object)(() -> {
         return var1;
      }));
   }
}
