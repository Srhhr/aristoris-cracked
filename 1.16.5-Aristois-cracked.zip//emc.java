public abstract class emc implements emt {
   protected emq a;
   protected final adr b;
   protected final vk c;
   protected float d;
   protected float e;
   protected double f;
   protected double g;
   protected double h;
   protected boolean i;
   protected int j;
   protected emt.a k;
   protected boolean l;
   protected boolean m;

   protected emc(adp var1, adr var2) {
      this(var1.a(), var2);
   }

   protected emc(vk var1, adr var2) {
      this.d = 1.0F;
      this.e = 1.0F;
      this.k = emt.a.b;
      this.c = var1;
      this.b = var2;
   }

   public vk a() {
      return this.c;
   }

   public env a(enu var1) {
      env var2 = var1.a(this.c);
      if (var2 == null) {
         this.a = enu.a;
      } else {
         this.a = var2.a();
      }

      return var2;
   }

   public emq b() {
      return this.a;
   }

   public adr c() {
      return this.b;
   }

   public boolean d() {
      return this.i;
   }

   public int e() {
      return this.j;
   }

   public float f() {
      return this.d * this.a.c();
   }

   public float g() {
      return this.e * this.a.d();
   }

   public double h() {
      return this.f;
   }

   public double i() {
      return this.g;
   }

   public double j() {
      return this.h;
   }

   public emt.a k() {
      return this.k;
   }

   public boolean m() {
      return this.m;
   }

   public String toString() {
      return "SoundInstance[" + this.c + "]";
   }
}
