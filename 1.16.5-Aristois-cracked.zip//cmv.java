import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.Optional;
import javax.annotation.Nullable;

public class cmv implements cma {
   public static final Codec<cmv> a = RecordCodecBuilder.create((var0) -> {
      return var0.group(Codec.BOOL.fieldOf("crystal_invulnerable").orElse(false).forGetter((var0x) -> {
         return var0x.b;
      }), ckx.a.a.listOf().fieldOf("spikes").forGetter((var0x) -> {
         return var0x.c;
      }), fx.a.optionalFieldOf("crystal_beam_target").forGetter((var0x) -> {
         return Optional.ofNullable(var0x.d);
      })).apply(var0, cmv::new);
   });
   private final boolean b;
   private final List<ckx.a> c;
   @Nullable
   private final fx d;

   public cmv(boolean var1, List<ckx.a> var2, @Nullable fx var3) {
      this(var1, var2, Optional.ofNullable(var3));
   }

   private cmv(boolean var1, List<ckx.a> var2, Optional<fx> var3) {
      this.b = var1;
      this.c = var2;
      this.d = (fx)var3.orElse((Object)null);
   }

   public boolean b() {
      return this.b;
   }

   public List<ckx.a> c() {
      return this.c;
   }

   @Nullable
   public fx d() {
      return this.d;
   }
}
