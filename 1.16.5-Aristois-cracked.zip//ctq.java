import com.mojang.serialization.Codec;
import java.util.Random;

public class ctq extends ctt<ctu> {
   public ctq(Codec<ctu> var1) {
      super(var1);
   }

   public void a(Random var1, cfw var2, bsv var3, int var4, int var5, int var6, double var7, ceh var9, ceh var10, int var11, long var12, ctu var14) {
   }
}
