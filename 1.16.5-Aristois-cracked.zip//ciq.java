import com.mojang.serialization.Codec;
import java.util.Iterator;
import java.util.Random;

public class ciq extends cjl<clr> {
   public ciq(Codec<clr> var1) {
      super(var1);
   }

   public boolean a(bsr var1, cfy var2, Random var3, fx var4, clr var5) {
      if (var4.v() < 5) {
         return false;
      } else {
         int var6 = 2 + var3.nextInt(2);
         int var7 = 2 + var3.nextInt(2);
         Iterator var8 = fx.a(var4.b(-var6, 0, -var7), var4.b(var6, 1, var7)).iterator();

         while(var8.hasNext()) {
            fx var9 = (fx)var8.next();
            int var10 = var4.u() - var9.u();
            int var11 = var4.w() - var9.w();
            if ((float)(var10 * var10 + var11 * var11) <= var3.nextFloat() * 10.0F - var3.nextFloat() * 6.0F) {
               this.a(var1, var9, var3, var5);
            } else if ((double)var3.nextFloat() < 0.031D) {
               this.a(var1, var9, var3, var5);
            }
         }

         return true;
      }
   }

   private boolean a(bry var1, fx var2, Random var3) {
      fx var4 = var2.c();
      ceh var5 = var1.d_(var4);
      return var5.a(bup.iE) ? var3.nextBoolean() : var5.d(var1, var4, gc.b);
   }

   private void a(bry var1, fx var2, Random var3, clr var4) {
      if (var1.w(var2) && this.a(var1, var2, var3)) {
         var1.a(var2, var4.b.a(var3, var2), 4);
      }

   }
}
