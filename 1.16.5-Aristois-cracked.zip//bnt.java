import com.google.common.collect.ImmutableList;
import com.google.common.collect.UnmodifiableIterator;
import java.util.List;
import javax.annotation.Nullable;

public class bnt {
   private final String a;
   private final ImmutableList<apu> b;

   public static bnt a(String var0) {
      return (bnt)gm.U.a(vk.a(var0));
   }

   public bnt(apu... var1) {
      this((String)null, var1);
   }

   public bnt(@Nullable String var1, apu... var2) {
      this.a = var1;
      this.b = ImmutableList.copyOf(var2);
   }

   public String b(String var1) {
      return var1 + (this.a == null ? gm.U.b((Object)this).a() : this.a);
   }

   public List<apu> a() {
      return this.b;
   }

   public boolean b() {
      if (!this.b.isEmpty()) {
         UnmodifiableIterator var1 = this.b.iterator();

         while(var1.hasNext()) {
            apu var2 = (apu)var1.next();
            if (var2.a().a()) {
               return true;
            }
         }
      }

      return false;
   }
}
