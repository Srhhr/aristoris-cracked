import java.util.Iterator;

public class dks {
   private final gh<dkr> a = new gh(32);

   public static dks a(dko var0) {
      dks var1 = new dks();
      var1.a((var0x, var1x) -> {
         return var1x > 0 ? -1 : ((blb)var0x.b()).b(var0x);
      }, bmd.kY, bmd.kZ, bmd.la, bmd.lb, bmd.pG);
      var1.a((var0x, var1x) -> {
         return brv.a(0.5D, 1.0D);
      }, bup.gY, bup.gZ);
      var1.a((var0x, var1x) -> {
         if (var1x != 1) {
            return -1;
         } else {
            md var2 = var0x.b("Explosion");
            int[] var3 = var2 != null && var2.c("Colors", 11) ? var2.n("Colors") : null;
            if (var3 != null && var3.length != 0) {
               if (var3.length == 1) {
                  return var3[0];
               } else {
                  int var4 = 0;
                  int var5 = 0;
                  int var6 = 0;
                  int[] var7 = var3;
                  int var8 = var3.length;

                  for(int var9 = 0; var9 < var8; ++var9) {
                     int var10 = var7[var9];
                     var4 += (var10 & 16711680) >> 16;
                     var5 += (var10 & '\uff00') >> 8;
                     var6 += (var10 & 255) >> 0;
                  }

                  var4 /= var3.length;
                  var5 /= var3.length;
                  var6 /= var3.length;
                  return var4 << 16 | var5 << 8 | var6;
               }
            } else {
               return 9079434;
            }
         }
      }, bmd.pp);
      var1.a((var0x, var1x) -> {
         return var1x > 0 ? -1 : bnv.c(var0x);
      }, bmd.nv, bmd.qj, bmd.qm);
      Iterator var2 = bna.f().iterator();

      while(var2.hasNext()) {
         bna var3 = (bna)var2.next();
         var1.a((var1x, var2x) -> {
            return var3.a(var2x);
         }, var3);
      }

      var1.a((var1x, var2x) -> {
         ceh var3 = ((bkh)var1x.b()).e().n();
         return var0.a(var3, (bra)null, (fx)null, var2x);
      }, bup.i, bup.aR, bup.aS, bup.dP, bup.ah, bup.ai, bup.aj, bup.ak, bup.al, bup.am, bup.dU);
      var1.a((var0x, var1x) -> {
         return var1x == 0 ? bnv.c(var0x) : -1;
      }, bmd.ql);
      var1.a((var0x, var1x) -> {
         return var1x == 0 ? -1 : bmh.g(var0x);
      }, bmd.nf);
      return var1;
   }

   public int a(bmb var1, int var2) {
      dkr var3 = (dkr)this.a.a(gm.T.a((Object)var1.b()));
      return var3 == null ? -1 : var3.getColor(var1, var2);
   }

   public void a(dkr var1, brw... var2) {
      brw[] var3 = var2;
      int var4 = var2.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         brw var6 = var3[var5];
         this.a.a(var1, blx.a(var6.h()));
      }

   }
}
