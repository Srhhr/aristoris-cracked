import com.google.common.collect.Lists;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Nullable;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class adl extends adi {
   private static final Logger d = LogManager.getLogger();
   private final ServerSocket e;
   private final String f;
   private final List<adk> g = Lists.newArrayList();
   private final vy h;

   private adl(vy var1, ServerSocket var2, String var3) {
      super("RCON Listener");
      this.h = var1;
      this.e = var2;
      this.f = var3;
   }

   private void d() {
      this.g.removeIf((var0) -> {
         return !var0.c();
      });
   }

   public void run() {
      try {
         while(this.a) {
            try {
               Socket var1 = this.e.accept();
               adk var2 = new adk(this.h, this.f, var1);
               var2.a();
               this.g.add(var2);
               this.d();
            } catch (SocketTimeoutException var7) {
               this.d();
            } catch (IOException var8) {
               if (this.a) {
                  d.info("IO exception: ", var8);
               }
            }
         }
      } finally {
         this.a(this.e);
      }

   }

   @Nullable
   public static adl a(vy var0) {
      zh var1 = var0.g_();
      String var2 = var0.h_();
      if (var2.isEmpty()) {
         var2 = "0.0.0.0";
      }

      int var3 = var1.u;
      if (0 < var3 && 65535 >= var3) {
         String var4 = var1.v;
         if (var4.isEmpty()) {
            d.warn("No rcon password set in server.properties, rcon disabled!");
            return null;
         } else {
            try {
               ServerSocket var5 = new ServerSocket(var3, 0, InetAddress.getByName(var2));
               var5.setSoTimeout(500);
               adl var6 = new adl(var0, var5, var4);
               if (!var6.a()) {
                  return null;
               } else {
                  d.info("RCON running on {}:{}", var2, var3);
                  return var6;
               }
            } catch (IOException var7) {
               d.warn("Unable to initialise RCON on {}:{}", var2, var3, var7);
               return null;
            }
         }
      } else {
         d.warn("Invalid rcon port {} found in server.properties, rcon disabled!", var3);
         return null;
      }
   }

   public void b() {
      this.a = false;
      this.a(this.e);
      super.b();
      Iterator var1 = this.g.iterator();

      while(var1.hasNext()) {
         adk var2 = (adk)var1.next();
         if (var2.c()) {
            var2.b();
         }
      }

      this.g.clear();
   }

   private void a(ServerSocket var1) {
      d.debug("closeSocket: {}", var1);

      try {
         var1.close();
      } catch (IOException var3) {
         d.warn("Failed to close socket", var3);
      }

   }
}
