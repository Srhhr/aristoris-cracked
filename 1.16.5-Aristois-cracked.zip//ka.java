import com.google.common.collect.ImmutableList;
import com.mojang.datafixers.util.Pair;

public class ka {
   public static void a() {
   }

   static {
      kk.a(new cok(new vk("bastion/units/center_pieces"), new vk("empty"), ImmutableList.of(Pair.of(coi.b("bastion/units/center_pieces/center_0", kl.u), 1), Pair.of(coi.b("bastion/units/center_pieces/center_1", kl.u), 1), Pair.of(coi.b("bastion/units/center_pieces/center_2", kl.u), 1)), cok.a.b));
      kk.a(new cok(new vk("bastion/units/pathways"), new vk("empty"), ImmutableList.of(Pair.of(coi.b("bastion/units/pathways/pathway_0", kl.u), 1), Pair.of(coi.b("bastion/units/pathways/pathway_wall_0", kl.u), 1)), cok.a.b));
      kk.a(new cok(new vk("bastion/units/walls/wall_bases"), new vk("empty"), ImmutableList.of(Pair.of(coi.b("bastion/units/walls/wall_base", kl.u), 1), Pair.of(coi.b("bastion/units/walls/connected_wall", kl.u), 1)), cok.a.b));
      kk.a(new cok(new vk("bastion/units/stages/stage_0"), new vk("empty"), ImmutableList.of(Pair.of(coi.b("bastion/units/stages/stage_0_0", kl.u), 1), Pair.of(coi.b("bastion/units/stages/stage_0_1", kl.u), 1), Pair.of(coi.b("bastion/units/stages/stage_0_2", kl.u), 1), Pair.of(coi.b("bastion/units/stages/stage_0_3", kl.u), 1)), cok.a.b));
      kk.a(new cok(new vk("bastion/units/stages/stage_1"), new vk("empty"), ImmutableList.of(Pair.of(coi.b("bastion/units/stages/stage_1_0", kl.u), 1), Pair.of(coi.b("bastion/units/stages/stage_1_1", kl.u), 1), Pair.of(coi.b("bastion/units/stages/stage_1_2", kl.u), 1), Pair.of(coi.b("bastion/units/stages/stage_1_3", kl.u), 1)), cok.a.b));
      kk.a(new cok(new vk("bastion/units/stages/rot/stage_1"), new vk("empty"), ImmutableList.of(Pair.of(coi.b("bastion/units/stages/rot/stage_1_0", kl.u), 1)), cok.a.b));
      kk.a(new cok(new vk("bastion/units/stages/stage_2"), new vk("empty"), ImmutableList.of(Pair.of(coi.b("bastion/units/stages/stage_2_0", kl.u), 1), Pair.of(coi.b("bastion/units/stages/stage_2_1", kl.u), 1)), cok.a.b));
      kk.a(new cok(new vk("bastion/units/stages/stage_3"), new vk("empty"), ImmutableList.of(Pair.of(coi.b("bastion/units/stages/stage_3_0", kl.u), 1), Pair.of(coi.b("bastion/units/stages/stage_3_1", kl.u), 1), Pair.of(coi.b("bastion/units/stages/stage_3_2", kl.u), 1), Pair.of(coi.b("bastion/units/stages/stage_3_3", kl.u), 1)), cok.a.b));
      kk.a(new cok(new vk("bastion/units/fillers/stage_0"), new vk("empty"), ImmutableList.of(Pair.of(coi.b("bastion/units/fillers/stage_0", kl.u), 1)), cok.a.b));
      kk.a(new cok(new vk("bastion/units/edges"), new vk("empty"), ImmutableList.of(Pair.of(coi.b("bastion/units/edges/edge_0", kl.u), 1)), cok.a.b));
      kk.a(new cok(new vk("bastion/units/wall_units"), new vk("empty"), ImmutableList.of(Pair.of(coi.b("bastion/units/wall_units/unit_0", kl.u), 1)), cok.a.b));
      kk.a(new cok(new vk("bastion/units/edge_wall_units"), new vk("empty"), ImmutableList.of(Pair.of(coi.b("bastion/units/wall_units/edge_0_large", kl.u), 1)), cok.a.b));
      kk.a(new cok(new vk("bastion/units/ramparts"), new vk("empty"), ImmutableList.of(Pair.of(coi.b("bastion/units/ramparts/ramparts_0", kl.u), 1), Pair.of(coi.b("bastion/units/ramparts/ramparts_1", kl.u), 1), Pair.of(coi.b("bastion/units/ramparts/ramparts_2", kl.u), 1)), cok.a.b));
      kk.a(new cok(new vk("bastion/units/large_ramparts"), new vk("empty"), ImmutableList.of(Pair.of(coi.b("bastion/units/ramparts/ramparts_0", kl.u), 1)), cok.a.b));
      kk.a(new cok(new vk("bastion/units/rampart_plates"), new vk("empty"), ImmutableList.of(Pair.of(coi.b("bastion/units/rampart_plates/plate_0", kl.u), 1)), cok.a.b));
   }
}
