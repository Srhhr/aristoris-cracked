public class biv extends bjr {
   private final bfw a;
   private int b;

   public biv(bfw var1, aon var2, int var3, int var4, int var5) {
      super(var2, var3, var4, var5);
      this.a = var1;
   }

   public boolean a(bmb var1) {
      return false;
   }

   public bmb a(int var1) {
      if (this.f()) {
         this.b += Math.min(var1, this.e().E());
      }

      return super.a(var1);
   }

   public bmb a(bfw var1, bmb var2) {
      this.c(var2);
      super.a(var1, var2);
      return var2;
   }

   protected void a(bmb var1, int var2) {
      this.b += var2;
      this.c(var1);
   }

   protected void c(bmb var1) {
      var1.a(this.a.l, this.a, this.b);
      if (!this.a.l.v && this.c instanceof cbz) {
         ((cbz)this.c).d(this.a);
      }

      this.b = 0;
   }
}
