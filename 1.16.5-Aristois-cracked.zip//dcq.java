import java.util.BitSet;

public final class dcq extends dcw {
   private final BitSet d;
   private int e;
   private int f;
   private int g;
   private int h;
   private int i;
   private int j;

   public dcq(int var1, int var2, int var3) {
      this(var1, var2, var3, var1, var2, var3, 0, 0, 0);
   }

   public dcq(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9) {
      super(var1, var2, var3);
      this.d = new BitSet(var1 * var2 * var3);
      this.e = var4;
      this.f = var5;
      this.g = var6;
      this.h = var7;
      this.i = var8;
      this.j = var9;
   }

   public dcq(dcw var1) {
      super(var1.a, var1.b, var1.c);
      if (var1 instanceof dcq) {
         this.d = (BitSet)((dcq)var1).d.clone();
      } else {
         this.d = new BitSet(this.a * this.b * this.c);

         for(int var2 = 0; var2 < this.a; ++var2) {
            for(int var3 = 0; var3 < this.b; ++var3) {
               for(int var4 = 0; var4 < this.c; ++var4) {
                  if (var1.b(var2, var3, var4)) {
                     this.d.set(this.a(var2, var3, var4));
                  }
               }
            }
         }
      }

      this.e = var1.a(gc.a.a);
      this.f = var1.a(gc.a.b);
      this.g = var1.a(gc.a.c);
      this.h = var1.b(gc.a.a);
      this.i = var1.b(gc.a.b);
      this.j = var1.b(gc.a.c);
   }

   protected int a(int var1, int var2, int var3) {
      return (var1 * this.b + var2) * this.c + var3;
   }

   public boolean b(int var1, int var2, int var3) {
      return this.d.get(this.a(var1, var2, var3));
   }

   public void a(int var1, int var2, int var3, boolean var4, boolean var5) {
      this.d.set(this.a(var1, var2, var3), var5);
      if (var4 && var5) {
         this.e = Math.min(this.e, var1);
         this.f = Math.min(this.f, var2);
         this.g = Math.min(this.g, var3);
         this.h = Math.max(this.h, var1 + 1);
         this.i = Math.max(this.i, var2 + 1);
         this.j = Math.max(this.j, var3 + 1);
      }

   }

   public boolean a() {
      return this.d.isEmpty();
   }

   public int a(gc.a var1) {
      return var1.a(this.e, this.f, this.g);
   }

   public int b(gc.a var1) {
      return var1.a(this.h, this.i, this.j);
   }

   protected boolean a(int var1, int var2, int var3, int var4) {
      if (var3 >= 0 && var4 >= 0 && var1 >= 0) {
         if (var3 < this.a && var4 < this.b && var2 <= this.c) {
            return this.d.nextClearBit(this.a(var3, var4, var1)) >= this.a(var3, var4, var2);
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   protected void a(int var1, int var2, int var3, int var4, boolean var5) {
      this.d.set(this.a(var3, var4, var1), this.a(var3, var4, var2), var5);
   }

   static dcq a(dcw var0, dcw var1, dcz var2, dcz var3, dcz var4, dcr var5) {
      dcq var6 = new dcq(var2.a().size() - 1, var3.a().size() - 1, var4.a().size() - 1);
      int[] var7 = new int[]{Integer.MAX_VALUE, Integer.MAX_VALUE, Integer.MAX_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE};
      var2.a((var7x, var8, var9) -> {
         boolean[] var10 = new boolean[]{false};
         boolean var11 = var3.a((var10x, var11x, var12) -> {
            boolean[] var13 = new boolean[]{false};
            boolean var14 = var4.a((var12x, var13x, var14x) -> {
               boolean var15 = var5.apply(var0.c(var7x, var10x, var12x), var1.c(var8, var11x, var13x));
               if (var15) {
                  var6.d.set(var6.a(var9, var12, var14x));
                  var7[2] = Math.min(var7[2], var14x);
                  var7[5] = Math.max(var7[5], var14x);
                  var13[0] = true;
               }

               return true;
            });
            if (var13[0]) {
               var7[1] = Math.min(var7[1], var12);
               var7[4] = Math.max(var7[4], var12);
               var10[0] = true;
            }

            return var14;
         });
         if (var10[0]) {
            var7[0] = Math.min(var7[0], var9);
            var7[3] = Math.max(var7[3], var9);
         }

         return var11;
      });
      var6.e = var7[0];
      var6.f = var7[1];
      var6.g = var7[2];
      var6.h = var7[3] + 1;
      var6.i = var7[4] + 1;
      var6.j = var7[5] + 1;
      return var6;
   }
}
