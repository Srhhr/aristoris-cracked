import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class edd implements edh.a {
   private final Map<fx, fx> a = Maps.newHashMap();
   private final Map<fx, Float> b = Maps.newHashMap();
   private final List<fx> c = Lists.newArrayList();

   public void a(fx var1, List<fx> var2, List<Float> var3) {
      for(int var4 = 0; var4 < var2.size(); ++var4) {
         this.a.put(var2.get(var4), var1);
         this.b.put(var2.get(var4), var3.get(var4));
      }

      this.c.add(var1);
   }

   public void a(dfm var1, eag var2, double var3, double var5, double var7) {
      RenderSystem.pushMatrix();
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.disableTexture();
      fx var9 = new fx(var3, 0.0D, var7);
      dfo var10 = dfo.a();
      dfh var11 = var10.c();
      var11.a(5, dfk.l);
      Iterator var12 = this.a.entrySet().iterator();

      while(var12.hasNext()) {
         Entry<fx, fx> var13 = (Entry)var12.next();
         fx var14 = (fx)var13.getKey();
         fx var15 = (fx)var13.getValue();
         float var16 = (float)(var15.u() * 128 % 256) / 256.0F;
         float var17 = (float)(var15.v() * 128 % 256) / 256.0F;
         float var18 = (float)(var15.w() * 128 % 256) / 256.0F;
         float var19 = (Float)this.b.get(var14);
         if (var9.a(var14, 160.0D)) {
            eae.a(var11, (double)((float)var14.u() + 0.5F) - var3 - (double)var19, (double)((float)var14.v() + 0.5F) - var5 - (double)var19, (double)((float)var14.w() + 0.5F) - var7 - (double)var19, (double)((float)var14.u() + 0.5F) - var3 + (double)var19, (double)((float)var14.v() + 0.5F) - var5 + (double)var19, (double)((float)var14.w() + 0.5F) - var7 + (double)var19, var16, var17, var18, 0.5F);
         }
      }

      var12 = this.c.iterator();

      while(var12.hasNext()) {
         fx var20 = (fx)var12.next();
         if (var9.a(var20, 160.0D)) {
            eae.a(var11, (double)var20.u() - var3, (double)var20.v() - var5, (double)var20.w() - var7, (double)((float)var20.u() + 1.0F) - var3, (double)((float)var20.v() + 1.0F) - var5, (double)((float)var20.w() + 1.0F) - var7, 1.0F, 1.0F, 1.0F, 1.0F);
         }
      }

      var10.b();
      RenderSystem.enableDepthTest();
      RenderSystem.enableTexture();
      RenderSystem.popMatrix();
   }
}
