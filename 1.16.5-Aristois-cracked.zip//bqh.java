public class bqh extends bps {
   public bqh(bps.a var1, aqf... var2) {
      super(var1, bpt.b, var2);
   }

   public int a(int var1) {
      return var1 * 10;
   }

   public int b(int var1) {
      return this.a(var1) + 15;
   }

   public boolean b() {
      return true;
   }

   public boolean h() {
      return false;
   }

   public boolean i() {
      return false;
   }

   public int a() {
      return 3;
   }
}
