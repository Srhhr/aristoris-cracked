import com.google.common.collect.ImmutableList;
import com.google.common.collect.Sets;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.nio.file.Path;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ho implements hm {
   private static final Logger b = LogManager.getLogger();
   private static final Gson c = (new GsonBuilder()).setPrettyPrinting().create();
   private final hl d;
   private final List<Consumer<Consumer<y>>> e = ImmutableList.of(new ht(), new hq(), new hp(), new hr(), new hs());

   public ho(hl var1) {
      this.d = var1;
   }

   public void a(hn var1) throws IOException {
      Path var2 = this.d.b();
      Set<vk> var3 = Sets.newHashSet();
      Consumer<y> var4 = (var3x) -> {
         if (!var3.add(var3x.h())) {
            throw new IllegalStateException("Duplicate advancement " + var3x.h());
         } else {
            Path var4 = a(var2, var3x);

            try {
               hm.a(c, var1, var3x.a().b(), var4);
            } catch (IOException var6) {
               b.error("Couldn't save advancement {}", var4, var6);
            }

         }
      };
      Iterator var5 = this.e.iterator();

      while(var5.hasNext()) {
         Consumer<Consumer<y>> var6 = (Consumer)var5.next();
         var6.accept(var4);
      }

   }

   private static Path a(Path var0, y var1) {
      return var0.resolve("data/" + var1.h().b() + "/advancements/" + var1.h().a() + ".json");
   }

   public String a() {
      return "Advancements";
   }
}
