import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;
import javax.annotation.Nullable;

public class ark {
   private final Map<arg, arh> a;

   public ark(Map<arg, arh> var1) {
      this.a = ImmutableMap.copyOf(var1);
   }

   private arh d(arg var1) {
      arh var2 = (arh)this.a.get(var1);
      if (var2 == null) {
         throw new IllegalArgumentException("Can't find attribute " + gm.af.b((Object)var1));
      } else {
         return var2;
      }
   }

   public double a(arg var1) {
      return this.d(var1).f();
   }

   public double b(arg var1) {
      return this.d(var1).b();
   }

   public double a(arg var1, UUID var2) {
      arj var3 = this.d(var1).a(var2);
      if (var3 == null) {
         throw new IllegalArgumentException("Can't find modifier " + var2 + " on attribute " + gm.af.b((Object)var1));
      } else {
         return var3.d();
      }
   }

   @Nullable
   public arh a(Consumer<arh> var1, arg var2) {
      arh var3 = (arh)this.a.get(var2);
      if (var3 == null) {
         return null;
      } else {
         arh var4 = new arh(var2, var1);
         var4.a(var3);
         return var4;
      }
   }

   public static ark.a a() {
      return new ark.a();
   }

   public boolean c(arg var1) {
      return this.a.containsKey(var1);
   }

   public boolean b(arg var1, UUID var2) {
      arh var3 = (arh)this.a.get(var1);
      return var3 != null && var3.a(var2) != null;
   }

   public static class a {
      private final Map<arg, arh> a = Maps.newHashMap();
      private boolean b;

      private arh b(arg var1) {
         arh var2 = new arh(var1, (var2x) -> {
            if (this.b) {
               throw new UnsupportedOperationException("Tried to change value for default attribute instance: " + gm.af.b((Object)var1));
            }
         });
         this.a.put(var1, var2);
         return var2;
      }

      public ark.a a(arg var1) {
         this.b(var1);
         return this;
      }

      public ark.a a(arg var1, double var2) {
         arh var4 = this.b(var1);
         var4.a(var2);
         return this;
      }

      public ark a() {
         this.b = true;
         return new ark(this.a);
      }
   }
}
