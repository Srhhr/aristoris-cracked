import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import java.util.Random;

public class cnz extends cnt {
   public static final Codec<cnz> b;
   private final aup<ceh> c;

   private static DataResult<cnz> a(aup<ceh> var0) {
      return var0.b() ? DataResult.error("WeightedStateProvider with no states") : DataResult.success(new cnz(var0));
   }

   private cnz(aup<ceh> var1) {
      this.c = var1;
   }

   protected cnu<?> a() {
      return cnu.b;
   }

   public cnz() {
      this(new aup());
   }

   public cnz a(ceh var1, int var2) {
      this.c.a(var1, var2);
      return this;
   }

   public ceh a(Random var1, fx var2) {
      return (ceh)this.c.b(var1);
   }

   static {
      b = aup.a(ceh.b).comapFlatMap(cnz::a, (var0) -> {
         return var0.c;
      }).fieldOf("entries").codec();
   }
}
