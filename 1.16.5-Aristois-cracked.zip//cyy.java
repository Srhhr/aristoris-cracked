import com.google.common.collect.Lists;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import java.lang.reflect.Type;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class cyy {
   private static final Logger c = LogManager.getLogger();
   public static final cyy a;
   public static final dba b;
   private final dba d;
   private final cyx[] e;
   private final daj[] f;
   private final BiFunction<bmb, cyv, bmb> g;

   private cyy(dba var1, cyx[] var2, daj[] var3) {
      this.d = var1;
      this.e = var2;
      this.f = var3;
      this.g = dal.a(var3);
   }

   public static Consumer<bmb> a(Consumer<bmb> var0) {
      return (var1) -> {
         if (var1.E() < var1.c()) {
            var0.accept(var1);
         } else {
            int var2 = var1.E();

            while(var2 > 0) {
               bmb var3 = var1.i();
               var3.e(Math.min(var1.c(), var2));
               var2 -= var3.E();
               var0.accept(var3);
            }
         }

      };
   }

   public void a(cyv var1, Consumer<bmb> var2) {
      if (var1.a(this)) {
         Consumer<bmb> var3 = daj.a(this.g, var2, var1);
         cyx[] var4 = this.e;
         int var5 = var4.length;

         for(int var6 = 0; var6 < var5; ++var6) {
            cyx var7 = var4[var6];
            var7.a(var3, var1);
         }

         var1.b(this);
      } else {
         c.warn("Detected infinite loop in loot tables");
      }

   }

   public void b(cyv var1, Consumer<bmb> var2) {
      this.a(var1, a(var2));
   }

   public List<bmb> a(cyv var1) {
      List<bmb> var2 = Lists.newArrayList();
      this.b(var1, var2::add);
      return var2;
   }

   public dba a() {
      return this.d;
   }

   public void a(czg var1) {
      int var2;
      for(var2 = 0; var2 < this.e.length; ++var2) {
         this.e[var2].a(var1.b(".pools[" + var2 + "]"));
      }

      for(var2 = 0; var2 < this.f.length; ++var2) {
         this.f[var2].a(var1.b(".functions[" + var2 + "]"));
      }

   }

   public void a(aon var1, cyv var2) {
      List<bmb> var3 = this.a(var2);
      Random var4 = var2.a();
      List<Integer> var5 = this.a(var1, var4);
      this.a(var3, var5.size(), var4);
      Iterator var6 = var3.iterator();

      while(var6.hasNext()) {
         bmb var7 = (bmb)var6.next();
         if (var5.isEmpty()) {
            c.warn("Tried to over-fill a container");
            return;
         }

         if (var7.a()) {
            var1.a((Integer)var5.remove(var5.size() - 1), bmb.b);
         } else {
            var1.a((Integer)var5.remove(var5.size() - 1), var7);
         }
      }

   }

   private void a(List<bmb> var1, int var2, Random var3) {
      List<bmb> var4 = Lists.newArrayList();
      Iterator var5 = var1.iterator();

      while(var5.hasNext()) {
         bmb var6 = (bmb)var5.next();
         if (var6.a()) {
            var5.remove();
         } else if (var6.E() > 1) {
            var4.add(var6);
            var5.remove();
         }
      }

      while(var2 - var1.size() - var4.size() > 0 && !var4.isEmpty()) {
         bmb var8 = (bmb)var4.remove(afm.a(var3, 0, var4.size() - 1));
         int var9 = afm.a(var3, 1, var8.E() / 2);
         bmb var7 = var8.a(var9);
         if (var8.E() > 1 && var3.nextBoolean()) {
            var4.add(var8);
         } else {
            var1.add(var8);
         }

         if (var7.E() > 1 && var3.nextBoolean()) {
            var4.add(var7);
         } else {
            var1.add(var7);
         }
      }

      var1.addAll(var4);
      Collections.shuffle(var1, var3);
   }

   private List<Integer> a(aon var1, Random var2) {
      List<Integer> var3 = Lists.newArrayList();

      for(int var4 = 0; var4 < var1.Z_(); ++var4) {
         if (var1.a(var4).a()) {
            var3.add(var4);
         }
      }

      Collections.shuffle(var3, var2);
      return var3;
   }

   public static cyy.a b() {
      return new cyy.a();
   }

   // $FF: synthetic method
   cyy(dba var1, cyx[] var2, daj[] var3, Object var4) {
      this(var1, var2, var3);
   }

   static {
      a = new cyy(dbb.a, new cyx[0], new daj[0]);
      b = dbb.k;
   }

   public static class b implements JsonDeserializer<cyy>, JsonSerializer<cyy> {
      public cyy a(JsonElement var1, Type var2, JsonDeserializationContext var3) throws JsonParseException {
         JsonObject var4 = afd.m(var1, "loot table");
         cyx[] var5 = (cyx[])afd.a(var4, "pools", new cyx[0], var3, cyx[].class);
         dba var6 = null;
         if (var4.has("type")) {
            String var7 = afd.h(var4, "type");
            var6 = dbb.a(new vk(var7));
         }

         daj[] var8 = (daj[])afd.a(var4, "functions", new daj[0], var3, daj[].class);
         return new cyy(var6 != null ? var6 : dbb.k, var5, var8);
      }

      public JsonElement a(cyy var1, Type var2, JsonSerializationContext var3) {
         JsonObject var4 = new JsonObject();
         if (var1.d != cyy.b) {
            vk var5 = dbb.a(var1.d);
            if (var5 != null) {
               var4.addProperty("type", var5.toString());
            } else {
               cyy.c.warn("Failed to find id for param set " + var1.d);
            }
         }

         if (var1.e.length > 0) {
            var4.add("pools", var3.serialize(var1.e));
         }

         if (!ArrayUtils.isEmpty(var1.f)) {
            var4.add("functions", var3.serialize(var1.f));
         }

         return var4;
      }

      // $FF: synthetic method
      public JsonElement serialize(Object var1, Type var2, JsonSerializationContext var3) {
         return this.a((cyy)var1, var2, var3);
      }

      // $FF: synthetic method
      public Object deserialize(JsonElement var1, Type var2, JsonDeserializationContext var3) throws JsonParseException {
         return this.a(var1, var2, var3);
      }
   }

   public static class a implements dag<cyy.a> {
      private final List<cyx> a = Lists.newArrayList();
      private final List<daj> b = Lists.newArrayList();
      private dba c;

      public a() {
         this.c = cyy.b;
      }

      public cyy.a a(cyx.a var1) {
         this.a.add(var1.b());
         return this;
      }

      public cyy.a a(dba var1) {
         this.c = var1;
         return this;
      }

      public cyy.a a(daj.a var1) {
         this.b.add(var1.b());
         return this;
      }

      public cyy.a a() {
         return this;
      }

      public cyy b() {
         return new cyy(this.c, (cyx[])this.a.toArray(new cyx[0]), (daj[])this.b.toArray(new daj[0]));
      }

      // $FF: synthetic method
      public Object c() {
         return this.a();
      }

      // $FF: synthetic method
      public Object b(daj.a var1) {
         return this.a(var1);
      }
   }
}
