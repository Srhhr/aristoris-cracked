import com.google.common.collect.Iterables;
import com.google.common.collect.LinkedHashMultiset;
import com.google.common.collect.Multiset;
import com.google.common.collect.Multisets;
import java.util.List;
import javax.annotation.Nullable;

public class bmh extends bkr {
   public bmh(blx.a var1) {
      super(var1);
   }

   public static bmb a(brx var0, int var1, int var2, byte var3, boolean var4, boolean var5) {
      bmb var6 = new bmb(bmd.nf);
      a(var6, var0, var1, var2, var3, var4, var5, var0.Y());
      return var6;
   }

   @Nullable
   public static cxx a(bmb var0, brx var1) {
      return var1.a(a(d(var0)));
   }

   @Nullable
   public static cxx b(bmb var0, brx var1) {
      cxx var2 = a(var0, var1);
      if (var2 == null && var1 instanceof aag) {
         var2 = a(var0, var1, var1.h().a(), var1.h().c(), 3, false, false, var1.Y());
      }

      return var2;
   }

   public static int d(bmb var0) {
      md var1 = var0.o();
      return var1 != null && var1.c("map", 99) ? var1.h("map") : 0;
   }

   private static cxx a(bmb var0, brx var1, int var2, int var3, int var4, boolean var5, boolean var6, vj<brx> var7) {
      int var8 = var1.t();
      cxx var9 = new cxx(a(var8));
      var9.a(var2, var3, var4, var5, var6, var7);
      var1.a(var9);
      var0.p().b("map", var8);
      return var9;
   }

   public static String a(int var0) {
      return "map_" + var0;
   }

   public void a(brx var1, aqa var2, cxx var3) {
      if (var1.Y() == var3.c && var2 instanceof bfw) {
         int var4 = 1 << var3.f;
         int var5 = var3.a;
         int var6 = var3.b;
         int var7 = afm.c(var2.cD() - (double)var5) / var4 + 64;
         int var8 = afm.c(var2.cH() - (double)var6) / var4 + 64;
         int var9 = 128 / var4;
         if (var1.k().c()) {
            var9 /= 2;
         }

         cxx.a var10 = var3.a((bfw)var2);
         ++var10.b;
         boolean var11 = false;

         for(int var12 = var7 - var9 + 1; var12 < var7 + var9; ++var12) {
            if ((var12 & 15) == (var10.b & 15) || var11) {
               var11 = false;
               double var13 = 0.0D;

               for(int var15 = var8 - var9 - 1; var15 < var8 + var9; ++var15) {
                  if (var12 >= 0 && var15 >= -1 && var12 < 128 && var15 < 128) {
                     int var16 = var12 - var7;
                     int var17 = var15 - var8;
                     boolean var18 = var16 * var16 + var17 * var17 > (var9 - 2) * (var9 - 2);
                     int var19 = (var5 / var4 + var12 - 64) * var4;
                     int var20 = (var6 / var4 + var15 - 64) * var4;
                     Multiset<cvb> var21 = LinkedHashMultiset.create();
                     cgh var22 = var1.n(new fx(var19, 0, var20));
                     if (!var22.t()) {
                        brd var23 = var22.g();
                        int var24 = var19 & 15;
                        int var25 = var20 & 15;
                        int var26 = 0;
                        double var27 = 0.0D;
                        if (var1.k().c()) {
                           int var29 = var19 + var20 * 231871;
                           var29 = var29 * var29 * 31287121 + var29 * 11;
                           if ((var29 >> 20 & 1) == 0) {
                              var21.add(bup.j.n().d(var1, fx.b), 10);
                           } else {
                              var21.add(bup.b.n().d(var1, fx.b), 100);
                           }

                           var27 = 100.0D;
                        } else {
                           fx.a var37 = new fx.a();
                           fx.a var30 = new fx.a();

                           for(int var31 = 0; var31 < var4; ++var31) {
                              for(int var32 = 0; var32 < var4; ++var32) {
                                 int var33 = var22.a(chn.a.b, var31 + var24, var32 + var25) + 1;
                                 ceh var34;
                                 if (var33 <= 1) {
                                    var34 = bup.z.n();
                                 } else {
                                    do {
                                       --var33;
                                       var37.d(var23.d() + var31 + var24, var33, var23.e() + var32 + var25);
                                       var34 = var22.d_(var37);
                                    } while(var34.d(var1, var37) == cvb.b && var33 > 0);

                                    if (var33 > 0 && !var34.m().c()) {
                                       int var35 = var33 - 1;
                                       var30.g(var37);

                                       ceh var36;
                                       do {
                                          var30.p(var35--);
                                          var36 = var22.d_(var30);
                                          ++var26;
                                       } while(var35 > 0 && !var36.m().c());

                                       var34 = this.a((brx)var1, (ceh)var34, (fx)var37);
                                    }
                                 }

                                 var3.a(var1, var23.d() + var31 + var24, var23.e() + var32 + var25);
                                 var27 += (double)var33 / (double)(var4 * var4);
                                 var21.add(var34.d(var1, var37));
                              }
                           }
                        }

                        var26 /= var4 * var4;
                        double var38 = (var27 - var13) * 4.0D / (double)(var4 + 4) + ((double)(var12 + var15 & 1) - 0.5D) * 0.4D;
                        int var39 = 1;
                        if (var38 > 0.6D) {
                           var39 = 2;
                        }

                        if (var38 < -0.6D) {
                           var39 = 0;
                        }

                        cvb var40 = (cvb)Iterables.getFirst(Multisets.copyHighestCountFirst(var21), cvb.b);
                        if (var40 == cvb.n) {
                           var38 = (double)var26 * 0.1D + (double)(var12 + var15 & 1) * 0.2D;
                           var39 = 1;
                           if (var38 < 0.5D) {
                              var39 = 2;
                           }

                           if (var38 > 0.9D) {
                              var39 = 0;
                           }
                        }

                        var13 = var27;
                        if (var15 >= 0 && var16 * var16 + var17 * var17 < var9 * var9 && (!var18 || (var12 + var15 & 1) != 0)) {
                           byte var41 = var3.g[var12 + var15 * 128];
                           byte var42 = (byte)(var40.aj * 4 + var39);
                           if (var41 != var42) {
                              var3.g[var12 + var15 * 128] = var42;
                              var3.a(var12, var15);
                              var11 = true;
                           }
                        }
                     }
                  }
               }
            }
         }

      }
   }

   private ceh a(brx var1, ceh var2, fx var3) {
      cux var4 = var2.m();
      return !var4.c() && !var2.d(var1, var3, gc.b) ? var4.g() : var2;
   }

   private static boolean a(bsv[] var0, int var1, int var2, int var3) {
      return var0[var2 * var1 + var3 * var1 * 128 * var1].h() >= 0.0F;
   }

   public static void a(aag var0, bmb var1) {
      cxx var2 = b(var1, var0);
      if (var2 != null) {
         if (var0.Y() == var2.c) {
            int var3 = 1 << var2.f;
            int var4 = var2.a;
            int var5 = var2.b;
            bsv[] var6 = new bsv[128 * var3 * 128 * var3];

            int var7;
            int var8;
            for(var7 = 0; var7 < 128 * var3; ++var7) {
               for(var8 = 0; var8 < 128 * var3; ++var8) {
                  var6[var7 * 128 * var3 + var8] = var0.v(new fx((var4 / var3 - 64) * var3 + var8, 0, (var5 / var3 - 64) * var3 + var7));
               }
            }

            for(var7 = 0; var7 < 128; ++var7) {
               for(var8 = 0; var8 < 128; ++var8) {
                  if (var7 > 0 && var8 > 0 && var7 < 127 && var8 < 127) {
                     bsv var9 = var6[var7 * var3 + var8 * var3 * 128 * var3];
                     int var10 = 8;
                     if (a(var6, var3, var7 - 1, var8 - 1)) {
                        --var10;
                     }

                     if (a(var6, var3, var7 - 1, var8 + 1)) {
                        --var10;
                     }

                     if (a(var6, var3, var7 - 1, var8)) {
                        --var10;
                     }

                     if (a(var6, var3, var7 + 1, var8 - 1)) {
                        --var10;
                     }

                     if (a(var6, var3, var7 + 1, var8 + 1)) {
                        --var10;
                     }

                     if (a(var6, var3, var7 + 1, var8)) {
                        --var10;
                     }

                     if (a(var6, var3, var7, var8 - 1)) {
                        --var10;
                     }

                     if (a(var6, var3, var7, var8 + 1)) {
                        --var10;
                     }

                     int var11 = 3;
                     cvb var12 = cvb.b;
                     if (var9.h() < 0.0F) {
                        var12 = cvb.q;
                        if (var10 > 7 && var8 % 2 == 0) {
                           var11 = (var7 + (int)(afm.a((float)var8 + 0.0F) * 7.0F)) / 8 % 5;
                           if (var11 == 3) {
                              var11 = 1;
                           } else if (var11 == 4) {
                              var11 = 0;
                           }
                        } else if (var10 > 7) {
                           var12 = cvb.b;
                        } else if (var10 > 5) {
                           var11 = 1;
                        } else if (var10 > 3) {
                           var11 = 0;
                        } else if (var10 > 1) {
                           var11 = 0;
                        }
                     } else if (var10 > 0) {
                        var12 = cvb.B;
                        if (var10 > 3) {
                           var11 = 1;
                        } else {
                           var11 = 3;
                        }
                     }

                     if (var12 != cvb.b) {
                        var2.g[var7 + var8 * 128] = (byte)(var12.aj * 4 + var11);
                        var2.a(var7, var8);
                     }
                  }
               }
            }

         }
      }
   }

   public void a(bmb var1, brx var2, aqa var3, int var4, boolean var5) {
      if (!var2.v) {
         cxx var6 = b(var1, var2);
         if (var6 != null) {
            if (var3 instanceof bfw) {
               bfw var7 = (bfw)var3;
               var6.a(var7, var1);
            }

            if (!var6.h && (var5 || var3 instanceof bfw && ((bfw)var3).dE() == var1)) {
               this.a(var2, var3, var6);
            }

         }
      }
   }

   @Nullable
   public oj<?> a(bmb var1, brx var2, bfw var3) {
      return b(var1, var2).a(var1, var2, var3);
   }

   public void b(bmb var1, brx var2, bfw var3) {
      md var4 = var1.o();
      if (var4 != null && var4.c("map_scale_direction", 99)) {
         a(var1, var2, var4.h("map_scale_direction"));
         var4.r("map_scale_direction");
      } else if (var4 != null && var4.c("map_to_lock", 1) && var4.q("map_to_lock")) {
         a(var2, var1);
         var4.r("map_to_lock");
      }

   }

   protected static void a(bmb var0, brx var1, int var2) {
      cxx var3 = b(var0, var1);
      if (var3 != null) {
         a(var0, var1, var3.a, var3.b, afm.a(var3.f + var2, 0, 4), var3.d, var3.e, var3.c);
      }

   }

   public static void a(brx var0, bmb var1) {
      cxx var2 = b(var1, var0);
      if (var2 != null) {
         cxx var3 = a(var1, var0, 0, 0, var2.f, var2.d, var2.e, var2.c);
         var3.a(var2);
      }

   }

   public void a(bmb var1, @Nullable brx var2, List<nr> var3, bnl var4) {
      cxx var5 = var2 == null ? null : b(var1, var2);
      if (var5 != null && var5.h) {
         var3.add((new of("filled_map.locked", new Object[]{d(var1)})).a(k.h));
      }

      if (var4.a()) {
         if (var5 != null) {
            var3.add((new of("filled_map.id", new Object[]{d(var1)})).a(k.h));
            var3.add((new of("filled_map.scale", new Object[]{1 << var5.f})).a(k.h));
            var3.add((new of("filled_map.level", new Object[]{var5.f, 4})).a(k.h));
         } else {
            var3.add((new of("filled_map.unknown")).a(k.h));
         }
      }

   }

   public static int g(bmb var0) {
      md var1 = var0.b("display");
      if (var1 != null && var1.c("MapColor", 99)) {
         int var2 = var1.h("MapColor");
         return -16777216 | var2 & 16777215;
      } else {
         return -12173266;
      }
   }

   public aou a(boa var1) {
      ceh var2 = var1.p().d_(var1.a());
      if (var2.a(aed.B)) {
         if (!var1.p().v) {
            cxx var3 = b(var1.m(), var1.p());
            var3.a((bry)var1.p(), (fx)var1.a());
         }

         return aou.a(var1.p().v);
      } else {
         return super.a(var1);
      }
   }
}
