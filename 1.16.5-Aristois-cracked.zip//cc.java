import com.google.gson.JsonObject;

public class cc extends ck<cc.a> {
   private static final vk a = new vk("nether_travel");

   public vk a() {
      return a;
   }

   public cc.a a(JsonObject var1, bg.b var2, ax var3) {
      bw var4 = bw.a(var1.get("entered"));
      bw var5 = bw.a(var1.get("exited"));
      ay var6 = ay.a(var1.get("distance"));
      return new cc.a(var2, var4, var5, var6);
   }

   public void a(aah var1, dcn var2) {
      this.a(var1, (var2x) -> {
         return var2x.a(var1.u(), var2, var1.cD(), var1.cE(), var1.cH());
      });
   }

   // $FF: synthetic method
   public al b(JsonObject var1, bg.b var2, ax var3) {
      return this.a(var1, var2, var3);
   }

   public static class a extends al {
      private final bw a;
      private final bw b;
      private final ay c;

      public a(bg.b var1, bw var2, bw var3, ay var4) {
         super(cc.a, var1);
         this.a = var2;
         this.b = var3;
         this.c = var4;
      }

      public static cc.a a(ay var0) {
         return new cc.a(bg.b.a, bw.a, bw.a, var0);
      }

      public boolean a(aag var1, dcn var2, double var3, double var5, double var7) {
         if (!this.a.a(var1, var2.b, var2.c, var2.d)) {
            return false;
         } else if (!this.b.a(var1, var3, var5, var7)) {
            return false;
         } else {
            return this.c.a(var2.b, var2.c, var2.d, var3, var5, var7);
         }
      }

      public JsonObject a(ci var1) {
         JsonObject var2 = super.a(var1);
         var2.add("entered", this.a.a());
         var2.add("exited", this.b.a());
         var2.add("distance", this.c.a());
         return var2;
      }
   }
}
