import java.io.IOException;

public class rp implements oj<om> {
   private nr a;
   private nr b;

   public void a(nf var1) throws IOException {
      this.a = var1.h();
      this.b = var1.h();
   }

   public void b(nf var1) throws IOException {
      var1.a(this.a);
      var1.a(this.b);
   }

   public void a(om var1) {
      var1.a(this);
   }

   public nr b() {
      return this.a;
   }

   public nr c() {
      return this.b;
   }
}
