public class ees extends efw<bdh, dub<bdh>> {
   private static final vk a = new vk("textures/entity/endermite.png");

   public ees(eet var1) {
      super(var1, new dub(), 0.3F);
   }

   protected float a(bdh var1) {
      return 180.0F;
   }

   public vk b(bdh var1) {
      return a;
   }

   // $FF: synthetic method
   protected float c(aqm var1) {
      return this.a((bdh)var1);
   }

   // $FF: synthetic method
   public vk a(aqa var1) {
      return this.b((bdh)var1);
   }
}
