import com.google.common.collect.Lists;
import java.util.List;
import java.util.UUID;
import java.util.function.Predicate;
import javax.annotation.Nullable;

public class bgo extends bgm {
   private aqa b;
   @Nullable
   private gc c;
   private int d;
   private double e;
   private double f;
   private double g;
   @Nullable
   private UUID ag;

   public bgo(aqe<? extends bgo> var1, brx var2) {
      super(var1, var2);
      this.H = true;
   }

   public bgo(brx var1, double var2, double var4, double var6, double var8, double var10, double var12) {
      this(aqe.at, var1);
      this.b(var2, var4, var6, this.p, this.q);
      this.n(var8, var10, var12);
   }

   public bgo(brx var1, aqm var2, aqa var3, gc.a var4) {
      this(aqe.at, var1);
      this.b(var2);
      fx var5 = var2.cB();
      double var6 = (double)var5.u() + 0.5D;
      double var8 = (double)var5.v() + 0.5D;
      double var10 = (double)var5.w() + 0.5D;
      this.b(var6, var8, var10, this.p, this.q);
      this.b = var3;
      this.c = gc.b;
      this.a(var4);
   }

   public adr cu() {
      return adr.f;
   }

   protected void b(md var1) {
      super.b(var1);
      if (this.b != null) {
         var1.a("Target", this.b.bS());
      }

      if (this.c != null) {
         var1.b("Dir", this.c.c());
      }

      var1.b("Steps", this.d);
      var1.a("TXD", this.e);
      var1.a("TYD", this.f);
      var1.a("TZD", this.g);
   }

   protected void a(md var1) {
      super.a(var1);
      this.d = var1.h("Steps");
      this.e = var1.k("TXD");
      this.f = var1.k("TYD");
      this.g = var1.k("TZD");
      if (var1.c("Dir", 99)) {
         this.c = gc.a(var1.h("Dir"));
      }

      if (var1.b("Target")) {
         this.ag = var1.a("Target");
      }

   }

   protected void e() {
   }

   private void a(@Nullable gc var1) {
      this.c = var1;
   }

   private void a(@Nullable gc.a var1) {
      double var3 = 0.5D;
      fx var2;
      if (this.b == null) {
         var2 = this.cB().c();
      } else {
         var3 = (double)this.b.cz() * 0.5D;
         var2 = new fx(this.b.cD(), this.b.cE() + var3, this.b.cH());
      }

      double var5 = (double)var2.u() + 0.5D;
      double var7 = (double)var2.v() + var3;
      double var9 = (double)var2.w() + 0.5D;
      gc var11 = null;
      if (!var2.a(this.cA(), 2.0D)) {
         fx var12 = this.cB();
         List<gc> var13 = Lists.newArrayList();
         if (var1 != gc.a.a) {
            if (var12.u() < var2.u() && this.l.w(var12.g())) {
               var13.add(gc.f);
            } else if (var12.u() > var2.u() && this.l.w(var12.f())) {
               var13.add(gc.e);
            }
         }

         if (var1 != gc.a.b) {
            if (var12.v() < var2.v() && this.l.w(var12.b())) {
               var13.add(gc.b);
            } else if (var12.v() > var2.v() && this.l.w(var12.c())) {
               var13.add(gc.a);
            }
         }

         if (var1 != gc.a.c) {
            if (var12.w() < var2.w() && this.l.w(var12.e())) {
               var13.add(gc.d);
            } else if (var12.w() > var2.w() && this.l.w(var12.d())) {
               var13.add(gc.c);
            }
         }

         var11 = gc.a(this.J);
         if (var13.isEmpty()) {
            for(int var14 = 5; !this.l.w(var12.a(var11)) && var14 > 0; --var14) {
               var11 = gc.a(this.J);
            }
         } else {
            var11 = (gc)var13.get(this.J.nextInt(var13.size()));
         }

         var5 = this.cD() + (double)var11.i();
         var7 = this.cE() + (double)var11.j();
         var9 = this.cH() + (double)var11.k();
      }

      this.a(var11);
      double var20 = var5 - this.cD();
      double var21 = var7 - this.cE();
      double var16 = var9 - this.cH();
      double var18 = (double)afm.a(var20 * var20 + var21 * var21 + var16 * var16);
      if (var18 == 0.0D) {
         this.e = 0.0D;
         this.f = 0.0D;
         this.g = 0.0D;
      } else {
         this.e = var20 / var18 * 0.15D;
         this.f = var21 / var18 * 0.15D;
         this.g = var16 / var18 * 0.15D;
      }

      this.Z = true;
      this.d = 10 + this.J.nextInt(5) * 10;
   }

   public void cI() {
      if (this.l.ad() == aor.a) {
         this.ad();
      }

   }

   public void j() {
      super.j();
      dcn var1;
      if (!this.l.v) {
         if (this.b == null && this.ag != null) {
            this.b = ((aag)this.l).a(this.ag);
            if (this.b == null) {
               this.ag = null;
            }
         }

         if (this.b == null || !this.b.aX() || this.b instanceof bfw && ((bfw)this.b).a_()) {
            if (!this.aB()) {
               this.f(this.cC().b(0.0D, -0.04D, 0.0D));
            }
         } else {
            this.e = afm.a(this.e * 1.025D, -1.0D, 1.0D);
            this.f = afm.a(this.f * 1.025D, -1.0D, 1.0D);
            this.g = afm.a(this.g * 1.025D, -1.0D, 1.0D);
            var1 = this.cC();
            this.f(var1.b((this.e - var1.b) * 0.2D, (this.f - var1.c) * 0.2D, (this.g - var1.d) * 0.2D));
         }

         dcl var5 = bgn.a((aqa)this, (Predicate)(this::a));
         if (var5.c() != dcl.a.a) {
            this.a(var5);
         }
      }

      this.ay();
      var1 = this.cC();
      this.d(this.cD() + var1.b, this.cE() + var1.c, this.cH() + var1.d);
      bgn.a(this, 0.5F);
      if (this.l.v) {
         this.l.a(hh.t, this.cD() - var1.b, this.cE() - var1.c + 0.15D, this.cH() - var1.d, 0.0D, 0.0D, 0.0D);
      } else if (this.b != null && !this.b.y) {
         if (this.d > 0) {
            --this.d;
            if (this.d == 0) {
               this.a(this.c == null ? null : this.c.n());
            }
         }

         if (this.c != null) {
            fx var2 = this.cB();
            gc.a var3 = this.c.n();
            if (this.l.a((fx)var2.a(this.c), (aqa)this)) {
               this.a(var3);
            } else {
               fx var4 = this.b.cB();
               if (var3 == gc.a.a && var2.u() == var4.u() || var3 == gc.a.c && var2.w() == var4.w() || var3 == gc.a.b && var2.v() == var4.v()) {
                  this.a(var3);
               }
            }
         }
      }

   }

   protected boolean a(aqa var1) {
      return super.a(var1) && !var1.H;
   }

   public boolean bq() {
      return false;
   }

   public boolean a(double var1) {
      return var1 < 16384.0D;
   }

   public float aR() {
      return 1.0F;
   }

   protected void a(dck var1) {
      super.a(var1);
      aqa var2 = var1.a();
      aqa var3 = this.v();
      aqm var4 = var3 instanceof aqm ? (aqm)var3 : null;
      boolean var5 = var2.a(apk.a((aqa)this, (aqm)var4).c(), 4.0F);
      if (var5) {
         this.a(var4, var2);
         if (var2 instanceof aqm) {
            ((aqm)var2).c(new apu(apw.y, 200));
         }
      }

   }

   protected void a(dcj var1) {
      super.a(var1);
      ((aag)this.l).a(hh.w, this.cD(), this.cE(), this.cH(), 2, 0.2D, 0.2D, 0.2D, 0.0D);
      this.a(adq.nf, 1.0F, 1.0F);
   }

   protected void a(dcl var1) {
      super.a(var1);
      this.ad();
   }

   public boolean aT() {
      return true;
   }

   public boolean a(apk var1, float var2) {
      if (!this.l.v) {
         this.a(adq.ng, 1.0F, 1.0F);
         ((aag)this.l).a(hh.g, this.cD(), this.cE(), this.cH(), 15, 0.2D, 0.2D, 0.2D, 0.0D);
         this.ad();
      }

      return true;
   }

   public oj<?> P() {
      return new on(this);
   }
}
