import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Locale;

public class hd implements hf {
   public static final hd a = new hd(1.0F, 0.0F, 0.0F, 1.0F);
   public static final Codec<hd> b = RecordCodecBuilder.create((var0) -> {
      return var0.group(Codec.FLOAT.fieldOf("r").forGetter((var0x) -> {
         return var0x.d;
      }), Codec.FLOAT.fieldOf("g").forGetter((var0x) -> {
         return var0x.e;
      }), Codec.FLOAT.fieldOf("b").forGetter((var0x) -> {
         return var0x.f;
      }), Codec.FLOAT.fieldOf("scale").forGetter((var0x) -> {
         return var0x.g;
      })).apply(var0, hd::new);
   });
   public static final hf.a<hd> c = new hf.a<hd>() {
      public hd a(hg<hd> var1, StringReader var2) throws CommandSyntaxException {
         var2.expect(' ');
         float var3 = (float)var2.readDouble();
         var2.expect(' ');
         float var4 = (float)var2.readDouble();
         var2.expect(' ');
         float var5 = (float)var2.readDouble();
         var2.expect(' ');
         float var6 = (float)var2.readDouble();
         return new hd(var3, var4, var5, var6);
      }

      public hd a(hg<hd> var1, nf var2) {
         return new hd(var2.readFloat(), var2.readFloat(), var2.readFloat(), var2.readFloat());
      }

      // $FF: synthetic method
      public hf b(hg var1, nf var2) {
         return this.a(var1, var2);
      }

      // $FF: synthetic method
      public hf b(hg var1, StringReader var2) throws CommandSyntaxException {
         return this.a(var1, var2);
      }
   };
   private final float d;
   private final float e;
   private final float f;
   private final float g;

   public hd(float var1, float var2, float var3, float var4) {
      this.d = var1;
      this.e = var2;
      this.f = var3;
      this.g = afm.a(var4, 0.01F, 4.0F);
   }

   public void a(nf var1) {
      var1.writeFloat(this.d);
      var1.writeFloat(this.e);
      var1.writeFloat(this.f);
      var1.writeFloat(this.g);
   }

   public String a() {
      return String.format(Locale.ROOT, "%s %.2f %.2f %.2f %.2f", gm.V.b((Object)this.b()), this.d, this.e, this.f, this.g);
   }

   public hg<hd> b() {
      return hh.o;
   }

   public float c() {
      return this.d;
   }

   public float d() {
      return this.e;
   }

   public float e() {
      return this.f;
   }

   public float f() {
      return this.g;
   }
}
