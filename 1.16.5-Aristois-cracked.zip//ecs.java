import com.google.common.collect.ImmutableList;
import java.util.List;
import java.util.Random;
import java.util.stream.IntStream;

public class ecs<T extends cdl> extends ece<T> {
   public static final vk a = new vk("textures/environment/end_sky.png");
   public static final vk c = new vk("textures/entity/end_portal.png");
   private static final Random d = new Random(31100L);
   private static final List<eao> e = (List)IntStream.range(0, 16).mapToObj((var0) -> {
      return eao.a(var0 + 1);
   }).collect(ImmutableList.toImmutableList());

   public ecs(ecd var1) {
      super(var1);
   }

   public void a(T var1, float var2, dfm var3, eag var4, int var5, int var6) {
      d.setSeed(31100L);
      double var7 = var1.o().a(this.b.d.b(), true);
      int var9 = this.a(var7);
      float var10 = this.a();
      b var11 = var3.c().a();
      this.a(var1, var10, 0.15F, var11, var4.getBuffer((eao)e.get(0)));

      for(int var12 = 1; var12 < var9; ++var12) {
         this.a(var1, var10, 2.0F / (float)(18 - var12), var11, var4.getBuffer((eao)e.get(var12)));
      }

   }

   private void a(T var1, float var2, float var3, b var4, dfq var5) {
      float var6 = (d.nextFloat() * 0.5F + 0.1F) * var3;
      float var7 = (d.nextFloat() * 0.5F + 0.4F) * var3;
      float var8 = (d.nextFloat() * 0.5F + 0.5F) * var3;
      this.a(var1, var4, var5, 0.0F, 1.0F, 0.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F, var6, var7, var8, gc.d);
      this.a(var1, var4, var5, 0.0F, 1.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, var6, var7, var8, gc.c);
      this.a(var1, var4, var5, 1.0F, 1.0F, 1.0F, 0.0F, 0.0F, 1.0F, 1.0F, 0.0F, var6, var7, var8, gc.f);
      this.a(var1, var4, var5, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 1.0F, 1.0F, 0.0F, var6, var7, var8, gc.e);
      this.a(var1, var4, var5, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 1.0F, var6, var7, var8, gc.a);
      this.a(var1, var4, var5, 0.0F, 1.0F, var2, var2, 1.0F, 1.0F, 0.0F, 0.0F, var6, var7, var8, gc.b);
   }

   private void a(T var1, b var2, dfq var3, float var4, float var5, float var6, float var7, float var8, float var9, float var10, float var11, float var12, float var13, float var14, gc var15) {
      if (var1.a(var15)) {
         var3.a(var2, var4, var6, var8).a(var12, var13, var14, 1.0F).d();
         var3.a(var2, var5, var6, var9).a(var12, var13, var14, 1.0F).d();
         var3.a(var2, var5, var7, var10).a(var12, var13, var14, 1.0F).d();
         var3.a(var2, var4, var7, var11).a(var12, var13, var14, 1.0F).d();
      }

   }

   protected int a(double var1) {
      if (var1 > 36864.0D) {
         return 1;
      } else if (var1 > 25600.0D) {
         return 3;
      } else if (var1 > 16384.0D) {
         return 5;
      } else if (var1 > 9216.0D) {
         return 7;
      } else if (var1 > 4096.0D) {
         return 9;
      } else if (var1 > 1024.0D) {
         return 11;
      } else if (var1 > 576.0D) {
         return 13;
      } else {
         return var1 > 256.0D ? 14 : 15;
      }
   }

   protected float a() {
      return 0.75F;
   }
}
