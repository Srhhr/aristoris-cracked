import java.util.Random;
import javax.annotation.Nullable;

public class caa extends buo {
   public static final cfg a;
   protected static final ddh[] b;

   protected caa(ceg.c var1) {
      super(var1);
      this.j((ceh)((ceh)this.n.b()).a(a, 1));
   }

   public boolean a(ceh var1, brc var2, fx var3, cxe var4) {
      switch(var4) {
      case a:
         return (Integer)var1.c(a) < 5;
      case b:
         return false;
      case c:
         return false;
      default:
         return false;
      }
   }

   public ddh b(ceh var1, brc var2, fx var3, dcs var4) {
      return b[(Integer)var1.c(a)];
   }

   public ddh c(ceh var1, brc var2, fx var3, dcs var4) {
      return b[(Integer)var1.c(a) - 1];
   }

   public ddh e(ceh var1, brc var2, fx var3) {
      return b[(Integer)var1.c(a)];
   }

   public ddh a(ceh var1, brc var2, fx var3, dcs var4) {
      return b[(Integer)var1.c(a)];
   }

   public boolean c_(ceh var1) {
      return true;
   }

   public boolean a(ceh var1, brz var2, fx var3) {
      ceh var4 = var2.d_(var3.c());
      if (!var4.a(bup.cD) && !var4.a(bup.gT) && !var4.a(bup.go)) {
         if (!var4.a(bup.ne) && !var4.a(bup.cM)) {
            return buo.a(var4.k(var2, var3.c()), gc.b) || var4.b() == this && (Integer)var4.c(a) == 8;
         } else {
            return true;
         }
      } else {
         return false;
      }
   }

   public ceh a(ceh var1, gc var2, ceh var3, bry var4, fx var5, fx var6) {
      return !var1.a(var4, var5) ? bup.a.n() : super.a((ceh)var1, (gc)var2, (ceh)var3, (bry)var4, (fx)var5, (fx)var6);
   }

   public void b(ceh var1, aag var2, fx var3, Random var4) {
      if (var2.a((bsf)bsf.b, (fx)var3) > 11) {
         c(var1, var2, var3);
         var2.a(var3, false);
      }

   }

   public boolean a(ceh var1, bny var2) {
      int var3 = (Integer)var1.c(a);
      if (var2.m().b() == this.h() && var3 < 8) {
         if (var2.c()) {
            return var2.j() == gc.b;
         } else {
            return true;
         }
      } else {
         return var3 == 1;
      }
   }

   @Nullable
   public ceh a(bny var1) {
      ceh var2 = var1.p().d_(var1.a());
      if (var2.a(this)) {
         int var3 = (Integer)var2.c(a);
         return (ceh)var2.a(a, Math.min(8, var3 + 1));
      } else {
         return super.a(var1);
      }
   }

   protected void a(cei.a<buo, ceh> var1) {
      var1.a(a);
   }

   static {
      a = cex.aq;
      b = new ddh[]{dde.a(), buo.a(0.0D, 0.0D, 0.0D, 16.0D, 2.0D, 16.0D), buo.a(0.0D, 0.0D, 0.0D, 16.0D, 4.0D, 16.0D), buo.a(0.0D, 0.0D, 0.0D, 16.0D, 6.0D, 16.0D), buo.a(0.0D, 0.0D, 0.0D, 16.0D, 8.0D, 16.0D), buo.a(0.0D, 0.0D, 0.0D, 16.0D, 10.0D, 16.0D), buo.a(0.0D, 0.0D, 0.0D, 16.0D, 12.0D, 16.0D), buo.a(0.0D, 0.0D, 0.0D, 16.0D, 14.0D, 16.0D), buo.a(0.0D, 0.0D, 0.0D, 16.0D, 16.0D, 16.0D)};
   }
}
