import com.mojang.blaze3d.systems.RenderSystem;

public class dqd extends dpp<bir> {
   private static final vk A = new vk("textures/gui/container/dispenser.png");

   public dqd(bir var1, bfv var2, nr var3) {
      super(var1, var2, var3);
   }

   protected void b() {
      super.b();
      this.p = (this.b - this.o.a((nu)this.d)) / 2;
   }

   public void a(dfm var1, int var2, int var3, float var4) {
      this.a(var1);
      super.a(var1, var2, var3, var4);
      this.a(var1, var2, var3);
   }

   protected void a(dfm var1, float var2, int var3, int var4) {
      RenderSystem.color4f(1.0F, 1.0F, 1.0F, 1.0F);
      this.i.M().a(A);
      int var5 = (this.k - this.b) / 2;
      int var6 = (this.l - this.c) / 2;
      this.b(var1, var5, var6, 0, 0, this.b, this.c);
   }
}
