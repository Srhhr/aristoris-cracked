import java.util.function.Predicate;

public class dbq {
   public static final dbp a = a((String)"inverted", (cze)(new dbl.a()));
   public static final dbp b = a((String)"alternative", (cze)(new dbe.b()));
   public static final dbp c = a((String)"random_chance", (cze)(new dbt.a()));
   public static final dbp d = a((String)"random_chance_with_looting", (cze)(new dbu.a()));
   public static final dbp e = a((String)"entity_properties", (cze)(new dbr.a()));
   public static final dbp f = a((String)"killed_by_player", (cze)(new dbs.a()));
   public static final dbp g = a((String)"entity_scores", (cze)(new dbj.b()));
   public static final dbp h = a((String)"block_state_property", (cze)(new dbn.b()));
   public static final dbp i = a((String)"match_tool", (cze)(new dbv.a()));
   public static final dbp j = a((String)"table_bonus", (cze)(new dbf.a()));
   public static final dbp k = a((String)"survives_explosion", (cze)(new dbk.a()));
   public static final dbp l = a((String)"damage_source_properties", (cze)(new dbi.a()));
   public static final dbp m = a((String)"location_check", (cze)(new dbm.a()));
   public static final dbp n = a((String)"weather_check", (cze)(new dbx.b()));
   public static final dbp o = a((String)"reference", (cze)(new dbg.a()));
   public static final dbp p = a((String)"time_check", (cze)(new dbw.b()));

   private static dbp a(String var0, cze<? extends dbo> var1) {
      return (dbp)gm.a((gm)gm.aq, (vk)(new vk(var0)), (Object)(new dbp(var1)));
   }

   public static Object a() {
      return cyt.a(gm.aq, "condition", "condition", dbo::b).a();
   }

   public static <T> Predicate<T> a(Predicate<T>[] var0) {
      switch(var0.length) {
      case 0:
         return (var0x) -> {
            return true;
         };
      case 1:
         return var0[0];
      case 2:
         return var0[0].and(var0[1]);
      default:
         return (var1) -> {
            Predicate[] var2 = var0;
            int var3 = var0.length;

            for(int var4 = 0; var4 < var3; ++var4) {
               Predicate<T> var5 = var2[var4];
               if (!var5.test(var1)) {
                  return false;
               }
            }

            return true;
         };
      }
   }

   public static <T> Predicate<T> b(Predicate<T>[] var0) {
      switch(var0.length) {
      case 0:
         return (var0x) -> {
            return false;
         };
      case 1:
         return var0[0];
      case 2:
         return var0[0].or(var0[1]);
      default:
         return (var1) -> {
            Predicate[] var2 = var0;
            int var3 = var0.length;

            for(int var4 = 0; var4 < var3; ++var4) {
               Predicate<T> var5 = var2[var4];
               if (var5.test(var1)) {
                  return true;
               }
            }

            return false;
         };
      }
   }
}
