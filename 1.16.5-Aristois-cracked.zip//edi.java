import com.google.common.collect.Maps;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.Map;

public class edi implements edh.a {
   private final Map<fx, edi.a> a = Maps.newHashMap();

   public void a(fx var1, int var2, String var3, int var4) {
      this.a.put(var1, new edi.a(var2, var3, x.b() + (long)var4));
   }

   public void a() {
      this.a.clear();
   }

   public void a(dfm var1, eag var2, double var3, double var5, double var7) {
      long var9 = x.b();
      this.a.entrySet().removeIf((var2x) -> {
         return var9 > ((edi.a)var2x.getValue()).c;
      });
      this.a.forEach(this::a);
   }

   private void a(fx var1, edi.a var2) {
      RenderSystem.pushMatrix();
      RenderSystem.enableBlend();
      RenderSystem.blendFuncSeparate(dem.r.l, dem.j.j, dem.r.e, dem.j.n);
      RenderSystem.color4f(0.0F, 1.0F, 0.0F, 0.75F);
      RenderSystem.disableTexture();
      edh.a(var1, 0.02F, var2.a(), var2.b(), var2.c(), var2.d());
      if (!var2.b.isEmpty()) {
         double var3 = (double)var1.u() + 0.5D;
         double var5 = (double)var1.v() + 1.2D;
         double var7 = (double)var1.w() + 0.5D;
         edh.a(var2.b, var3, var5, var7, -1, 0.01F, true, 0.0F, true);
      }

      RenderSystem.enableTexture();
      RenderSystem.disableBlend();
      RenderSystem.popMatrix();
   }

   static class a {
      public int a;
      public String b;
      public long c;

      public a(int var1, String var2, long var3) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
      }

      public float a() {
         return (float)(this.a >> 16 & 255) / 255.0F;
      }

      public float b() {
         return (float)(this.a >> 8 & 255) / 255.0F;
      }

      public float c() {
         return (float)(this.a & 255) / 255.0F;
      }

      public float d() {
         return (float)(this.a >> 24 & 255) / 255.0F;
      }
   }
}
