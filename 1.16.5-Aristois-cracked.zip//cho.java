import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectList;
import it.unimi.dsi.fastutil.objects.ObjectListIterator;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.IntStream;
import javax.annotation.Nullable;

public final class cho extends cfy {
   public static final Codec<cho> d = RecordCodecBuilder.create((var0) -> {
      return var0.group(bsy.a.fieldOf("biome_source").forGetter((var0x) -> {
         return var0x.b;
      }), Codec.LONG.fieldOf("seed").stable().forGetter((var0x) -> {
         return var0x.w;
      }), chp.b.fieldOf("settings").forGetter((var0x) -> {
         return var0x.h;
      })).apply(var0, var0.stable(cho::new));
   });
   private static final float[] i = (float[])x.a((Object)(new float[13824]), (Consumer)((var0) -> {
      for(int var1 = 0; var1 < 24; ++var1) {
         for(int var2 = 0; var2 < 24; ++var2) {
            for(int var3 = 0; var3 < 24; ++var3) {
               var0[var1 * 24 * 24 + var2 * 24 + var3] = (float)b(var2 - 12, var3 - 12, var1 - 12);
            }
         }
      }

   }));
   private static final float[] j = (float[])x.a((Object)(new float[25]), (Consumer)((var0) -> {
      for(int var1 = -2; var1 <= 2; ++var1) {
         for(int var2 = -2; var2 <= 2; ++var2) {
            float var3 = 10.0F / afm.c((float)(var1 * var1 + var2 * var2) + 0.2F);
            var0[var1 + 2 + (var2 + 2) * 5] = var3;
         }
      }

   }));
   private static final ceh k;
   private final int l;
   private final int m;
   private final int n;
   private final int o;
   private final int p;
   protected final chx e;
   private final cub q;
   private final cub r;
   private final cub s;
   private final cue t;
   private final cub u;
   @Nullable
   private final cud v;
   protected final ceh f;
   protected final ceh g;
   private final long w;
   protected final Supplier<chp> h;
   private final int x;

   public cho(bsy var1, long var2, Supplier<chp> var4) {
      this(var1, var1, var2, var4);
   }

   private cho(bsy var1, bsy var2, long var3, Supplier<chp> var5) {
      super(var1, var2, ((chp)var5.get()).a(), var3);
      this.w = var3;
      chp var6 = (chp)var5.get();
      this.h = var5;
      chr var7 = var6.b();
      this.x = var7.a();
      this.l = var7.f() * 4;
      this.m = var7.e() * 4;
      this.f = var6.c();
      this.g = var6.d();
      this.n = 16 / this.m;
      this.o = var7.a() / this.l;
      this.p = 16 / this.m;
      this.e = new chx(var3);
      this.q = new cub(this.e, IntStream.rangeClosed(-15, 0));
      this.r = new cub(this.e, IntStream.rangeClosed(-15, 0));
      this.s = new cub(this.e, IntStream.rangeClosed(-7, 0));
      this.t = (cue)(var7.i() ? new cuc(this.e, IntStream.rangeClosed(-3, 0)) : new cub(this.e, IntStream.rangeClosed(-3, 0)));
      this.e.a(2620);
      this.u = new cub(this.e, IntStream.rangeClosed(-15, 0));
      if (var7.k()) {
         chx var8 = new chx(var3);
         var8.a(17292);
         this.v = new cud(var8);
      } else {
         this.v = null;
      }

   }

   protected Codec<? extends cfy> a() {
      return d;
   }

   public cfy a(long var1) {
      return new cho(this.b.a(var1), var1, this.h);
   }

   public boolean a(long var1, vj<chp> var3) {
      return this.w == var1 && ((chp)this.h.get()).a(var3);
   }

   private double a(int var1, int var2, int var3, double var4, double var6, double var8, double var10) {
      double var12 = 0.0D;
      double var14 = 0.0D;
      double var16 = 0.0D;
      boolean var18 = true;
      double var19 = 1.0D;

      for(int var21 = 0; var21 < 16; ++var21) {
         double var22 = cub.a((double)var1 * var4 * var19);
         double var24 = cub.a((double)var2 * var6 * var19);
         double var26 = cub.a((double)var3 * var4 * var19);
         double var28 = var6 * var19;
         ctz var30 = this.q.a(var21);
         if (var30 != null) {
            var12 += var30.a(var22, var24, var26, var28, (double)var2 * var28) / var19;
         }

         ctz var31 = this.r.a(var21);
         if (var31 != null) {
            var14 += var31.a(var22, var24, var26, var28, (double)var2 * var28) / var19;
         }

         if (var21 < 8) {
            ctz var32 = this.s.a(var21);
            if (var32 != null) {
               var16 += var32.a(cub.a((double)var1 * var8 * var19), cub.a((double)var2 * var10 * var19), cub.a((double)var3 * var8 * var19), var10 * var19, (double)var2 * var10 * var19) / var19;
            }
         }

         var19 /= 2.0D;
      }

      return afm.b(var12 / 512.0D, var14 / 512.0D, (var16 / 10.0D + 1.0D) / 2.0D);
   }

   private double[] b(int var1, int var2) {
      double[] var3 = new double[this.o + 1];
      this.a(var3, var1, var2);
      return var3;
   }

   private void a(double[] var1, int var2, int var3) {
      chr var8 = ((chp)this.h.get()).b();
      double var4;
      double var6;
      double var52;
      double var53;
      if (this.v != null) {
         var4 = (double)(btk.a(this.v, var2, var3) - 8.0F);
         if (var4 > 0.0D) {
            var6 = 0.25D;
         } else {
            var6 = 1.0D;
         }
      } else {
         float var9 = 0.0F;
         float var10 = 0.0F;
         float var11 = 0.0F;
         int var12 = true;
         int var13 = this.f();
         float var14 = this.b.b(var2, var13, var3).h();

         for(int var15 = -2; var15 <= 2; ++var15) {
            for(int var16 = -2; var16 <= 2; ++var16) {
               bsv var17 = this.b.b(var2 + var15, var13, var3 + var16);
               float var18 = var17.h();
               float var19 = var17.j();
               float var20;
               float var21;
               if (var8.l() && var18 > 0.0F) {
                  var20 = 1.0F + var18 * 2.0F;
                  var21 = 1.0F + var19 * 4.0F;
               } else {
                  var20 = var18;
                  var21 = var19;
               }

               float var22 = var18 > var14 ? 0.5F : 1.0F;
               float var23 = var22 * j[var15 + 2 + (var16 + 2) * 5] / (var20 + 2.0F);
               var9 += var21 * var23;
               var10 += var20 * var23;
               var11 += var23;
            }
         }

         float var49 = var10 / var11;
         float var51 = var9 / var11;
         var52 = (double)(var49 * 0.5F - 0.125F);
         var53 = (double)(var51 * 0.9F + 0.1F);
         var4 = var52 * 0.265625D;
         var6 = 96.0D / var53;
      }

      double var46 = 684.412D * var8.b().a();
      double var47 = 684.412D * var8.b().b();
      double var48 = var46 / var8.b().c();
      double var50 = var47 / var8.b().d();
      var52 = (double)var8.c().a();
      var53 = (double)var8.c().b();
      double var54 = (double)var8.c().c();
      double var55 = (double)var8.d().a();
      double var25 = (double)var8.d().b();
      double var27 = (double)var8.d().c();
      double var29 = var8.j() ? this.c(var2, var3) : 0.0D;
      double var31 = var8.g();
      double var33 = var8.h();

      for(int var35 = 0; var35 <= this.o; ++var35) {
         double var36 = this.a(var2, var35, var3, var46, var47, var48, var50);
         double var38 = 1.0D - (double)var35 * 2.0D / (double)this.o + var29;
         double var40 = var38 * var31 + var33;
         double var42 = (var40 + var4) * var6;
         if (var42 > 0.0D) {
            var36 += var42 * 4.0D;
         } else {
            var36 += var42;
         }

         double var44;
         if (var53 > 0.0D) {
            var44 = ((double)(this.o - var35) - var54) / var53;
            var36 = afm.b(var52, var36, var44);
         }

         if (var25 > 0.0D) {
            var44 = ((double)var35 - var27) / var25;
            var36 = afm.b(var55, var36, var44);
         }

         var1[var35] = var36;
      }

   }

   private double c(int var1, int var2) {
      double var3 = this.u.a((double)(var1 * 200), 10.0D, (double)(var2 * 200), 1.0D, 0.0D, true);
      double var5;
      if (var3 < 0.0D) {
         var5 = -var3 * 0.3D;
      } else {
         var5 = var3;
      }

      double var7 = var5 * 24.575625D - 2.0D;
      return var7 < 0.0D ? var7 * 0.009486607142857142D : Math.min(var7, 1.0D) * 0.006640625D;
   }

   public int a(int var1, int var2, chn.a var3) {
      return this.a(var1, var2, (ceh[])null, var3.e());
   }

   public brc a(int var1, int var2) {
      ceh[] var3 = new ceh[this.o * this.l];
      this.a(var1, var2, var3, (Predicate)null);
      return new bsh(var3);
   }

   private int a(int var1, int var2, @Nullable ceh[] var3, @Nullable Predicate<ceh> var4) {
      int var5 = Math.floorDiv(var1, this.m);
      int var6 = Math.floorDiv(var2, this.m);
      int var7 = Math.floorMod(var1, this.m);
      int var8 = Math.floorMod(var2, this.m);
      double var9 = (double)var7 / (double)this.m;
      double var11 = (double)var8 / (double)this.m;
      double[][] var13 = new double[][]{this.b(var5, var6), this.b(var5, var6 + 1), this.b(var5 + 1, var6), this.b(var5 + 1, var6 + 1)};

      for(int var14 = this.o - 1; var14 >= 0; --var14) {
         double var15 = var13[0][var14];
         double var17 = var13[1][var14];
         double var19 = var13[2][var14];
         double var21 = var13[3][var14];
         double var23 = var13[0][var14 + 1];
         double var25 = var13[1][var14 + 1];
         double var27 = var13[2][var14 + 1];
         double var29 = var13[3][var14 + 1];

         for(int var31 = this.l - 1; var31 >= 0; --var31) {
            double var32 = (double)var31 / (double)this.l;
            double var34 = afm.a(var32, var9, var11, var15, var23, var19, var27, var17, var25, var21, var29);
            int var36 = var14 * this.l + var31;
            ceh var37 = this.a(var34, var36);
            if (var3 != null) {
               var3[var36] = var37;
            }

            if (var4 != null && var4.test(var37)) {
               return var36 + 1;
            }
         }
      }

      return 0;
   }

   protected ceh a(double var1, int var3) {
      ceh var4;
      if (var1 > 0.0D) {
         var4 = this.f;
      } else if (var3 < this.f()) {
         var4 = this.g;
      } else {
         var4 = k;
      }

      return var4;
   }

   public void a(aam var1, cfw var2) {
      brd var3 = var2.g();
      int var4 = var3.b;
      int var5 = var3.c;
      chx var6 = new chx();
      var6.a(var4, var5);
      brd var7 = var2.g();
      int var8 = var7.d();
      int var9 = var7.e();
      double var10 = 0.0625D;
      fx.a var12 = new fx.a();

      for(int var13 = 0; var13 < 16; ++var13) {
         for(int var14 = 0; var14 < 16; ++var14) {
            int var15 = var8 + var13;
            int var16 = var9 + var14;
            int var17 = var2.a(chn.a.a, var13, var14) + 1;
            double var18 = this.t.a((double)var15 * 0.0625D, (double)var16 * 0.0625D, 0.0625D, (double)var13 * 0.0625D) * 15.0D;
            var1.v(var12.d(var8 + var13, var17, var9 + var14)).a(var6, var2, var15, var16, var17, var18, this.f, this.g, this.f(), var1.C());
         }
      }

      this.a((cfw)var2, (Random)var6);
   }

   private void a(cfw var1, Random var2) {
      fx.a var3 = new fx.a();
      int var4 = var1.g().d();
      int var5 = var1.g().e();
      chp var6 = (chp)this.h.get();
      int var7 = var6.f();
      int var8 = this.x - 1 - var6.e();
      int var9 = true;
      boolean var10 = var8 + 4 >= 0 && var8 < this.x;
      boolean var11 = var7 + 4 >= 0 && var7 < this.x;
      if (var10 || var11) {
         Iterator var12 = fx.b(var4, 0, var5, var4 + 15, 0, var5 + 15).iterator();

         while(true) {
            fx var13;
            int var14;
            do {
               if (!var12.hasNext()) {
                  return;
               }

               var13 = (fx)var12.next();
               if (var10) {
                  for(var14 = 0; var14 < 5; ++var14) {
                     if (var14 <= var2.nextInt(5)) {
                        var1.a(var3.d(var13.u(), var8 - var14, var13.w()), bup.z.n(), false);
                     }
                  }
               }
            } while(!var11);

            for(var14 = 4; var14 >= 0; --var14) {
               if (var14 <= var2.nextInt(5)) {
                  var1.a(var3.d(var13.u(), var7 + var14, var13.w()), bup.z.n(), false);
               }
            }
         }
      }
   }

   public void a(bry var1, bsn var2, cfw var3) {
      ObjectList<cru> var4 = new ObjectArrayList(10);
      ObjectList<cod> var5 = new ObjectArrayList(32);
      brd var6 = var3.g();
      int var7 = var6.b;
      int var8 = var6.c;
      int var9 = var7 << 4;
      int var10 = var8 << 4;
      Iterator var11 = cla.t.iterator();

      while(var11.hasNext()) {
         cla<?> var12 = (cla)var11.next();
         var2.a(gp.a((brd)var6, 0), var12).forEach((var5x) -> {
            Iterator var6x = var5x.d().iterator();

            while(true) {
               while(true) {
                  cru var7;
                  do {
                     if (!var6x.hasNext()) {
                        return;
                     }

                     var7 = (cru)var6x.next();
                  } while(!var7.a(var6, 12));

                  if (var7 instanceof cro) {
                     cro var8 = (cro)var7;
                     cok.a var9x = var8.b().e();
                     if (var9x == cok.a.b) {
                        var4.add(var8);
                     }

                     Iterator var10x = var8.e().iterator();

                     while(var10x.hasNext()) {
                        cod var11 = (cod)var10x.next();
                        int var12 = var11.a();
                        int var13 = var11.c();
                        if (var12 > var9 - 12 && var13 > var10 - 12 && var12 < var9 + 15 + 12 && var13 < var10 + 15 + 12) {
                           var5.add(var11);
                        }
                     }
                  } else {
                     var4.add(var7);
                  }
               }
            }
         });
      }

      double[][][] var75 = new double[2][this.p + 1][this.o + 1];

      for(int var76 = 0; var76 < this.p + 1; ++var76) {
         var75[0][var76] = new double[this.o + 1];
         this.a(var75[0][var76], var7 * this.n, var8 * this.p + var76);
         var75[1][var76] = new double[this.o + 1];
      }

      cgp var77 = (cgp)var3;
      chn var13 = var77.a(chn.a.c);
      chn var14 = var77.a(chn.a.a);
      fx.a var15 = new fx.a();
      ObjectListIterator<cru> var16 = var4.iterator();
      ObjectListIterator<cod> var17 = var5.iterator();

      for(int var18 = 0; var18 < this.n; ++var18) {
         int var19;
         for(var19 = 0; var19 < this.p + 1; ++var19) {
            this.a(var75[1][var19], var7 * this.n + var18 + 1, var8 * this.p + var19);
         }

         for(var19 = 0; var19 < this.p; ++var19) {
            cgi var20 = var77.a(15);
            var20.a();

            for(int var21 = this.o - 1; var21 >= 0; --var21) {
               double var22 = var75[0][var19][var21];
               double var24 = var75[0][var19 + 1][var21];
               double var26 = var75[1][var19][var21];
               double var28 = var75[1][var19 + 1][var21];
               double var30 = var75[0][var19][var21 + 1];
               double var32 = var75[0][var19 + 1][var21 + 1];
               double var34 = var75[1][var19][var21 + 1];
               double var36 = var75[1][var19 + 1][var21 + 1];

               for(int var38 = this.l - 1; var38 >= 0; --var38) {
                  int var39 = var21 * this.l + var38;
                  int var40 = var39 & 15;
                  int var41 = var39 >> 4;
                  if (var20.g() >> 4 != var41) {
                     var20.b();
                     var20 = var77.a(var41);
                     var20.a();
                  }

                  double var42 = (double)var38 / (double)this.l;
                  double var44 = afm.d(var42, var22, var30);
                  double var46 = afm.d(var42, var26, var34);
                  double var48 = afm.d(var42, var24, var32);
                  double var50 = afm.d(var42, var28, var36);

                  for(int var52 = 0; var52 < this.m; ++var52) {
                     int var53 = var9 + var18 * this.m + var52;
                     int var54 = var53 & 15;
                     double var55 = (double)var52 / (double)this.m;
                     double var57 = afm.d(var55, var44, var46);
                     double var59 = afm.d(var55, var48, var50);

                     for(int var61 = 0; var61 < this.m; ++var61) {
                        int var62 = var10 + var19 * this.m + var61;
                        int var63 = var62 & 15;
                        double var64 = (double)var61 / (double)this.m;
                        double var66 = afm.d(var64, var57, var59);
                        double var68 = afm.a(var66 / 200.0D, -1.0D, 1.0D);

                        int var72;
                        int var73;
                        int var74;
                        for(var68 = var68 / 2.0D - var68 * var68 * var68 / 24.0D; var16.hasNext(); var68 += a(var72, var73, var74) * 0.8D) {
                           cru var70 = (cru)var16.next();
                           cra var71 = var70.g();
                           var72 = Math.max(0, Math.max(var71.a - var53, var53 - var71.d));
                           var73 = var39 - (var71.b + (var70 instanceof cro ? ((cro)var70).d() : 0));
                           var74 = Math.max(0, Math.max(var71.c - var62, var62 - var71.f));
                        }

                        var16.back(var4.size());

                        while(var17.hasNext()) {
                           cod var79 = (cod)var17.next();
                           int var81 = var53 - var79.a();
                           var72 = var39 - var79.b();
                           var73 = var62 - var79.c();
                           var68 += a(var81, var72, var73) * 0.4D;
                        }

                        var17.back(var5.size());
                        ceh var80 = this.a(var68, var39);
                        if (var80 != k) {
                           if (var80.f() != 0) {
                              var15.d(var53, var39, var62);
                              var77.k(var15);
                           }

                           var20.a(var54, var40, var63, var80, false);
                           var13.a(var54, var39, var63, var80);
                           var14.a(var54, var39, var63, var80);
                        }
                     }
                  }
               }
            }

            var20.b();
         }

         double[][] var78 = var75[0];
         var75[0] = var75[1];
         var75[1] = var78;
      }

   }

   private static double a(int var0, int var1, int var2) {
      int var3 = var0 + 12;
      int var4 = var1 + 12;
      int var5 = var2 + 12;
      if (var3 >= 0 && var3 < 24) {
         if (var4 >= 0 && var4 < 24) {
            return var5 >= 0 && var5 < 24 ? (double)i[var5 * 24 * 24 + var3 * 24 + var4] : 0.0D;
         } else {
            return 0.0D;
         }
      } else {
         return 0.0D;
      }
   }

   private static double b(int var0, int var1, int var2) {
      double var3 = (double)(var0 * var0 + var2 * var2);
      double var5 = (double)var1 + 0.5D;
      double var7 = var5 * var5;
      double var9 = Math.pow(2.718281828459045D, -(var7 / 16.0D + var3 / 16.0D));
      double var11 = -var5 * afm.i(var7 / 2.0D + var3 / 2.0D) / 2.0D;
      return var11 * var9;
   }

   public int e() {
      return this.x;
   }

   public int f() {
      return ((chp)this.h.get()).g();
   }

   public List<btg.c> a(bsv var1, bsn var2, aqo var3, fx var4) {
      if (var2.a(var4, true, cla.j).e()) {
         if (var3 == aqo.a) {
            return cla.j.c();
         }

         if (var3 == aqo.b) {
            return cla.j.j();
         }
      }

      if (var3 == aqo.a) {
         if (var2.a(var4, false, cla.b).e()) {
            return cla.b.c();
         }

         if (var2.a(var4, false, cla.l).e()) {
            return cla.l.c();
         }

         if (var2.a(var4, true, cla.n).e()) {
            return cla.n.c();
         }
      }

      return super.a(var1, var2, var3, var4);
   }

   public void a(aam var1) {
      if (!((chp)this.h.get()).h()) {
         int var2 = var1.a();
         int var3 = var1.b();
         bsv var4 = var1.v((new brd(var2, var3)).l());
         chx var5 = new chx();
         var5.a(var1.C(), var2 << 4, var3 << 4);
         bsg.a(var1, var4, var2, var3, var5);
      }
   }

   static {
      k = bup.a.n();
   }
}
