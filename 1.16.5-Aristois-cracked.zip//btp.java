public abstract class btp extends bxi {
   protected btp(ceg.c var1) {
      super(var1);
   }

   public ddh a(ceh var1, brc var2, fx var3, dcs var4) {
      return dde.a();
   }

   public float a(ceh var1, brc var2, fx var3) {
      return 1.0F;
   }

   public boolean b(ceh var1, brc var2, fx var3) {
      return true;
   }
}
