import java.util.Objects;
import java.util.UUID;
import javax.annotation.Nullable;

public interface aqs {
   int E_();

   void a_(int var1);

   @Nullable
   UUID F_();

   void a(@Nullable UUID var1);

   void G_();

   default void c(md var1) {
      var1.b("AngerTime", this.E_());
      if (this.F_() != null) {
         var1.a("AngryAt", this.F_());
      }

   }

   default void a(aag var1, md var2) {
      this.a_(var2.h("AngerTime"));
      if (!var2.b("AngryAt")) {
         this.a((UUID)null);
      } else {
         UUID var3 = var2.a("AngryAt");
         this.a(var3);
         aqa var4 = var1.a(var3);
         if (var4 != null) {
            if (var4 instanceof aqn) {
               this.a((aqm)((aqn)var4));
            }

            if (var4.X() == aqe.bc) {
               this.e((bfw)var4);
            }

         }
      }
   }

   default void a(aag var1, boolean var2) {
      aqm var3 = this.A();
      UUID var4 = this.F_();
      if ((var3 == null || var3.dl()) && var4 != null && var1.a(var4) instanceof aqn) {
         this.J_();
      } else {
         if (var3 != null && !Objects.equals(var4, var3.bS())) {
            this.a(var3.bS());
            this.G_();
         }

         if (this.E_() > 0 && (var3 == null || var3.X() != aqe.bc || !var2)) {
            this.a_(this.E_() - 1);
            if (this.E_() == 0) {
               this.J_();
            }
         }

      }
   }

   default boolean a_(aqm var1) {
      if (!aqd.f.test(var1)) {
         return false;
      } else {
         return var1.X() == aqe.bc && this.a(var1.l) ? true : var1.bS().equals(this.F_());
      }
   }

   default boolean a(brx var1) {
      return var1.V().b(brt.G) && this.H_() && this.F_() == null;
   }

   default boolean H_() {
      return this.E_() > 0;
   }

   default void b(bfw var1) {
      if (var1.l.V().b(brt.F)) {
         if (var1.bS().equals(this.F_())) {
            this.J_();
         }
      }
   }

   default void I_() {
      this.J_();
      this.G_();
   }

   default void J_() {
      this.a((aqm)null);
      this.a((UUID)null);
      this.h((aqm)null);
      this.a_(0);
   }

   void a(@Nullable aqm var1);

   void e(@Nullable bfw var1);

   void h(@Nullable aqm var1);

   @Nullable
   aqm A();
}
