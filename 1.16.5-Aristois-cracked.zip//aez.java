public class aez {
   public static class a {
      public static int a(int var0) {
         return var0 >>> 24;
      }

      public static int b(int var0) {
         return var0 >> 16 & 255;
      }

      public static int c(int var0) {
         return var0 >> 8 & 255;
      }

      public static int d(int var0) {
         return var0 & 255;
      }

      public static int a(int var0, int var1, int var2, int var3) {
         return var0 << 24 | var1 << 16 | var2 << 8 | var3;
      }

      public static int a(int var0, int var1) {
         return a(a(var0) * a(var1) / 255, b(var0) * b(var1) / 255, c(var0) * c(var1) / 255, d(var0) * d(var1) / 255);
      }
   }
}
