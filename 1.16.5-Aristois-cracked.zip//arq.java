import com.google.common.collect.ImmutableMap;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

public class arq extends arv<azz> {
   private final aqe<? extends azz> b;
   private final float c;
   private long d;

   public arq(aqe<? extends azz> var1, float var2) {
      super(ImmutableMap.of(ayd.h, aye.a, ayd.r, aye.b, ayd.m, aye.c, ayd.n, aye.c), 325);
      this.b = var1;
      this.c = var2;
   }

   protected boolean a(aag var1, azz var2) {
      return var2.eS() && this.c(var2).isPresent();
   }

   protected void a(aag var1, azz var2, long var3) {
      azz var5 = (azz)this.c(var2).get();
      var2.cJ().a((ayd)ayd.r, (Object)var5);
      var5.cJ().a((ayd)ayd.r, (Object)var2);
      arw.a(var2, var5, this.c);
      int var6 = 275 + var2.cY().nextInt(50);
      this.d = var3 + (long)var6;
   }

   protected boolean b(aag var1, azz var2, long var3) {
      if (!this.b(var2)) {
         return false;
      } else {
         azz var5 = this.a(var2);
         return var5.aX() && var2.a(var5) && arw.a((arf)var2.cJ(), (aqm)var5) && var3 <= this.d;
      }
   }

   protected void c(aag var1, azz var2, long var3) {
      azz var5 = this.a(var2);
      arw.a(var2, var5, this.c);
      if (var2.a(var5, 3.0D)) {
         if (var3 >= this.d) {
            var2.a(var1, var5);
            var2.cJ().b(ayd.r);
            var5.cJ().b(ayd.r);
         }

      }
   }

   protected void d(aag var1, azz var2, long var3) {
      var2.cJ().b(ayd.r);
      var2.cJ().b(ayd.m);
      var2.cJ().b(ayd.n);
      this.d = 0L;
   }

   private azz a(azz var1) {
      return (azz)var1.cJ().c(ayd.r).get();
   }

   private boolean b(azz var1) {
      arf<?> var2 = var1.cJ();
      return var2.a(ayd.r) && ((apy)var2.c(ayd.r).get()).X() == this.b;
   }

   private Optional<? extends azz> c(azz var1) {
      Stream var10000 = ((List)var1.cJ().c(ayd.h).get()).stream().filter((var1x) -> {
         return var1x.X() == this.b;
      }).map((var0) -> {
         return (azz)var0;
      });
      var1.getClass();
      return var10000.filter(var1::a).findFirst();
   }

   // $FF: synthetic method
   protected void c(aag var1, aqm var2, long var3) {
      this.d(var1, (azz)var2, var3);
   }

   // $FF: synthetic method
   protected void d(aag var1, aqm var2, long var3) {
      this.c(var1, (azz)var2, var3);
   }
}
