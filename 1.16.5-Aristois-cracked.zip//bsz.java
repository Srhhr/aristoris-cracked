import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Arrays;
import java.util.Map;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.stream.Collectors;

public class bsz {
   public static final Codec<bsz> a = RecordCodecBuilder.create((var0) -> {
      return var0.group(Codec.INT.fieldOf("fog_color").forGetter((var0x) -> {
         return var0x.b;
      }), Codec.INT.fieldOf("water_color").forGetter((var0x) -> {
         return var0x.c;
      }), Codec.INT.fieldOf("water_fog_color").forGetter((var0x) -> {
         return var0x.d;
      }), Codec.INT.fieldOf("sky_color").forGetter((var0x) -> {
         return var0x.e;
      }), Codec.INT.optionalFieldOf("foliage_color").forGetter((var0x) -> {
         return var0x.f;
      }), Codec.INT.optionalFieldOf("grass_color").forGetter((var0x) -> {
         return var0x.g;
      }), bsz.b.d.optionalFieldOf("grass_color_modifier", bsz.b.a).forGetter((var0x) -> {
         return var0x.h;
      }), bsu.a.optionalFieldOf("particle").forGetter((var0x) -> {
         return var0x.i;
      }), adp.a.optionalFieldOf("ambient_sound").forGetter((var0x) -> {
         return var0x.j;
      }), bst.a.optionalFieldOf("mood_sound").forGetter((var0x) -> {
         return var0x.k;
      }), bss.a.optionalFieldOf("additions_sound").forGetter((var0x) -> {
         return var0x.l;
      }), adn.a.optionalFieldOf("music").forGetter((var0x) -> {
         return var0x.m;
      })).apply(var0, bsz::new);
   });
   private final int b;
   private final int c;
   private final int d;
   private final int e;
   private final Optional<Integer> f;
   private final Optional<Integer> g;
   private final bsz.b h;
   private final Optional<bsu> i;
   private final Optional<adp> j;
   private final Optional<bst> k;
   private final Optional<bss> l;
   private final Optional<adn> m;

   private bsz(int var1, int var2, int var3, int var4, Optional<Integer> var5, Optional<Integer> var6, bsz.b var7, Optional<bsu> var8, Optional<adp> var9, Optional<bst> var10, Optional<bss> var11, Optional<adn> var12) {
      this.b = var1;
      this.c = var2;
      this.d = var3;
      this.e = var4;
      this.f = var5;
      this.g = var6;
      this.h = var7;
      this.i = var8;
      this.j = var9;
      this.k = var10;
      this.l = var11;
      this.m = var12;
   }

   public int a() {
      return this.b;
   }

   public int b() {
      return this.c;
   }

   public int c() {
      return this.d;
   }

   public int d() {
      return this.e;
   }

   public Optional<Integer> e() {
      return this.f;
   }

   public Optional<Integer> f() {
      return this.g;
   }

   public bsz.b g() {
      return this.h;
   }

   public Optional<bsu> h() {
      return this.i;
   }

   public Optional<adp> i() {
      return this.j;
   }

   public Optional<bst> j() {
      return this.k;
   }

   public Optional<bss> k() {
      return this.l;
   }

   public Optional<adn> l() {
      return this.m;
   }

   // $FF: synthetic method
   bsz(int var1, int var2, int var3, int var4, Optional var5, Optional var6, bsz.b var7, Optional var8, Optional var9, Optional var10, Optional var11, Optional var12, Object var13) {
      this(var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12);
   }

   public static enum b implements afs {
      a("none") {
         public int a(double var1, double var3, int var5) {
            return var5;
         }
      },
      b("dark_forest") {
         public int a(double var1, double var3, int var5) {
            return (var5 & 16711422) + 2634762 >> 1;
         }
      },
      c("swamp") {
         public int a(double var1, double var3, int var5) {
            double var6 = bsv.f.a(var1 * 0.0225D, var3 * 0.0225D, false);
            return var6 < -0.1D ? 5011004 : 6975545;
         }
      };

      private final String e;
      public static final Codec<bsz.b> d = afs.a(bsz.b::values, bsz.b::a);
      private static final Map<String, bsz.b> f = (Map)Arrays.stream(values()).collect(Collectors.toMap(bsz.b::b, (var0) -> {
         return var0;
      }));

      public abstract int a(double var1, double var3, int var5);

      private b(String var3) {
         this.e = var3;
      }

      public String b() {
         return this.e;
      }

      public String a() {
         return this.e;
      }

      public static bsz.b a(String var0) {
         return (bsz.b)f.get(var0);
      }

      // $FF: synthetic method
      b(String var3, Object var4) {
         this(var3);
      }
   }

   public static class a {
      private OptionalInt a = OptionalInt.empty();
      private OptionalInt b = OptionalInt.empty();
      private OptionalInt c = OptionalInt.empty();
      private OptionalInt d = OptionalInt.empty();
      private Optional<Integer> e = Optional.empty();
      private Optional<Integer> f = Optional.empty();
      private bsz.b g;
      private Optional<bsu> h;
      private Optional<adp> i;
      private Optional<bst> j;
      private Optional<bss> k;
      private Optional<adn> l;

      public a() {
         this.g = bsz.b.a;
         this.h = Optional.empty();
         this.i = Optional.empty();
         this.j = Optional.empty();
         this.k = Optional.empty();
         this.l = Optional.empty();
      }

      public bsz.a a(int var1) {
         this.a = OptionalInt.of(var1);
         return this;
      }

      public bsz.a b(int var1) {
         this.b = OptionalInt.of(var1);
         return this;
      }

      public bsz.a c(int var1) {
         this.c = OptionalInt.of(var1);
         return this;
      }

      public bsz.a d(int var1) {
         this.d = OptionalInt.of(var1);
         return this;
      }

      public bsz.a e(int var1) {
         this.e = Optional.of(var1);
         return this;
      }

      public bsz.a f(int var1) {
         this.f = Optional.of(var1);
         return this;
      }

      public bsz.a a(bsz.b var1) {
         this.g = var1;
         return this;
      }

      public bsz.a a(bsu var1) {
         this.h = Optional.of(var1);
         return this;
      }

      public bsz.a a(adp var1) {
         this.i = Optional.of(var1);
         return this;
      }

      public bsz.a a(bst var1) {
         this.j = Optional.of(var1);
         return this;
      }

      public bsz.a a(bss var1) {
         this.k = Optional.of(var1);
         return this;
      }

      public bsz.a a(adn var1) {
         this.l = Optional.of(var1);
         return this;
      }

      public bsz a() {
         return new bsz(this.a.orElseThrow(() -> {
            return new IllegalStateException("Missing 'fog' color.");
         }), this.b.orElseThrow(() -> {
            return new IllegalStateException("Missing 'water' color.");
         }), this.c.orElseThrow(() -> {
            return new IllegalStateException("Missing 'water fog' color.");
         }), this.d.orElseThrow(() -> {
            return new IllegalStateException("Missing 'sky' color.");
         }), this.e, this.f, this.g, this.h, this.i, this.j, this.k, this.l);
      }
   }
}
