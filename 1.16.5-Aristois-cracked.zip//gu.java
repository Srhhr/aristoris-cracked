public class gu extends gv {
   private final gv b = new gv();
   private final bhn.b c;

   public gu(bhn.b var1) {
      this.c = var1;
   }

   public bmb a(fy var1, bmb var2) {
      gc var3 = (gc)var1.e().c(bwa.a);
      brx var4 = var1.h();
      double var5 = var1.a() + (double)((float)var3.i() * 1.125F);
      double var7 = var1.b() + (double)((float)var3.j() * 1.125F);
      double var9 = var1.c() + (double)((float)var3.k() * 1.125F);
      fx var11 = var1.d().a(var3);
      double var12;
      if (var4.b(var11).a(aef.b)) {
         var12 = 1.0D;
      } else {
         if (!var4.d_(var11).g() || !var4.b(var11.c()).a(aef.b)) {
            return this.b.dispense(var1, var2);
         }

         var12 = 0.0D;
      }

      bhn var14 = new bhn(var4, var5, var7 + var12, var9);
      var14.a(this.c);
      var14.p = var3.o();
      var4.c((aqa)var14);
      var2.g(1);
      return var2;
   }

   protected void a(fy var1) {
      var1.h().c(1000, var1.d(), 0);
   }
}
