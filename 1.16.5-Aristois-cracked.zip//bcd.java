public class bcd extends bbu {
   private int b;
   private int c;
   private apz d;

   public bcd(bbr var1) {
      super(var1);
   }

   public void b() {
      ++this.b;
      if (this.b % 2 == 0 && this.b < 10) {
         dcn var1 = this.a.x(1.0F).d();
         var1.b(-0.7853982F);
         double var2 = this.a.bo.cD();
         double var4 = this.a.bo.e(0.5D);
         double var6 = this.a.bo.cH();

         for(int var8 = 0; var8 < 8; ++var8) {
            double var9 = var2 + this.a.cY().nextGaussian() / 2.0D;
            double var11 = var4 + this.a.cY().nextGaussian() / 2.0D;
            double var13 = var6 + this.a.cY().nextGaussian() / 2.0D;

            for(int var15 = 0; var15 < 6; ++var15) {
               this.a.l.a(hh.i, var9, var11, var13, -var1.b * 0.07999999821186066D * (double)var15, -var1.c * 0.6000000238418579D, -var1.d * 0.07999999821186066D * (double)var15);
            }

            var1.b(0.19634955F);
         }
      }

   }

   public void c() {
      ++this.b;
      if (this.b >= 200) {
         if (this.c >= 4) {
            this.a.eK().a(bch.e);
         } else {
            this.a.eK().a(bch.g);
         }
      } else if (this.b == 10) {
         dcn var1 = (new dcn(this.a.bo.cD() - this.a.cD(), 0.0D, this.a.bo.cH() - this.a.cH())).d();
         float var2 = 5.0F;
         double var3 = this.a.bo.cD() + var1.b * 5.0D / 2.0D;
         double var5 = this.a.bo.cH() + var1.d * 5.0D / 2.0D;
         double var7 = this.a.bo.e(0.5D);
         double var9 = var7;
         fx.a var11 = new fx.a(var3, var7, var5);

         while(this.a.l.w(var11)) {
            --var9;
            if (var9 < 0.0D) {
               var9 = var7;
               break;
            }

            var11.c(var3, var9, var5);
         }

         var9 = (double)(afm.c(var9) + 1);
         this.d = new apz(this.a.l, var3, var9, var5);
         this.d.a((aqm)this.a);
         this.d.a(5.0F);
         this.d.b(200);
         this.d.a((hf)hh.i);
         this.d.a(new apu(apw.g));
         this.a.l.c((aqa)this.d);
      }

   }

   public void d() {
      this.b = 0;
      ++this.c;
   }

   public void e() {
      if (this.d != null) {
         this.d.ad();
         this.d = null;
      }

   }

   public bch<bcd> i() {
      return bch.f;
   }

   public void j() {
      this.c = 0;
   }
}
