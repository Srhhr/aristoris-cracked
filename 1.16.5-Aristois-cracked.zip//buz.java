public class buz extends bvs {
   private static final ddh[] a = new ddh[]{buo.a(0.0D, 0.0D, 0.0D, 16.0D, 2.0D, 16.0D), buo.a(0.0D, 0.0D, 0.0D, 16.0D, 3.0D, 16.0D), buo.a(0.0D, 0.0D, 0.0D, 16.0D, 4.0D, 16.0D), buo.a(0.0D, 0.0D, 0.0D, 16.0D, 5.0D, 16.0D), buo.a(0.0D, 0.0D, 0.0D, 16.0D, 6.0D, 16.0D), buo.a(0.0D, 0.0D, 0.0D, 16.0D, 7.0D, 16.0D), buo.a(0.0D, 0.0D, 0.0D, 16.0D, 8.0D, 16.0D), buo.a(0.0D, 0.0D, 0.0D, 16.0D, 9.0D, 16.0D)};

   public buz(ceg.c var1) {
      super(var1);
   }

   protected brw e() {
      return bmd.oY;
   }

   public ddh b(ceh var1, brc var2, fx var3, dcs var4) {
      return a[(Integer)var1.c(this.c())];
   }
}
