import java.util.EnumSet;
import java.util.Random;
import java.util.function.Predicate;
import javax.annotation.Nullable;

public class bdm extends bdq {
   private static final us<Boolean> b;
   private static final us<Integer> d;
   private float bo;
   private float bp;
   private float bq;
   private float br;
   private float bs;
   private aqm bt;
   private int bu;
   private boolean bv;
   protected awt c;

   public bdm(aqe<? extends bdm> var1, brx var2) {
      super(var1, var2);
      this.f = 10;
      this.a(cwz.h, 0.0F);
      this.bh = new bdm.c(this);
      this.bo = this.J.nextFloat();
      this.bp = this.bo;
   }

   protected void o() {
      awk var1 = new awk(this, 1.0D);
      this.c = new awt(this, 1.0D, 80);
      this.bk.a(4, new bdm.a(this));
      this.bk.a(5, var1);
      this.bk.a(7, this.c);
      this.bk.a(8, new awd(this, bfw.class, 8.0F));
      this.bk.a(8, new awd(this, bdm.class, 12.0F, 0.01F));
      this.bk.a(9, new aws(this));
      this.c.a(EnumSet.of(avv.a.a, avv.a.b));
      var1.a(EnumSet.of(avv.a.a, avv.a.b));
      this.bl.a(1, new axq(this, aqm.class, 10, true, false, new bdm.b(this)));
   }

   public static ark.a eM() {
      return bdq.eR().a(arl.f, 6.0D).a(arl.d, 0.5D).a(arl.b, 16.0D).a(arl.a, 30.0D);
   }

   protected ayj b(brx var1) {
      return new ayl(this, var1);
   }

   protected void e() {
      super.e();
      this.R.a((us)b, (Object)false);
      this.R.a((us)d, (int)0);
   }

   public boolean cM() {
      return true;
   }

   public aqq dC() {
      return aqq.e;
   }

   public boolean eN() {
      return (Boolean)this.R.a(b);
   }

   private void t(boolean var1) {
      this.R.b(b, var1);
   }

   public int eK() {
      return 80;
   }

   private void a(int var1) {
      this.R.b(d, var1);
   }

   public boolean eO() {
      return (Integer)this.R.a(d) != 0;
   }

   @Nullable
   public aqm eP() {
      if (!this.eO()) {
         return null;
      } else if (this.l.v) {
         if (this.bt != null) {
            return this.bt;
         } else {
            aqa var1 = this.l.a((Integer)this.R.a(d));
            if (var1 instanceof aqm) {
               this.bt = (aqm)var1;
               return this.bt;
            } else {
               return null;
            }
         }
      } else {
         return this.A();
      }
   }

   public void a(us<?> var1) {
      super.a(var1);
      if (d.equals(var1)) {
         this.bu = 0;
         this.bt = null;
      }

   }

   public int D() {
      return 160;
   }

   protected adp I() {
      return this.aH() ? adq.fs : adq.ft;
   }

   protected adp e(apk var1) {
      return this.aH() ? adq.fy : adq.fz;
   }

   protected adp dq() {
      return this.aH() ? adq.fv : adq.fw;
   }

   protected boolean aC() {
      return false;
   }

   protected float b(aqx var1, aqb var2) {
      return var2.b * 0.5F;
   }

   public float a(fx var1, brz var2) {
      return var2.b(var1).a(aef.b) ? 10.0F + var2.y(var1) - 0.5F : super.a(var1, var2);
   }

   public void k() {
      if (this.aX()) {
         if (this.l.v) {
            this.bp = this.bo;
            dcn var1;
            if (!this.aE()) {
               this.bq = 2.0F;
               var1 = this.cC();
               if (var1.c > 0.0D && this.bv && !this.aA()) {
                  this.l.a(this.cD(), this.cE(), this.cH(), this.eL(), this.cu(), 1.0F, 1.0F, false);
               }

               this.bv = var1.c < 0.0D && this.l.a((fx)this.cB().c(), (aqa)this);
            } else if (this.eN()) {
               if (this.bq < 0.5F) {
                  this.bq = 4.0F;
               } else {
                  this.bq += (0.5F - this.bq) * 0.1F;
               }
            } else {
               this.bq += (0.125F - this.bq) * 0.2F;
            }

            this.bo += this.bq;
            this.bs = this.br;
            if (!this.aH()) {
               this.br = this.J.nextFloat();
            } else if (this.eN()) {
               this.br += (0.0F - this.br) * 0.25F;
            } else {
               this.br += (1.0F - this.br) * 0.06F;
            }

            if (this.eN() && this.aE()) {
               var1 = this.f(0.0F);

               for(int var2 = 0; var2 < 2; ++var2) {
                  this.l.a(hh.e, this.d(0.5D) - var1.b * 1.5D, this.cF() - var1.c * 1.5D, this.g(0.5D) - var1.d * 1.5D, 0.0D, 0.0D, 0.0D);
               }
            }

            if (this.eO()) {
               if (this.bu < this.eK()) {
                  ++this.bu;
               }

               aqm var14 = this.eP();
               if (var14 != null) {
                  this.t().a(var14, 90.0F, 90.0F);
                  this.t().a();
                  double var15 = (double)this.A(0.0F);
                  double var4 = var14.cD() - this.cD();
                  double var6 = var14.e(0.5D) - this.cG();
                  double var8 = var14.cH() - this.cH();
                  double var10 = Math.sqrt(var4 * var4 + var6 * var6 + var8 * var8);
                  var4 /= var10;
                  var6 /= var10;
                  var8 /= var10;
                  double var12 = this.J.nextDouble();

                  while(var12 < var10) {
                     var12 += 1.8D - var15 + this.J.nextDouble() * (1.7D - var15);
                     this.l.a(hh.e, this.cD() + var4 * var12, this.cG() + var6 * var12, this.cH() + var8 * var12, 0.0D, 0.0D, 0.0D);
                  }
               }
            }
         }

         if (this.aH()) {
            this.j(300);
         } else if (this.t) {
            this.f(this.cC().b((double)((this.J.nextFloat() * 2.0F - 1.0F) * 0.4F), 0.5D, (double)((this.J.nextFloat() * 2.0F - 1.0F) * 0.4F)));
            this.p = this.J.nextFloat() * 360.0F;
            this.t = false;
            this.Z = true;
         }

         if (this.eO()) {
            this.p = this.aC;
         }
      }

      super.k();
   }

   protected adp eL() {
      return adq.fx;
   }

   public float y(float var1) {
      return afm.g(var1, this.bp, this.bo);
   }

   public float z(float var1) {
      return afm.g(var1, this.bs, this.br);
   }

   public float A(float var1) {
      return ((float)this.bu + var1) / (float)this.eK();
   }

   public boolean a(brz var1) {
      return var1.j(this);
   }

   public static boolean b(aqe<? extends bdm> var0, bry var1, aqp var2, fx var3, Random var4) {
      return (var4.nextInt(20) == 0 || !var1.x(var3)) && var1.ad() != aor.a && (var2 == aqp.c || var1.b(var3).a(aef.b));
   }

   public boolean a(apk var1, float var2) {
      if (!this.eN() && !var1.t() && var1.j() instanceof aqm) {
         aqm var3 = (aqm)var1.j();
         if (!var1.d()) {
            var3.a(apk.a((aqa)this), 2.0F);
         }
      }

      if (this.c != null) {
         this.c.h();
      }

      return super.a(var1, var2);
   }

   public int O() {
      return 180;
   }

   public void g(dcn var1) {
      if (this.dS() && this.aE()) {
         this.a(0.1F, var1);
         this.a(aqr.a, this.cC());
         this.f(this.cC().a(0.9D));
         if (!this.eN() && this.A() == null) {
            this.f(this.cC().b(0.0D, -0.005D, 0.0D));
         }
      } else {
         super.g(var1);
      }

   }

   static {
      b = uv.a(bdm.class, uu.i);
      d = uv.a(bdm.class, uu.b);
   }

   static class c extends avb {
      private final bdm i;

      public c(bdm var1) {
         super(var1);
         this.i = var1;
      }

      public void a() {
         if (this.h == avb.a.b && !this.i.x().m()) {
            dcn var1 = new dcn(this.b - this.i.cD(), this.c - this.i.cE(), this.d - this.i.cH());
            double var2 = var1.f();
            double var4 = var1.b / var2;
            double var6 = var1.c / var2;
            double var8 = var1.d / var2;
            float var10 = (float)(afm.d(var1.d, var1.b) * 57.2957763671875D) - 90.0F;
            this.i.p = this.a(this.i.p, var10, 90.0F);
            this.i.aA = this.i.p;
            float var11 = (float)(this.e * this.i.b(arl.d));
            float var12 = afm.g(0.125F, this.i.dN(), var11);
            this.i.q(var12);
            double var13 = Math.sin((double)(this.i.K + this.i.Y()) * 0.5D) * 0.05D;
            double var15 = Math.cos((double)(this.i.p * 0.017453292F));
            double var17 = Math.sin((double)(this.i.p * 0.017453292F));
            double var19 = Math.sin((double)(this.i.K + this.i.Y()) * 0.75D) * 0.05D;
            this.i.f(this.i.cC().b(var13 * var15, var19 * (var17 + var15) * 0.25D + (double)var12 * var6 * 0.1D, var13 * var17));
            ava var21 = this.i.t();
            double var22 = this.i.cD() + var4 * 2.0D;
            double var24 = this.i.cG() + var6 / var2;
            double var26 = this.i.cH() + var8 * 2.0D;
            double var28 = var21.d();
            double var30 = var21.e();
            double var32 = var21.f();
            if (!var21.c()) {
               var28 = var22;
               var30 = var24;
               var32 = var26;
            }

            this.i.t().a(afm.d(0.125D, var28, var22), afm.d(0.125D, var30, var24), afm.d(0.125D, var32, var26), 10.0F, 40.0F);
            this.i.t(true);
         } else {
            this.i.q(0.0F);
            this.i.t(false);
         }
      }
   }

   static class a extends avv {
      private final bdm a;
      private int b;
      private final boolean c;

      public a(bdm var1) {
         this.a = var1;
         this.c = var1 instanceof bdf;
         this.a(EnumSet.of(avv.a.a, avv.a.b));
      }

      public boolean a() {
         aqm var1 = this.a.A();
         return var1 != null && var1.aX();
      }

      public boolean b() {
         return super.b() && (this.c || this.a.h(this.a.A()) > 9.0D);
      }

      public void c() {
         this.b = -10;
         this.a.x().o();
         this.a.t().a(this.a.A(), 90.0F, 90.0F);
         this.a.Z = true;
      }

      public void d() {
         this.a.a(0);
         this.a.h((aqm)null);
         this.a.c.h();
      }

      public void e() {
         aqm var1 = this.a.A();
         this.a.x().o();
         this.a.t().a(var1, 90.0F, 90.0F);
         if (!this.a.D(var1)) {
            this.a.h((aqm)null);
         } else {
            ++this.b;
            if (this.b == 0) {
               this.a.a(this.a.A().Y());
               if (!this.a.aA()) {
                  this.a.l.a(this.a, (byte)21);
               }
            } else if (this.b >= this.a.eK()) {
               float var2 = 1.0F;
               if (this.a.l.ad() == aor.d) {
                  var2 += 2.0F;
               }

               if (this.c) {
                  var2 += 2.0F;
               }

               var1.a(apk.c(this.a, this.a), var2);
               var1.a(apk.c(this.a), (float)this.a.b(arl.f));
               this.a.h((aqm)null);
            }

            super.e();
         }
      }
   }

   static class b implements Predicate<aqm> {
      private final bdm a;

      public b(bdm var1) {
         this.a = var1;
      }

      public boolean a(@Nullable aqm var1) {
         return (var1 instanceof bfw || var1 instanceof bav) && var1.h((aqa)this.a) > 9.0D;
      }

      // $FF: synthetic method
      public boolean test(@Nullable Object var1) {
         return this.a((aqm)var1);
      }
   }
}
