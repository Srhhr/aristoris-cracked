import java.io.IOException;

public class sz implements oj<sa> {
   private fx a;
   private gc b;
   private sz.a c;

   public sz() {
   }

   public sz(sz.a var1, fx var2, gc var3) {
      this.c = var1;
      this.a = var2.h();
      this.b = var3;
   }

   public void a(nf var1) throws IOException {
      this.c = (sz.a)var1.a(sz.a.class);
      this.a = var1.e();
      this.b = gc.a(var1.readUnsignedByte());
   }

   public void b(nf var1) throws IOException {
      var1.a((Enum)this.c);
      var1.a(this.a);
      var1.writeByte(this.b.c());
   }

   public void a(sa var1) {
      var1.a(this);
   }

   public fx b() {
      return this.a;
   }

   public gc c() {
      return this.b;
   }

   public sz.a d() {
      return this.c;
   }

   public static enum a {
      a,
      b,
      c,
      d,
      e,
      f,
      g;
   }
}
