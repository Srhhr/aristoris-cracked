import com.google.common.collect.ImmutableMap;

public class atd extends arv<aqm> {
   public atd() {
      super(ImmutableMap.of(ayd.C, aye.a));
   }

   protected void a(aag var1, aqm var2, long var3) {
      arf<?> var5 = var2.cJ();
      bhb var6 = var1.b_(var2.cB());
      if (var6 == null) {
         var5.a(bhf.j);
      }

   }
}
