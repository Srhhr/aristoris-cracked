import com.google.common.collect.Lists;
import com.mojang.authlib.GameProfile;
import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class dm implements ArgumentType<dm.a> {
   private static final Collection<String> b = Arrays.asList("Player", "0123", "dd12be42-52a9-4a91-a8a1-11c01849e498", "@e");
   public static final SimpleCommandExceptionType a = new SimpleCommandExceptionType(new of("argument.player.unknown"));

   public static Collection<GameProfile> a(CommandContext<db> var0, String var1) throws CommandSyntaxException {
      return ((dm.a)var0.getArgument(var1, dm.a.class)).getNames((db)var0.getSource());
   }

   public static dm a() {
      return new dm();
   }

   public dm.a a(StringReader var1) throws CommandSyntaxException {
      if (var1.canRead() && var1.peek() == '@') {
         fd var4 = new fd(var1);
         fc var5 = var4.t();
         if (var5.b()) {
            throw dk.c.create();
         } else {
            return new dm.b(var5);
         }
      } else {
         int var2 = var1.getCursor();

         while(var1.canRead() && var1.peek() != ' ') {
            var1.skip();
         }

         String var3 = var1.getString().substring(var2, var1.getCursor());
         return (var1x) -> {
            GameProfile var2 = var1x.j().ar().a(var3);
            if (var2 == null) {
               throw a.create();
            } else {
               return Collections.singleton(var2);
            }
         };
      }
   }

   public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> var1, SuggestionsBuilder var2) {
      if (var1.getSource() instanceof dd) {
         StringReader var3 = new StringReader(var2.getInput());
         var3.setCursor(var2.getStart());
         fd var4 = new fd(var3);

         try {
            var4.t();
         } catch (CommandSyntaxException var6) {
         }

         return var4.a(var2, (var1x) -> {
            dd.b((Iterable)((dd)var1.getSource()).l(), (SuggestionsBuilder)var1x);
         });
      } else {
         return Suggestions.empty();
      }
   }

   public Collection<String> getExamples() {
      return b;
   }

   // $FF: synthetic method
   public Object parse(StringReader var1) throws CommandSyntaxException {
      return this.a(var1);
   }

   public static class b implements dm.a {
      private final fc a;

      public b(fc var1) {
         this.a = var1;
      }

      public Collection<GameProfile> getNames(db var1) throws CommandSyntaxException {
         List<aah> var2 = this.a.d(var1);
         if (var2.isEmpty()) {
            throw dk.e.create();
         } else {
            List<GameProfile> var3 = Lists.newArrayList();
            Iterator var4 = var2.iterator();

            while(var4.hasNext()) {
               aah var5 = (aah)var4.next();
               var3.add(var5.eA());
            }

            return var3;
         }
      }
   }

   @FunctionalInterface
   public interface a {
      Collection<GameProfile> getNames(db var1) throws CommandSyntaxException;
   }
}
