import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import com.mojang.brigadier.tree.LiteralCommandNode;
import java.util.Collection;
import java.util.Iterator;
import java.util.function.BiConsumer;
import java.util.function.BiPredicate;
import java.util.function.ToIntFunction;

public class wy {
   private static final SimpleCommandExceptionType a = new SimpleCommandExceptionType(new of("commands.experience.set.points.invalid"));

   public static void a(CommandDispatcher<db> var0) {
      LiteralCommandNode<db> var1 = var0.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)dc.a("experience").requires((var0x) -> {
         return var0x.c(2);
      })).then(dc.a("add").then(dc.a((String)"targets", (ArgumentType)dk.d()).then(((RequiredArgumentBuilder)((RequiredArgumentBuilder)dc.a((String)"amount", (ArgumentType)IntegerArgumentType.integer()).executes((var0x) -> {
         return a((db)var0x.getSource(), dk.f(var0x, "targets"), IntegerArgumentType.getInteger(var0x, "amount"), wy.a.a);
      })).then(dc.a("points").executes((var0x) -> {
         return a((db)var0x.getSource(), dk.f(var0x, "targets"), IntegerArgumentType.getInteger(var0x, "amount"), wy.a.a);
      }))).then(dc.a("levels").executes((var0x) -> {
         return a((db)var0x.getSource(), dk.f(var0x, "targets"), IntegerArgumentType.getInteger(var0x, "amount"), wy.a.b);
      })))))).then(dc.a("set").then(dc.a((String)"targets", (ArgumentType)dk.d()).then(((RequiredArgumentBuilder)((RequiredArgumentBuilder)dc.a((String)"amount", (ArgumentType)IntegerArgumentType.integer(0)).executes((var0x) -> {
         return b((db)var0x.getSource(), dk.f(var0x, "targets"), IntegerArgumentType.getInteger(var0x, "amount"), wy.a.a);
      })).then(dc.a("points").executes((var0x) -> {
         return b((db)var0x.getSource(), dk.f(var0x, "targets"), IntegerArgumentType.getInteger(var0x, "amount"), wy.a.a);
      }))).then(dc.a("levels").executes((var0x) -> {
         return b((db)var0x.getSource(), dk.f(var0x, "targets"), IntegerArgumentType.getInteger(var0x, "amount"), wy.a.b);
      })))))).then(dc.a("query").then(((RequiredArgumentBuilder)dc.a((String)"targets", (ArgumentType)dk.c()).then(dc.a("points").executes((var0x) -> {
         return a((db)var0x.getSource(), dk.e(var0x, "targets"), wy.a.a);
      }))).then(dc.a("levels").executes((var0x) -> {
         return a((db)var0x.getSource(), dk.e(var0x, "targets"), wy.a.b);
      })))));
      var0.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)dc.a("xp").requires((var0x) -> {
         return var0x.c(2);
      })).redirect(var1));
   }

   private static int a(db var0, aah var1, wy.a var2) {
      int var3 = var2.f.applyAsInt(var1);
      var0.a(new of("commands.experience.query." + var2.e, new Object[]{var1.d(), var3}), false);
      return var3;
   }

   private static int a(db var0, Collection<? extends aah> var1, int var2, wy.a var3) {
      Iterator var4 = var1.iterator();

      while(var4.hasNext()) {
         aah var5 = (aah)var4.next();
         var3.c.accept(var5, var2);
      }

      if (var1.size() == 1) {
         var0.a(new of("commands.experience.add." + var3.e + ".success.single", new Object[]{var2, ((aah)var1.iterator().next()).d()}), true);
      } else {
         var0.a(new of("commands.experience.add." + var3.e + ".success.multiple", new Object[]{var2, var1.size()}), true);
      }

      return var1.size();
   }

   private static int b(db var0, Collection<? extends aah> var1, int var2, wy.a var3) throws CommandSyntaxException {
      int var4 = 0;
      Iterator var5 = var1.iterator();

      while(var5.hasNext()) {
         aah var6 = (aah)var5.next();
         if (var3.d.test(var6, var2)) {
            ++var4;
         }
      }

      if (var4 == 0) {
         throw a.create();
      } else {
         if (var1.size() == 1) {
            var0.a(new of("commands.experience.set." + var3.e + ".success.single", new Object[]{var2, ((aah)var1.iterator().next()).d()}), true);
         } else {
            var0.a(new of("commands.experience.set." + var3.e + ".success.multiple", new Object[]{var2, var1.size()}), true);
         }

         return var1.size();
      }
   }

   static enum a {
      a("points", bfw::d, (var0, var1) -> {
         if (var1 >= var0.eH()) {
            return false;
         } else {
            var0.a(var1);
            return true;
         }
      }, (var0) -> {
         return afm.d(var0.bF * (float)var0.eH());
      }),
      b("levels", aah::c, (var0, var1) -> {
         var0.b(var1);
         return true;
      }, (var0) -> {
         return var0.bD;
      });

      public final BiConsumer<aah, Integer> c;
      public final BiPredicate<aah, Integer> d;
      public final String e;
      private final ToIntFunction<aah> f;

      private a(String var3, BiConsumer<aah, Integer> var4, BiPredicate<aah, Integer> var5, ToIntFunction<aah> var6) {
         this.c = var4;
         this.e = var3;
         this.d = var5;
         this.f = var6;
      }
   }
}
