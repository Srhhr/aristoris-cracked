import java.util.function.Consumer;

public enum dzx {
   a(new dzx.b[]{new dzx.b(dzx.a.f, dzx.a.e, dzx.a.a), new dzx.b(dzx.a.f, dzx.a.e, dzx.a.d), new dzx.b(dzx.a.c, dzx.a.e, dzx.a.d), new dzx.b(dzx.a.c, dzx.a.e, dzx.a.a)}),
   b(new dzx.b[]{new dzx.b(dzx.a.f, dzx.a.b, dzx.a.d), new dzx.b(dzx.a.f, dzx.a.b, dzx.a.a), new dzx.b(dzx.a.c, dzx.a.b, dzx.a.a), new dzx.b(dzx.a.c, dzx.a.b, dzx.a.d)}),
   c(new dzx.b[]{new dzx.b(dzx.a.c, dzx.a.b, dzx.a.d), new dzx.b(dzx.a.c, dzx.a.e, dzx.a.d), new dzx.b(dzx.a.f, dzx.a.e, dzx.a.d), new dzx.b(dzx.a.f, dzx.a.b, dzx.a.d)}),
   d(new dzx.b[]{new dzx.b(dzx.a.f, dzx.a.b, dzx.a.a), new dzx.b(dzx.a.f, dzx.a.e, dzx.a.a), new dzx.b(dzx.a.c, dzx.a.e, dzx.a.a), new dzx.b(dzx.a.c, dzx.a.b, dzx.a.a)}),
   e(new dzx.b[]{new dzx.b(dzx.a.f, dzx.a.b, dzx.a.d), new dzx.b(dzx.a.f, dzx.a.e, dzx.a.d), new dzx.b(dzx.a.f, dzx.a.e, dzx.a.a), new dzx.b(dzx.a.f, dzx.a.b, dzx.a.a)}),
   f(new dzx.b[]{new dzx.b(dzx.a.c, dzx.a.b, dzx.a.a), new dzx.b(dzx.a.c, dzx.a.e, dzx.a.a), new dzx.b(dzx.a.c, dzx.a.e, dzx.a.d), new dzx.b(dzx.a.c, dzx.a.b, dzx.a.d)});

   private static final dzx[] g = (dzx[])x.a((Object)(new dzx[6]), (Consumer)((var0) -> {
      var0[dzx.a.e] = a;
      var0[dzx.a.b] = b;
      var0[dzx.a.d] = c;
      var0[dzx.a.a] = d;
      var0[dzx.a.f] = e;
      var0[dzx.a.c] = f;
   }));
   private final dzx.b[] h;

   public static dzx a(gc var0) {
      return g[var0.c()];
   }

   private dzx(dzx.b... var3) {
      this.h = var3;
   }

   public dzx.b a(int var1) {
      return this.h[var1];
   }

   public static class b {
      public final int a;
      public final int b;
      public final int c;

      private b(int var1, int var2, int var3) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
      }

      // $FF: synthetic method
      b(int var1, int var2, int var3, Object var4) {
         this(var1, var2, var3);
      }
   }

   public static final class a {
      public static final int a;
      public static final int b;
      public static final int c;
      public static final int d;
      public static final int e;
      public static final int f;

      static {
         a = gc.d.c();
         b = gc.b.c();
         c = gc.f.c();
         d = gc.c.c();
         e = gc.a.c();
         f = gc.e.c();
      }
   }
}
