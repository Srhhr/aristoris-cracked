public class apq extends aps {
   public apq(apt var1, int var2) {
      super(var1, var2);
   }

   public void a(aqm var1, ari var2, int var3) {
      super.a(var1, var2, var3);
      if (var1.dk() > var1.dx()) {
         var1.c(var1.dx());
      }

   }
}
