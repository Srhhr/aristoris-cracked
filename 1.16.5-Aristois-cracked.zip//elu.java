import java.util.Locale;

public class elu extends vk {
   private final String d;

   protected elu(String[] var1) {
      super(var1);
      this.d = var1[2].toLowerCase(Locale.ROOT);
   }

   public elu(String var1) {
      this(c(var1));
   }

   public elu(vk var1, String var2) {
      this(var1.toString(), var2);
   }

   public elu(String var1, String var2) {
      this(c(var1 + '#' + var2));
   }

   protected static String[] c(String var0) {
      String[] var1 = new String[]{null, var0, ""};
      int var2 = var0.indexOf(35);
      String var3 = var0;
      if (var2 >= 0) {
         var1[2] = var0.substring(var2 + 1, var0.length());
         if (var2 > 1) {
            var3 = var0.substring(0, var2);
         }
      }

      System.arraycopy(vk.b(var3, ':'), 0, var1, 0, 2);
      return var1;
   }

   public String d() {
      return this.d;
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 instanceof elu && super.equals(var1)) {
         elu var2 = (elu)var1;
         return this.d.equals(var2.d);
      } else {
         return false;
      }
   }

   public int hashCode() {
      return 31 * super.hashCode() + this.d.hashCode();
   }

   public String toString() {
      return super.toString() + '#' + this.d;
   }
}
