import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import net.minecraft.server.MinecraftServer;

public class wt {
   private static final DynamicCommandExceptionType a = new DynamicCommandExceptionType((var0) -> {
      return new of("commands.difficulty.failure", new Object[]{var0});
   });

   public static void a(CommandDispatcher<db> var0) {
      LiteralArgumentBuilder<db> var1 = dc.a("difficulty");
      aor[] var2 = aor.values();
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         aor var5 = var2[var4];
         var1.then(dc.a(var5.c()).executes((var1x) -> {
            return a((db)var1x.getSource(), var5);
         }));
      }

      var0.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)var1.requires((var0x) -> {
         return var0x.c(2);
      })).executes((var0x) -> {
         aor var1 = ((db)var0x.getSource()).e().ad();
         ((db)var0x.getSource()).a(new of("commands.difficulty.query", new Object[]{var1.b()}), false);
         return var1.a();
      }));
   }

   public static int a(db var0, aor var1) throws CommandSyntaxException {
      MinecraftServer var2 = var0.j();
      if (var2.aX().s() == var1) {
         throw a.create(var1.c());
      } else {
         var2.a(var1, true);
         var0.a(new of("commands.difficulty.success", new Object[]{var1.b()}), true);
         return 0;
      }
   }
}
