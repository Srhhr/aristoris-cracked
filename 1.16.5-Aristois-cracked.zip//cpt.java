import com.mojang.serialization.Codec;
import java.util.Random;
import java.util.stream.Stream;

public class cpt extends cqc<cpu> {
   public cpt(Codec<cpu> var1) {
      super(var1);
   }

   public Stream<fx> a(cpv var1, Random var2, cpu var3, fx var4) {
      return var3.a().a(var1, var2, var4).flatMap((var3x) -> {
         return var3.b().a(var1, var2, var3x);
      });
   }
}
