public class blv extends blx {
   public blv(blx.a var1) {
      super(var1);
   }

   public bmb a(bmb var1, brx var2, aqm var3) {
      super.a(var1, var2, var3);
      if (var3 instanceof aah) {
         aah var4 = (aah)var3;
         ac.z.a(var4, var1);
         var4.b((adx)aea.c.b(this));
      }

      if (!var2.v) {
         var3.d(apw.s);
      }

      if (var1.a()) {
         return new bmb(bmd.nw);
      } else {
         if (var3 instanceof bfw && !((bfw)var3).bC.d) {
            bmb var6 = new bmb(bmd.nw);
            bfw var5 = (bfw)var3;
            if (!var5.bm.e(var6)) {
               var5.a(var6, false);
            }
         }

         return var1;
      }
   }

   public int e_(bmb var1) {
      return 40;
   }

   public bnn d_(bmb var1) {
      return bnn.c;
   }

   public adp ae_() {
      return adq.fP;
   }

   public adp ad_() {
      return adq.fP;
   }

   public aov<bmb> a(brx var1, bfw var2, aot var3) {
      return bmc.a(var1, var2, var3);
   }
}
