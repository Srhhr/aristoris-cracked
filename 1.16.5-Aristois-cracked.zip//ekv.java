import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ekv extends ly {
   private static final Logger a = LogManager.getLogger();
   private final Map<String, String> b;
   private final boolean c;

   private ekv(Map<String, String> var1, boolean var2) {
      this.b = var1;
      this.c = var2;
   }

   public static ekv a(ach var0, List<eky> var1) {
      Map<String, String> var2 = Maps.newHashMap();
      boolean var3 = false;
      Iterator var4 = var1.iterator();

      while(var4.hasNext()) {
         eky var5 = (eky)var4.next();
         var3 |= var5.a();
         String var6 = String.format("lang/%s.json", var5.getCode());
         Iterator var7 = var0.a().iterator();

         while(var7.hasNext()) {
            String var8 = (String)var7.next();

            try {
               vk var9 = new vk(var8, var6);
               a((List)var0.c(var9), (Map)var2);
            } catch (FileNotFoundException var10) {
            } catch (Exception var11) {
               a.warn("Skipped language file: {}:{} ({})", var8, var6, var11.toString());
            }
         }
      }

      return new ekv(ImmutableMap.copyOf(var2), var3);
   }

   private static void a(List<acg> var0, Map<String, String> var1) {
      Iterator var2 = var0.iterator();

      while(var2.hasNext()) {
         acg var3 = (acg)var2.next();

         try {
            InputStream var4 = var3.b();
            Throwable var5 = null;

            try {
               ly.a(var4, var1::put);
            } catch (Throwable var15) {
               var5 = var15;
               throw var15;
            } finally {
               if (var4 != null) {
                  if (var5 != null) {
                     try {
                        var4.close();
                     } catch (Throwable var14) {
                        var5.addSuppressed(var14);
                     }
                  } else {
                     var4.close();
                  }
               }

            }
         } catch (IOException var17) {
            a.warn("Failed to load translations from {}", var3, var17);
         }
      }

   }

   public String a(String var1) {
      return (String)this.b.getOrDefault(var1, var1);
   }

   public boolean b(String var1) {
      return this.b.containsKey(var1);
   }

   public boolean b() {
      return this.c;
   }

   public afa a(nu var1) {
      return ekw.a(var1, this.c);
   }
}
