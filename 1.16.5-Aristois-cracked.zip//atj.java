public class atj<E extends aqm> extends arv<E> {
   private boolean b;
   private boolean c;
   private final afh d;
   private final arv<? super E> e;
   private int f;

   public atj(arv<? super E> var1, afh var2) {
      this(var1, false, var2);
   }

   public atj(arv<? super E> var1, boolean var2, afh var3) {
      super(var1.a);
      this.e = var1;
      this.b = !var2;
      this.d = var3;
   }

   protected boolean a(aag var1, E var2) {
      if (!this.e.a(var1, var2)) {
         return false;
      } else {
         if (this.b) {
            this.a(var1);
            this.b = false;
         }

         if (this.f > 0) {
            --this.f;
         }

         return !this.c && this.f == 0;
      }
   }

   protected void a(aag var1, E var2, long var3) {
      this.e.a(var1, var2, var3);
   }

   protected boolean b(aag var1, E var2, long var3) {
      return this.e.b(var1, var2, var3);
   }

   protected void d(aag var1, E var2, long var3) {
      this.e.d(var1, var2, var3);
      this.c = this.e.a() == arv.a.b;
   }

   protected void c(aag var1, E var2, long var3) {
      this.a(var1);
      this.e.c(var1, var2, var3);
   }

   private void a(aag var1) {
      this.f = this.d.a(var1.t);
   }

   protected boolean a(long var1) {
      return false;
   }

   public String toString() {
      return "RunSometimes: " + this.e;
   }
}
