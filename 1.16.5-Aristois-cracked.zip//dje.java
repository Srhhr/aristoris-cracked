public class dje extends dja {
   private final long c;
   private final dhe d;
   private final dhs e;

   public dje(long var1, dhe var3, dhs var4) {
      this.c = var1;
      this.d = var3;
      this.e = var4;
   }

   public void run() {
      dgb var1 = dgb.a();
      this.b(new of("mco.minigame.world.starting.screen.title"));

      for(int var2 = 0; var2 < 25; ++var2) {
         try {
            if (this.c()) {
               return;
            }

            if (var1.d(this.c, this.d.a)) {
               a(this.e);
               break;
            }
         } catch (dhj var4) {
            if (this.c()) {
               return;
            }

            a(var4.e);
         } catch (Exception var5) {
            if (this.c()) {
               return;
            }

            a.error("Couldn't start mini game!");
            this.a(var5.toString());
         }
      }

   }
}
