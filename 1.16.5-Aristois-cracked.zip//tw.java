public interface tw extends ni {
   void a(tv var1);
}
