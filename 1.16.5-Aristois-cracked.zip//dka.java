import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import org.lwjgl.glfw.GLFWDropCallback;

public class dka {
   private final djz a;
   private boolean b;
   private boolean c;
   private boolean d;
   private double e;
   private double f;
   private int g;
   private int h = -1;
   private boolean i = true;
   private int j;
   private double k;
   private final afp l = new afp();
   private final afp m = new afp();
   private double n;
   private double o;
   private double p;
   private double q = Double.MIN_VALUE;
   private boolean r;

   public dka(djz var1) {
      this.a = var1;
   }

   private void a(long var1, int var3, int var4, int var5) {
      if (var1 == this.a.aD().i()) {
         boolean var6 = var4 == 1;
         if (djz.a && var3 == 0) {
            if (var6) {
               if ((var5 & 2) == 2) {
                  var3 = 1;
                  ++this.g;
               }
            } else if (this.g > 0) {
               var3 = 1;
               --this.g;
            }
         }

         if (var6) {
            if (this.a.k.Y && this.j++ > 0) {
               return;
            }

            this.h = var3;
            this.k = ddt.b();
         } else if (this.h != -1) {
            if (this.a.k.Y && --this.j > 0) {
               return;
            }

            this.h = -1;
         }

         boolean[] var8 = new boolean[]{false};
         if (this.a.z == null) {
            if (this.a.y == null) {
               if (!this.r && var6) {
                  this.i();
               }
            } else {
               double var9 = this.e * (double)this.a.aD().o() / (double)this.a.aD().m();
               double var11 = this.f * (double)this.a.aD().p() / (double)this.a.aD().n();
               if (var6) {
                  dot.a(() -> {
                     var8[0] = this.a.y.a(var9, var11, var3);
                  }, "mouseClicked event handler", this.a.y.getClass().getCanonicalName());
               } else {
                  dot.a(() -> {
                     var8[0] = this.a.y.c(var9, var11, var3);
                  }, "mouseReleased event handler", this.a.y.getClass().getCanonicalName());
               }
            }
         }

         if (!var8[0] && (this.a.y == null || this.a.y.n) && this.a.z == null) {
            if (var3 == 0) {
               this.b = var6;
            } else if (var3 == 2) {
               this.c = var6;
            } else if (var3 == 1) {
               this.d = var6;
            }

            djw.a(deo.b.c.a(var3), var6);
            if (var6) {
               if (this.a.s.a_() && var3 == 2) {
                  this.a.j.f().b();
               } else {
                  djw.a(deo.b.c.a(var3));
               }
            }
         }

      }
   }

   private void a(long var1, double var3, double var5) {
      if (var1 == djz.C().aD().i()) {
         double var7 = (this.a.k.S ? Math.signum(var5) : var5) * this.a.k.G;
         if (this.a.z == null) {
            if (this.a.y != null) {
               double var9 = this.e * (double)this.a.aD().o() / (double)this.a.aD().m();
               double var11 = this.f * (double)this.a.aD().p() / (double)this.a.aD().n();
               this.a.y.a(var9, var11, var7);
            } else if (this.a.s != null) {
               if (this.p != 0.0D && Math.signum(var7) != Math.signum(this.p)) {
                  this.p = 0.0D;
               }

               this.p += var7;
               float var13 = (float)((int)this.p);
               if (var13 == 0.0F) {
                  return;
               }

               this.p -= (double)var13;
               if (this.a.s.a_()) {
                  if (this.a.j.f().a()) {
                     this.a.j.f().a((double)(-var13));
                  } else {
                     float var10 = afm.a(this.a.s.bC.a() + var13 * 0.005F, 0.0F, 0.2F);
                     this.a.s.bC.a(var10);
                  }
               } else {
                  this.a.s.bm.a((double)var13);
               }
            }
         }
      }

   }

   private void a(long var1, List<Path> var3) {
      if (this.a.y != null) {
         this.a.y.a(var3);
      }

   }

   public void a(long var1) {
      deo.a(var1, (var1x, var3, var5) -> {
         this.a.execute(() -> {
            this.b(var1x, var3, var5);
         });
      }, (var1x, var3, var4, var5) -> {
         this.a.execute(() -> {
            this.a(var1x, var3, var4, var5);
         });
      }, (var1x, var3, var5) -> {
         this.a.execute(() -> {
            this.a(var1x, var3, var5);
         });
      }, (var1x, var3, var4) -> {
         Path[] var6 = new Path[var3];

         for(int var7 = 0; var7 < var3; ++var7) {
            var6[var7] = Paths.get(GLFWDropCallback.getName(var4, var7));
         }

         this.a.execute(() -> {
            this.a(var1x, Arrays.asList(var6));
         });
      });
   }

   private void b(long var1, double var3, double var5) {
      if (var1 == djz.C().aD().i()) {
         if (this.i) {
            this.e = var3;
            this.f = var5;
            this.i = false;
         }

         dmi var7 = this.a.y;
         if (var7 != null && this.a.z == null) {
            double var8 = var3 * (double)this.a.aD().o() / (double)this.a.aD().m();
            double var10 = var5 * (double)this.a.aD().p() / (double)this.a.aD().n();
            dot.a(() -> {
               var7.e(var8, var10);
            }, "mouseMoved event handler", var7.getClass().getCanonicalName());
            if (this.h != -1 && this.k > 0.0D) {
               double var12 = (var3 - this.e) * (double)this.a.aD().o() / (double)this.a.aD().m();
               double var14 = (var5 - this.f) * (double)this.a.aD().p() / (double)this.a.aD().n();
               dot.a(() -> {
                  var7.a(var8, var10, this.h, var12, var14);
               }, "mouseDragged event handler", var7.getClass().getCanonicalName());
            }
         }

         this.a.au().a("mouse");
         if (this.h() && this.a.ap()) {
            this.n += var3 - this.e;
            this.o += var5 - this.f;
         }

         this.a();
         this.e = var3;
         this.f = var5;
         this.a.au().c();
      }
   }

   public void a() {
      double var1 = ddt.b();
      double var3 = var1 - this.q;
      this.q = var1;
      if (this.h() && this.a.ap()) {
         double var9 = this.a.k.a * 0.6000000238418579D + 0.20000000298023224D;
         double var11 = var9 * var9 * var9 * 8.0D;
         double var5;
         double var7;
         if (this.a.k.aN) {
            double var13 = this.l.a(this.n * var11, var3 * var11);
            double var15 = this.m.a(this.o * var11, var3 * var11);
            var5 = var13;
            var7 = var15;
         } else {
            this.l.a();
            this.m.a();
            var5 = this.n * var11;
            var7 = this.o * var11;
         }

         this.n = 0.0D;
         this.o = 0.0D;
         int var17 = 1;
         if (this.a.k.R) {
            var17 = -1;
         }

         this.a.ao().a(var5, var7);
         if (this.a.s != null) {
            this.a.s.a(var5, var7 * (double)var17);
         }

      } else {
         this.n = 0.0D;
         this.o = 0.0D;
      }
   }

   public boolean b() {
      return this.b;
   }

   public boolean d() {
      return this.d;
   }

   public double e() {
      return this.e;
   }

   public double f() {
      return this.f;
   }

   public void g() {
      this.i = true;
   }

   public boolean h() {
      return this.r;
   }

   public void i() {
      if (this.a.ap()) {
         if (!this.r) {
            if (!djz.a) {
               djw.a();
            }

            this.r = true;
            this.e = (double)(this.a.aD().m() / 2);
            this.f = (double)(this.a.aD().n() / 2);
            deo.a(this.a.aD().i(), 212995, this.e, this.f);
            this.a.a((dot)null);
            this.a.w = 10000;
            this.i = true;
         }
      }
   }

   public void j() {
      if (this.r) {
         this.r = false;
         this.e = (double)(this.a.aD().m() / 2);
         this.f = (double)(this.a.aD().n() / 2);
         deo.a(this.a.aD().i(), 212993, this.e, this.f);
      }
   }

   public void k() {
      this.i = true;
   }
}
