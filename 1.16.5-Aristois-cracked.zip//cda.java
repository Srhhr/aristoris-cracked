public class cda extends ccj implements aol {
   private bmb a;

   public cda() {
      super(cck.e);
      this.a = bmb.b;
   }

   public void a(ceh var1, md var2) {
      super.a(var1, var2);
      if (var2.c("RecordItem", 10)) {
         this.a(bmb.a(var2.p("RecordItem")));
      }

   }

   public md a(md var1) {
      super.a(var1);
      if (!this.d().a()) {
         var1.a((String)"RecordItem", (mt)this.d().b(new md()));
      }

      return var1;
   }

   public bmb d() {
      return this.a;
   }

   public void a(bmb var1) {
      this.a = var1;
      this.X_();
   }

   public void Y_() {
      this.a(bmb.b);
   }
}
