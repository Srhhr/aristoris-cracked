import com.mojang.blaze3d.systems.RenderSystem;

public class dqk extends dpp<biy> {
   private static final vk A = new vk("textures/gui/container/horse.png");
   private final bbb B;
   private float C;
   private float D;

   public dqk(biy var1, bfv var2, bbb var3) {
      super(var1, var2, var3.d());
      this.B = var3;
      this.n = false;
   }

   protected void a(dfm var1, float var2, int var3, int var4) {
      RenderSystem.color4f(1.0F, 1.0F, 1.0F, 1.0F);
      this.i.M().a(A);
      int var5 = (this.k - this.b) / 2;
      int var6 = (this.l - this.c) / 2;
      this.b(var1, var5, var6, 0, 0, this.b, this.c);
      if (this.B instanceof bba) {
         bba var7 = (bba)this.B;
         if (var7.eM()) {
            this.b(var1, var5 + 79, var6 + 17, 0, this.c, var7.eU() * 18, 54);
         }
      }

      if (this.B.L_()) {
         this.b(var1, var5 + 7, var6 + 35 - 18, 18, this.c + 54, 18, 18);
      }

      if (this.B.fs()) {
         if (this.B instanceof bbe) {
            this.b(var1, var5 + 7, var6 + 35, 36, this.c + 54, 18, 18);
         } else {
            this.b(var1, var5 + 7, var6 + 35, 0, this.c + 54, 18, 18);
         }
      }

      dql.a(var5 + 51, var6 + 60, 17, (float)(var5 + 51) - this.C, (float)(var6 + 75 - 50) - this.D, this.B);
   }

   public void a(dfm var1, int var2, int var3, float var4) {
      this.a(var1);
      this.C = (float)var2;
      this.D = (float)var3;
      super.a(var1, var2, var3, var4);
      this.a(var1, var2, var3);
   }
}
