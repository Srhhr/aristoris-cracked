import com.google.common.collect.ImmutableMap;

public class ast extends arv<bfj> {
   private final float b;

   public ast(float var1) {
      super(ImmutableMap.of(ayd.m, aye.c, ayd.n, aye.c), Integer.MAX_VALUE);
      this.b = var1;
   }

   protected boolean a(aag var1, bfj var2) {
      bfw var3 = var2.eM();
      return var2.aX() && var3 != null && !var2.aE() && !var2.w && var2.h(var3) <= 16.0D && var3.bp != null;
   }

   protected boolean a(aag var1, bfj var2, long var3) {
      return this.a(var1, var2);
   }

   protected void b(aag var1, bfj var2, long var3) {
      this.a(var2);
   }

   protected void c(aag var1, bfj var2, long var3) {
      arf<?> var5 = var2.cJ();
      var5.b(ayd.m);
      var5.b(ayd.n);
   }

   protected void d(aag var1, bfj var2, long var3) {
      this.a(var2);
   }

   protected boolean a(long var1) {
      return false;
   }

   private void a(bfj var1) {
      arf<?> var2 = var1.cJ();
      var2.a((ayd)ayd.m, (Object)(new ayf(new asd(var1.eM(), false), this.b, 2)));
      var2.a((ayd)ayd.n, (Object)(new asd(var1.eM(), true)));
   }

   // $FF: synthetic method
   protected boolean b(aag var1, aqm var2, long var3) {
      return this.a(var1, (bfj)var2, var3);
   }

   // $FF: synthetic method
   protected void a(aag var1, aqm var2, long var3) {
      this.b(var1, (bfj)var2, var3);
   }
}
