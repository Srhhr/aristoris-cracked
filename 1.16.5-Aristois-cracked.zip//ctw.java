import com.mojang.serialization.Codec;
import java.util.Random;

public class ctw extends ctt<ctu> {
   public ctw(Codec<ctu> var1) {
      super(var1);
   }

   public void a(Random var1, cfw var2, bsv var3, int var4, int var5, int var6, double var7, ceh var9, ceh var10, int var11, long var12, ctu var14) {
      double var15 = bsv.f.a((double)var4 * 0.25D, (double)var5 * 0.25D, false);
      if (var15 > 0.0D) {
         int var17 = var4 & 15;
         int var18 = var5 & 15;
         fx.a var19 = new fx.a();

         for(int var20 = var6; var20 >= 0; --var20) {
            var19.d(var17, var20, var18);
            if (!var2.d_(var19).g()) {
               if (var20 == 62 && !var2.d_(var19).a(var10.b())) {
                  var2.a(var19, var10, false);
               }
               break;
            }
         }
      }

      ctt.v.a(var1, var2, var3, var4, var5, var6, var7, var9, var10, var11, var12, var14);
   }
}
