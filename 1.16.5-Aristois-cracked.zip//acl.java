import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicInteger;

public class acl<S> implements ace {
   protected final ach a;
   protected final CompletableFuture<afx> b = new CompletableFuture();
   protected final CompletableFuture<List<S>> c;
   private final Set<acc> d;
   private final int e;
   private int f;
   private int g;
   private final AtomicInteger h = new AtomicInteger();
   private final AtomicInteger i = new AtomicInteger();

   public static acl<Void> a(ach var0, List<acc> var1, Executor var2, Executor var3, CompletableFuture<afx> var4) {
      return new acl(var2, var3, var0, var1, (var1x, var2x, var3x, var4x, var5) -> {
         return var3x.a(var1x, var2x, ant.a, ant.a, var2, var5);
      }, var4);
   }

   protected acl(Executor var1, final Executor var2, ach var3, List<acc> var4, acl.a<S> var5, CompletableFuture<afx> var6) {
      this.a = var3;
      this.e = var4.size();
      this.h.incrementAndGet();
      AtomicInteger var10001 = this.i;
      var6.thenRun(var10001::incrementAndGet);
      List<CompletableFuture<S>> var7 = Lists.newArrayList();
      final CompletableFuture<?> var8 = var6;
      this.d = Sets.newHashSet(var4);

      CompletableFuture var12;
      for(Iterator var9 = var4.iterator(); var9.hasNext(); var8 = var12) {
         final acc var10 = (acc)var9.next();
         var12 = var5.create(new acc.a() {
            public <T> CompletableFuture<T> a(T var1) {
               var2.execute(() -> {
                  acl.this.d.remove(var10);
                  if (acl.this.d.isEmpty()) {
                     acl.this.b.complete(afx.a);
                  }

               });
               return acl.this.b.thenCombine(var8, (var1x, var2x) -> {
                  return var1;
               });
            }
         }, var3, var10, (var2x) -> {
            this.h.incrementAndGet();
            var1.execute(() -> {
               var2x.run();
               this.i.incrementAndGet();
            });
         }, (var2x) -> {
            ++this.f;
            var2.execute(() -> {
               var2x.run();
               ++this.g;
            });
         });
         var7.add(var12);
      }

      this.c = x.b((List)var7);
   }

   public CompletableFuture<afx> a() {
      return this.c.thenApply((var0) -> {
         return afx.a;
      });
   }

   public float b() {
      int var1 = this.e - this.d.size();
      float var2 = (float)(this.i.get() * 2 + this.g * 2 + var1 * 1);
      float var3 = (float)(this.h.get() * 2 + this.f * 2 + this.e * 1);
      return var2 / var3;
   }

   public boolean c() {
      return this.b.isDone();
   }

   public boolean d() {
      return this.c.isDone();
   }

   public void e() {
      if (this.c.isCompletedExceptionally()) {
         this.c.join();
      }

   }

   public interface a<S> {
      CompletableFuture<S> create(acc.a var1, ach var2, acc var3, Executor var4, Executor var5);
   }
}
