import java.util.Iterator;
import java.util.List;

public class eee extends efw<bab, dtp<bab>> {
   public eee(eet var1) {
      super(var1, new dtp(0.0F), 0.4F);
      this.a((eit)(new ehw(this)));
   }

   public vk a(bab var1) {
      return var1.eU();
   }

   protected void a(bab var1, dfm var2, float var3) {
      super.a(var1, var2, var3);
      var2.a(0.8F, 0.8F, 0.8F);
   }

   protected void a(bab var1, dfm var2, float var3, float var4, float var5) {
      super.a(var1, var2, var3, var4, var5);
      float var6 = var1.y(var5);
      if (var6 > 0.0F) {
         var2.a((double)(0.4F * var6), (double)(0.15F * var6), (double)(0.1F * var6));
         var2.a(g.f.a(afm.h(var6, 0.0F, 90.0F)));
         fx var7 = var1.cB();
         List<bfw> var8 = var1.l.a((Class)bfw.class, (dci)(new dci(var7)).c(2.0D, 2.0D, 2.0D));
         Iterator var9 = var8.iterator();

         while(var9.hasNext()) {
            bfw var10 = (bfw)var9.next();
            if (var10.em()) {
               var2.a((double)(0.15F * var6), 0.0D, 0.0D);
               break;
            }
         }
      }

   }
}
