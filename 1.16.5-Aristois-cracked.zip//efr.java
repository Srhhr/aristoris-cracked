import com.google.common.collect.Lists;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Nullable;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public abstract class efr<T extends aqm, M extends duc<T>> extends eeu<T> implements egk<T, M> {
   private static final Logger a = LogManager.getLogger();
   protected M e;
   protected final List<eit<T, M>> f = Lists.newArrayList();

   public efr(eet var1, M var2, float var3) {
      super(var1);
      this.e = var2;
      this.c = var3;
   }

   protected final boolean a(eit<T, M> var1) {
      return this.f.add(var1);
   }

   public M c() {
      return this.e;
   }

   public void a(T var1, float var2, float var3, dfm var4, eag var5, int var6) {
      var4.a();
      this.e.c = this.d(var1, var3);
      this.e.d = var1.br();
      this.e.e = var1.w_();
      float var7 = afm.h(var3, var1.aB, var1.aA);
      float var8 = afm.h(var3, var1.aD, var1.aC);
      float var9 = var8 - var7;
      float var11;
      if (var1.br() && var1.ct() instanceof aqm) {
         aqm var10 = (aqm)var1.ct();
         var7 = afm.h(var3, var10.aB, var10.aA);
         var9 = var8 - var7;
         var11 = afm.g(var9);
         if (var11 < -85.0F) {
            var11 = -85.0F;
         }

         if (var11 >= 85.0F) {
            var11 = 85.0F;
         }

         var7 = var8 - var11;
         if (var11 * var11 > 2500.0F) {
            var7 += var11 * 0.2F;
         }

         var9 = var8 - var7;
      }

      float var21 = afm.g(var3, var1.s, var1.q);
      float var12;
      if (var1.ae() == aqx.c) {
         gc var22 = var1.eo();
         if (var22 != null) {
            var12 = var1.e((aqx)aqx.a) - 0.1F;
            var4.a((double)((float)(-var22.i()) * var12), 0.0D, (double)((float)(-var22.k()) * var12));
         }
      }

      var11 = this.a(var1, var3);
      this.a(var1, var4, var11, var7, var3);
      var4.a(-1.0F, -1.0F, 1.0F);
      this.a(var1, var4, var3);
      var4.a(0.0D, -1.5010000467300415D, 0.0D);
      var12 = 0.0F;
      float var13 = 0.0F;
      if (!var1.br() && var1.aX()) {
         var12 = afm.g(var3, var1.au, var1.av);
         var13 = var1.aw - var1.av * (1.0F - var3);
         if (var1.w_()) {
            var13 *= 3.0F;
         }

         if (var12 > 1.0F) {
            var12 = 1.0F;
         }
      }

      this.e.a(var1, var13, var12, var3);
      this.e.a(var1, var13, var12, var11, var9, var21);
      djz var14 = djz.C();
      boolean var15 = this.d(var1);
      boolean var16 = !var15 && !var1.c((bfw)var14.s);
      boolean var17 = var14.b((aqa)var1);
      eao var18 = this.a(var1, var15, var16, var17);
      if (var18 != null) {
         dfq var19 = var5.getBuffer(var18);
         int var20 = c(var1, this.b(var1, var3));
         this.e.a(var4, var19, var6, var20, 1.0F, 1.0F, 1.0F, var16 ? 0.15F : 1.0F);
      }

      if (!var1.a_()) {
         Iterator var23 = this.f.iterator();

         while(var23.hasNext()) {
            eit<T, M> var24 = (eit)var23.next();
            var24.a(var4, var5, var6, var1, var13, var12, var3, var11, var9, var21);
         }
      }

      var4.b();
      super.a(var1, var2, var3, var4, var5, var6);
   }

   @Nullable
   protected eao a(T var1, boolean var2, boolean var3, boolean var4) {
      vk var5 = this.a((aqa)var1);
      if (var3) {
         return eao.f(var5);
      } else if (var2) {
         return this.e.a(var5);
      } else {
         return var4 ? eao.n(var5) : null;
      }
   }

   public static int c(aqm var0, float var1) {
      return ejw.a(ejw.a(var1), ejw.a(var0.an > 0 || var0.aq > 0));
   }

   protected boolean d(T var1) {
      return !var1.bF();
   }

   private static float a(gc var0) {
      switch(var0) {
      case d:
         return 90.0F;
      case e:
         return 0.0F;
      case c:
         return 270.0F;
      case f:
         return 180.0F;
      default:
         return 0.0F;
      }
   }

   protected boolean a(T var1) {
      return false;
   }

   protected void a(T var1, dfm var2, float var3, float var4, float var5) {
      if (this.a(var1)) {
         var4 += (float)(Math.cos((double)var1.K * 3.25D) * 3.141592653589793D * 0.4000000059604645D);
      }

      aqx var6 = var1.ae();
      if (var6 != aqx.c) {
         var2.a(g.d.a(180.0F - var4));
      }

      if (var1.aq > 0) {
         float var7 = ((float)var1.aq + var5 - 1.0F) / 20.0F * 1.6F;
         var7 = afm.c(var7);
         if (var7 > 1.0F) {
            var7 = 1.0F;
         }

         var2.a(g.f.a(var7 * this.c(var1)));
      } else if (var1.dR()) {
         var2.a(g.b.a(-90.0F - var1.q));
         var2.a(g.d.a(((float)var1.K + var5) * -75.0F));
      } else if (var6 == aqx.c) {
         gc var9 = var1.eo();
         float var8 = var9 != null ? a(var9) : var4;
         var2.a(g.d.a(var8));
         var2.a(g.f.a(this.c(var1)));
         var2.a(g.d.a(270.0F));
      } else if (var1.S() || var1 instanceof bfw) {
         String var10 = k.a(var1.R().getString());
         if (("Dinnerbone".equals(var10) || "Grumm".equals(var10)) && (!(var1 instanceof bfw) || ((bfw)var1).a(bfx.a))) {
            var2.a(0.0D, (double)(var1.cz() + 0.1F), 0.0D);
            var2.a(g.f.a(180.0F));
         }
      }

   }

   protected float d(T var1, float var2) {
      return var1.r(var2);
   }

   protected float a(T var1, float var2) {
      return (float)var1.K + var2;
   }

   protected float c(T var1) {
      return 90.0F;
   }

   protected float b(T var1, float var2) {
      return 0.0F;
   }

   protected void a(T var1, dfm var2, float var3) {
   }

   protected boolean b(T var1) {
      double var2 = this.b.b(var1);
      float var4 = var1.bx() ? 32.0F : 64.0F;
      if (var2 >= (double)(var4 * var4)) {
         return false;
      } else {
         djz var5 = djz.C();
         dzm var6 = var5.s;
         boolean var7 = !var1.c((bfw)var6);
         if (var1 != var6) {
            ddp var8 = var1.bG();
            ddp var9 = var6.bG();
            if (var8 != null) {
               ddp.b var10 = var8.j();
               switch(var10) {
               case a:
                  return var7;
               case b:
                  return false;
               case c:
                  return var9 == null ? var7 : var8.a(var9) && (var8.i() || var7);
               case d:
                  return var9 == null ? var7 : !var8.a(var9) && var7;
               default:
                  return true;
               }
            }
         }

         return djz.x() && var1 != var5.aa() && var7 && !var1.bs();
      }
   }
}
