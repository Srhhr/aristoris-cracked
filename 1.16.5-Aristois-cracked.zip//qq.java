import java.io.IOException;

public class qq implements oj<om> {
   private int a;
   private byte b;

   public qq() {
   }

   public qq(aqa var1, byte var2) {
      this.a = var1.Y();
      this.b = var2;
   }

   public void a(nf var1) throws IOException {
      this.a = var1.i();
      this.b = var1.readByte();
   }

   public void b(nf var1) throws IOException {
      var1.d(this.a);
      var1.writeByte(this.b);
   }

   public void a(om var1) {
      var1.a(this);
   }

   public aqa a(brx var1) {
      return var1.a(this.a);
   }

   public byte b() {
      return this.b;
   }
}
