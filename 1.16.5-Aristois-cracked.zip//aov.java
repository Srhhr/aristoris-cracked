public class aov<T> {
   private final aou a;
   private final T b;

   public aov(aou var1, T var2) {
      this.a = var1;
      this.b = var2;
   }

   public aou a() {
      return this.a;
   }

   public T b() {
      return this.b;
   }

   public static <T> aov<T> a(T var0) {
      return new aov(aou.a, var0);
   }

   public static <T> aov<T> b(T var0) {
      return new aov(aou.b, var0);
   }

   public static <T> aov<T> c(T var0) {
      return new aov(aou.c, var0);
   }

   public static <T> aov<T> d(T var0) {
      return new aov(aou.d, var0);
   }

   public static <T> aov<T> a(T var0, boolean var1) {
      return var1 ? a(var0) : b(var0);
   }
}
