import java.util.Random;
import javax.annotation.Nullable;

public class bxy extends bud {
   public static final cfb a;
   public static final cey b;
   public static final cey c;
   public static final ddh d;
   public static final ddh e;
   public static final ddh f;
   public static final ddh g;
   public static final ddh h;
   public static final ddh i;
   public static final ddh j;
   public static final ddh k;
   public static final ddh o;

   protected bxy(ceg.c var1) {
      super(var1);
      this.j((ceh)((ceh)((ceh)((ceh)this.n.b()).a(a, gc.c)).a(b, false)).a(c, false));
   }

   public bzh b(ceh var1) {
      return bzh.c;
   }

   public ddh d(ceh var1, brc var2, fx var3) {
      return f;
   }

   public boolean c_(ceh var1) {
      return true;
   }

   public ceh a(bny var1) {
      brx var2 = var1.p();
      bmb var3 = var1.m();
      md var4 = var3.o();
      bfw var5 = var1.n();
      boolean var6 = false;
      if (!var2.v && var5 != null && var4 != null && var5.eV() && var4.e("BlockEntityTag")) {
         md var7 = var4.p("BlockEntityTag");
         if (var7.e("Book")) {
            var6 = true;
         }
      }

      return (ceh)((ceh)this.n().a(a, var1.f().f())).a(c, var6);
   }

   public ddh c(ceh var1, brc var2, fx var3, dcs var4) {
      return h;
   }

   public ddh b(ceh var1, brc var2, fx var3, dcs var4) {
      switch((gc)var1.c(a)) {
      case c:
         return j;
      case d:
         return o;
      case f:
         return k;
      case e:
         return i;
      default:
         return f;
      }
   }

   public ceh a(ceh var1, bzm var2) {
      return (ceh)var1.a(a, var2.a((gc)var1.c(a)));
   }

   public ceh a(ceh var1, byg var2) {
      return var1.a(var2.a((gc)var1.c(a)));
   }

   protected void a(cei.a<buo, ceh> var1) {
      var1.a(a, b, c);
   }

   @Nullable
   public ccj a(brc var1) {
      return new cdb();
   }

   public static boolean a(brx var0, fx var1, ceh var2, bmb var3) {
      if (!(Boolean)var2.c(c)) {
         if (!var0.v) {
            b(var0, var1, var2, var3);
         }

         return true;
      } else {
         return false;
      }
   }

   private static void b(brx var0, fx var1, ceh var2, bmb var3) {
      ccj var4 = var0.c(var1);
      if (var4 instanceof cdb) {
         cdb var5 = (cdb)var4;
         var5.a(var3.a(1));
         a(var0, var1, var2, true);
         var0.a((bfw)null, (fx)var1, adq.aY, adr.e, 1.0F, 1.0F);
      }

   }

   public static void a(brx var0, fx var1, ceh var2, boolean var3) {
      var0.a(var1, (ceh)((ceh)var2.a(b, false)).a(c, var3), 3);
      b(var0, var1, var2);
   }

   public static void a(brx var0, fx var1, ceh var2) {
      b(var0, var1, var2, true);
      var0.J().a(var1, var2.b(), 2);
      var0.c(1043, var1, 0);
   }

   private static void b(brx var0, fx var1, ceh var2, boolean var3) {
      var0.a(var1, (ceh)var2.a(b, var3), 3);
      b(var0, var1, var2);
   }

   private static void b(brx var0, fx var1, ceh var2) {
      var0.b(var1.c(), var2.b());
   }

   public void a(ceh var1, aag var2, fx var3, Random var4) {
      b(var2, var3, var1, false);
   }

   public void a(ceh var1, brx var2, fx var3, ceh var4, boolean var5) {
      if (!var1.a(var4.b())) {
         if ((Boolean)var1.c(c)) {
            this.d(var1, var2, var3);
         }

         if ((Boolean)var1.c(b)) {
            var2.b(var3.c(), (buo)this);
         }

         super.a(var1, var2, var3, var4, var5);
      }
   }

   private void d(ceh var1, brx var2, fx var3) {
      ccj var4 = var2.c(var3);
      if (var4 instanceof cdb) {
         cdb var5 = (cdb)var4;
         gc var6 = (gc)var1.c(a);
         bmb var7 = var5.f().i();
         float var8 = 0.25F * (float)var6.i();
         float var9 = 0.25F * (float)var6.k();
         bcv var10 = new bcv(var2, (double)var3.u() + 0.5D + (double)var8, (double)(var3.v() + 1), (double)var3.w() + 0.5D + (double)var9, var7);
         var10.m();
         var2.c((aqa)var10);
         var5.Y_();
      }

   }

   public boolean b_(ceh var1) {
      return true;
   }

   public int a(ceh var1, brc var2, fx var3, gc var4) {
      return (Boolean)var1.c(b) ? 15 : 0;
   }

   public int b(ceh var1, brc var2, fx var3, gc var4) {
      return var4 == gc.b && (Boolean)var1.c(b) ? 15 : 0;
   }

   public boolean a(ceh var1) {
      return true;
   }

   public int a(ceh var1, brx var2, fx var3) {
      if ((Boolean)var1.c(c)) {
         ccj var4 = var2.c(var3);
         if (var4 instanceof cdb) {
            return ((cdb)var4).j();
         }
      }

      return 0;
   }

   public aou a(ceh var1, brx var2, fx var3, bfw var4, aot var5, dcj var6) {
      if ((Boolean)var1.c(c)) {
         if (!var2.v) {
            this.a(var2, var3, var4);
         }

         return aou.a(var2.v);
      } else {
         bmb var7 = var4.b((aot)var5);
         return !var7.a() && !var7.b().a((ael)aeg.Z) ? aou.b : aou.c;
      }
   }

   @Nullable
   public aox b(ceh var1, brx var2, fx var3) {
      return !(Boolean)var1.c(c) ? null : super.b(var1, var2, var3);
   }

   private void a(brx var1, fx var2, bfw var3) {
      ccj var4 = var1.c(var2);
      if (var4 instanceof cdb) {
         var3.a((aox)((cdb)var4));
         var3.a(aea.at);
      }

   }

   public boolean a(ceh var1, brc var2, fx var3, cxe var4) {
      return false;
   }

   static {
      a = bxm.aq;
      b = cex.w;
      c = cex.o;
      d = buo.a(0.0D, 0.0D, 0.0D, 16.0D, 2.0D, 16.0D);
      e = buo.a(4.0D, 2.0D, 4.0D, 12.0D, 14.0D, 12.0D);
      f = dde.a(d, e);
      g = buo.a(0.0D, 15.0D, 0.0D, 16.0D, 15.0D, 16.0D);
      h = dde.a(f, g);
      i = dde.a(buo.a(1.0D, 10.0D, 0.0D, 5.333333D, 14.0D, 16.0D), buo.a(5.333333D, 12.0D, 0.0D, 9.666667D, 16.0D, 16.0D), buo.a(9.666667D, 14.0D, 0.0D, 14.0D, 18.0D, 16.0D), f);
      j = dde.a(buo.a(0.0D, 10.0D, 1.0D, 16.0D, 14.0D, 5.333333D), buo.a(0.0D, 12.0D, 5.333333D, 16.0D, 16.0D, 9.666667D), buo.a(0.0D, 14.0D, 9.666667D, 16.0D, 18.0D, 14.0D), f);
      k = dde.a(buo.a(15.0D, 10.0D, 0.0D, 10.666667D, 14.0D, 16.0D), buo.a(10.666667D, 12.0D, 0.0D, 6.333333D, 16.0D, 16.0D), buo.a(6.333333D, 14.0D, 0.0D, 2.0D, 18.0D, 16.0D), f);
      o = dde.a(buo.a(0.0D, 10.0D, 15.0D, 16.0D, 14.0D, 10.666667D), buo.a(0.0D, 12.0D, 10.666667D, 16.0D, 16.0D, 6.333333D), buo.a(0.0D, 14.0D, 6.333333D, 16.0D, 18.0D, 2.0D), f);
   }
}
