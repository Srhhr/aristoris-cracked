import java.util.Random;
import java.util.function.Predicate;

public class bkb extends blx {
   public bkb(blx.a var1) {
      super(var1);
   }

   public aou a(boa var1) {
      gc var2 = var1.j();
      if (var2 == gc.a) {
         return aou.d;
      } else {
         brx var3 = var1.p();
         bny var4 = new bny(var1);
         fx var5 = var4.a();
         bmb var6 = var1.m();
         dcn var7 = dcn.c((gr)var5);
         dci var8 = aqe.b.l().a(var7.a(), var7.b(), var7.c());
         if (var3.b((aqa)null, (dci)var8, (Predicate)((var0) -> {
            return true;
         })) && var3.a((aqa)null, (dci)var8).isEmpty()) {
            if (var3 instanceof aag) {
               aag var9 = (aag)var3;
               bcn var10 = (bcn)aqe.b.b(var9, var6.o(), (nr)null, var1.n(), var5, aqp.m, true, true);
               if (var10 == null) {
                  return aou.d;
               }

               var9.l(var10);
               float var11 = (float)afm.d((afm.g(var1.h() - 180.0F) + 22.5F) / 45.0F) * 45.0F;
               var10.b(var10.cD(), var10.cE(), var10.cH(), var11, 0.0F);
               this.a(var10, var3.t);
               var3.c((aqa)var10);
               var3.a((bfw)null, var10.cD(), var10.cE(), var10.cH(), adq.V, adr.e, 0.75F, 0.8F);
            }

            var6.g(1);
            return aou.a(var3.v);
         } else {
            return aou.d;
         }
      }
   }

   private void a(bcn var1, Random var2) {
      go var3 = var1.r();
      float var5 = var2.nextFloat() * 5.0F;
      float var6 = var2.nextFloat() * 20.0F - 10.0F;
      go var4 = new go(var3.b() + var5, var3.c() + var6, var3.d());
      var1.a(var4);
      var3 = var1.t();
      var5 = var2.nextFloat() * 10.0F - 5.0F;
      var4 = new go(var3.b(), var3.c() + var5, var3.d());
      var1.b(var4);
   }
}
