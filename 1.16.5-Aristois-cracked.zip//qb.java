import java.io.IOException;

public class qb implements oj<om> {
   private double a;
   private double b;
   private double c;
   private float d;
   private float e;

   public qb() {
   }

   public qb(aqa var1) {
      this.a = var1.cD();
      this.b = var1.cE();
      this.c = var1.cH();
      this.d = var1.p;
      this.e = var1.q;
   }

   public void a(nf var1) throws IOException {
      this.a = var1.readDouble();
      this.b = var1.readDouble();
      this.c = var1.readDouble();
      this.d = var1.readFloat();
      this.e = var1.readFloat();
   }

   public void b(nf var1) throws IOException {
      var1.writeDouble(this.a);
      var1.writeDouble(this.b);
      var1.writeDouble(this.c);
      var1.writeFloat(this.d);
      var1.writeFloat(this.e);
   }

   public void a(om var1) {
      var1.a(this);
   }

   public double b() {
      return this.a;
   }

   public double c() {
      return this.b;
   }

   public double d() {
      return this.c;
   }

   public float e() {
      return this.d;
   }

   public float f() {
      return this.e;
   }
}
