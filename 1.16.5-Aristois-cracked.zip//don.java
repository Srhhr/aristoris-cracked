public abstract class don extends dkw implements dmf {
   public boolean a() {
      return true;
   }
}
