public class ehs<T extends aqm, M extends dvd<T>> extends ejc<T, M> {
   private final eet a;
   private bgc b;

   public ehs(efr<T, M> var1) {
      super(var1);
      this.a = var1.b();
   }

   protected int a(T var1) {
      return var1.dy();
   }

   protected void a(dfm var1, eag var2, int var3, aqa var4, float var5, float var6, float var7, float var8) {
      float var9 = afm.c(var5 * var5 + var7 * var7);
      this.b = new bgc(var4.l, var4.cD(), var4.cE(), var4.cH());
      this.b.p = (float)(Math.atan2((double)var5, (double)var7) * 57.2957763671875D);
      this.b.q = (float)(Math.atan2((double)var6, (double)var9) * 57.2957763671875D);
      this.b.r = this.b.p;
      this.b.s = this.b.q;
      this.a.a(this.b, 0.0D, 0.0D, 0.0D, 0.0F, var8, var1, var2, var3);
   }
}
