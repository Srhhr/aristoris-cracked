import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;

public class dap extends dai {
   private final vk a;
   private final long b;

   private dap(dbo[] var1, vk var2, long var3) {
      super(var1);
      this.a = var2;
      this.b = var3;
   }

   public dak b() {
      return dal.q;
   }

   public bmb a(bmb var1, cyv var2) {
      if (var1.a()) {
         return var1;
      } else {
         md var3 = new md();
         var3.a("LootTable", this.a.toString());
         if (this.b != 0L) {
            var3.a("LootTableSeed", this.b);
         }

         var1.p().a((String)"BlockEntityTag", (mt)var3);
         return var1;
      }
   }

   public void a(czg var1) {
      if (var1.a(this.a)) {
         var1.a("Table " + this.a + " is recursively called");
      } else {
         super.a(var1);
         cyy var2 = var1.c(this.a);
         if (var2 == null) {
            var1.a("Unknown loot table called " + this.a);
         } else {
            var2.a(var1.a("->{" + this.a + "}", this.a));
         }

      }
   }

   // $FF: synthetic method
   dap(dbo[] var1, vk var2, long var3, Object var5) {
      this(var1, var2, var3);
   }

   public static class a extends dai.c<dap> {
      public void a(JsonObject var1, dap var2, JsonSerializationContext var3) {
         super.a(var1, (dai)var2, var3);
         var1.addProperty("name", var2.a.toString());
         if (var2.b != 0L) {
            var1.addProperty("seed", var2.b);
         }

      }

      public dap a(JsonObject var1, JsonDeserializationContext var2, dbo[] var3) {
         vk var4 = new vk(afd.h(var1, "name"));
         long var5 = afd.a(var1, "seed", 0L);
         return new dap(var3, var4, var5);
      }

      // $FF: synthetic method
      public dai b(JsonObject var1, JsonDeserializationContext var2, dbo[] var3) {
         return this.a(var1, var2, var3);
      }
   }
}
