import com.google.common.collect.ImmutableList;
import com.google.gson.JsonElement;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import java.util.Arrays;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import javax.annotation.Nullable;

public class ii {
   private final Consumer<il> a;
   private final BiConsumer<vk, Supplier<JsonElement>> b;
   private final Consumer<blx> c;

   public ii(Consumer<il> var1, BiConsumer<vk, Supplier<JsonElement>> var2, Consumer<blx> var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
   }

   private void a(buo var1) {
      this.c.accept(var1.h());
   }

   private void c(buo var1, vk var2) {
      this.b.accept(iw.a(var1.h()), new iv(var2));
   }

   private void a(blx var1, vk var2) {
      this.b.accept(iw.a(var1), new iv(var2));
   }

   private void a(blx var1) {
      iy.aK.a(iw.a(var1), iz.b(var1), this.b);
   }

   private void b(buo var1) {
      blx var2 = var1.h();
      if (var2 != bmd.a) {
         iy.aK.a(iw.a(var2), iz.B(var1), this.b);
      }

   }

   private void a(buo var1, String var2) {
      blx var3 = var1.h();
      iy.aK.a(iw.a(var3), iz.j(iz.a(var1, var2)), this.b);
   }

   private static ip b() {
      return ip.a((cfj)cex.O).a(gc.f, (ir)ir.a().a((it)is.b, (Object)is.a.b)).a(gc.d, (ir)ir.a().a((it)is.b, (Object)is.a.c)).a(gc.e, (ir)ir.a().a((it)is.b, (Object)is.a.d)).a(gc.c, (ir)ir.a());
   }

   private static ip c() {
      return ip.a((cfj)cex.O).a(gc.d, (ir)ir.a()).a(gc.e, (ir)ir.a().a((it)is.b, (Object)is.a.b)).a(gc.c, (ir)ir.a().a((it)is.b, (Object)is.a.c)).a(gc.f, (ir)ir.a().a((it)is.b, (Object)is.a.d));
   }

   private static ip d() {
      return ip.a((cfj)cex.O).a(gc.f, (ir)ir.a()).a(gc.d, (ir)ir.a().a((it)is.b, (Object)is.a.b)).a(gc.e, (ir)ir.a().a((it)is.b, (Object)is.a.c)).a(gc.c, (ir)ir.a().a((it)is.b, (Object)is.a.d));
   }

   private static ip e() {
      return ip.a((cfj)cex.M).a(gc.a, (ir)ir.a().a((it)is.a, (Object)is.a.b)).a(gc.b, (ir)ir.a().a((it)is.a, (Object)is.a.d)).a(gc.c, (ir)ir.a()).a(gc.d, (ir)ir.a().a((it)is.b, (Object)is.a.c)).a(gc.e, (ir)ir.a().a((it)is.b, (Object)is.a.d)).a(gc.f, (ir)ir.a().a((it)is.b, (Object)is.a.b));
   }

   private static io d(buo var0, vk var1) {
      return io.a(var0, a(var1));
   }

   private static ir[] a(vk var0) {
      return new ir[]{ir.a().a((it)is.c, (Object)var0), ir.a().a((it)is.c, (Object)var0).a((it)is.b, (Object)is.a.b), ir.a().a((it)is.c, (Object)var0).a((it)is.b, (Object)is.a.c), ir.a().a((it)is.c, (Object)var0).a((it)is.b, (Object)is.a.d)};
   }

   private static io e(buo var0, vk var1, vk var2) {
      return io.a(var0, ir.a().a((it)is.c, (Object)var1), ir.a().a((it)is.c, (Object)var2), ir.a().a((it)is.c, (Object)var1).a((it)is.b, (Object)is.a.c), ir.a().a((it)is.c, (Object)var2).a((it)is.b, (Object)is.a.c));
   }

   private static ip a(cey var0, vk var1, vk var2) {
      return ip.a((cfj)var0).a(true, (ir)ir.a().a((it)is.c, (Object)var1)).a(false, (ir)ir.a().a((it)is.c, (Object)var2));
   }

   private void c(buo var1) {
      vk var2 = jb.a.a(var1, this.b);
      vk var3 = jb.b.a(var1, this.b);
      this.a.accept(e(var1, var2, var3));
   }

   private void d(buo var1) {
      vk var2 = jb.a.a(var1, this.b);
      this.a.accept(d(var1, var2));
   }

   private static il f(buo var0, vk var1, vk var2) {
      return io.a(var0).a((ip)ip.a((cfj)cex.w).a(false, (ir)ir.a().a((it)is.c, (Object)var1)).a(true, (ir)ir.a().a((it)is.c, (Object)var2))).a((ip)ip.a((cfj)cex.Q, (cfj)cex.O).a(cet.a, (Comparable)gc.f, (ir)ir.a().a((it)is.b, (Object)is.a.b)).a(cet.a, (Comparable)gc.e, (ir)ir.a().a((it)is.b, (Object)is.a.d)).a(cet.a, (Comparable)gc.d, (ir)ir.a().a((it)is.b, (Object)is.a.c)).a(cet.a, (Comparable)gc.c, (ir)ir.a()).a(cet.b, (Comparable)gc.f, (ir)ir.a().a((it)is.b, (Object)is.a.b).a((it)is.a, (Object)is.a.b).a((it)is.d, (Object)true)).a(cet.b, (Comparable)gc.e, (ir)ir.a().a((it)is.b, (Object)is.a.d).a((it)is.a, (Object)is.a.b).a((it)is.d, (Object)true)).a(cet.b, (Comparable)gc.d, (ir)ir.a().a((it)is.b, (Object)is.a.c).a((it)is.a, (Object)is.a.b).a((it)is.d, (Object)true)).a(cet.b, (Comparable)gc.c, (ir)ir.a().a((it)is.a, (Object)is.a.b).a((it)is.d, (Object)true)).a(cet.c, (Comparable)gc.f, (ir)ir.a().a((it)is.b, (Object)is.a.d).a((it)is.a, (Object)is.a.c)).a(cet.c, (Comparable)gc.e, (ir)ir.a().a((it)is.b, (Object)is.a.b).a((it)is.a, (Object)is.a.c)).a(cet.c, (Comparable)gc.d, (ir)ir.a().a((it)is.a, (Object)is.a.c)).a(cet.c, (Comparable)gc.c, (ir)ir.a().a((it)is.b, (Object)is.a.c).a((it)is.a, (Object)is.a.c)));
   }

   private static ip.d<gc, cfd, cfc, Boolean> a(ip.d<gc, cfd, cfc, Boolean> var0, cfd var1, vk var2, vk var3) {
      return var0.a(gc.f, var1, cfc.a, false, (ir)ir.a().a((it)is.c, (Object)var2)).a(gc.d, var1, cfc.a, false, (ir)ir.a().a((it)is.c, (Object)var2).a((it)is.b, (Object)is.a.b)).a(gc.e, var1, cfc.a, false, (ir)ir.a().a((it)is.c, (Object)var2).a((it)is.b, (Object)is.a.c)).a(gc.c, var1, cfc.a, false, (ir)ir.a().a((it)is.c, (Object)var2).a((it)is.b, (Object)is.a.d)).a(gc.f, var1, cfc.b, false, (ir)ir.a().a((it)is.c, (Object)var3)).a(gc.d, var1, cfc.b, false, (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.b, (Object)is.a.b)).a(gc.e, var1, cfc.b, false, (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.b, (Object)is.a.c)).a(gc.c, var1, cfc.b, false, (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.b, (Object)is.a.d)).a(gc.f, var1, cfc.a, true, (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.b, (Object)is.a.b)).a(gc.d, var1, cfc.a, true, (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.b, (Object)is.a.c)).a(gc.e, var1, cfc.a, true, (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.b, (Object)is.a.d)).a(gc.c, var1, cfc.a, true, (ir)ir.a().a((it)is.c, (Object)var3)).a(gc.f, var1, cfc.b, true, (ir)ir.a().a((it)is.c, (Object)var2).a((it)is.b, (Object)is.a.d)).a(gc.d, var1, cfc.b, true, (ir)ir.a().a((it)is.c, (Object)var2)).a(gc.e, var1, cfc.b, true, (ir)ir.a().a((it)is.c, (Object)var2).a((it)is.b, (Object)is.a.b)).a(gc.c, var1, cfc.b, true, (ir)ir.a().a((it)is.c, (Object)var2).a((it)is.b, (Object)is.a.c));
   }

   private static il b(buo var0, vk var1, vk var2, vk var3, vk var4) {
      return io.a(var0).a((ip)a(a(ip.a(cex.O, cex.aa, cex.aH, cex.u), cfd.b, var1, var2), cfd.a, var3, var4));
   }

   private static il g(buo var0, vk var1, vk var2) {
      return in.a(var0).a(ir.a().a((it)is.c, (Object)var1)).a((im)im.a().a((cfj)cex.I, (Comparable)true), (ir)ir.a().a((it)is.c, (Object)var2).a((it)is.d, (Object)true)).a((im)im.a().a((cfj)cex.J, (Comparable)true), (ir)ir.a().a((it)is.c, (Object)var2).a((it)is.b, (Object)is.a.b).a((it)is.d, (Object)true)).a((im)im.a().a((cfj)cex.K, (Comparable)true), (ir)ir.a().a((it)is.c, (Object)var2).a((it)is.b, (Object)is.a.c).a((it)is.d, (Object)true)).a((im)im.a().a((cfj)cex.L, (Comparable)true), (ir)ir.a().a((it)is.c, (Object)var2).a((it)is.b, (Object)is.a.d).a((it)is.d, (Object)true));
   }

   private static il d(buo var0, vk var1, vk var2, vk var3) {
      return in.a(var0).a((im)im.a().a((cfj)cex.G, (Comparable)true), (ir)ir.a().a((it)is.c, (Object)var1)).a((im)im.a().a((cfj)cex.T, (Comparable)cfp.b), (ir)ir.a().a((it)is.c, (Object)var2).a((it)is.d, (Object)true)).a((im)im.a().a((cfj)cex.S, (Comparable)cfp.b), (ir)ir.a().a((it)is.c, (Object)var2).a((it)is.b, (Object)is.a.b).a((it)is.d, (Object)true)).a((im)im.a().a((cfj)cex.U, (Comparable)cfp.b), (ir)ir.a().a((it)is.c, (Object)var2).a((it)is.b, (Object)is.a.c).a((it)is.d, (Object)true)).a((im)im.a().a((cfj)cex.V, (Comparable)cfp.b), (ir)ir.a().a((it)is.c, (Object)var2).a((it)is.b, (Object)is.a.d).a((it)is.d, (Object)true)).a((im)im.a().a((cfj)cex.T, (Comparable)cfp.c), (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.d, (Object)true)).a((im)im.a().a((cfj)cex.S, (Comparable)cfp.c), (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.b, (Object)is.a.b).a((it)is.d, (Object)true)).a((im)im.a().a((cfj)cex.U, (Comparable)cfp.c), (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.b, (Object)is.a.c).a((it)is.d, (Object)true)).a((im)im.a().a((cfj)cex.V, (Comparable)cfp.c), (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.b, (Object)is.a.d).a((it)is.d, (Object)true));
   }

   private static il c(buo var0, vk var1, vk var2, vk var3, vk var4) {
      return io.a(var0, ir.a().a((it)is.d, (Object)true)).a(c()).a((ip)ip.a((cfj)cex.q, (cfj)cex.u).a(false, (Comparable)false, (ir)ir.a().a((it)is.c, (Object)var2)).a(true, (Comparable)false, (ir)ir.a().a((it)is.c, (Object)var4)).a(false, (Comparable)true, (ir)ir.a().a((it)is.c, (Object)var1)).a(true, (Comparable)true, (ir)ir.a().a((it)is.c, (Object)var3)));
   }

   private static il e(buo var0, vk var1, vk var2, vk var3) {
      return io.a(var0).a((ip)ip.a(cex.O, cex.ab, cex.aL).a(gc.f, cff.b, cfn.a, (ir)ir.a().a((it)is.c, (Object)var2)).a(gc.e, cff.b, cfn.a, (ir)ir.a().a((it)is.c, (Object)var2).a((it)is.b, (Object)is.a.c).a((it)is.d, (Object)true)).a(gc.d, cff.b, cfn.a, (ir)ir.a().a((it)is.c, (Object)var2).a((it)is.b, (Object)is.a.b).a((it)is.d, (Object)true)).a(gc.c, cff.b, cfn.a, (ir)ir.a().a((it)is.c, (Object)var2).a((it)is.b, (Object)is.a.d).a((it)is.d, (Object)true)).a(gc.f, cff.b, cfn.e, (ir)ir.a().a((it)is.c, (Object)var3)).a(gc.e, cff.b, cfn.e, (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.b, (Object)is.a.c).a((it)is.d, (Object)true)).a(gc.d, cff.b, cfn.e, (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.b, (Object)is.a.b).a((it)is.d, (Object)true)).a(gc.c, cff.b, cfn.e, (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.b, (Object)is.a.d).a((it)is.d, (Object)true)).a(gc.f, cff.b, cfn.d, (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.b, (Object)is.a.d).a((it)is.d, (Object)true)).a(gc.e, cff.b, cfn.d, (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.b, (Object)is.a.b).a((it)is.d, (Object)true)).a(gc.d, cff.b, cfn.d, (ir)ir.a().a((it)is.c, (Object)var3)).a(gc.c, cff.b, cfn.d, (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.b, (Object)is.a.c).a((it)is.d, (Object)true)).a(gc.f, cff.b, cfn.c, (ir)ir.a().a((it)is.c, (Object)var1)).a(gc.e, cff.b, cfn.c, (ir)ir.a().a((it)is.c, (Object)var1).a((it)is.b, (Object)is.a.c).a((it)is.d, (Object)true)).a(gc.d, cff.b, cfn.c, (ir)ir.a().a((it)is.c, (Object)var1).a((it)is.b, (Object)is.a.b).a((it)is.d, (Object)true)).a(gc.c, cff.b, cfn.c, (ir)ir.a().a((it)is.c, (Object)var1).a((it)is.b, (Object)is.a.d).a((it)is.d, (Object)true)).a(gc.f, cff.b, cfn.b, (ir)ir.a().a((it)is.c, (Object)var1).a((it)is.b, (Object)is.a.d).a((it)is.d, (Object)true)).a(gc.e, cff.b, cfn.b, (ir)ir.a().a((it)is.c, (Object)var1).a((it)is.b, (Object)is.a.b).a((it)is.d, (Object)true)).a(gc.d, cff.b, cfn.b, (ir)ir.a().a((it)is.c, (Object)var1)).a(gc.c, cff.b, cfn.b, (ir)ir.a().a((it)is.c, (Object)var1).a((it)is.b, (Object)is.a.c).a((it)is.d, (Object)true)).a(gc.f, cff.a, cfn.a, (ir)ir.a().a((it)is.c, (Object)var2).a((it)is.a, (Object)is.a.c).a((it)is.d, (Object)true)).a(gc.e, cff.a, cfn.a, (ir)ir.a().a((it)is.c, (Object)var2).a((it)is.a, (Object)is.a.c).a((it)is.b, (Object)is.a.c).a((it)is.d, (Object)true)).a(gc.d, cff.a, cfn.a, (ir)ir.a().a((it)is.c, (Object)var2).a((it)is.a, (Object)is.a.c).a((it)is.b, (Object)is.a.b).a((it)is.d, (Object)true)).a(gc.c, cff.a, cfn.a, (ir)ir.a().a((it)is.c, (Object)var2).a((it)is.a, (Object)is.a.c).a((it)is.b, (Object)is.a.d).a((it)is.d, (Object)true)).a(gc.f, cff.a, cfn.e, (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.a, (Object)is.a.c).a((it)is.b, (Object)is.a.b).a((it)is.d, (Object)true)).a(gc.e, cff.a, cfn.e, (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.a, (Object)is.a.c).a((it)is.b, (Object)is.a.d).a((it)is.d, (Object)true)).a(gc.d, cff.a, cfn.e, (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.a, (Object)is.a.c).a((it)is.b, (Object)is.a.c).a((it)is.d, (Object)true)).a(gc.c, cff.a, cfn.e, (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.a, (Object)is.a.c).a((it)is.d, (Object)true)).a(gc.f, cff.a, cfn.d, (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.a, (Object)is.a.c).a((it)is.d, (Object)true)).a(gc.e, cff.a, cfn.d, (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.a, (Object)is.a.c).a((it)is.b, (Object)is.a.c).a((it)is.d, (Object)true)).a(gc.d, cff.a, cfn.d, (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.a, (Object)is.a.c).a((it)is.b, (Object)is.a.b).a((it)is.d, (Object)true)).a(gc.c, cff.a, cfn.d, (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.a, (Object)is.a.c).a((it)is.b, (Object)is.a.d).a((it)is.d, (Object)true)).a(gc.f, cff.a, cfn.c, (ir)ir.a().a((it)is.c, (Object)var1).a((it)is.a, (Object)is.a.c).a((it)is.b, (Object)is.a.b).a((it)is.d, (Object)true)).a(gc.e, cff.a, cfn.c, (ir)ir.a().a((it)is.c, (Object)var1).a((it)is.a, (Object)is.a.c).a((it)is.b, (Object)is.a.d).a((it)is.d, (Object)true)).a(gc.d, cff.a, cfn.c, (ir)ir.a().a((it)is.c, (Object)var1).a((it)is.a, (Object)is.a.c).a((it)is.b, (Object)is.a.c).a((it)is.d, (Object)true)).a(gc.c, cff.a, cfn.c, (ir)ir.a().a((it)is.c, (Object)var1).a((it)is.a, (Object)is.a.c).a((it)is.d, (Object)true)).a(gc.f, cff.a, cfn.b, (ir)ir.a().a((it)is.c, (Object)var1).a((it)is.a, (Object)is.a.c).a((it)is.d, (Object)true)).a(gc.e, cff.a, cfn.b, (ir)ir.a().a((it)is.c, (Object)var1).a((it)is.a, (Object)is.a.c).a((it)is.b, (Object)is.a.c).a((it)is.d, (Object)true)).a(gc.d, cff.a, cfn.b, (ir)ir.a().a((it)is.c, (Object)var1).a((it)is.a, (Object)is.a.c).a((it)is.b, (Object)is.a.b).a((it)is.d, (Object)true)).a(gc.c, cff.a, cfn.b, (ir)ir.a().a((it)is.c, (Object)var1).a((it)is.a, (Object)is.a.c).a((it)is.b, (Object)is.a.d).a((it)is.d, (Object)true)));
   }

   private static il f(buo var0, vk var1, vk var2, vk var3) {
      return io.a(var0).a((ip)ip.a(cex.O, cex.ab, cex.u).a(gc.c, cff.b, false, (ir)ir.a().a((it)is.c, (Object)var2)).a(gc.d, cff.b, false, (ir)ir.a().a((it)is.c, (Object)var2).a((it)is.b, (Object)is.a.c)).a(gc.f, cff.b, false, (ir)ir.a().a((it)is.c, (Object)var2).a((it)is.b, (Object)is.a.b)).a(gc.e, cff.b, false, (ir)ir.a().a((it)is.c, (Object)var2).a((it)is.b, (Object)is.a.d)).a(gc.c, cff.a, false, (ir)ir.a().a((it)is.c, (Object)var1)).a(gc.d, cff.a, false, (ir)ir.a().a((it)is.c, (Object)var1).a((it)is.b, (Object)is.a.c)).a(gc.f, cff.a, false, (ir)ir.a().a((it)is.c, (Object)var1).a((it)is.b, (Object)is.a.b)).a(gc.e, cff.a, false, (ir)ir.a().a((it)is.c, (Object)var1).a((it)is.b, (Object)is.a.d)).a(gc.c, cff.b, true, (ir)ir.a().a((it)is.c, (Object)var3)).a(gc.d, cff.b, true, (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.b, (Object)is.a.c)).a(gc.f, cff.b, true, (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.b, (Object)is.a.b)).a(gc.e, cff.b, true, (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.b, (Object)is.a.d)).a(gc.c, cff.a, true, (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.a, (Object)is.a.c).a((it)is.b, (Object)is.a.c)).a(gc.d, cff.a, true, (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.a, (Object)is.a.c).a((it)is.b, (Object)is.a.a)).a(gc.f, cff.a, true, (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.a, (Object)is.a.c).a((it)is.b, (Object)is.a.d)).a(gc.e, cff.a, true, (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.a, (Object)is.a.c).a((it)is.b, (Object)is.a.b)));
   }

   private static il g(buo var0, vk var1, vk var2, vk var3) {
      return io.a(var0).a((ip)ip.a(cex.O, cex.ab, cex.u).a(gc.c, cff.b, false, (ir)ir.a().a((it)is.c, (Object)var2)).a(gc.d, cff.b, false, (ir)ir.a().a((it)is.c, (Object)var2)).a(gc.f, cff.b, false, (ir)ir.a().a((it)is.c, (Object)var2)).a(gc.e, cff.b, false, (ir)ir.a().a((it)is.c, (Object)var2)).a(gc.c, cff.a, false, (ir)ir.a().a((it)is.c, (Object)var1)).a(gc.d, cff.a, false, (ir)ir.a().a((it)is.c, (Object)var1)).a(gc.f, cff.a, false, (ir)ir.a().a((it)is.c, (Object)var1)).a(gc.e, cff.a, false, (ir)ir.a().a((it)is.c, (Object)var1)).a(gc.c, cff.b, true, (ir)ir.a().a((it)is.c, (Object)var3)).a(gc.d, cff.b, true, (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.b, (Object)is.a.c)).a(gc.f, cff.b, true, (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.b, (Object)is.a.b)).a(gc.e, cff.b, true, (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.b, (Object)is.a.d)).a(gc.c, cff.a, true, (ir)ir.a().a((it)is.c, (Object)var3)).a(gc.d, cff.a, true, (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.b, (Object)is.a.c)).a(gc.f, cff.a, true, (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.b, (Object)is.a.b)).a(gc.e, cff.a, true, (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.b, (Object)is.a.d)));
   }

   private static io e(buo var0, vk var1) {
      return io.a(var0, ir.a().a((it)is.c, (Object)var1));
   }

   private static ip f() {
      return ip.a((cfj)cex.F).a(gc.a.b, (ir)ir.a()).a(gc.a.c, (ir)ir.a().a((it)is.a, (Object)is.a.b)).a(gc.a.a, (ir)ir.a().a((it)is.a, (Object)is.a.b).a((it)is.b, (Object)is.a.b));
   }

   private static il f(buo var0, vk var1) {
      return io.a(var0, ir.a().a((it)is.c, (Object)var1)).a(f());
   }

   private void g(buo var1, vk var2) {
      this.a.accept(f(var1, var2));
   }

   private void a(buo var1, jb.a var2) {
      vk var3 = var2.a(var1, this.b);
      this.a.accept(f(var1, var3));
   }

   private void b(buo var1, jb.a var2) {
      vk var3 = var2.a(var1, this.b);
      this.a.accept(io.a(var1, ir.a().a((it)is.c, (Object)var3)).a(b()));
   }

   private static il h(buo var0, vk var1, vk var2) {
      return io.a(var0).a((ip)ip.a((cfj)cex.F).a(gc.a.b, (ir)ir.a().a((it)is.c, (Object)var1)).a(gc.a.c, (ir)ir.a().a((it)is.c, (Object)var2).a((it)is.a, (Object)is.a.b)).a(gc.a.a, (ir)ir.a().a((it)is.c, (Object)var2).a((it)is.a, (Object)is.a.b).a((it)is.b, (Object)is.a.b)));
   }

   private void a(buo var1, jb.a var2, jb.a var3) {
      vk var4 = var2.a(var1, this.b);
      vk var5 = var3.a(var1, this.b);
      this.a.accept(h(var1, var4, var5));
   }

   private vk a(buo var1, String var2, ix var3, Function<vk, iz> var4) {
      return var3.a(var1, var2, (iz)var4.apply(iz.a(var1, var2)), this.b);
   }

   private static il i(buo var0, vk var1, vk var2) {
      return io.a(var0).a(a(cex.w, var2, var1));
   }

   private static il h(buo var0, vk var1, vk var2, vk var3) {
      return io.a(var0).a((ip)ip.a((cfj)cex.aK).a(cfm.b, (ir)ir.a().a((it)is.c, (Object)var1)).a(cfm.a, (ir)ir.a().a((it)is.c, (Object)var2)).a(cfm.c, (ir)ir.a().a((it)is.c, (Object)var3)));
   }

   private void e(buo var1) {
      this.c(var1, jb.a);
   }

   private void c(buo var1, jb.a var2) {
      this.a.accept(e(var1, var2.a(var1, this.b)));
   }

   private void a(buo var1, iz var2, ix var3) {
      vk var4 = var3.a(var1, var2, this.b);
      this.a.accept(e(var1, var4));
   }

   private ii.b a(buo var1, jb var2) {
      return (new ii.b(var2.b())).a(var1, var2.a());
   }

   private ii.b d(buo var1, jb.a var2) {
      jb var3 = var2.get(var1);
      return (new ii.b(var3.b())).a(var1, var3.a());
   }

   private ii.b f(buo var1) {
      return this.d(var1, jb.a);
   }

   private ii.b a(iz var1) {
      return new ii.b(var1);
   }

   private void g(buo var1) {
      iz var2 = iz.p(var1);
      vk var3 = iy.o.a(var1, var2, this.b);
      vk var4 = iy.p.a(var1, var2, this.b);
      vk var5 = iy.q.a(var1, var2, this.b);
      vk var6 = iy.r.a(var1, var2, this.b);
      this.a(var1.h());
      this.a.accept(b(var1, var3, var4, var5, var6));
   }

   private void h(buo var1) {
      iz var2 = iz.b(var1);
      vk var3 = iy.P.a(var1, var2, this.b);
      vk var4 = iy.Q.a(var1, var2, this.b);
      vk var5 = iy.R.a(var1, var2, this.b);
      this.a.accept(f(var1, var3, var4, var5));
      this.c(var1, var4);
   }

   private void i(buo var1) {
      iz var2 = iz.b(var1);
      vk var3 = iy.M.a(var1, var2, this.b);
      vk var4 = iy.N.a(var1, var2, this.b);
      vk var5 = iy.O.a(var1, var2, this.b);
      this.a.accept(g(var1, var3, var4, var5));
      this.c(var1, var4);
   }

   private ii.d j(buo var1) {
      return new ii.d(iz.l(var1));
   }

   private void k(buo var1) {
      this.a(var1, var1);
   }

   private void a(buo var1, buo var2) {
      this.a.accept(e(var1, iw.a(var2)));
   }

   private void a(buo var1, ii.c var2) {
      this.b(var1);
      this.b(var1, var2);
   }

   private void a(buo var1, ii.c var2, iz var3) {
      this.b(var1);
      this.b(var1, var2, var3);
   }

   private void b(buo var1, ii.c var2) {
      iz var3 = iz.c(var1);
      this.b(var1, var2, var3);
   }

   private void b(buo var1, ii.c var2, iz var3) {
      vk var4 = var2.a().a(var1, var3, this.b);
      this.a.accept(e(var1, var4));
   }

   private void a(buo var1, buo var2, ii.c var3) {
      this.a(var1, var3);
      iz var4 = iz.d(var1);
      vk var5 = var3.b().a(var2, var4, this.b);
      this.a.accept(e(var2, var5));
   }

   private void b(buo var1, buo var2) {
      jb var3 = jb.k.get(var1);
      vk var4 = var3.a(var1, this.b);
      this.a.accept(e(var1, var4));
      vk var5 = iy.ac.a(var2, var3.b(), this.b);
      this.a.accept(io.a(var2, ir.a().a((it)is.c, (Object)var5)).a(b()));
      this.b(var1);
   }

   private void c(buo var1, buo var2) {
      this.a(var1.h());
      iz var3 = iz.g(var1);
      iz var4 = iz.a(var1, var2);
      vk var5 = iy.ao.a(var2, var4, this.b);
      this.a.accept(io.a(var2, ir.a().a((it)is.c, (Object)var5)).a((ip)ip.a((cfj)cex.O).a(gc.e, (ir)ir.a()).a(gc.d, (ir)ir.a().a((it)is.b, (Object)is.a.d)).a(gc.c, (ir)ir.a().a((it)is.b, (Object)is.a.b)).a(gc.f, (ir)ir.a().a((it)is.b, (Object)is.a.c))));
      this.a.accept(io.a(var1).a(ip.a((cfj)cex.ai).a((var3x) -> {
         return ir.a().a((it)is.c, (Object)iy.an[var3x].a(var1, var3, this.b));
      })));
   }

   private void a(buo var1, buo var2, buo var3, buo var4, buo var5, buo var6, buo var7, buo var8) {
      this.a(var1, ii.c.b);
      this.a(var2, ii.c.b);
      this.e(var3);
      this.e(var4);
      this.b(var5, var7);
      this.b(var6, var8);
   }

   private void c(buo var1, ii.c var2) {
      this.a(var1, "_top");
      vk var3 = this.a(var1, "_top", var2.a(), iz::c);
      vk var4 = this.a(var1, "_bottom", var2.a(), iz::c);
      this.j(var1, var3, var4);
   }

   private void g() {
      this.a(bup.gU, "_front");
      vk var1 = iw.a(bup.gU, "_top");
      vk var2 = this.a(bup.gU, "_bottom", ii.c.b.a(), iz::c);
      this.j(bup.gU, var1, var2);
   }

   private void h() {
      vk var1 = this.a(bup.aV, "_top", iy.aE, iz::a);
      vk var2 = this.a(bup.aV, "_bottom", iy.aE, iz::a);
      this.j(bup.aV, var1, var2);
   }

   private void j(buo var1, vk var2, vk var3) {
      this.a.accept(io.a(var1).a((ip)ip.a((cfj)cex.aa).a(cfd.b, (ir)ir.a().a((it)is.c, (Object)var3)).a(cfd.a, (ir)ir.a().a((it)is.c, (Object)var2))));
   }

   private void l(buo var1) {
      iz var2 = iz.e(var1);
      iz var3 = iz.e(iz.a(var1, "_corner"));
      vk var4 = iy.W.a(var1, var2, this.b);
      vk var5 = iy.X.a(var1, var3, this.b);
      vk var6 = iy.Y.a(var1, var2, this.b);
      vk var7 = iy.Z.a(var1, var2, this.b);
      this.b(var1);
      this.a.accept(io.a(var1).a((ip)ip.a((cfj)cex.ac).a(cfk.a, (ir)ir.a().a((it)is.c, (Object)var4)).a(cfk.b, (ir)ir.a().a((it)is.c, (Object)var4).a((it)is.b, (Object)is.a.b)).a(cfk.c, (ir)ir.a().a((it)is.c, (Object)var6).a((it)is.b, (Object)is.a.b)).a(cfk.d, (ir)ir.a().a((it)is.c, (Object)var7).a((it)is.b, (Object)is.a.b)).a(cfk.e, (ir)ir.a().a((it)is.c, (Object)var6)).a(cfk.f, (ir)ir.a().a((it)is.c, (Object)var7)).a(cfk.g, (ir)ir.a().a((it)is.c, (Object)var5)).a(cfk.h, (ir)ir.a().a((it)is.c, (Object)var5).a((it)is.b, (Object)is.a.b)).a(cfk.i, (ir)ir.a().a((it)is.c, (Object)var5).a((it)is.b, (Object)is.a.c)).a(cfk.j, (ir)ir.a().a((it)is.c, (Object)var5).a((it)is.b, (Object)is.a.d))));
   }

   private void m(buo var1) {
      vk var2 = this.a(var1, "", iy.W, iz::e);
      vk var3 = this.a(var1, "", iy.Y, iz::e);
      vk var4 = this.a(var1, "", iy.Z, iz::e);
      vk var5 = this.a(var1, "_on", iy.W, iz::e);
      vk var6 = this.a(var1, "_on", iy.Y, iz::e);
      vk var7 = this.a(var1, "_on", iy.Z, iz::e);
      ip var8 = ip.a((cfj)cex.w, (cfj)cex.ad).a((var6x, var7x) -> {
         switch(var7x) {
         case a:
            return ir.a().a((it)is.c, (Object)(var6x ? var5 : var2));
         case b:
            return ir.a().a((it)is.c, (Object)(var6x ? var5 : var2)).a((it)is.b, (Object)is.a.b);
         case c:
            return ir.a().a((it)is.c, (Object)(var6x ? var6 : var3)).a((it)is.b, (Object)is.a.b);
         case d:
            return ir.a().a((it)is.c, (Object)(var6x ? var7 : var4)).a((it)is.b, (Object)is.a.b);
         case e:
            return ir.a().a((it)is.c, (Object)(var6x ? var6 : var3));
         case f:
            return ir.a().a((it)is.c, (Object)(var6x ? var7 : var4));
         default:
            throw new UnsupportedOperationException("Fix you generator!");
         }
      });
      this.b(var1);
      this.a.accept(io.a(var1).a(var8));
   }

   private ii.a a(vk var1, buo var2) {
      return new ii.a(var1, var2);
   }

   private ii.a d(buo var1, buo var2) {
      return new ii.a(iw.a(var1), var2);
   }

   private void a(buo var1, blx var2) {
      vk var3 = iy.F.a(var1, iz.a(var2), this.b);
      this.a.accept(e(var1, var3));
   }

   private void h(buo var1, vk var2) {
      vk var3 = iy.F.a(var1, iz.h(var2), this.b);
      this.a.accept(e(var1, var3));
   }

   private void e(buo var1, buo var2) {
      this.c(var1, jb.a);
      vk var3 = jb.i.get(var1).a(var2, this.b);
      this.a.accept(e(var2, var3));
   }

   private void a(jb.a var1, buo... var2) {
      buo[] var3 = var2;
      int var4 = var2.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         buo var6 = var3[var5];
         vk var7 = var1.a(var6, this.b);
         this.a.accept(d(var6, var7));
      }

   }

   private void b(jb.a var1, buo... var2) {
      buo[] var3 = var2;
      int var4 = var2.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         buo var6 = var3[var5];
         vk var7 = var1.a(var6, this.b);
         this.a.accept(io.a(var6, ir.a().a((it)is.c, (Object)var7)).a(c()));
      }

   }

   private void f(buo var1, buo var2) {
      this.e(var1);
      iz var3 = iz.b(var1, var2);
      vk var4 = iy.ai.a(var2, var3, this.b);
      vk var5 = iy.aj.a(var2, var3, this.b);
      vk var6 = iy.ak.a(var2, var3, this.b);
      vk var7 = iy.ag.a(var2, var3, this.b);
      vk var8 = iy.ah.a(var2, var3, this.b);
      blx var9 = var2.h();
      iy.aK.a(iw.a(var9), iz.B(var1), this.b);
      this.a.accept(in.a(var2).a(ir.a().a((it)is.c, (Object)var4)).a((im)im.a().a((cfj)cex.I, (Comparable)true), (ir)ir.a().a((it)is.c, (Object)var5)).a((im)im.a().a((cfj)cex.J, (Comparable)true), (ir)ir.a().a((it)is.c, (Object)var5).a((it)is.b, (Object)is.a.b)).a((im)im.a().a((cfj)cex.K, (Comparable)true), (ir)ir.a().a((it)is.c, (Object)var6)).a((im)im.a().a((cfj)cex.L, (Comparable)true), (ir)ir.a().a((it)is.c, (Object)var6).a((it)is.b, (Object)is.a.b)).a((im)im.a().a((cfj)cex.I, (Comparable)false), (ir)ir.a().a((it)is.c, (Object)var7)).a((im)im.a().a((cfj)cex.J, (Comparable)false), (ir)ir.a().a((it)is.c, (Object)var8)).a((im)im.a().a((cfj)cex.K, (Comparable)false), (ir)ir.a().a((it)is.c, (Object)var8).a((it)is.b, (Object)is.a.b)).a((im)im.a().a((cfj)cex.L, (Comparable)false), (ir)ir.a().a((it)is.c, (Object)var7).a((it)is.b, (Object)is.a.d)));
   }

   private void n(buo var1) {
      iz var2 = iz.v(var1);
      vk var3 = iy.al.a(var1, var2, this.b);
      vk var4 = this.a(var1, "_conditional", iy.al, (var1x) -> {
         return var2.c(ja.i, var1x);
      });
      this.a.accept(io.a(var1).a(a(cex.c, var4, var3)).a(e()));
   }

   private void o(buo var1) {
      vk var2 = jb.m.a(var1, this.b);
      this.a.accept(e(var1, var2).a(c()));
   }

   private List<ir> a(int var1) {
      String var2 = "_age" + var1;
      return (List)IntStream.range(1, 5).mapToObj((var1x) -> {
         return ir.a().a((it)is.c, (Object)iw.a(bup.kY, var1x + var2));
      }).collect(Collectors.toList());
   }

   private void i() {
      this.a(bup.kY);
      this.a.accept(in.a(bup.kY).a((im)im.a().a((cfj)cex.ae, (int)0), (List)this.a(0)).a((im)im.a().a((cfj)cex.ae, (int)1), (List)this.a(1)).a((im)im.a().a((cfj)cex.aN, (Comparable)ceu.b), (ir)ir.a().a((it)is.c, (Object)iw.a(bup.kY, "_small_leaves"))).a((im)im.a().a((cfj)cex.aN, (Comparable)ceu.c), (ir)ir.a().a((it)is.c, (Object)iw.a(bup.kY, "_large_leaves"))));
   }

   private ip j() {
      return ip.a((cfj)cex.M).a(gc.a, (ir)ir.a().a((it)is.a, (Object)is.a.c)).a(gc.b, (ir)ir.a()).a(gc.c, (ir)ir.a().a((it)is.a, (Object)is.a.b)).a(gc.d, (ir)ir.a().a((it)is.a, (Object)is.a.b).a((it)is.b, (Object)is.a.c)).a(gc.e, (ir)ir.a().a((it)is.a, (Object)is.a.b).a((it)is.b, (Object)is.a.d)).a(gc.f, (ir)ir.a().a((it)is.a, (Object)is.a.b).a((it)is.b, (Object)is.a.b));
   }

   private void k() {
      vk var1 = iz.a(bup.lS, "_top_open");
      this.a.accept(io.a(bup.lS).a(this.j()).a((ip)ip.a((cfj)cex.u).a(false, (ir)ir.a().a((it)is.c, (Object)jb.e.a(bup.lS, this.b))).a(true, (ir)ir.a().a((it)is.c, (Object)jb.e.get(bup.lS).a((var1x) -> {
         var1x.a(ja.f, var1);
      }).a(bup.lS, "_open", this.b)))));
   }

   private static <T extends Comparable<T>> ip a(cfj<T> var0, T var1, vk var2, vk var3) {
      ir var4 = ir.a().a((it)is.c, (Object)var2);
      ir var5 = ir.a().a((it)is.c, (Object)var3);
      return ip.a(var0).a((var3x) -> {
         boolean var4x = var3x.compareTo(var1) >= 0;
         return var4x ? var4 : var5;
      });
   }

   private void a(buo var1, Function<buo, iz> var2) {
      iz var3 = ((iz)var2.apply(var1)).b(ja.i, ja.c);
      iz var4 = var3.c(ja.g, iz.a(var1, "_front_honey"));
      vk var5 = iy.j.a(var1, var3, this.b);
      vk var6 = iy.j.a(var1, "_honey", var4, this.b);
      this.a.accept(io.a(var1).a(b()).a(a((cfj)cex.au, (int)5, (vk)var6, (vk)var5)));
   }

   private void a(buo var1, cfj<Integer> var2, int... var3) {
      if (var2.a().size() != var3.length) {
         throw new IllegalArgumentException();
      } else {
         Int2ObjectMap<vk> var4 = new Int2ObjectOpenHashMap();
         ip var5 = ip.a(var2).a((var4x) -> {
            int var5 = var3[var4x];
            vk var6 = (vk)var4.computeIfAbsent(var5, (var3x) -> {
               return this.a(var1, "_stage" + var5, iy.ap, iz::g);
            });
            return ir.a().a((it)is.c, (Object)var6);
         });
         this.a(var1.h());
         this.a.accept(io.a(var1).a(var5));
      }
   }

   private void l() {
      vk var1 = iw.a(bup.mb, "_floor");
      vk var2 = iw.a(bup.mb, "_ceiling");
      vk var3 = iw.a(bup.mb, "_wall");
      vk var4 = iw.a(bup.mb, "_between_walls");
      this.a(bmd.rj);
      this.a.accept(io.a(bup.mb).a((ip)ip.a((cfj)cex.O, (cfj)cex.R).a(gc.c, (Comparable)cew.a, (ir)ir.a().a((it)is.c, (Object)var1)).a(gc.d, (Comparable)cew.a, (ir)ir.a().a((it)is.c, (Object)var1).a((it)is.b, (Object)is.a.c)).a(gc.f, (Comparable)cew.a, (ir)ir.a().a((it)is.c, (Object)var1).a((it)is.b, (Object)is.a.b)).a(gc.e, (Comparable)cew.a, (ir)ir.a().a((it)is.c, (Object)var1).a((it)is.b, (Object)is.a.d)).a(gc.c, (Comparable)cew.b, (ir)ir.a().a((it)is.c, (Object)var2)).a(gc.d, (Comparable)cew.b, (ir)ir.a().a((it)is.c, (Object)var2).a((it)is.b, (Object)is.a.c)).a(gc.f, (Comparable)cew.b, (ir)ir.a().a((it)is.c, (Object)var2).a((it)is.b, (Object)is.a.b)).a(gc.e, (Comparable)cew.b, (ir)ir.a().a((it)is.c, (Object)var2).a((it)is.b, (Object)is.a.d)).a(gc.c, (Comparable)cew.c, (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.b, (Object)is.a.d)).a(gc.d, (Comparable)cew.c, (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.b, (Object)is.a.b)).a(gc.f, (Comparable)cew.c, (ir)ir.a().a((it)is.c, (Object)var3)).a(gc.e, (Comparable)cew.c, (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.b, (Object)is.a.c)).a(gc.d, (Comparable)cew.d, (ir)ir.a().a((it)is.c, (Object)var4).a((it)is.b, (Object)is.a.b)).a(gc.c, (Comparable)cew.d, (ir)ir.a().a((it)is.c, (Object)var4).a((it)is.b, (Object)is.a.d)).a(gc.f, (Comparable)cew.d, (ir)ir.a().a((it)is.c, (Object)var4)).a(gc.e, (Comparable)cew.d, (ir)ir.a().a((it)is.c, (Object)var4).a((it)is.b, (Object)is.a.c))));
   }

   private void m() {
      this.a.accept(io.a(bup.lX, ir.a().a((it)is.c, (Object)iw.a(bup.lX))).a((ip)ip.a((cfj)cex.Q, (cfj)cex.O).a(cet.a, (Comparable)gc.c, (ir)ir.a()).a(cet.a, (Comparable)gc.f, (ir)ir.a().a((it)is.b, (Object)is.a.b)).a(cet.a, (Comparable)gc.d, (ir)ir.a().a((it)is.b, (Object)is.a.c)).a(cet.a, (Comparable)gc.e, (ir)ir.a().a((it)is.b, (Object)is.a.d)).a(cet.b, (Comparable)gc.c, (ir)ir.a().a((it)is.a, (Object)is.a.b)).a(cet.b, (Comparable)gc.f, (ir)ir.a().a((it)is.a, (Object)is.a.b).a((it)is.b, (Object)is.a.b)).a(cet.b, (Comparable)gc.d, (ir)ir.a().a((it)is.a, (Object)is.a.b).a((it)is.b, (Object)is.a.c)).a(cet.b, (Comparable)gc.e, (ir)ir.a().a((it)is.a, (Object)is.a.b).a((it)is.b, (Object)is.a.d)).a(cet.c, (Comparable)gc.d, (ir)ir.a().a((it)is.a, (Object)is.a.c)).a(cet.c, (Comparable)gc.e, (ir)ir.a().a((it)is.a, (Object)is.a.c).a((it)is.b, (Object)is.a.b)).a(cet.c, (Comparable)gc.c, (ir)ir.a().a((it)is.a, (Object)is.a.c).a((it)is.b, (Object)is.a.c)).a(cet.c, (Comparable)gc.f, (ir)ir.a().a((it)is.a, (Object)is.a.c).a((it)is.b, (Object)is.a.d))));
   }

   private void e(buo var1, jb.a var2) {
      vk var3 = var2.a(var1, this.b);
      vk var4 = iz.a(var1, "_front_on");
      vk var5 = var2.get(var1).a((var1x) -> {
         var1x.a(ja.g, var4);
      }).a(var1, "_on", this.b);
      this.a.accept(io.a(var1).a(a(cex.r, var5, var3)).a(b()));
   }

   private void a(buo... var1) {
      vk var2 = iw.a("campfire_off");
      buo[] var3 = var1;
      int var4 = var1.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         buo var6 = var3[var5];
         vk var7 = iy.aw.a(var6, iz.A(var6), this.b);
         this.a(var6.h());
         this.a.accept(io.a(var6).a(a(cex.r, var7, var2)).a(c()));
      }

   }

   private void n() {
      iz var1 = iz.a(iz.C(bup.bI), iz.C(bup.n));
      vk var2 = iy.e.a(bup.bI, var1, this.b);
      this.a.accept(e(bup.bI, var2));
   }

   private void o() {
      this.a(bmd.lP);
      this.a.accept(in.a(bup.bS).a(im.b(im.a().a((cfj)cex.X, (Comparable)cfl.c).a((cfj)cex.W, (Comparable)cfl.c).a((cfj)cex.Y, (Comparable)cfl.c).a((cfj)cex.Z, (Comparable)cfl.c), im.a().a((cfj)cex.X, (Comparable)cfl.b, (Comparable[])(cfl.a)).a((cfj)cex.W, (Comparable)cfl.b, (Comparable[])(cfl.a)), im.a().a((cfj)cex.W, (Comparable)cfl.b, (Comparable[])(cfl.a)).a((cfj)cex.Y, (Comparable)cfl.b, (Comparable[])(cfl.a)), im.a().a((cfj)cex.Y, (Comparable)cfl.b, (Comparable[])(cfl.a)).a((cfj)cex.Z, (Comparable)cfl.b, (Comparable[])(cfl.a)), im.a().a((cfj)cex.Z, (Comparable)cfl.b, (Comparable[])(cfl.a)).a((cfj)cex.X, (Comparable)cfl.b, (Comparable[])(cfl.a))), ir.a().a((it)is.c, (Object)iw.a("redstone_dust_dot"))).a((im)im.a().a((cfj)cex.X, (Comparable)cfl.b, (Comparable[])(cfl.a)), (ir)ir.a().a((it)is.c, (Object)iw.a("redstone_dust_side0"))).a((im)im.a().a((cfj)cex.Y, (Comparable)cfl.b, (Comparable[])(cfl.a)), (ir)ir.a().a((it)is.c, (Object)iw.a("redstone_dust_side_alt0"))).a((im)im.a().a((cfj)cex.W, (Comparable)cfl.b, (Comparable[])(cfl.a)), (ir)ir.a().a((it)is.c, (Object)iw.a("redstone_dust_side_alt1")).a((it)is.b, (Object)is.a.d)).a((im)im.a().a((cfj)cex.Z, (Comparable)cfl.b, (Comparable[])(cfl.a)), (ir)ir.a().a((it)is.c, (Object)iw.a("redstone_dust_side1")).a((it)is.b, (Object)is.a.d)).a((im)im.a().a((cfj)cex.X, (Comparable)cfl.a), (ir)ir.a().a((it)is.c, (Object)iw.a("redstone_dust_up"))).a((im)im.a().a((cfj)cex.W, (Comparable)cfl.a), (ir)ir.a().a((it)is.c, (Object)iw.a("redstone_dust_up")).a((it)is.b, (Object)is.a.b)).a((im)im.a().a((cfj)cex.Y, (Comparable)cfl.a), (ir)ir.a().a((it)is.c, (Object)iw.a("redstone_dust_up")).a((it)is.b, (Object)is.a.c)).a((im)im.a().a((cfj)cex.Z, (Comparable)cfl.a), (ir)ir.a().a((it)is.c, (Object)iw.a("redstone_dust_up")).a((it)is.b, (Object)is.a.d)));
   }

   private void p() {
      this.a(bmd.jV);
      this.a.accept(io.a(bup.fu).a(c()).a((ip)ip.a((cfj)cex.aG, (cfj)cex.w).a(cfa.a, (Comparable)false, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.fu))).a(cfa.a, (Comparable)true, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.fu, "_on"))).a(cfa.b, (Comparable)false, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.fu, "_subtract"))).a(cfa.b, (Comparable)true, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.fu, "_on_subtract")))));
   }

   private void q() {
      iz var1 = iz.a(bup.id);
      iz var2 = iz.a(iz.a(bup.hR, "_side"), var1.a(ja.f));
      vk var3 = iy.G.a(bup.hR, var2, this.b);
      vk var4 = iy.H.a(bup.hR, var2, this.b);
      vk var5 = iy.e.b(bup.hR, "_double", var2, this.b);
      this.a.accept(h(bup.hR, var3, var4, var5));
      this.a.accept(e(bup.id, iy.c.a(bup.id, var1, this.b)));
   }

   private void r() {
      this.a(bmd.nB);
      this.a.accept(in.a(bup.ea).a(ir.a().a((it)is.c, (Object)iz.C(bup.ea))).a((im)im.a().a((cfj)cex.k, (Comparable)true), (ir)ir.a().a((it)is.c, (Object)iz.a(bup.ea, "_bottle0"))).a((im)im.a().a((cfj)cex.l, (Comparable)true), (ir)ir.a().a((it)is.c, (Object)iz.a(bup.ea, "_bottle1"))).a((im)im.a().a((cfj)cex.m, (Comparable)true), (ir)ir.a().a((it)is.c, (Object)iz.a(bup.ea, "_bottle2"))).a((im)im.a().a((cfj)cex.k, (Comparable)false), (ir)ir.a().a((it)is.c, (Object)iz.a(bup.ea, "_empty0"))).a((im)im.a().a((cfj)cex.l, (Comparable)false), (ir)ir.a().a((it)is.c, (Object)iz.a(bup.ea, "_empty1"))).a((im)im.a().a((cfj)cex.m, (Comparable)false), (ir)ir.a().a((it)is.c, (Object)iz.a(bup.ea, "_empty2"))));
   }

   private void p(buo var1) {
      vk var2 = iy.aJ.a(var1, iz.b(var1), this.b);
      vk var3 = iw.a("mushroom_block_inside");
      this.a.accept(in.a(var1).a((im)im.a().a((cfj)cex.I, (Comparable)true), (ir)ir.a().a((it)is.c, (Object)var2)).a((im)im.a().a((cfj)cex.J, (Comparable)true), (ir)ir.a().a((it)is.c, (Object)var2).a((it)is.b, (Object)is.a.b).a((it)is.d, (Object)true)).a((im)im.a().a((cfj)cex.K, (Comparable)true), (ir)ir.a().a((it)is.c, (Object)var2).a((it)is.b, (Object)is.a.c).a((it)is.d, (Object)true)).a((im)im.a().a((cfj)cex.L, (Comparable)true), (ir)ir.a().a((it)is.c, (Object)var2).a((it)is.b, (Object)is.a.d).a((it)is.d, (Object)true)).a((im)im.a().a((cfj)cex.G, (Comparable)true), (ir)ir.a().a((it)is.c, (Object)var2).a((it)is.a, (Object)is.a.d).a((it)is.d, (Object)true)).a((im)im.a().a((cfj)cex.H, (Comparable)true), (ir)ir.a().a((it)is.c, (Object)var2).a((it)is.a, (Object)is.a.b).a((it)is.d, (Object)true)).a((im)im.a().a((cfj)cex.I, (Comparable)false), (ir)ir.a().a((it)is.c, (Object)var3)).a((im)im.a().a((cfj)cex.J, (Comparable)false), (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.b, (Object)is.a.b).a((it)is.d, (Object)false)).a((im)im.a().a((cfj)cex.K, (Comparable)false), (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.b, (Object)is.a.c).a((it)is.d, (Object)false)).a((im)im.a().a((cfj)cex.L, (Comparable)false), (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.b, (Object)is.a.d).a((it)is.d, (Object)false)).a((im)im.a().a((cfj)cex.G, (Comparable)false), (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.a, (Object)is.a.d).a((it)is.d, (Object)false)).a((im)im.a().a((cfj)cex.H, (Comparable)false), (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.a, (Object)is.a.b).a((it)is.d, (Object)false)));
      this.c(var1, jb.a.a(var1, "_inventory", this.b));
   }

   private void s() {
      this.a(bmd.mN);
      this.a.accept(io.a(bup.cW).a((ip)ip.a((cfj)cex.al).a(0, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.cW))).a(1, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.cW, "_slice1"))).a(2, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.cW, "_slice2"))).a(3, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.cW, "_slice3"))).a(4, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.cW, "_slice4"))).a(5, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.cW, "_slice5"))).a(6, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.cW, "_slice6")))));
   }

   private void t() {
      iz var1 = (new iz()).a(ja.c, iz.a(bup.lV, "_side3")).a(ja.o, iz.C(bup.s)).a(ja.n, iz.a(bup.lV, "_top")).a(ja.j, iz.a(bup.lV, "_side3")).a(ja.l, iz.a(bup.lV, "_side3")).a(ja.k, iz.a(bup.lV, "_side1")).a(ja.m, iz.a(bup.lV, "_side2"));
      this.a.accept(e(bup.lV, iy.a.a(bup.lV, var1, this.b)));
   }

   private void u() {
      iz var1 = (new iz()).a(ja.c, iz.a(bup.lZ, "_front")).a(ja.o, iz.a(bup.lZ, "_bottom")).a(ja.n, iz.a(bup.lZ, "_top")).a(ja.j, iz.a(bup.lZ, "_front")).a(ja.k, iz.a(bup.lZ, "_front")).a(ja.l, iz.a(bup.lZ, "_side")).a(ja.m, iz.a(bup.lZ, "_side"));
      this.a.accept(e(bup.lZ, iy.a.a(bup.lZ, var1, this.b)));
   }

   private void a(buo var1, buo var2, BiFunction<buo, buo, iz> var3) {
      iz var4 = (iz)var3.apply(var1, var2);
      this.a.accept(e(var1, iy.a.a(var1, var4, this.b)));
   }

   private void v() {
      iz var1 = iz.j(bup.cK);
      this.a.accept(e(bup.cK, iw.a(bup.cK)));
      this.a(bup.cU, var1);
      this.a(bup.cV, var1);
   }

   private void a(buo var1, iz var2) {
      vk var3 = iy.i.a(var1, var2.c(ja.g, iz.C(var1)), this.b);
      this.a.accept(io.a(var1, ir.a().a((it)is.c, (Object)var3)).a(b()));
   }

   private void w() {
      this.a(bmd.nC);
      this.a.accept(io.a(bup.eb).a((ip)ip.a((cfj)cex.ar).a(0, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.eb))).a(1, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.eb, "_level1"))).a(2, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.eb, "_level2"))).a(3, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.eb, "_level3")))));
   }

   private void g(buo var1, buo var2) {
      iz var3 = (new iz()).a(ja.d, iz.a(var2, "_top")).a(ja.i, iz.C(var1));
      this.a(var1, var3, iy.e);
   }

   private void x() {
      iz var1 = iz.b(bup.iy);
      vk var2 = iy.ae.a(bup.iy, var1, this.b);
      vk var3 = this.a(bup.iy, "_dead", iy.ae, (var1x) -> {
         return var1.c(ja.b, var1x);
      });
      this.a.accept(io.a(bup.iy).a(a((cfj)cex.ah, (int)5, (vk)var3, (vk)var2)));
   }

   private void q(buo var1) {
      iz var2 = (new iz()).a(ja.f, iz.a(bup.bY, "_top")).a(ja.i, iz.a(bup.bY, "_side")).a(ja.g, iz.a(var1, "_front"));
      iz var3 = (new iz()).a(ja.i, iz.a(bup.bY, "_top")).a(ja.g, iz.a(var1, "_front_vertical"));
      vk var4 = iy.i.a(var1, var2, this.b);
      vk var5 = iy.k.a(var1, var3, this.b);
      this.a.accept(io.a(var1).a((ip)ip.a((cfj)cex.M).a(gc.a, (ir)ir.a().a((it)is.c, (Object)var5).a((it)is.a, (Object)is.a.c)).a(gc.b, (ir)ir.a().a((it)is.c, (Object)var5)).a(gc.c, (ir)ir.a().a((it)is.c, (Object)var4)).a(gc.f, (ir)ir.a().a((it)is.c, (Object)var4).a((it)is.b, (Object)is.a.b)).a(gc.d, (ir)ir.a().a((it)is.c, (Object)var4).a((it)is.b, (Object)is.a.c)).a(gc.e, (ir)ir.a().a((it)is.c, (Object)var4).a((it)is.b, (Object)is.a.d))));
   }

   private void y() {
      vk var1 = iw.a(bup.ed);
      vk var2 = iw.a(bup.ed, "_filled");
      this.a.accept(io.a(bup.ed).a((ip)ip.a((cfj)cex.h).a(false, (ir)ir.a().a((it)is.c, (Object)var1)).a(true, (ir)ir.a().a((it)is.c, (Object)var2))).a(c()));
   }

   private void z() {
      vk var1 = iw.a(bup.ix, "_side");
      vk var2 = iw.a(bup.ix, "_noside");
      vk var3 = iw.a(bup.ix, "_noside1");
      vk var4 = iw.a(bup.ix, "_noside2");
      vk var5 = iw.a(bup.ix, "_noside3");
      this.a.accept(in.a(bup.ix).a((im)im.a().a((cfj)cex.I, (Comparable)true), (ir)ir.a().a((it)is.c, (Object)var1)).a((im)im.a().a((cfj)cex.J, (Comparable)true), (ir)ir.a().a((it)is.c, (Object)var1).a((it)is.b, (Object)is.a.b).a((it)is.d, (Object)true)).a((im)im.a().a((cfj)cex.K, (Comparable)true), (ir)ir.a().a((it)is.c, (Object)var1).a((it)is.b, (Object)is.a.c).a((it)is.d, (Object)true)).a((im)im.a().a((cfj)cex.L, (Comparable)true), (ir)ir.a().a((it)is.c, (Object)var1).a((it)is.b, (Object)is.a.d).a((it)is.d, (Object)true)).a((im)im.a().a((cfj)cex.G, (Comparable)true), (ir)ir.a().a((it)is.c, (Object)var1).a((it)is.a, (Object)is.a.d).a((it)is.d, (Object)true)).a((im)im.a().a((cfj)cex.H, (Comparable)true), (ir)ir.a().a((it)is.c, (Object)var1).a((it)is.a, (Object)is.a.b).a((it)is.d, (Object)true)).a((im)im.a().a((cfj)cex.I, (Comparable)false), (ir[])(ir.a().a((it)is.c, (Object)var2).a((it)is.e, (int)2), ir.a().a((it)is.c, (Object)var3), ir.a().a((it)is.c, (Object)var4), ir.a().a((it)is.c, (Object)var5))).a((im)im.a().a((cfj)cex.J, (Comparable)false), (ir[])(ir.a().a((it)is.c, (Object)var3).a((it)is.b, (Object)is.a.b).a((it)is.d, (Object)true), ir.a().a((it)is.c, (Object)var4).a((it)is.b, (Object)is.a.b).a((it)is.d, (Object)true), ir.a().a((it)is.c, (Object)var5).a((it)is.b, (Object)is.a.b).a((it)is.d, (Object)true), ir.a().a((it)is.c, (Object)var2).a((it)is.e, (int)2).a((it)is.b, (Object)is.a.b).a((it)is.d, (Object)true))).a((im)im.a().a((cfj)cex.K, (Comparable)false), (ir[])(ir.a().a((it)is.c, (Object)var4).a((it)is.b, (Object)is.a.c).a((it)is.d, (Object)true), ir.a().a((it)is.c, (Object)var5).a((it)is.b, (Object)is.a.c).a((it)is.d, (Object)true), ir.a().a((it)is.c, (Object)var2).a((it)is.e, (int)2).a((it)is.b, (Object)is.a.c).a((it)is.d, (Object)true), ir.a().a((it)is.c, (Object)var3).a((it)is.b, (Object)is.a.c).a((it)is.d, (Object)true))).a((im)im.a().a((cfj)cex.L, (Comparable)false), (ir[])(ir.a().a((it)is.c, (Object)var5).a((it)is.b, (Object)is.a.d).a((it)is.d, (Object)true), ir.a().a((it)is.c, (Object)var2).a((it)is.e, (int)2).a((it)is.b, (Object)is.a.d).a((it)is.d, (Object)true), ir.a().a((it)is.c, (Object)var3).a((it)is.b, (Object)is.a.d).a((it)is.d, (Object)true), ir.a().a((it)is.c, (Object)var4).a((it)is.b, (Object)is.a.d).a((it)is.d, (Object)true))).a((im)im.a().a((cfj)cex.G, (Comparable)false), (ir[])(ir.a().a((it)is.c, (Object)var2).a((it)is.e, (int)2).a((it)is.a, (Object)is.a.d).a((it)is.d, (Object)true), ir.a().a((it)is.c, (Object)var5).a((it)is.a, (Object)is.a.d).a((it)is.d, (Object)true), ir.a().a((it)is.c, (Object)var3).a((it)is.a, (Object)is.a.d).a((it)is.d, (Object)true), ir.a().a((it)is.c, (Object)var4).a((it)is.a, (Object)is.a.d).a((it)is.d, (Object)true))).a((im)im.a().a((cfj)cex.H, (Comparable)false), (ir[])(ir.a().a((it)is.c, (Object)var5).a((it)is.a, (Object)is.a.b).a((it)is.d, (Object)true), ir.a().a((it)is.c, (Object)var4).a((it)is.a, (Object)is.a.b).a((it)is.d, (Object)true), ir.a().a((it)is.c, (Object)var3).a((it)is.a, (Object)is.a.b).a((it)is.d, (Object)true), ir.a().a((it)is.c, (Object)var2).a((it)is.e, (int)2).a((it)is.a, (Object)is.a.b).a((it)is.d, (Object)true))));
   }

   private void A() {
      this.a.accept(in.a(bup.na).a(ir.a().a((it)is.c, (Object)iz.C(bup.na))).a((im)im.a().a((cfj)cex.as, (int)1), (ir)ir.a().a((it)is.c, (Object)iz.a(bup.na, "_contents1"))).a((im)im.a().a((cfj)cex.as, (int)2), (ir)ir.a().a((it)is.c, (Object)iz.a(bup.na, "_contents2"))).a((im)im.a().a((cfj)cex.as, (int)3), (ir)ir.a().a((it)is.c, (Object)iz.a(bup.na, "_contents3"))).a((im)im.a().a((cfj)cex.as, (int)4), (ir)ir.a().a((it)is.c, (Object)iz.a(bup.na, "_contents4"))).a((im)im.a().a((cfj)cex.as, (int)5), (ir)ir.a().a((it)is.c, (Object)iz.a(bup.na, "_contents5"))).a((im)im.a().a((cfj)cex.as, (int)6), (ir)ir.a().a((it)is.c, (Object)iz.a(bup.na, "_contents6"))).a((im)im.a().a((cfj)cex.as, (int)7), (ir)ir.a().a((it)is.c, (Object)iz.a(bup.na, "_contents7"))).a((im)im.a().a((cfj)cex.as, (int)8), (ir)ir.a().a((it)is.c, (Object)iz.a(bup.na, "_contents_ready"))));
   }

   private void r(buo var1) {
      iz var2 = (new iz()).a(ja.e, iz.C(bup.cL)).a(ja.f, iz.C(var1)).a(ja.i, iz.a(var1, "_side"));
      this.a.accept(e(var1, iy.h.a(var1, var2, this.b)));
   }

   private void B() {
      vk var1 = iz.a(bup.fv, "_side");
      iz var2 = (new iz()).a(ja.f, iz.a(bup.fv, "_top")).a(ja.i, var1);
      iz var3 = (new iz()).a(ja.f, iz.a(bup.fv, "_inverted_top")).a(ja.i, var1);
      this.a.accept(io.a(bup.fv).a((ip)ip.a((cfj)cex.p).a(false, (ir)ir.a().a((it)is.c, (Object)iy.af.a(bup.fv, var2, this.b))).a(true, (ir)ir.a().a((it)is.c, (Object)iy.af.a(iw.a(bup.fv, "_inverted"), var3, this.b)))));
   }

   private void s(buo var1) {
      this.a.accept(io.a(var1, ir.a().a((it)is.c, (Object)iw.a(var1))).a(this.j()));
   }

   private void C() {
      iz var1 = (new iz()).a(ja.B, iz.C(bup.j)).a(ja.f, iz.C(bup.bX));
      iz var2 = (new iz()).a(ja.B, iz.C(bup.j)).a(ja.f, iz.a(bup.bX, "_moist"));
      vk var3 = iy.aq.a(bup.bX, var1, this.b);
      vk var4 = iy.aq.a(iz.a(bup.bX, "_moist"), var2, this.b);
      this.a.accept(io.a(bup.bX).a(a((cfj)cex.aw, (int)7, (vk)var4, (vk)var3)));
   }

   private List<vk> t(buo var1) {
      vk var2 = iy.ar.a(iw.a(var1, "_floor0"), iz.r(var1), this.b);
      vk var3 = iy.ar.a(iw.a(var1, "_floor1"), iz.s(var1), this.b);
      return ImmutableList.of(var2, var3);
   }

   private List<vk> u(buo var1) {
      vk var2 = iy.as.a(iw.a(var1, "_side0"), iz.r(var1), this.b);
      vk var3 = iy.as.a(iw.a(var1, "_side1"), iz.s(var1), this.b);
      vk var4 = iy.at.a(iw.a(var1, "_side_alt0"), iz.r(var1), this.b);
      vk var5 = iy.at.a(iw.a(var1, "_side_alt1"), iz.s(var1), this.b);
      return ImmutableList.of(var2, var3, var4, var5);
   }

   private List<vk> v(buo var1) {
      vk var2 = iy.au.a(iw.a(var1, "_up0"), iz.r(var1), this.b);
      vk var3 = iy.au.a(iw.a(var1, "_up1"), iz.s(var1), this.b);
      vk var4 = iy.av.a(iw.a(var1, "_up_alt0"), iz.r(var1), this.b);
      vk var5 = iy.av.a(iw.a(var1, "_up_alt1"), iz.s(var1), this.b);
      return ImmutableList.of(var2, var3, var4, var5);
   }

   private static List<ir> a(List<vk> var0, UnaryOperator<ir> var1) {
      return (List)var0.stream().map((var0x) -> {
         return ir.a().a((it)is.c, (Object)var0x);
      }).map(var1).collect(Collectors.toList());
   }

   private void D() {
      im var1 = im.a().a((cfj)cex.I, (Comparable)false).a((cfj)cex.J, (Comparable)false).a((cfj)cex.K, (Comparable)false).a((cfj)cex.L, (Comparable)false).a((cfj)cex.G, (Comparable)false);
      List<vk> var2 = this.t(bup.bN);
      List<vk> var3 = this.u(bup.bN);
      List<vk> var4 = this.v(bup.bN);
      this.a.accept(in.a(bup.bN).a((im)var1, (List)a(var2, (var0) -> {
         return var0;
      })).a(im.b(im.a().a((cfj)cex.I, (Comparable)true), var1), a(var3, (var0) -> {
         return var0;
      })).a(im.b(im.a().a((cfj)cex.J, (Comparable)true), var1), a(var3, (var0) -> {
         return var0.a((it)is.b, (Object)is.a.b);
      })).a(im.b(im.a().a((cfj)cex.K, (Comparable)true), var1), a(var3, (var0) -> {
         return var0.a((it)is.b, (Object)is.a.c);
      })).a(im.b(im.a().a((cfj)cex.L, (Comparable)true), var1), a(var3, (var0) -> {
         return var0.a((it)is.b, (Object)is.a.d);
      })).a((im)im.a().a((cfj)cex.G, (Comparable)true), (List)a(var4, (var0) -> {
         return var0;
      })));
   }

   private void E() {
      List<vk> var1 = this.t(bup.bO);
      List<vk> var2 = this.u(bup.bO);
      this.a.accept(in.a(bup.bO).a(a(var1, (var0) -> {
         return var0;
      })).a(a(var2, (var0) -> {
         return var0;
      })).a(a(var2, (var0) -> {
         return var0.a((it)is.b, (Object)is.a.b);
      })).a(a(var2, (var0) -> {
         return var0.a((it)is.b, (Object)is.a.c);
      })).a(a(var2, (var0) -> {
         return var0.a((it)is.b, (Object)is.a.d);
      })));
   }

   private void w(buo var1) {
      vk var2 = jb.o.a(var1, this.b);
      vk var3 = jb.p.a(var1, this.b);
      this.a(var1.h());
      this.a.accept(io.a(var1).a(a(cex.j, var3, var2)));
   }

   private void F() {
      this.a.accept(io.a(bup.iI).a((ip)ip.a((cfj)cex.ag).a(0, (ir)ir.a().a((it)is.c, (Object)this.a(bup.iI, "_0", iy.c, iz::b))).a(1, (ir)ir.a().a((it)is.c, (Object)this.a(bup.iI, "_1", iy.c, iz::b))).a(2, (ir)ir.a().a((it)is.c, (Object)this.a(bup.iI, "_2", iy.c, iz::b))).a(3, (ir)ir.a().a((it)is.c, (Object)this.a(bup.iI, "_3", iy.c, iz::b)))));
   }

   private void G() {
      vk var1 = iz.C(bup.j);
      iz var2 = (new iz()).a(ja.e, var1).b(ja.e, ja.c).a(ja.f, iz.a(bup.i, "_top")).a(ja.i, iz.a(bup.i, "_snow"));
      ir var3 = ir.a().a((it)is.c, (Object)iy.h.a(bup.i, "_snow", var2, this.b));
      this.a(bup.i, iw.a(bup.i), var3);
      vk var4 = jb.e.get(bup.dT).a((var1x) -> {
         var1x.a(ja.e, var1);
      }).a(bup.dT, this.b);
      this.a(bup.dT, var4, var3);
      vk var5 = jb.e.get(bup.l).a((var1x) -> {
         var1x.a(ja.e, var1);
      }).a(bup.l, this.b);
      this.a(bup.l, var5, var3);
   }

   private void a(buo var1, vk var2, ir var3) {
      List<ir> var4 = Arrays.asList(a(var2));
      this.a.accept(io.a(var1).a((ip)ip.a((cfj)cex.z).a(true, (ir)var3).a(false, (List)var4)));
   }

   private void H() {
      this.a(bmd.ms);
      this.a.accept(io.a(bup.eh).a((ip)ip.a((cfj)cex.af).a(0, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.eh, "_stage0"))).a(1, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.eh, "_stage1"))).a(2, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.eh, "_stage2")))).a(c()));
   }

   private void I() {
      this.a.accept(d(bup.iE, iw.a(bup.iE)));
   }

   private void h(buo var1, buo var2) {
      iz var3 = iz.b(var2);
      vk var4 = iy.D.a(var1, var3, this.b);
      vk var5 = iy.E.a(var1, var3, this.b);
      this.a.accept(io.a(var1).a(a((cfj)cex.az, (int)1, (vk)var5, (vk)var4)));
   }

   private void J() {
      vk var1 = iw.a(bup.fy);
      vk var2 = iw.a(bup.fy, "_side");
      this.a(bmd.fl);
      this.a.accept(io.a(bup.fy).a((ip)ip.a((cfj)cex.N).a(gc.a, (ir)ir.a().a((it)is.c, (Object)var1)).a(gc.c, (ir)ir.a().a((it)is.c, (Object)var2)).a(gc.f, (ir)ir.a().a((it)is.c, (Object)var2).a((it)is.b, (Object)is.a.b)).a(gc.d, (ir)ir.a().a((it)is.c, (Object)var2).a((it)is.b, (Object)is.a.c)).a(gc.e, (ir)ir.a().a((it)is.c, (Object)var2).a((it)is.b, (Object)is.a.d))));
   }

   private void i(buo var1, buo var2) {
      vk var3 = iw.a(var1);
      this.a.accept(io.a(var2, ir.a().a((it)is.c, (Object)var3)));
      this.c(var2, var3);
   }

   private void K() {
      vk var1 = iw.a(bup.dH, "_post_ends");
      vk var2 = iw.a(bup.dH, "_post");
      vk var3 = iw.a(bup.dH, "_cap");
      vk var4 = iw.a(bup.dH, "_cap_alt");
      vk var5 = iw.a(bup.dH, "_side");
      vk var6 = iw.a(bup.dH, "_side_alt");
      this.a.accept(in.a(bup.dH).a(ir.a().a((it)is.c, (Object)var1)).a((im)im.a().a((cfj)cex.I, (Comparable)false).a((cfj)cex.J, (Comparable)false).a((cfj)cex.K, (Comparable)false).a((cfj)cex.L, (Comparable)false), (ir)ir.a().a((it)is.c, (Object)var2)).a((im)im.a().a((cfj)cex.I, (Comparable)true).a((cfj)cex.J, (Comparable)false).a((cfj)cex.K, (Comparable)false).a((cfj)cex.L, (Comparable)false), (ir)ir.a().a((it)is.c, (Object)var3)).a((im)im.a().a((cfj)cex.I, (Comparable)false).a((cfj)cex.J, (Comparable)true).a((cfj)cex.K, (Comparable)false).a((cfj)cex.L, (Comparable)false), (ir)ir.a().a((it)is.c, (Object)var3).a((it)is.b, (Object)is.a.b)).a((im)im.a().a((cfj)cex.I, (Comparable)false).a((cfj)cex.J, (Comparable)false).a((cfj)cex.K, (Comparable)true).a((cfj)cex.L, (Comparable)false), (ir)ir.a().a((it)is.c, (Object)var4)).a((im)im.a().a((cfj)cex.I, (Comparable)false).a((cfj)cex.J, (Comparable)false).a((cfj)cex.K, (Comparable)false).a((cfj)cex.L, (Comparable)true), (ir)ir.a().a((it)is.c, (Object)var4).a((it)is.b, (Object)is.a.b)).a((im)im.a().a((cfj)cex.I, (Comparable)true), (ir)ir.a().a((it)is.c, (Object)var5)).a((im)im.a().a((cfj)cex.J, (Comparable)true), (ir)ir.a().a((it)is.c, (Object)var5).a((it)is.b, (Object)is.a.b)).a((im)im.a().a((cfj)cex.K, (Comparable)true), (ir)ir.a().a((it)is.c, (Object)var6)).a((im)im.a().a((cfj)cex.L, (Comparable)true), (ir)ir.a().a((it)is.c, (Object)var6).a((it)is.b, (Object)is.a.b)));
      this.b(bup.dH);
   }

   private void x(buo var1) {
      this.a.accept(io.a(var1, ir.a().a((it)is.c, (Object)iw.a(var1))).a(b()));
   }

   private void L() {
      vk var1 = iw.a(bup.cp);
      vk var2 = iw.a(bup.cp, "_on");
      this.b(bup.cp);
      this.a.accept(io.a(bup.cp).a(a(cex.w, var1, var2)).a((ip)ip.a((cfj)cex.Q, (cfj)cex.O).a(cet.c, (Comparable)gc.c, (ir)ir.a().a((it)is.a, (Object)is.a.c).a((it)is.b, (Object)is.a.c)).a(cet.c, (Comparable)gc.f, (ir)ir.a().a((it)is.a, (Object)is.a.c).a((it)is.b, (Object)is.a.d)).a(cet.c, (Comparable)gc.d, (ir)ir.a().a((it)is.a, (Object)is.a.c)).a(cet.c, (Comparable)gc.e, (ir)ir.a().a((it)is.a, (Object)is.a.c).a((it)is.b, (Object)is.a.b)).a(cet.a, (Comparable)gc.c, (ir)ir.a()).a(cet.a, (Comparable)gc.f, (ir)ir.a().a((it)is.b, (Object)is.a.b)).a(cet.a, (Comparable)gc.d, (ir)ir.a().a((it)is.b, (Object)is.a.c)).a(cet.a, (Comparable)gc.e, (ir)ir.a().a((it)is.b, (Object)is.a.d)).a(cet.b, (Comparable)gc.c, (ir)ir.a().a((it)is.a, (Object)is.a.b)).a(cet.b, (Comparable)gc.f, (ir)ir.a().a((it)is.a, (Object)is.a.b).a((it)is.b, (Object)is.a.b)).a(cet.b, (Comparable)gc.d, (ir)ir.a().a((it)is.a, (Object)is.a.b).a((it)is.b, (Object)is.a.c)).a(cet.b, (Comparable)gc.e, (ir)ir.a().a((it)is.a, (Object)is.a.b).a((it)is.b, (Object)is.a.d))));
   }

   private void M() {
      this.b(bup.dU);
      this.a.accept(d(bup.dU, iw.a(bup.dU)));
   }

   private void N() {
      this.a.accept(io.a(bup.cT).a((ip)ip.a((cfj)cex.E).a(gc.a.a, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.cT, "_ns"))).a(gc.a.c, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.cT, "_ew")))));
   }

   private void O() {
      vk var1 = jb.a.a(bup.cL, this.b);
      this.a.accept(io.a(bup.cL, ir.a().a((it)is.c, (Object)var1), ir.a().a((it)is.c, (Object)var1).a((it)is.a, (Object)is.a.b), ir.a().a((it)is.c, (Object)var1).a((it)is.a, (Object)is.a.c), ir.a().a((it)is.c, (Object)var1).a((it)is.a, (Object)is.a.d), ir.a().a((it)is.c, (Object)var1).a((it)is.b, (Object)is.a.b), ir.a().a((it)is.c, (Object)var1).a((it)is.b, (Object)is.a.b).a((it)is.a, (Object)is.a.b), ir.a().a((it)is.c, (Object)var1).a((it)is.b, (Object)is.a.b).a((it)is.a, (Object)is.a.c), ir.a().a((it)is.c, (Object)var1).a((it)is.b, (Object)is.a.b).a((it)is.a, (Object)is.a.d), ir.a().a((it)is.c, (Object)var1).a((it)is.b, (Object)is.a.c), ir.a().a((it)is.c, (Object)var1).a((it)is.b, (Object)is.a.c).a((it)is.a, (Object)is.a.b), ir.a().a((it)is.c, (Object)var1).a((it)is.b, (Object)is.a.c).a((it)is.a, (Object)is.a.c), ir.a().a((it)is.c, (Object)var1).a((it)is.b, (Object)is.a.c).a((it)is.a, (Object)is.a.d), ir.a().a((it)is.c, (Object)var1).a((it)is.b, (Object)is.a.d), ir.a().a((it)is.c, (Object)var1).a((it)is.b, (Object)is.a.d).a((it)is.a, (Object)is.a.b), ir.a().a((it)is.c, (Object)var1).a((it)is.b, (Object)is.a.d).a((it)is.a, (Object)is.a.c), ir.a().a((it)is.c, (Object)var1).a((it)is.b, (Object)is.a.d).a((it)is.a, (Object)is.a.d)));
   }

   private void P() {
      vk var1 = iw.a(bup.iO);
      vk var2 = iw.a(bup.iO, "_on");
      this.a.accept(io.a(bup.iO).a(a(cex.w, var2, var1)).a(e()));
   }

   private void Q() {
      iz var1 = (new iz()).a(ja.e, iz.a(bup.aW, "_bottom")).a(ja.i, iz.a(bup.aW, "_side"));
      vk var2 = iz.a(bup.aW, "_top_sticky");
      vk var3 = iz.a(bup.aW, "_top");
      iz var4 = var1.c(ja.E, var2);
      iz var5 = var1.c(ja.E, var3);
      vk var6 = iw.a(bup.aW, "_base");
      this.a(bup.aW, var6, var5);
      this.a(bup.aP, var6, var4);
      vk var7 = iy.h.a(bup.aW, "_inventory", var1.c(ja.f, var3), this.b);
      vk var8 = iy.h.a(bup.aP, "_inventory", var1.c(ja.f, var2), this.b);
      this.c(bup.aW, var7);
      this.c(bup.aP, var8);
   }

   private void a(buo var1, vk var2, iz var3) {
      vk var4 = iy.aB.a(var1, var3, this.b);
      this.a.accept(io.a(var1).a(a(cex.g, var2, var4)).a(e()));
   }

   private void R() {
      iz var1 = (new iz()).a(ja.F, iz.a(bup.aW, "_top")).a(ja.i, iz.a(bup.aW, "_side"));
      iz var2 = var1.c(ja.E, iz.a(bup.aW, "_top_sticky"));
      iz var3 = var1.c(ja.E, iz.a(bup.aW, "_top"));
      this.a.accept(io.a(bup.aX).a((ip)ip.a((cfj)cex.x, (cfj)cex.aJ).a(false, (Comparable)cfi.a, (ir)ir.a().a((it)is.c, (Object)iy.aC.a(bup.aW, "_head", var3, this.b))).a(false, (Comparable)cfi.b, (ir)ir.a().a((it)is.c, (Object)iy.aC.a(bup.aW, "_head_sticky", var2, this.b))).a(true, (Comparable)cfi.a, (ir)ir.a().a((it)is.c, (Object)iy.aD.a(bup.aW, "_head_short", var3, this.b))).a(true, (Comparable)cfi.b, (ir)ir.a().a((it)is.c, (Object)iy.aD.a(bup.aW, "_head_short_sticky", var2, this.b)))).a(e()));
   }

   private void S() {
      vk var1 = iw.a(bup.lQ, "_stable");
      vk var2 = iw.a(bup.lQ, "_unstable");
      this.c(bup.lQ, var1);
      this.a.accept(io.a(bup.lQ).a(a(cex.b, var2, var1)));
   }

   private void T() {
      vk var1 = jb.a.a(bup.eg, this.b);
      vk var2 = this.a(bup.eg, "_on", iy.c, iz::b);
      this.a.accept(io.a(bup.eg).a(a(cex.r, var2, var1)));
   }

   private void j(buo var1, buo var2) {
      iz var3 = iz.u(var1);
      this.a.accept(e(var1, iy.az.a(var1, var3, this.b)));
      this.a.accept(io.a(var2, ir.a().a((it)is.c, (Object)iy.aA.a(var2, var3, this.b))).a(d()));
      this.b(var1);
      this.a(var2);
   }

   private void U() {
      iz var1 = iz.u(bup.cz);
      iz var2 = iz.i(iz.a(bup.cz, "_off"));
      vk var3 = iy.az.a(bup.cz, var1, this.b);
      vk var4 = iy.az.a(bup.cz, "_off", var2, this.b);
      this.a.accept(io.a(bup.cz).a(a(cex.r, var3, var4)));
      vk var5 = iy.aA.a(bup.cA, var1, this.b);
      vk var6 = iy.aA.a(bup.cA, "_off", var2, this.b);
      this.a.accept(io.a(bup.cA).a(a(cex.r, var5, var6)).a(d()));
      this.b(bup.cz);
      this.a(bup.cA);
   }

   private void V() {
      this.a(bmd.jU);
      this.a.accept(io.a(bup.cX).a(ip.a(cex.am, cex.s, cex.w).a((var0, var1, var2) -> {
         StringBuilder var3 = new StringBuilder();
         var3.append('_').append(var0).append("tick");
         if (var2) {
            var3.append("_on");
         }

         if (var1) {
            var3.append("_locked");
         }

         return ir.a().a((it)is.c, (Object)iz.a(bup.cX, var3.toString()));
      })).a(c()));
   }

   private void W() {
      this.a(bmd.aP);
      this.a.accept(io.a(bup.kU).a((ip)ip.a((cfj)cex.ay, (cfj)cex.C).a(1, (Comparable)false, (List)Arrays.asList(a(iw.a("dead_sea_pickle")))).a(2, (Comparable)false, (List)Arrays.asList(a(iw.a("two_dead_sea_pickles")))).a(3, (Comparable)false, (List)Arrays.asList(a(iw.a("three_dead_sea_pickles")))).a(4, (Comparable)false, (List)Arrays.asList(a(iw.a("four_dead_sea_pickles")))).a(1, (Comparable)true, (List)Arrays.asList(a(iw.a("sea_pickle")))).a(2, (Comparable)true, (List)Arrays.asList(a(iw.a("two_sea_pickles")))).a(3, (Comparable)true, (List)Arrays.asList(a(iw.a("three_sea_pickles")))).a(4, (Comparable)true, (List)Arrays.asList(a(iw.a("four_sea_pickles"))))));
   }

   private void X() {
      iz var1 = iz.a(bup.cC);
      vk var2 = iy.c.a(bup.cE, var1, this.b);
      this.a.accept(io.a(bup.cC).a(ip.a((cfj)cex.aq).a((var1x) -> {
         return ir.a().a((it)is.c, (Object)(var1x < 8 ? iw.a(bup.cC, "_height" + var1x * 2) : var2));
      })));
      this.c(bup.cC, iw.a(bup.cC, "_height2"));
      this.a.accept(e(bup.cE, var2));
   }

   private void Y() {
      this.a.accept(io.a(bup.ma, ir.a().a((it)is.c, (Object)iw.a(bup.ma))).a(b()));
   }

   private void Z() {
      vk var1 = jb.a.a(bup.mY, this.b);
      this.c(bup.mY, var1);
      this.a.accept(io.a(bup.mY).a(ip.a((cfj)cex.aM).a((var1x) -> {
         return ir.a().a((it)is.c, (Object)this.a(bup.mY, "_" + var1x.a(), iy.c, iz::b));
      })));
   }

   private void aa() {
      this.a(bmd.rm);
      this.a.accept(io.a(bup.mg).a(ip.a((cfj)cex.ag).a((var1) -> {
         return ir.a().a((it)is.c, (Object)this.a(bup.mg, "_stage" + var1, iy.S, iz::c));
      })));
   }

   private void ab() {
      this.a(bmd.kS);
      this.a.accept(io.a(bup.em).a((ip)ip.a(cex.a, cex.J, cex.I, cex.K, cex.L).a(false, false, false, false, false, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.em, "_ns"))).a(false, true, false, false, false, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.em, "_n")).a((it)is.b, (Object)is.a.b)).a(false, false, true, false, false, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.em, "_n"))).a(false, false, false, true, false, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.em, "_n")).a((it)is.b, (Object)is.a.c)).a(false, false, false, false, true, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.em, "_n")).a((it)is.b, (Object)is.a.d)).a(false, true, true, false, false, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.em, "_ne"))).a(false, true, false, true, false, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.em, "_ne")).a((it)is.b, (Object)is.a.b)).a(false, false, false, true, true, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.em, "_ne")).a((it)is.b, (Object)is.a.c)).a(false, false, true, false, true, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.em, "_ne")).a((it)is.b, (Object)is.a.d)).a(false, false, true, true, false, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.em, "_ns"))).a(false, true, false, false, true, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.em, "_ns")).a((it)is.b, (Object)is.a.b)).a(false, true, true, true, false, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.em, "_nse"))).a(false, true, false, true, true, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.em, "_nse")).a((it)is.b, (Object)is.a.b)).a(false, false, true, true, true, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.em, "_nse")).a((it)is.b, (Object)is.a.c)).a(false, true, true, false, true, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.em, "_nse")).a((it)is.b, (Object)is.a.d)).a(false, true, true, true, true, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.em, "_nsew"))).a(true, false, false, false, false, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.em, "_attached_ns"))).a(true, false, true, false, false, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.em, "_attached_n"))).a(true, false, false, true, false, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.em, "_attached_n")).a((it)is.b, (Object)is.a.c)).a(true, true, false, false, false, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.em, "_attached_n")).a((it)is.b, (Object)is.a.b)).a(true, false, false, false, true, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.em, "_attached_n")).a((it)is.b, (Object)is.a.d)).a(true, true, true, false, false, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.em, "_attached_ne"))).a(true, true, false, true, false, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.em, "_attached_ne")).a((it)is.b, (Object)is.a.b)).a(true, false, false, true, true, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.em, "_attached_ne")).a((it)is.b, (Object)is.a.c)).a(true, false, true, false, true, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.em, "_attached_ne")).a((it)is.b, (Object)is.a.d)).a(true, false, true, true, false, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.em, "_attached_ns"))).a(true, true, false, false, true, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.em, "_attached_ns")).a((it)is.b, (Object)is.a.b)).a(true, true, true, true, false, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.em, "_attached_nse"))).a(true, true, false, true, true, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.em, "_attached_nse")).a((it)is.b, (Object)is.a.b)).a(true, false, true, true, true, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.em, "_attached_nse")).a((it)is.b, (Object)is.a.c)).a(true, true, true, false, true, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.em, "_attached_nse")).a((it)is.b, (Object)is.a.d)).a(true, true, true, true, true, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.em, "_attached_nsew")))));
   }

   private void ac() {
      this.b(bup.el);
      this.a.accept(io.a(bup.el).a(ip.a((cfj)cex.a, (cfj)cex.w).a((var0, var1) -> {
         return ir.a().a((it)is.c, (Object)iz.a(bup.el, (var0 ? "_attached" : "") + (var1 ? "_on" : "")));
      })).a(b()));
   }

   private vk a(int var1, String var2, iz var3) {
      switch(var1) {
      case 1:
         return iy.aF.a(iw.a(var2 + "turtle_egg"), var3, this.b);
      case 2:
         return iy.aG.a(iw.a("two_" + var2 + "turtle_eggs"), var3, this.b);
      case 3:
         return iy.aH.a(iw.a("three_" + var2 + "turtle_eggs"), var3, this.b);
      case 4:
         return iy.aI.a(iw.a("four_" + var2 + "turtle_eggs"), var3, this.b);
      default:
         throw new UnsupportedOperationException();
      }
   }

   private vk a(Integer var1, Integer var2) {
      switch(var2) {
      case 0:
         return this.a(var1, "", iz.b(iz.C(bup.kf)));
      case 1:
         return this.a(var1, "slightly_cracked_", iz.b(iz.a(bup.kf, "_slightly_cracked")));
      case 2:
         return this.a(var1, "very_cracked_", iz.b(iz.a(bup.kf, "_very_cracked")));
      default:
         throw new UnsupportedOperationException();
      }
   }

   private void ad() {
      this.a(bmd.iC);
      this.a.accept(io.a(bup.kf).a(ip.a((cfj)cex.ao, (cfj)cex.ap).b((var1, var2) -> {
         return Arrays.asList(a(this.a(var1, var2)));
      })));
   }

   private void ae() {
      this.b(bup.dP);
      this.a.accept(io.a(bup.dP).a((ip)ip.a(cex.J, cex.I, cex.K, cex.G, cex.L).a(false, false, false, false, false, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.dP, "_1"))).a(false, false, true, false, false, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.dP, "_1"))).a(false, false, false, false, true, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.dP, "_1")).a((it)is.b, (Object)is.a.b)).a(false, true, false, false, false, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.dP, "_1")).a((it)is.b, (Object)is.a.c)).a(true, false, false, false, false, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.dP, "_1")).a((it)is.b, (Object)is.a.d)).a(true, true, false, false, false, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.dP, "_2"))).a(true, false, true, false, false, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.dP, "_2")).a((it)is.b, (Object)is.a.b)).a(false, false, true, false, true, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.dP, "_2")).a((it)is.b, (Object)is.a.c)).a(false, true, false, false, true, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.dP, "_2")).a((it)is.b, (Object)is.a.d)).a(true, false, false, false, true, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.dP, "_2_opposite"))).a(false, true, true, false, false, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.dP, "_2_opposite")).a((it)is.b, (Object)is.a.b)).a(true, true, true, false, false, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.dP, "_3"))).a(true, false, true, false, true, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.dP, "_3")).a((it)is.b, (Object)is.a.b)).a(false, true, true, false, true, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.dP, "_3")).a((it)is.b, (Object)is.a.c)).a(true, true, false, false, true, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.dP, "_3")).a((it)is.b, (Object)is.a.d)).a(true, true, true, false, true, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.dP, "_4"))).a(false, false, false, true, false, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.dP, "_u"))).a(false, false, true, true, false, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.dP, "_1u"))).a(false, false, false, true, true, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.dP, "_1u")).a((it)is.b, (Object)is.a.b)).a(false, true, false, true, false, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.dP, "_1u")).a((it)is.b, (Object)is.a.c)).a(true, false, false, true, false, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.dP, "_1u")).a((it)is.b, (Object)is.a.d)).a(true, true, false, true, false, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.dP, "_2u"))).a(true, false, true, true, false, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.dP, "_2u")).a((it)is.b, (Object)is.a.b)).a(false, false, true, true, true, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.dP, "_2u")).a((it)is.b, (Object)is.a.c)).a(false, true, false, true, true, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.dP, "_2u")).a((it)is.b, (Object)is.a.d)).a(true, false, false, true, true, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.dP, "_2u_opposite"))).a(false, true, true, true, false, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.dP, "_2u_opposite")).a((it)is.b, (Object)is.a.b)).a(true, true, true, true, false, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.dP, "_3u"))).a(true, false, true, true, true, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.dP, "_3u")).a((it)is.b, (Object)is.a.b)).a(false, true, true, true, true, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.dP, "_3u")).a((it)is.b, (Object)is.a.c)).a(true, true, false, true, true, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.dP, "_3u")).a((it)is.b, (Object)is.a.d)).a(true, true, true, true, true, (ir)ir.a().a((it)is.c, (Object)iw.a(bup.dP, "_4u")))));
   }

   private void af() {
      this.a.accept(e(bup.iJ, iy.c.a(bup.iJ, iz.b(iw.a("magma")), this.b)));
   }

   private void y(buo var1) {
      this.c(var1, jb.l);
      iy.aN.a(iw.a(var1.h()), iz.q(var1), this.b);
   }

   private void b(buo var1, buo var2, ii.c var3) {
      this.b(var1, var3);
      this.b(var2, var3);
   }

   private void k(buo var1, buo var2) {
      iy.aO.a(iw.a(var1.h()), iz.q(var2), this.b);
   }

   private void ag() {
      vk var1 = iw.a(bup.b);
      vk var2 = iw.a(bup.b, "_mirrored");
      this.a.accept(e(bup.dy, var1, var2));
      this.c(bup.dy, var1);
   }

   private void l(buo var1, buo var2) {
      this.a(var1, ii.c.b);
      iz var3 = iz.d(iz.a(var1, "_pot"));
      vk var4 = ii.c.b.b().a(var2, var3, this.b);
      this.a.accept(e(var2, var4));
   }

   private void ah() {
      vk var1 = iz.a(bup.nj, "_bottom");
      vk var2 = iz.a(bup.nj, "_top_off");
      vk var3 = iz.a(bup.nj, "_top");
      vk[] var4 = new vk[5];

      for(int var5 = 0; var5 < 5; ++var5) {
         iz var6 = (new iz()).a(ja.e, var1).a(ja.f, var5 == 0 ? var2 : var3).a(ja.i, iz.a(bup.nj, "_side" + var5));
         var4[var5] = iy.h.a(bup.nj, "_" + var5, var6, this.b);
      }

      this.a.accept(io.a(bup.nj).a(ip.a((cfj)cex.aC).a((var1x) -> {
         return ir.a().a((it)is.c, (Object)var4[var1x]);
      })));
      this.a(bmd.rN, var4[0]);
   }

   private ir a(ge var1, ir var2) {
      switch(var1) {
      case b:
         return var2.a((it)is.a, (Object)is.a.b);
      case c:
         return var2.a((it)is.a, (Object)is.a.b).a((it)is.b, (Object)is.a.c);
      case d:
         return var2.a((it)is.a, (Object)is.a.b).a((it)is.b, (Object)is.a.d);
      case a:
         return var2.a((it)is.a, (Object)is.a.b).a((it)is.b, (Object)is.a.b);
      case f:
         return var2.a((it)is.a, (Object)is.a.d).a((it)is.b, (Object)is.a.c);
      case g:
         return var2.a((it)is.a, (Object)is.a.d);
      case h:
         return var2.a((it)is.a, (Object)is.a.d).a((it)is.b, (Object)is.a.b);
      case e:
         return var2.a((it)is.a, (Object)is.a.d).a((it)is.b, (Object)is.a.d);
      case k:
         return var2;
      case l:
         return var2.a((it)is.b, (Object)is.a.c);
      case i:
         return var2.a((it)is.b, (Object)is.a.d);
      case j:
         return var2.a((it)is.b, (Object)is.a.b);
      default:
         throw new UnsupportedOperationException("Rotation " + var1 + " can't be expressed with existing x and y values");
      }
   }

   private void ai() {
      vk var1 = iz.a(bup.mZ, "_top");
      vk var2 = iz.a(bup.mZ, "_bottom");
      vk var3 = iz.a(bup.mZ, "_side");
      vk var4 = iz.a(bup.mZ, "_lock");
      iz var5 = (new iz()).a(ja.o, var3).a(ja.m, var3).a(ja.l, var3).a(ja.c, var1).a(ja.j, var1).a(ja.k, var2).a(ja.n, var4);
      vk var6 = iy.b.a(bup.mZ, var5, this.b);
      this.a.accept(io.a(bup.mZ, ir.a().a((it)is.c, (Object)var6)).a(ip.a((cfj)cex.P).a((var1x) -> {
         return this.a(var1x, ir.a());
      })));
   }

   public void a() {
      this.k(bup.a);
      this.a(bup.lb, bup.a);
      this.a(bup.la, bup.a);
      this.k(bup.es);
      this.k(bup.cF);
      this.a(bup.lc, bup.A);
      this.k(bup.ef);
      this.k(bup.ke);
      this.k(bup.dZ);
      this.k(bup.ev);
      this.a(bmd.oX);
      this.k(bup.ne);
      this.k(bup.A);
      this.k(bup.B);
      this.k(bup.gn);
      this.a(bmd.dO);
      this.k(bup.kZ);
      this.k(bup.eT);
      this.a(bup.go, bmd.fJ);
      this.a(bmd.fJ);
      this.a(bup.iN, bmd.hn);
      this.a(bmd.hn);
      this.h(bup.bo, iz.a(bup.aW, "_side"));
      this.c(bup.H, jb.a);
      this.c(bup.gS, jb.a);
      this.c(bup.bT, jb.a);
      this.c(bup.bU, jb.a);
      this.c(bup.ej, jb.a);
      this.c(bup.en, jb.a);
      this.c(bup.F, jb.a);
      this.c(bup.I, jb.a);
      this.c(bup.bE, jb.a);
      this.c(bup.G, jb.a);
      this.c(bup.bF, jb.a);
      this.c(bup.nh, jb.c);
      this.c(bup.ng, jb.a);
      this.c(bup.aq, jb.a);
      this.c(bup.ar, jb.a);
      this.c(bup.fx, jb.a);
      this.c(bup.cy, jb.a);
      this.c(bup.fw, jb.a);
      this.c(bup.nA, jb.a);
      this.c(bup.kV, jb.a);
      this.c(bup.nG, jb.a);
      this.c(bup.cG, jb.a);
      this.c(bup.k, jb.a);
      this.c(bup.nH, jb.a);
      this.c(bup.dw, jb.a);
      this.c(bup.ni, jb.a);
      this.c(bup.ee, jb.a);
      this.c(bup.cS, jb.a);
      this.c(bup.E, jb.a);
      this.c(bup.nf, jb.a);
      this.c(bup.cD, jb.a);
      this.c(bup.cI, jb.f);
      this.c(bup.no, jb.c);
      this.c(bup.dK, jb.c);
      this.c(bup.iK, jb.a);
      this.c(bup.aw, jb.a);
      this.c(bup.gT, jb.a);
      this.c(bup.bK, jb.a);
      this.c(bup.nI, jb.a);
      this.c(bup.gz, jb.a);
      this.c(bup.mw, jb.a);
      this.c(bup.cM, jb.a);
      this.c(bup.cN, jb.a);
      this.c(bup.bP, jb.a);
      this.c(bup.an, jb.a);
      this.c(bup.aU, jb.q);
      this.a(bmd.aO);
      this.c(bup.bH, jb.e);
      this.c(bup.nb, jb.c);
      this.c(bup.mn, jb.a);
      this.c(bup.ao, jb.a);
      this.c(bup.nv, jb.a);
      this.c(bup.fA, jb.c.a((var0) -> {
         var0.a(ja.i, iz.C(bup.fA));
      }));
      this.c(bup.dx, jb.a);
      this.g(bup.au, bup.at);
      this.g(bup.hH, bup.hG);
      this.c(bup.nw, jb.a);
      this.h(bup.fs, bup.bE);
      this.h(bup.ft, bup.bF);
      this.n();
      this.r();
      this.s();
      this.a(bup.me, bup.mf);
      this.t();
      this.w();
      this.x();
      this.z();
      this.A();
      this.B();
      this.y();
      this.s(bup.iw);
      this.C();
      this.D();
      this.E();
      this.F();
      this.G();
      this.H();
      this.I();
      this.m();
      this.J();
      this.K();
      this.L();
      this.M();
      this.N();
      this.O();
      this.P();
      this.Q();
      this.R();
      this.S();
      this.U();
      this.T();
      this.V();
      this.W();
      this.u();
      this.X();
      this.Y();
      this.Z();
      this.aa();
      this.ab();
      this.ac();
      this.ad();
      this.ae();
      this.af();
      this.ai();
      this.x(bup.cg);
      this.b(bup.cg);
      this.x(bup.lY);
      this.j(bup.bL, bup.bM);
      this.j(bup.cQ, bup.cR);
      this.a(bup.bV, bup.n, iz::c);
      this.a(bup.lW, bup.p, iz::d);
      this.r(bup.mu);
      this.r(bup.ml);
      this.q(bup.as);
      this.q(bup.fE);
      this.w(bup.mc);
      this.w(bup.md);
      this.g(bup.dI, iw.a(bup.dI));
      this.a(bup.cO, jb.c);
      this.a(bup.cP, jb.c);
      this.a(bup.iM, jb.c);
      this.d(bup.j);
      this.d(bup.C);
      this.d(bup.D);
      this.c(bup.z);
      this.a(bup.gA, jb.c, jb.d);
      this.a(bup.iA, jb.r, jb.s);
      this.a(bup.fB, jb.r, jb.s);
      this.b(bup.lR, jb.h);
      this.v();
      this.a(bup.nc, iz::w);
      this.a(bup.nd, iz::y);
      this.a((buo)bup.iD, (cfj)cex.ag, (int[])(0, 1, 2, 3));
      this.a((buo)bup.eU, (cfj)cex.ai, (int[])(0, 0, 1, 1, 2, 2, 2, 3));
      this.a((buo)bup.dY, (cfj)cex.ag, (int[])(0, 1, 1, 2));
      this.a((buo)bup.eV, (cfj)cex.ai, (int[])(0, 0, 1, 1, 2, 2, 2, 3));
      this.a((buo)bup.bW, (cfj)cex.ai, (int[])(0, 1, 2, 3, 4, 5, 6, 7));
      this.a(iw.a("banner"), bup.n).a(iy.aP, bup.ha, bup.hb, bup.hc, bup.hd, bup.he, bup.hf, bup.hg, bup.hh, bup.hi, bup.hj, bup.hk, bup.hl, bup.hm, bup.hn, bup.ho, bup.hp).b(bup.hq, bup.hr, bup.hs, bup.ht, bup.hu, bup.hv, bup.hw, bup.hx, bup.hy, bup.hz, bup.hA, bup.hB, bup.hC, bup.hD, bup.hE, bup.hF);
      this.a(iw.a("bed"), bup.n).b(bup.ax, bup.ay, bup.az, bup.aA, bup.aB, bup.aC, bup.aD, bup.aE, bup.aF, bup.aG, bup.aH, bup.aI, bup.aJ, bup.aK, bup.aL, bup.aM);
      this.k(bup.ax, bup.aY);
      this.k(bup.ay, bup.aZ);
      this.k(bup.az, bup.ba);
      this.k(bup.aA, bup.bb);
      this.k(bup.aB, bup.bc);
      this.k(bup.aC, bup.bd);
      this.k(bup.aD, bup.be);
      this.k(bup.aE, bup.bf);
      this.k(bup.aF, bup.bg);
      this.k(bup.aG, bup.bh);
      this.k(bup.aH, bup.bi);
      this.k(bup.aI, bup.bj);
      this.k(bup.aJ, bup.bk);
      this.k(bup.aK, bup.bl);
      this.k(bup.aL, bup.bm);
      this.k(bup.aM, bup.bn);
      this.a(iw.a("skull"), bup.cM).a(iy.aQ, bup.fk, bup.fi, bup.fg, bup.fc, bup.fe).a(bup.fm).b(bup.fl, bup.fn, bup.fj, bup.fh, bup.fd, bup.ff);
      this.y(bup.iP);
      this.y(bup.iQ);
      this.y(bup.iR);
      this.y(bup.iS);
      this.y(bup.iT);
      this.y(bup.iU);
      this.y(bup.iV);
      this.y(bup.iW);
      this.y(bup.iX);
      this.y(bup.iY);
      this.y(bup.iZ);
      this.y(bup.ja);
      this.y(bup.jb);
      this.y(bup.jc);
      this.y(bup.jd);
      this.y(bup.je);
      this.y(bup.jf);
      this.c(bup.kW, jb.l);
      this.a(bup.kW);
      this.a(iw.a("chest"), bup.n).b(bup.bR, bup.fr);
      this.a(iw.a("ender_chest"), bup.bK).b(bup.ek);
      this.d(bup.ec, bup.bK).a(bup.ec, bup.iF);
      this.e(bup.jw);
      this.e(bup.jx);
      this.e(bup.jy);
      this.e(bup.jz);
      this.e(bup.jA);
      this.e(bup.jB);
      this.e(bup.jC);
      this.e(bup.jD);
      this.e(bup.jE);
      this.e(bup.jF);
      this.e(bup.jG);
      this.e(bup.jH);
      this.e(bup.jI);
      this.e(bup.jJ);
      this.e(bup.jK);
      this.e(bup.jL);
      this.a(jb.a, bup.jM, bup.jN, bup.jO, bup.jP, bup.jQ, bup.jR, bup.jS, bup.jT, bup.jU, bup.jV, bup.jW, bup.jX, bup.jY, bup.jZ, bup.ka, bup.kb);
      this.e(bup.gR);
      this.e(bup.fF);
      this.e(bup.fG);
      this.e(bup.fH);
      this.e(bup.fI);
      this.e(bup.fJ);
      this.e(bup.fK);
      this.e(bup.fL);
      this.e(bup.fM);
      this.e(bup.fN);
      this.e(bup.fO);
      this.e(bup.fP);
      this.e(bup.fQ);
      this.e(bup.fR);
      this.e(bup.fS);
      this.e(bup.fT);
      this.e(bup.fU);
      this.f(bup.ap, bup.dJ);
      this.f(bup.cY, bup.fV);
      this.f(bup.cZ, bup.fW);
      this.f(bup.da, bup.fX);
      this.f(bup.db, bup.fY);
      this.f(bup.dc, bup.fZ);
      this.f(bup.dd, bup.ga);
      this.f(bup.de, bup.gb);
      this.f(bup.df, bup.gc);
      this.f(bup.dg, bup.gd);
      this.f(bup.dh, bup.ge);
      this.f(bup.di, bup.gf);
      this.f(bup.dj, bup.gg);
      this.f(bup.dk, bup.gh);
      this.f(bup.dl, bup.gi);
      this.f(bup.dm, bup.gj);
      this.f(bup.dn, bup.gk);
      this.b(jb.j, bup.jg, bup.jh, bup.ji, bup.jj, bup.jk, bup.jl, bup.jm, bup.jn, bup.jo, bup.jp, bup.jq, bup.jr, bup.js, bup.jt, bup.ju, bup.jv);
      this.e(bup.aY, bup.gB);
      this.e(bup.aZ, bup.gC);
      this.e(bup.ba, bup.gD);
      this.e(bup.bb, bup.gE);
      this.e(bup.bc, bup.gF);
      this.e(bup.bd, bup.gG);
      this.e(bup.be, bup.gH);
      this.e(bup.bf, bup.gI);
      this.e(bup.bg, bup.gJ);
      this.e(bup.bh, bup.gK);
      this.e(bup.bi, bup.gL);
      this.e(bup.bj, bup.gM);
      this.e(bup.bk, bup.gN);
      this.e(bup.bl, bup.gO);
      this.e(bup.bm, bup.gP);
      this.e(bup.bn, bup.gQ);
      this.a(bup.aS, bup.eC, ii.c.a);
      this.a(bup.bp, bup.eD, ii.c.b);
      this.a(bup.bq, bup.eE, ii.c.b);
      this.a(bup.br, bup.eF, ii.c.b);
      this.a(bup.bs, bup.eG, ii.c.b);
      this.a(bup.bt, bup.eH, ii.c.b);
      this.a(bup.bu, bup.eI, ii.c.b);
      this.a(bup.bv, bup.eJ, ii.c.b);
      this.a(bup.bw, bup.eK, ii.c.b);
      this.a(bup.bx, bup.eL, ii.c.b);
      this.a(bup.by, bup.eM, ii.c.b);
      this.a(bup.bz, bup.eN, ii.c.b);
      this.a(bup.bB, bup.eO, ii.c.b);
      this.a(bup.bA, bup.eP, ii.c.b);
      this.a(bup.bD, bup.eQ, ii.c.b);
      this.a(bup.bC, bup.eR, ii.c.b);
      this.a(bup.aT, bup.eS, ii.c.b);
      this.p(bup.dE);
      this.p(bup.dF);
      this.p(bup.dG);
      this.a(bup.aR, ii.c.a);
      this.b(bup.cH, ii.c.a);
      this.a(bmd.bD);
      this.b(bup.kc, bup.kd, ii.c.a);
      this.a(bmd.bE);
      this.a(bup.kd);
      this.b(bup.mx, bup.my, ii.c.b);
      this.b(bup.mz, bup.mA, ii.c.b);
      this.a(bup.mx, "_plant");
      this.a(bup.my);
      this.a(bup.mz, "_plant");
      this.a(bup.mA);
      this.a(bup.kX, ii.c.a, iz.c(iz.a(bup.kY, "_stage0")));
      this.i();
      this.a(bup.aQ, ii.c.b);
      this.c(bup.gV, ii.c.b);
      this.c(bup.gW, ii.c.b);
      this.c(bup.gX, ii.c.b);
      this.c(bup.gY, ii.c.a);
      this.c(bup.gZ, ii.c.a);
      this.g();
      this.h();
      this.a(bup.kv, bup.kq, bup.kl, bup.kg, bup.kF, bup.kA, bup.kP, bup.kK);
      this.a(bup.kw, bup.kr, bup.km, bup.kh, bup.kG, bup.kB, bup.kQ, bup.kL);
      this.a(bup.kx, bup.ks, bup.kn, bup.ki, bup.kH, bup.kC, bup.kR, bup.kM);
      this.a(bup.ky, bup.kt, bup.ko, bup.kj, bup.kI, bup.kD, bup.kS, bup.kN);
      this.a(bup.kz, bup.ku, bup.kp, bup.kk, bup.kJ, bup.kE, bup.kT, bup.kO);
      this.c(bup.dO, bup.dM);
      this.c(bup.dN, bup.dL);
      this.f(bup.r).a(bup.fa).c(bup.ip).d(bup.ik).e(bup.cw).a(bup.cc, bup.cm).f(bup.hO).g(bup.gl);
      this.g(bup.iu);
      this.h(bup.ds);
      this.j(bup.N).c(bup.N).a(bup.Z);
      this.j(bup.S).c(bup.S).a(bup.af);
      this.a(bup.x, bup.eA, ii.c.b);
      this.c(bup.al, jb.n);
      this.f(bup.p).a(bup.eY).c(bup.in).d(bup.ii).e(bup.cu).a(bup.cb, bup.cl).f(bup.hM).g(bup.ep);
      this.g(bup.is);
      this.h(bup.dq);
      this.j(bup.L).c(bup.L).a(bup.X);
      this.j(bup.Q).c(bup.Q).a(bup.ad);
      this.a(bup.v, bup.ey, ii.c.b);
      this.c(bup.aj, jb.n);
      this.f(bup.n).a(bup.eW).c(bup.cJ).d(bup.dQ).e(bup.cs).a(bup.bZ, bup.cj).f(bup.hK).f(bup.hU).g(bup.bQ);
      this.g(bup.cf);
      this.i(bup.do);
      this.j(bup.J).c(bup.J).a(bup.V);
      this.j(bup.U).c(bup.U).a(bup.ab);
      this.a(bup.t, bup.ew, ii.c.b);
      this.c(bup.ah, jb.n);
      this.f(bup.o).a(bup.eX).c(bup.im).d(bup.ih).e(bup.ct).a(bup.ca, bup.ck).f(bup.hL).g(bup.eo);
      this.g(bup.ir);
      this.h(bup.dp);
      this.j(bup.K).c(bup.K).a(bup.W);
      this.j(bup.P).c(bup.P).a(bup.ac);
      this.a(bup.u, bup.ex, ii.c.b);
      this.c(bup.ai, jb.n);
      this.f(bup.s).a(bup.fb).c(bup.iq).d(bup.il).e(bup.cx).a(bup.ce, bup.co).f(bup.hP).g(bup.gm);
      this.g(bup.iv);
      this.i(bup.dt);
      this.j(bup.O).c(bup.O).a(bup.aa);
      this.j(bup.T).c(bup.T).a(bup.ag);
      this.a(bup.y, bup.eB, ii.c.b);
      this.c(bup.am, jb.n);
      this.f(bup.q).a(bup.eZ).c(bup.io).d(bup.ij).e(bup.cv).a(bup.cd, bup.cn).f(bup.hN).g(bup.eq);
      this.g(bup.it);
      this.h(bup.dr);
      this.j(bup.M).c(bup.M).a(bup.Y);
      this.j(bup.R).c(bup.R).a(bup.ae);
      this.a(bup.w, bup.ez, ii.c.b);
      this.c(bup.ak, jb.n);
      this.f(bup.mC).a(bup.mQ).c(bup.mI).d(bup.mM).e(bup.mG).a(bup.mU, bup.mW).f(bup.mE).g(bup.mO);
      this.g(bup.mS);
      this.h(bup.mK);
      this.j(bup.mq).b(bup.mq).a(bup.ms);
      this.j(bup.mr).b(bup.mr).a(bup.mt);
      this.a(bup.mv, bup.nk, ii.c.b);
      this.l(bup.mB, bup.nm);
      this.f(bup.mD).a(bup.mR).c(bup.mJ).d(bup.mN).e(bup.mH).a(bup.mV, bup.mX).f(bup.mF).g(bup.mP);
      this.g(bup.mT);
      this.h(bup.mL);
      this.j(bup.mh).b(bup.mh).a(bup.mj);
      this.j(bup.mi).b(bup.mi).a(bup.mk);
      this.a(bup.mm, bup.nl, ii.c.b);
      this.l(bup.mo, bup.nn);
      this.b(bup.mp, ii.c.b);
      this.a(bmd.bA);
      this.a(iz.a(bup.b)).a((var1) -> {
         vk var2 = iy.c.a(bup.b, var1, this.b);
         vk var3 = iy.d.a(bup.b, var1, this.b);
         this.a.accept(e(bup.b, var2, var3));
         return var2;
      }).f(bup.hQ).e(bup.cq).a(bup.cB).g(bup.lj);
      this.g(bup.cr);
      this.i(bup.gp);
      this.f(bup.du).b(bup.lJ).g(bup.dS).f(bup.hX);
      this.f(bup.dv).b(bup.lH).g(bup.lf).f(bup.lt);
      this.f(bup.m).b(bup.et).g(bup.ci).f(bup.hV);
      this.f(bup.bJ).b(bup.eu).g(bup.lh).f(bup.lv);
      this.f(bup.gq).b(bup.lF).g(bup.gt).f(bup.gw);
      this.f(bup.gr).g(bup.gu).f(bup.gx);
      this.f(bup.gs).g(bup.gv).f(bup.gy);
      this.d(bup.at, jb.t).b(bup.lN).g(bup.ei).f(bup.hS);
      this.a(bup.ie, jb.a(iz.a(bup.at, "_top"))).f(bup.lx).g(bup.lk);
      this.a(bup.av, jb.c.get(bup.at).a((var0) -> {
         var0.a(ja.i, iz.C(bup.av));
      })).f(bup.hT);
      this.d(bup.hG, jb.t).b(bup.lG).g(bup.hJ).f(bup.ia);
      this.a(bup.ig, jb.a(iz.a(bup.hG, "_top"))).f(bup.ls).g(bup.le);
      this.a(bup.hI, jb.c.get(bup.hG).a((var0) -> {
         var0.a(ja.i, iz.C(bup.hI));
      })).f(bup.ib);
      this.f(bup.bG).b(bup.lE).g(bup.dR).f(bup.hW);
      this.f(bup.dV).c(bup.dW).b(bup.lK).g(bup.dX).f(bup.hY);
      this.f(bup.iz).g(bup.iB).f(bup.ic);
      this.f(bup.e).b(bup.lP).g(bup.lq).f(bup.lD);
      this.f(bup.f).g(bup.lg).f(bup.lu);
      this.f(bup.c).b(bup.lI).g(bup.lm).f(bup.lz);
      this.f(bup.d).g(bup.ld).f(bup.lr);
      this.f(bup.g).b(bup.lL).g(bup.ln).f(bup.lA);
      this.f(bup.h).g(bup.lp).f(bup.lC);
      this.f(bup.iC).b(bup.lO).g(bup.li).f(bup.lw);
      this.d(bup.fz, jb.c).g(bup.fC).f(bup.hZ);
      this.a(bup.if, jb.a(iz.a(bup.fz, "_bottom"))).g(bup.ll).f(bup.ly);
      this.f(bup.iL).f(bup.lB).g(bup.lo).b(bup.lM);
      this.d(bup.np, jb.u).b(bup.nr).g(bup.nq).f(bup.ns);
      this.f(bup.nu).b(bup.nz).g(bup.ny).f(bup.nx);
      this.f(bup.nt).b(bup.nF).e(bup.nD).a(bup.nE).g(bup.nB).f(bup.nC);
      this.q();
      this.l(bup.ch);
      this.m(bup.aN);
      this.m(bup.aO);
      this.m(bup.fD);
      this.p();
      this.n(bup.er);
      this.n(bup.iG);
      this.n(bup.iH);
      this.o(bup.fo);
      this.o(bup.fp);
      this.o(bup.fq);
      this.k();
      this.l();
      this.e(bup.bY, jb.g);
      this.e(bup.lU, jb.g);
      this.e(bup.lT, jb.h);
      this.o();
      this.ah();
      this.i(bup.dx, bup.dD);
      this.i(bup.m, bup.dz);
      this.i(bup.dw, bup.dC);
      this.i(bup.dv, bup.dB);
      this.ag();
      this.i(bup.du, bup.dA);
      bna.f().forEach((var1) -> {
         this.a((blx)var1, (vk)iw.b("template_spawn_egg"));
      });
   }

   class a {
      private final vk b;

      public a(vk var2, buo var3) {
         this.b = iy.F.a(var2, iz.q(var3), ii.this.b);
      }

      public ii.a a(buo... var1) {
         buo[] var2 = var1;
         int var3 = var1.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            buo var5 = var2[var4];
            ii.this.a.accept(ii.e(var5, this.b));
         }

         return this;
      }

      public ii.a b(buo... var1) {
         buo[] var2 = var1;
         int var3 = var1.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            buo var5 = var2[var4];
            ii.this.a(var5);
         }

         return this.a(var1);
      }

      public ii.a a(ix var1, buo... var2) {
         buo[] var3 = var2;
         int var4 = var2.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            buo var6 = var3[var5];
            var1.a(iw.a(var6.h()), iz.q(var6), ii.this.b);
         }

         return this.a(var2);
      }
   }

   static enum c {
      a,
      b;

      public ix a() {
         return this == a ? iy.T : iy.S;
      }

      public ix b() {
         return this == a ? iy.V : iy.U;
      }
   }

   class d {
      private final iz b;

      public d(iz var2) {
         this.b = var2;
      }

      public ii.d a(buo var1) {
         iz var2 = this.b.c(ja.d, this.b.a(ja.i));
         vk var3 = iy.e.a(var1, var2, ii.this.b);
         ii.this.a.accept(ii.f(var1, var3));
         return this;
      }

      public ii.d b(buo var1) {
         vk var2 = iy.e.a(var1, this.b, ii.this.b);
         ii.this.a.accept(ii.f(var1, var2));
         return this;
      }

      public ii.d c(buo var1) {
         vk var2 = iy.e.a(var1, this.b, ii.this.b);
         vk var3 = iy.f.a(var1, this.b, ii.this.b);
         ii.this.a.accept(ii.h(var1, var2, var3));
         return this;
      }
   }

   class b {
      private final iz b;
      @Nullable
      private vk c;

      public b(iz var2) {
         this.b = var2;
      }

      public ii.b a(buo var1, ix var2) {
         this.c = var2.a(var1, this.b, ii.this.b);
         ii.this.a.accept(ii.e(var1, this.c));
         return this;
      }

      public ii.b a(Function<iz, vk> var1) {
         this.c = (vk)var1.apply(this.b);
         return this;
      }

      public ii.b a(buo var1) {
         vk var2 = iy.l.a(var1, this.b, ii.this.b);
         vk var3 = iy.m.a(var1, this.b, ii.this.b);
         ii.this.a.accept(ii.f(var1, var2, var3));
         vk var4 = iy.n.a(var1, this.b, ii.this.b);
         ii.this.c(var1, var4);
         return this;
      }

      public ii.b b(buo var1) {
         vk var2 = iy.v.a(var1, this.b, ii.this.b);
         vk var3 = iy.w.a(var1, this.b, ii.this.b);
         vk var4 = iy.x.a(var1, this.b, ii.this.b);
         ii.this.a.accept(ii.d(var1, var2, var3, var4));
         vk var5 = iy.y.a(var1, this.b, ii.this.b);
         ii.this.c(var1, var5);
         return this;
      }

      public ii.b c(buo var1) {
         vk var2 = iy.s.a(var1, this.b, ii.this.b);
         vk var3 = iy.t.a(var1, this.b, ii.this.b);
         ii.this.a.accept(ii.g(var1, var2, var3));
         vk var4 = iy.u.a(var1, this.b, ii.this.b);
         ii.this.c(var1, var4);
         return this;
      }

      public ii.b d(buo var1) {
         vk var2 = iy.A.a(var1, this.b, ii.this.b);
         vk var3 = iy.z.a(var1, this.b, ii.this.b);
         vk var4 = iy.C.a(var1, this.b, ii.this.b);
         vk var5 = iy.B.a(var1, this.b, ii.this.b);
         ii.this.a.accept(ii.c(var1, var2, var3, var4, var5));
         return this;
      }

      public ii.b e(buo var1) {
         vk var2 = iy.D.a(var1, this.b, ii.this.b);
         vk var3 = iy.E.a(var1, this.b, ii.this.b);
         ii.this.a.accept(ii.i(var1, var2, var3));
         return this;
      }

      public ii.b a(buo var1, buo var2) {
         vk var3 = iy.F.a(var1, this.b, ii.this.b);
         ii.this.a.accept(ii.e(var1, var3));
         ii.this.a.accept(ii.e(var2, var3));
         ii.this.a(var1.h());
         ii.this.a(var2);
         return this;
      }

      public ii.b f(buo var1) {
         if (this.c == null) {
            throw new IllegalStateException("Full block not generated yet");
         } else {
            vk var2 = iy.G.a(var1, this.b, ii.this.b);
            vk var3 = iy.H.a(var1, this.b, ii.this.b);
            ii.this.a.accept(ii.h(var1, var2, var3, this.c));
            return this;
         }
      }

      public ii.b g(buo var1) {
         vk var2 = iy.K.a(var1, this.b, ii.this.b);
         vk var3 = iy.J.a(var1, this.b, ii.this.b);
         vk var4 = iy.L.a(var1, this.b, ii.this.b);
         ii.this.a.accept(ii.e(var1, var2, var3, var4));
         return this;
      }
   }
}
