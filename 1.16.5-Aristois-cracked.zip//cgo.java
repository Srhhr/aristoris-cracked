import it.unimi.dsi.fastutil.ints.Int2IntMap;
import it.unimi.dsi.fastutil.ints.Int2IntOpenHashMap;
import java.util.Arrays;
import java.util.Objects;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class cgo<T> implements cgn<T> {
   private final cgm<T> b;
   private final cgn<T> c = (var0, var1x) -> {
      return 0;
   };
   private final gh<T> d;
   private final Function<md, T> e;
   private final Function<T, md> f;
   private final T g;
   protected aer a;
   private cgm<T> h;
   private int i;
   private final ReentrantLock j = new ReentrantLock();

   public void a() {
      if (this.j.isLocked() && !this.j.isHeldByCurrentThread()) {
         String var1 = (String)Thread.getAllStackTraces().keySet().stream().filter(Objects::nonNull).map((var0) -> {
            return var0.getName() + ": \n\tat " + (String)Arrays.stream(var0.getStackTrace()).map(Object::toString).collect(Collectors.joining("\n\tat "));
         }).collect(Collectors.joining("\n"));
         l var2 = new l("Writing into PalettedContainer from multiple threads", new IllegalStateException());
         m var3 = var2.a("Thread dumps");
         var3.a((String)"Thread dumps", (Object)var1);
         throw new u(var2);
      } else {
         this.j.lock();
      }
   }

   public void b() {
      this.j.unlock();
   }

   public cgo(cgm<T> var1, gh<T> var2, Function<md, T> var3, Function<T, md> var4, T var5) {
      this.b = var1;
      this.d = var2;
      this.e = var3;
      this.f = var4;
      this.g = var5;
      this.b(4);
   }

   private static int b(int var0, int var1, int var2) {
      return var1 << 8 | var2 << 4 | var0;
   }

   private void b(int var1) {
      if (var1 != this.i) {
         this.i = var1;
         if (this.i <= 4) {
            this.i = 4;
            this.h = new cgk(this.d, this.i, this, this.e);
         } else if (this.i < 9) {
            this.h = new cgf(this.d, this.i, this, this.e, this.f);
         } else {
            this.h = this.b;
            this.i = afm.e(this.d.a());
         }

         this.h.a(this.g);
         this.a = new aer(this.i, 4096);
      }
   }

   public int onResize(int var1, T var2) {
      this.a();
      aer var3 = this.a;
      cgm<T> var4 = this.h;
      this.b(var1);

      int var5;
      for(var5 = 0; var5 < var3.b(); ++var5) {
         T var6 = var4.a(var3.a(var5));
         if (var6 != null) {
            this.b(var5, var6);
         }
      }

      var5 = this.h.a(var2);
      this.b();
      return var5;
   }

   public T a(int var1, int var2, int var3, T var4) {
      this.a();
      T var5 = this.a(b(var1, var2, var3), var4);
      this.b();
      return var5;
   }

   public T b(int var1, int var2, int var3, T var4) {
      return this.a(b(var1, var2, var3), var4);
   }

   protected T a(int var1, T var2) {
      int var3 = this.h.a(var2);
      int var4 = this.a.a(var1, var3);
      T var5 = this.h.a(var4);
      return var5 == null ? this.g : var5;
   }

   protected void b(int var1, T var2) {
      int var3 = this.h.a(var2);
      this.a.b(var1, var3);
   }

   public T a(int var1, int var2, int var3) {
      return this.a(b(var1, var2, var3));
   }

   protected T a(int var1) {
      T var2 = this.h.a(this.a.a(var1));
      return var2 == null ? this.g : var2;
   }

   public void a(nf var1) {
      this.a();
      int var2 = var1.readByte();
      if (this.i != var2) {
         this.b(var2);
      }

      this.h.a(var1);
      var1.b(this.a.a());
      this.b();
   }

   public void b(nf var1) {
      this.a();
      var1.writeByte(this.i);
      this.h.b(var1);
      var1.a(this.a.a());
      this.b();
   }

   public void a(mj var1, long[] var2) {
      this.a();
      int var3 = Math.max(4, afm.e(var1.size()));
      if (var3 != this.i) {
         this.b(var3);
      }

      this.h.a(var1);
      int var4 = var2.length * 64 / 4096;
      if (this.h == this.b) {
         cgm<T> var5 = new cgf(this.d, var3, this.c, this.e, this.f);
         var5.a(var1);
         aer var6 = new aer(var3, 4096, var2);

         for(int var7 = 0; var7 < 4096; ++var7) {
            this.a.b(var7, this.b.a(var5.a(var6.a(var7))));
         }
      } else if (var4 == this.i) {
         System.arraycopy(var2, 0, this.a.a(), 0, var2.length);
      } else {
         aer var8 = new aer(var4, 4096, var2);

         for(int var9 = 0; var9 < 4096; ++var9) {
            this.a.b(var9, var8.a(var9));
         }
      }

      this.b();
   }

   public void a(md var1, String var2, String var3) {
      this.a();
      cgf<T> var4 = new cgf(this.d, this.i, this.c, this.e, this.f);
      T var5 = this.g;
      int var6 = var4.a(this.g);
      int[] var7 = new int[4096];

      for(int var8 = 0; var8 < 4096; ++var8) {
         T var9 = this.a(var8);
         if (var9 != var5) {
            var5 = var9;
            var6 = var4.a(var9);
         }

         var7[var8] = var6;
      }

      mj var12 = new mj();
      var4.b(var12);
      var1.a((String)var2, (mt)var12);
      int var13 = Math.max(4, afm.e(var12.size()));
      aer var10 = new aer(var13, 4096);

      for(int var11 = 0; var11 < var7.length; ++var11) {
         var10.b(var11, var7[var11]);
      }

      var1.a(var3, var10.a());
      this.b();
   }

   public int c() {
      return 1 + this.h.a() + nf.a(this.a.b()) + this.a.a().length * 8;
   }

   public boolean a(Predicate<T> var1) {
      return this.h.a(var1);
   }

   public void a(cgo.a<T> var1) {
      Int2IntMap var2 = new Int2IntOpenHashMap();
      this.a.a((var1x) -> {
         var2.put(var1x, var2.get(var1x) + 1);
      });
      var2.int2IntEntrySet().forEach((var2x) -> {
         var1.accept(this.h.a(var2x.getIntKey()), var2x.getIntValue());
      });
   }

   @FunctionalInterface
   public interface a<T> {
      void accept(T var1, int var2);
   }
}
