public class eim extends eit<bai, duo<bai>> {
   public eim(egk<bai, duo<bai>> var1) {
      super(var1);
   }

   public void a(dfm var1, eag var2, int var3, bai var4, float var5, float var6, float var7, float var8, float var9, float var10) {
      if (var4.eM() != 0) {
         var1.a();
         dwn var11 = ((duo)this.aC_()).b();
         var11.a(var1);
         var1.a(-1.1875D, 1.0625D, -0.9375D);
         var1.a(0.5D, 0.5D, 0.5D);
         float var12 = 0.5F;
         var1.a(0.5F, 0.5F, 0.5F);
         var1.a(g.b.a(-90.0F));
         var1.a(-0.5D, -0.5D, -0.5D);
         djz.C().ab().a(bup.bq.n(), var1, var2, var3, ejw.a);
         var1.b();
      }
   }
}
