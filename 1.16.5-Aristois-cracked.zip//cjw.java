import com.mojang.serialization.Codec;
import java.util.Random;

public class cjw extends cla<cmh> {
   public cjw(Codec<cmh> var1) {
      super(var1);
   }

   public cla.a<cmh> a() {
      return cjw.a::new;
   }

   public static class a extends crv<cmh> {
      public a(cla<cmh> var1, int var2, int var3, cra var4, int var5, long var6) {
         super(var1, var2, var3, var4, var5, var6);
      }

      public void a(gn var1, cfy var2, csw var3, int var4, int var5, bsv var6, cmh var7) {
         int var8 = var4 * 16;
         int var9 = var5 * 16;
         fx var10 = new fx(var8, 90, var9);
         bzm var11 = bzm.a((Random)this.d);
         cre.a(var3, var10, var11, this.b, this.d);
         this.b();
      }
   }
}
