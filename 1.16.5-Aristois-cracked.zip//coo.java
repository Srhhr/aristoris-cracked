import com.mojang.serialization.Codec;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.stream.Collectors;

public class coo extends cor {
   public static final Codec<coo> a = Codec.floatRange(0.0F, 1.0F).fieldOf("probability").xmap(coo::new, (var0) -> {
      return var0.b;
   }).codec();
   private final float b;

   public coo(float var1) {
      this.b = var1;
   }

   protected cos<?> a() {
      return cos.d;
   }

   public void a(bsr var1, Random var2, List<fx> var3, List<fx> var4, Set<fx> var5, cra var6) {
      if (!(var2.nextFloat() >= this.b)) {
         gc var7 = buk.a(var2);
         int var8 = !var4.isEmpty() ? Math.max(((fx)var4.get(0)).v() - 1, ((fx)var3.get(0)).v()) : Math.min(((fx)var3.get(0)).v() + 1 + var2.nextInt(3), ((fx)var3.get(var3.size() - 1)).v());
         List<fx> var9 = (List)var3.stream().filter((var1x) -> {
            return var1x.v() == var8;
         }).collect(Collectors.toList());
         if (!var9.isEmpty()) {
            fx var10 = (fx)var9.get(var2.nextInt(var9.size()));
            fx var11 = var10.a(var7);
            if (cjl.b(var1, var11) && cjl.b(var1, var11.a(gc.d))) {
               ceh var12 = (ceh)bup.nc.n().a(buk.a, gc.d);
               this.a(var1, var11, var12, var5, var6);
               ccj var13 = var1.c(var11);
               if (var13 instanceof ccg) {
                  ccg var14 = (ccg)var13;
                  int var15 = 2 + var2.nextInt(2);

                  for(int var16 = 0; var16 < var15; ++var16) {
                     baa var17 = new baa(aqe.e, var1.E());
                     var14.a(var17, false, var2.nextInt(599));
                  }
               }

            }
         }
      }
   }
}
