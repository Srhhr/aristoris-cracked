import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;

public class wa extends ddn {
   private final MinecraftServer a;
   private final Set<ddk> b = Sets.newHashSet();
   private Runnable[] c = new Runnable[0];

   public wa(MinecraftServer var1) {
      this.a = var1;
   }

   public void a(ddm var1) {
      super.a(var1);
      if (this.b.contains(var1.d())) {
         this.a.ae().a((oj)(new rj(wa.a.a, var1.d().b(), var1.e(), var1.b())));
      }

      this.b();
   }

   public void a(String var1) {
      super.a(var1);
      this.a.ae().a((oj)(new rj(wa.a.b, (String)null, var1, 0)));
      this.b();
   }

   public void a(String var1, ddk var2) {
      super.a(var1, var2);
      if (this.b.contains(var2)) {
         this.a.ae().a((oj)(new rj(wa.a.b, var2.b(), var1, 0)));
      }

      this.b();
   }

   public void a(int var1, @Nullable ddk var2) {
      ddk var3 = this.a(var1);
      super.a(var1, var2);
      if (var3 != var2 && var3 != null) {
         if (this.h(var3) > 0) {
            this.a.ae().a((oj)(new qz(var1, var2)));
         } else {
            this.g(var3);
         }
      }

      if (var2 != null) {
         if (this.b.contains(var2)) {
            this.a.ae().a((oj)(new qz(var1, var2)));
         } else {
            this.e(var2);
         }
      }

      this.b();
   }

   public boolean a(String var1, ddl var2) {
      if (super.a(var1, var2)) {
         this.a.ae().a((oj)(new ri(var2, Arrays.asList(var1), 3)));
         this.b();
         return true;
      } else {
         return false;
      }
   }

   public void b(String var1, ddl var2) {
      super.b(var1, var2);
      this.a.ae().a((oj)(new ri(var2, Arrays.asList(var1), 4)));
      this.b();
   }

   public void a(ddk var1) {
      super.a(var1);
      this.b();
   }

   public void b(ddk var1) {
      super.b(var1);
      if (this.b.contains(var1)) {
         this.a.ae().a((oj)(new rg(var1, 2)));
      }

      this.b();
   }

   public void c(ddk var1) {
      super.c(var1);
      if (this.b.contains(var1)) {
         this.g(var1);
      }

      this.b();
   }

   public void a(ddl var1) {
      super.a(var1);
      this.a.ae().a((oj)(new ri(var1, 0)));
      this.b();
   }

   public void b(ddl var1) {
      super.b(var1);
      this.a.ae().a((oj)(new ri(var1, 2)));
      this.b();
   }

   public void c(ddl var1) {
      super.c(var1);
      this.a.ae().a((oj)(new ri(var1, 1)));
      this.b();
   }

   public void a(Runnable var1) {
      this.c = (Runnable[])Arrays.copyOf(this.c, this.c.length + 1);
      this.c[this.c.length - 1] = var1;
   }

   protected void b() {
      Runnable[] var1 = this.c;
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         Runnable var4 = var1[var3];
         var4.run();
      }

   }

   public List<oj<?>> d(ddk var1) {
      List<oj<?>> var2 = Lists.newArrayList();
      var2.add(new rg(var1, 0));

      for(int var3 = 0; var3 < 19; ++var3) {
         if (this.a(var3) == var1) {
            var2.add(new qz(var3, var1));
         }
      }

      Iterator var5 = this.i(var1).iterator();

      while(var5.hasNext()) {
         ddm var4 = (ddm)var5.next();
         var2.add(new rj(wa.a.a, var4.d().b(), var4.e(), var4.b()));
      }

      return var2;
   }

   public void e(ddk var1) {
      List<oj<?>> var2 = this.d(var1);
      Iterator var3 = this.a.ae().s().iterator();

      while(var3.hasNext()) {
         aah var4 = (aah)var3.next();
         Iterator var5 = var2.iterator();

         while(var5.hasNext()) {
            oj<?> var6 = (oj)var5.next();
            var4.b.a(var6);
         }
      }

      this.b.add(var1);
   }

   public List<oj<?>> f(ddk var1) {
      List<oj<?>> var2 = Lists.newArrayList();
      var2.add(new rg(var1, 1));

      for(int var3 = 0; var3 < 19; ++var3) {
         if (this.a(var3) == var1) {
            var2.add(new qz(var3, var1));
         }
      }

      return var2;
   }

   public void g(ddk var1) {
      List<oj<?>> var2 = this.f(var1);
      Iterator var3 = this.a.ae().s().iterator();

      while(var3.hasNext()) {
         aah var4 = (aah)var3.next();
         Iterator var5 = var2.iterator();

         while(var5.hasNext()) {
            oj<?> var6 = (oj)var5.next();
            var4.b.a(var6);
         }
      }

      this.b.remove(var1);
   }

   public int h(ddk var1) {
      int var2 = 0;

      for(int var3 = 0; var3 < 19; ++var3) {
         if (this.a(var3) == var1) {
            ++var2;
         }
      }

      return var2;
   }

   public static enum a {
      a,
      b;
   }
}
