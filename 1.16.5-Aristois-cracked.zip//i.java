import com.google.common.annotations.VisibleForTesting;
import com.mojang.datafixers.util.Pair;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntStack;
import java.util.function.Predicate;

public class i {
   public static i.a a(fx var0, gc.a var1, int var2, gc.a var3, int var4, Predicate<fx> var5) {
      fx.a var6 = var0.i();
      gc var7 = gc.a(gc.b.b, var1);
      gc var8 = var7.f();
      gc var9 = gc.a(gc.b.b, var3);
      gc var10 = var9.f();
      int var11 = a(var5, var6.g(var0), var7, var2);
      int var12 = a(var5, var6.g(var0), var8, var2);
      int var13 = var11;
      i.b[] var14 = new i.b[var11 + 1 + var12];
      var14[var11] = new i.b(a(var5, var6.g(var0), var9, var4), a(var5, var6.g(var0), var10, var4));
      int var15 = var14[var11].a;

      int var16;
      i.b var17;
      for(var16 = 1; var16 <= var11; ++var16) {
         var17 = var14[var13 - (var16 - 1)];
         var14[var13 - var16] = new i.b(a(var5, var6.g(var0).c(var7, var16), var9, var17.a), a(var5, var6.g(var0).c(var7, var16), var10, var17.b));
      }

      for(var16 = 1; var16 <= var12; ++var16) {
         var17 = var14[var13 + var16 - 1];
         var14[var13 + var16] = new i.b(a(var5, var6.g(var0).c(var8, var16), var9, var17.a), a(var5, var6.g(var0).c(var8, var16), var10, var17.b));
      }

      var16 = 0;
      int var26 = 0;
      int var18 = 0;
      int var19 = 0;
      int[] var20 = new int[var14.length];

      for(int var21 = var15; var21 >= 0; --var21) {
         i.b var23;
         int var24;
         int var25;
         for(int var22 = 0; var22 < var14.length; ++var22) {
            var23 = var14[var22];
            var24 = var15 - var23.a;
            var25 = var15 + var23.b;
            var20[var22] = var21 >= var24 && var21 <= var25 ? var25 + 1 - var21 : 0;
         }

         Pair<i.b, Integer> var27 = a(var20);
         var23 = (i.b)var27.getFirst();
         var24 = 1 + var23.b - var23.a;
         var25 = (Integer)var27.getSecond();
         if (var24 * var25 > var18 * var19) {
            var16 = var23.a;
            var26 = var21;
            var18 = var24;
            var19 = var25;
         }
      }

      return new i.a(var0.a(var1, var16 - var13).a(var3, var26 - var15), var18, var19);
   }

   private static int a(Predicate<fx> var0, fx.a var1, gc var2, int var3) {
      int var4;
      for(var4 = 0; var4 < var3 && var0.test(var1.c(var2)); ++var4) {
      }

      return var4;
   }

   @VisibleForTesting
   static Pair<i.b, Integer> a(int[] var0) {
      int var1 = 0;
      int var2 = 0;
      int var3 = 0;
      IntStack var4 = new IntArrayList();
      var4.push(0);

      for(int var5 = 1; var5 <= var0.length; ++var5) {
         int var6 = var5 == var0.length ? 0 : var0[var5];

         while(!var4.isEmpty()) {
            int var7 = var0[var4.topInt()];
            if (var6 >= var7) {
               var4.push(var5);
               break;
            }

            var4.popInt();
            int var8 = var4.isEmpty() ? 0 : var4.topInt() + 1;
            if (var7 * (var5 - var8) > var3 * (var2 - var1)) {
               var2 = var5;
               var1 = var8;
               var3 = var7;
            }
         }

         if (var4.isEmpty()) {
            var4.push(var5);
         }
      }

      return new Pair(new i.b(var1, var2 - 1), var3);
   }

   public static class a {
      public final fx a;
      public final int b;
      public final int c;

      public a(fx var1, int var2, int var3) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
      }
   }

   public static class b {
      public final int a;
      public final int b;

      public b(int var1, int var2) {
         this.a = var1;
         this.b = var2;
      }

      public String toString() {
         return "IntBounds{min=" + this.a + ", max=" + this.b + '}';
      }
   }
}
