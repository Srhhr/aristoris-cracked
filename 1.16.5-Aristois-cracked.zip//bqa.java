public class bqa extends bps {
   protected bqa(bps.a var1, aqf... var2) {
      super(var1, bpt.f, var2);
   }

   public int a(int var1) {
      return 5 + 20 * (var1 - 1);
   }

   public int b(int var1) {
      return super.a(var1) + 50;
   }

   public int a() {
      return 2;
   }
}
