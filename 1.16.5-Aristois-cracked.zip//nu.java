import com.google.common.collect.ImmutableList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

public interface nu {
   Optional<afx> b = Optional.of(afx.a);
   nu c = new nu() {
      public <T> Optional<T> a(nu.a<T> var1) {
         return Optional.empty();
      }

      public <T> Optional<T> a(nu.b<T> var1, ob var2) {
         return Optional.empty();
      }
   };

   <T> Optional<T> a(nu.a<T> var1);

   <T> Optional<T> a(nu.b<T> var1, ob var2);

   static nu b(final String var0) {
      return new nu() {
         public <T> Optional<T> a(nu.a<T> var1) {
            return var1.accept(var0);
         }

         public <T> Optional<T> a(nu.b<T> var1, ob var2) {
            return var1.accept(var2, var0);
         }
      };
   }

   static nu a(final String var0, final ob var1) {
      return new nu() {
         public <T> Optional<T> a(nu.a<T> var1x) {
            return var1x.accept(var0);
         }

         public <T> Optional<T> a(nu.b<T> var1x, ob var2) {
            return var1x.accept(var1.a(var2), var0);
         }
      };
   }

   static nu a(nu... var0) {
      return a((List)ImmutableList.copyOf(var0));
   }

   static nu a(final List<nu> var0) {
      return new nu() {
         public <T> Optional<T> a(nu.a<T> var1) {
            Iterator var2 = var0.iterator();

            Optional var4;
            do {
               if (!var2.hasNext()) {
                  return Optional.empty();
               }

               nu var3 = (nu)var2.next();
               var4 = var3.a(var1);
            } while(!var4.isPresent());

            return var4;
         }

         public <T> Optional<T> a(nu.b<T> var1, ob var2) {
            Iterator var3 = var0.iterator();

            Optional var5;
            do {
               if (!var3.hasNext()) {
                  return Optional.empty();
               }

               nu var4 = (nu)var3.next();
               var5 = var4.a(var1, var2);
            } while(!var5.isPresent());

            return var5;
         }
      };
   }

   default String getString() {
      StringBuilder var1 = new StringBuilder();
      this.a((var1x) -> {
         var1.append(var1x);
         return Optional.empty();
      });
      return var1.toString();
   }

   public interface a<T> {
      Optional<T> accept(String var1);
   }

   public interface b<T> {
      Optional<T> accept(ob var1, String var2);
   }
}
