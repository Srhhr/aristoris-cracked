public class byk extends buu {
   protected static final ddh a = buo.a(2.0D, 0.0D, 2.0D, 14.0D, 3.0D, 14.0D);

   public byk(ceg.c var1) {
      super(var1);
   }

   public ddh b(ceh var1, brc var2, fx var3, dcs var4) {
      return a;
   }

   protected boolean c(ceh var1, brc var2, fx var3) {
      return var1.a(aed.ao) || var1.a(bup.cN) || super.c(var1, var2, var3);
   }

   public ceg.b ah_() {
      return ceg.b.b;
   }
}
