public class bvr extends buo {
   private static final nr a = new of("container.crafting");

   protected bvr(ceg.c var1) {
      super(var1);
   }

   public aou a(ceh var1, brx var2, fx var3, bfw var4, aot var5, dcj var6) {
      if (var2.v) {
         return aou.a;
      } else {
         var4.a(var1.b(var2, var3));
         var4.a(aea.am);
         return aou.b;
      }
   }

   public aox b(ceh var1, brx var2, fx var3) {
      return new apb((var2x, var3x, var4) -> {
         return new bip(var2x, var3x, bim.a(var2, var3));
      }, a);
   }
}
