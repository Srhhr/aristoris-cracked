import java.util.Random;
import javax.annotation.Nullable;

public class cdt extends cdp {
   @Nullable
   protected civ<cmz, ?> a(Random var1, boolean var2) {
      return null;
   }

   @Nullable
   protected civ<cmz, ?> a(Random var1) {
      return kh.bI;
   }
}
