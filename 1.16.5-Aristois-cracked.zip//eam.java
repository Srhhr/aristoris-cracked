import it.unimi.dsi.fastutil.objects.Object2ObjectLinkedOpenHashMap;
import java.util.SortedMap;
import java.util.function.Consumer;

public class eam {
   private final dzt a = new dzt();
   private final SortedMap<eao, dfh> b = (SortedMap)x.a((Object)(new Object2ObjectLinkedOpenHashMap()), (Consumer)((var1) -> {
      var1.put(ear.g(), this.a.a(eao.c()));
      var1.put(ear.h(), this.a.a(eao.e()));
      var1.put(ear.a(), this.a.a(eao.d()));
      var1.put(ear.j(), this.a.a(eao.f()));
      a(var1, ear.b());
      a(var1, ear.c());
      a(var1, ear.d());
      a(var1, ear.e());
      a(var1, ear.f());
      a(var1, eao.h());
      a(var1, eao.k());
      a(var1, eao.l());
      a(var1, eao.n());
      a(var1, eao.o());
      a(var1, eao.m());
      a(var1, eao.p());
      a(var1, eao.q());
      a(var1, eao.j());
      els.k.forEach((var1x) -> {
         a(var1, var1x);
      });
   }));
   private final eag.a c;
   private final eag.a d;
   private final eah e;

   public eam() {
      this.c = eag.a(this.b, new dfh(256));
      this.d = eag.a(new dfh(256));
      this.e = new eah(this.c);
   }

   private static void a(Object2ObjectLinkedOpenHashMap<eao, dfh> var0, eao var1) {
      var0.put(var1, new dfh(var1.v()));
   }

   public dzt a() {
      return this.a;
   }

   public eag.a b() {
      return this.c;
   }

   public eag.a c() {
      return this.d;
   }

   public eah d() {
      return this.e;
   }
}
