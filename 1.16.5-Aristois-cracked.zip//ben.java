import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import com.mojang.datafixers.util.Pair;
import java.util.List;
import java.util.Optional;
import java.util.Set;

public class ben {
   private static final afh a = afu.a(5, 20);
   private static final afh b = afh.a(5, 16);

   protected static arf<?> a(arf<bem> var0) {
      b(var0);
      c(var0);
      d(var0);
      e(var0);
      var0.a((Set)ImmutableSet.of(bhf.a));
      var0.b(bhf.b);
      var0.e();
      return var0;
   }

   private static void b(arf<bem> var0) {
      var0.a(bhf.a, 0, ImmutableList.of(new asu(45, 90), new asy()));
   }

   private static void c(arf<bem> var0) {
      var0.a(bhf.b, 10, ImmutableList.of(new aru(ayd.ag, 200), new arq(aqe.G, 0.6F), atp.a(ayd.ag, 1.0F, 8, true), new atw(ben::d), new ath(bem::eL, atp.b(ayd.aa, 0.4F, 8, false)), new atj(new atl(8.0F), afh.a(30, 60)), new ars(b, 0.6F), a()));
   }

   private static void d(arf<bem> var0) {
      var0.a(bhf.k, 10, ImmutableList.of(new aru(ayd.ag, 200), new arq(aqe.G, 0.6F), new atq(1.0F), new ath(bem::eL, new asv(40)), new ath(apy::w_, new asv(15)), new aty(), new ase(ben::i, ayd.o)), ayd.o);
   }

   private static void e(arf<bem> var0) {
      var0.a(bhf.n, 10, ImmutableList.of(atp.b(ayd.z, 1.3F, 15, false), a(), new atj(new atl(8.0F), afh.a(30, 60)), new ase(ben::e, ayd.z)), ayd.z);
   }

   private static ati<bem> a() {
      return new ati(ImmutableList.of(Pair.of(new atc(0.4F), 2), Pair.of(new ats(0.4F, 3), 2), Pair.of(new asc(30, 60), 1)));
   }

   protected static void a(bem var0) {
      arf<bem> var1 = var0.cJ();
      bhf var2 = (bhf)var1.f().orElse((Object)null);
      var1.a((List)ImmutableList.of(bhf.k, bhf.n, bhf.b));
      bhf var3 = (bhf)var1.f().orElse((Object)null);
      if (var2 != var3) {
         b(var0).ifPresent(var0::a);
      }

      var0.s(var1.a(ayd.o));
   }

   protected static void a(bem var0, aqm var1) {
      if (!var0.w_()) {
         if (var1.X() == aqe.ai && f(var0)) {
            e(var0, var1);
            c(var0, var1);
         } else {
            h(var0, var1);
         }
      }
   }

   private static void c(bem var0, aqm var1) {
      g(var0).forEach((var1x) -> {
         d(var1x, var1);
      });
   }

   private static void d(bem var0, aqm var1) {
      arf<bem> var3 = var0.cJ();
      aqm var2 = arw.a((aqm)var0, (Optional)var3.c(ayd.z), (aqm)var1);
      var2 = arw.a((aqm)var0, (Optional)var3.c(ayd.o), (aqm)var2);
      e(var0, var2);
   }

   private static void e(bem var0, aqm var1) {
      var0.cJ().b(ayd.o);
      var0.cJ().b(ayd.m);
      var0.cJ().a(ayd.z, var1, (long)a.a(var0.l.t));
   }

   private static Optional<? extends aqm> d(bem var0) {
      return !c(var0) && !i(var0) ? var0.cJ().c(ayd.l) : Optional.empty();
   }

   static boolean a(bem var0, fx var1) {
      Optional<fx> var2 = var0.cJ().c(ayd.ag);
      return var2.isPresent() && ((fx)var2.get()).a(var1, 8.0D);
   }

   private static boolean e(bem var0) {
      return var0.eL() && !f(var0);
   }

   private static boolean f(bem var0) {
      if (var0.w_()) {
         return false;
      } else {
         int var1 = (Integer)var0.cJ().c(ayd.ac).orElse(0);
         int var2 = (Integer)var0.cJ().c(ayd.ad).orElse(0) + 1;
         return var1 > var2;
      }
   }

   protected static void b(bem var0, aqm var1) {
      arf<bem> var2 = var0.cJ();
      var2.b(ayd.ah);
      var2.b(ayd.r);
      if (var0.w_()) {
         d(var0, var1);
      } else {
         f(var0, var1);
      }
   }

   private static void f(bem var0, aqm var1) {
      if (!var0.cJ().c(bhf.n) || var1.X() != aqe.ai) {
         if (aqd.f.test(var1)) {
            if (var1.X() != aqe.G) {
               if (!arw.a(var0, var1, 4.0D)) {
                  g(var0, var1);
                  h(var0, var1);
               }
            }
         }
      }
   }

   private static void g(bem var0, aqm var1) {
      arf<bem> var2 = var0.cJ();
      var2.b(ayd.D);
      var2.b(ayd.r);
      var2.a(ayd.o, var1, 200L);
   }

   private static void h(bem var0, aqm var1) {
      g(var0).forEach((var1x) -> {
         i(var1x, var1);
      });
   }

   private static void i(bem var0, aqm var1) {
      if (!c(var0)) {
         Optional<aqm> var2 = var0.cJ().c(ayd.o);
         aqm var3 = arw.a((aqm)var0, (Optional)var2, (aqm)var1);
         g(var0, var3);
      }
   }

   public static Optional<adp> b(bem var0) {
      return var0.cJ().f().map((var1) -> {
         return a(var0, var1);
      });
   }

   private static adp a(bem var0, bhf var1) {
      if (var1 != bhf.n && !var0.eN()) {
         if (var1 == bhf.k) {
            return adq.fC;
         } else {
            return h(var0) ? adq.fH : adq.fB;
         }
      } else {
         return adq.fH;
      }
   }

   private static List<bem> g(bem var0) {
      return (List)var0.cJ().c(ayd.Z).orElse(ImmutableList.of());
   }

   private static boolean h(bem var0) {
      return var0.cJ().a(ayd.ag);
   }

   private static boolean i(bem var0) {
      return var0.cJ().a(ayd.r);
   }

   protected static boolean c(bem var0) {
      return var0.cJ().a(ayd.ah);
   }
}
