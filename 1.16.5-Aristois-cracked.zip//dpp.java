import com.google.common.collect.Sets;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.datafixers.util.Pair;
import java.util.Iterator;
import java.util.Set;
import javax.annotation.Nullable;

public abstract class dpp<T extends bic> extends dot implements dqq<T> {
   public static final vk a = new vk("textures/gui/container/inventory.png");
   protected int b = 176;
   protected int c = 166;
   protected int p;
   protected int q;
   protected int r;
   protected int s;
   protected final T t;
   protected final bfv u;
   @Nullable
   protected bjr v;
   @Nullable
   private bjr A;
   @Nullable
   private bjr B;
   @Nullable
   private bjr C;
   @Nullable
   private bjr D;
   protected int w;
   protected int x;
   private boolean E;
   private bmb F;
   private int G;
   private int H;
   private long I;
   private bmb J;
   private long K;
   protected final Set<bjr> y;
   protected boolean z;
   private int L;
   private int M;
   private boolean N;
   private int O;
   private long P;
   private int Q;
   private boolean R;
   private bmb S;

   public dpp(T var1, bfv var2, nr var3) {
      super(var3);
      this.F = bmb.b;
      this.J = bmb.b;
      this.y = Sets.newHashSet();
      this.S = bmb.b;
      this.t = var1;
      this.u = var2;
      this.N = true;
      this.p = 8;
      this.q = 6;
      this.r = 8;
      this.s = this.c - 94;
   }

   protected void b() {
      super.b();
      this.w = (this.k - this.b) / 2;
      this.x = (this.l - this.c) / 2;
   }

   public void a(dfm var1, int var2, int var3, float var4) {
      int var5 = this.w;
      int var6 = this.x;
      this.a(var1, var4, var2, var3);
      RenderSystem.disableRescaleNormal();
      RenderSystem.disableDepthTest();
      super.a(var1, var2, var3, var4);
      RenderSystem.pushMatrix();
      RenderSystem.translatef((float)var5, (float)var6, 0.0F);
      RenderSystem.color4f(1.0F, 1.0F, 1.0F, 1.0F);
      RenderSystem.enableRescaleNormal();
      this.v = null;
      int var7 = true;
      int var8 = true;
      RenderSystem.glMultiTexCoord2f(33986, 240.0F, 240.0F);
      RenderSystem.color4f(1.0F, 1.0F, 1.0F, 1.0F);

      int var12;
      for(int var9 = 0; var9 < this.t.a.size(); ++var9) {
         bjr var10 = (bjr)this.t.a.get(var9);
         if (var10.b()) {
            this.a(var1, var10);
         }

         if (this.a(var10, (double)var2, (double)var3) && var10.b()) {
            this.v = var10;
            RenderSystem.disableDepthTest();
            int var11 = var10.e;
            var12 = var10.f;
            RenderSystem.colorMask(true, true, true, false);
            this.a(var1, var11, var12, var11 + 16, var12 + 16, -2130706433, -2130706433);
            RenderSystem.colorMask(true, true, true, true);
            RenderSystem.enableDepthTest();
         }
      }

      this.b(var1, var2, var3);
      bfv var16 = this.i.s.bm;
      bmb var17 = this.F.a() ? var16.m() : this.F;
      if (!var17.a()) {
         int var18 = true;
         var12 = this.F.a() ? 8 : 16;
         String var13 = null;
         if (!this.F.a() && this.E) {
            var17 = var17.i();
            var17.e(afm.f((float)var17.E() / 2.0F));
         } else if (this.z && this.y.size() > 1) {
            var17 = var17.i();
            var17.e(this.O);
            if (var17.a()) {
               var13 = "" + k.o + "0";
            }
         }

         this.a(var17, var2 - var5 - 8, var3 - var6 - var12, var13);
      }

      if (!this.J.a()) {
         float var19 = (float)(x.b() - this.I) / 100.0F;
         if (var19 >= 1.0F) {
            var19 = 1.0F;
            this.J = bmb.b;
         }

         var12 = this.B.e - this.G;
         int var20 = this.B.f - this.H;
         int var14 = this.G + (int)((float)var12 * var19);
         int var15 = this.H + (int)((float)var20 * var19);
         this.a((bmb)this.J, var14, var15, (String)null);
      }

      RenderSystem.popMatrix();
      RenderSystem.enableDepthTest();
   }

   protected void a(dfm var1, int var2, int var3) {
      if (this.i.s.bm.m().a() && this.v != null && this.v.f()) {
         this.a(var1, this.v.e(), var2, var3);
      }

   }

   private void a(bmb var1, int var2, int var3, String var4) {
      RenderSystem.translatef(0.0F, 0.0F, 32.0F);
      this.d(200);
      this.j.b = 200.0F;
      this.j.b(var1, var2, var3);
      this.j.a(this.o, var1, var2, var3 - (this.F.a() ? 0 : 8), var4);
      this.d(0);
      this.j.b = 0.0F;
   }

   protected void b(dfm var1, int var2, int var3) {
      this.o.b(var1, this.d, (float)this.p, (float)this.q, 4210752);
      this.o.b(var1, this.u.d(), (float)this.r, (float)this.s, 4210752);
   }

   protected abstract void a(dfm var1, float var2, int var3, int var4);

   private void a(dfm var1, bjr var2) {
      int var3 = var2.e;
      int var4 = var2.f;
      bmb var5 = var2.e();
      boolean var6 = false;
      boolean var7 = var2 == this.A && !this.F.a() && !this.E;
      bmb var8 = this.i.s.bm.m();
      String var9 = null;
      if (var2 == this.A && !this.F.a() && this.E && !var5.a()) {
         var5 = var5.i();
         var5.e(var5.E() / 2);
      } else if (this.z && this.y.contains(var2) && !var8.a()) {
         if (this.y.size() == 1) {
            return;
         }

         if (bic.a(var2, var8, true) && this.t.b(var2)) {
            var5 = var8.i();
            var6 = true;
            bic.a(this.y, this.L, var5, var2.e().a() ? 0 : var2.e().E());
            int var10 = Math.min(var5.c(), var2.b(var5));
            if (var5.E() > var10) {
               var9 = k.o.toString() + var10;
               var5.e(var10);
            }
         } else {
            this.y.remove(var2);
            this.l();
         }
      }

      this.d(100);
      this.j.b = 100.0F;
      if (var5.a() && var2.b()) {
         Pair<vk, vk> var12 = var2.c();
         if (var12 != null) {
            ekc var11 = (ekc)this.i.a((vk)var12.getFirst()).apply(var12.getSecond());
            this.i.M().a(var11.m().g());
            a(var1, var3, var4, this.v(), 16, 16, var11);
            var7 = true;
         }
      }

      if (!var7) {
         if (var6) {
            a(var1, var3, var4, var3 + 16, var4 + 16, -2130706433);
         }

         RenderSystem.enableDepthTest();
         this.j.a((aqm)this.i.s, var5, var3, var4);
         this.j.a(this.o, var5, var3, var4, var9);
      }

      this.j.b = 0.0F;
      this.d(0);
   }

   private void l() {
      bmb var1 = this.i.s.bm.m();
      if (!var1.a() && this.z) {
         if (this.L == 2) {
            this.O = var1.c();
         } else {
            this.O = var1.E();

            bmb var4;
            int var6;
            for(Iterator var2 = this.y.iterator(); var2.hasNext(); this.O -= var4.E() - var6) {
               bjr var3 = (bjr)var2.next();
               var4 = var1.i();
               bmb var5 = var3.e();
               var6 = var5.a() ? 0 : var5.E();
               bic.a(this.y, this.L, var4, var6);
               int var7 = Math.min(var4.c(), var3.b(var4));
               if (var4.E() > var7) {
                  var4.e(var7);
               }
            }

         }
      }
   }

   @Nullable
   private bjr a(double var1, double var3) {
      for(int var5 = 0; var5 < this.t.a.size(); ++var5) {
         bjr var6 = (bjr)this.t.a.get(var5);
         if (this.a(var6, var1, var3) && var6.b()) {
            return var6;
         }
      }

      return null;
   }

   public boolean a(double var1, double var3, int var5) {
      if (super.a(var1, var3, var5)) {
         return true;
      } else {
         boolean var6 = this.i.k.ar.a(var5);
         bjr var7 = this.a(var1, var3);
         long var8 = x.b();
         this.R = this.D == var7 && var8 - this.P < 250L && this.Q == var5;
         this.N = false;
         if (var5 != 0 && var5 != 1 && !var6) {
            this.a(var5);
         } else {
            int var10 = this.w;
            int var11 = this.x;
            boolean var12 = this.a(var1, var3, var10, var11, var5);
            int var13 = -1;
            if (var7 != null) {
               var13 = var7.d;
            }

            if (var12) {
               var13 = -999;
            }

            if (this.i.k.Y && var12 && this.i.s.bm.m().a()) {
               this.i.a((dot)null);
               return true;
            }

            if (var13 != -1) {
               if (this.i.k.Y) {
                  if (var7 != null && var7.f()) {
                     this.A = var7;
                     this.F = bmb.b;
                     this.E = var5 == 1;
                  } else {
                     this.A = null;
                  }
               } else if (!this.z) {
                  if (this.i.s.bm.m().a()) {
                     if (this.i.k.ar.a(var5)) {
                        this.a(var7, var13, var5, bik.d);
                     } else {
                        boolean var14 = var13 != -999 && (deo.a(djz.C().aD().i(), 340) || deo.a(djz.C().aD().i(), 344));
                        bik var15 = bik.a;
                        if (var14) {
                           this.S = var7 != null && var7.f() ? var7.e().i() : bmb.b;
                           var15 = bik.b;
                        } else if (var13 == -999) {
                           var15 = bik.e;
                        }

                        this.a(var7, var13, var5, var15);
                     }

                     this.N = true;
                  } else {
                     this.z = true;
                     this.M = var5;
                     this.y.clear();
                     if (var5 == 0) {
                        this.L = 0;
                     } else if (var5 == 1) {
                        this.L = 1;
                     } else if (this.i.k.ar.a(var5)) {
                        this.L = 2;
                     }
                  }
               }
            }
         }

         this.D = var7;
         this.P = var8;
         this.Q = var5;
         return true;
      }
   }

   private void a(int var1) {
      if (this.v != null && this.i.s.bm.m().a()) {
         if (this.i.k.an.a(var1)) {
            this.a((bjr)this.v, this.v.d, 40, (bik)bik.c);
            return;
         }

         for(int var2 = 0; var2 < 9; ++var2) {
            if (this.i.k.aC[var2].a(var1)) {
               this.a(this.v, this.v.d, var2, bik.c);
            }
         }
      }

   }

   protected boolean a(double var1, double var3, int var5, int var6, int var7) {
      return var1 < (double)var5 || var3 < (double)var6 || var1 >= (double)(var5 + this.b) || var3 >= (double)(var6 + this.c);
   }

   public boolean a(double var1, double var3, int var5, double var6, double var8) {
      bjr var10 = this.a(var1, var3);
      bmb var11 = this.i.s.bm.m();
      if (this.A != null && this.i.k.Y) {
         if (var5 == 0 || var5 == 1) {
            if (this.F.a()) {
               if (var10 != this.A && !this.A.e().a()) {
                  this.F = this.A.e().i();
               }
            } else if (this.F.E() > 1 && var10 != null && bic.a(var10, this.F, false)) {
               long var12 = x.b();
               if (this.C == var10) {
                  if (var12 - this.K > 500L) {
                     this.a((bjr)this.A, this.A.d, 0, (bik)bik.a);
                     this.a((bjr)var10, var10.d, 1, (bik)bik.a);
                     this.a((bjr)this.A, this.A.d, 0, (bik)bik.a);
                     this.K = var12 + 750L;
                     this.F.g(1);
                  }
               } else {
                  this.C = var10;
                  this.K = var12;
               }
            }
         }
      } else if (this.z && var10 != null && !var11.a() && (var11.E() > this.y.size() || this.L == 2) && bic.a(var10, var11, true) && var10.a(var11) && this.t.b(var10)) {
         this.y.add(var10);
         this.l();
      }

      return true;
   }

   public boolean c(double var1, double var3, int var5) {
      bjr var6 = this.a(var1, var3);
      int var7 = this.w;
      int var8 = this.x;
      boolean var9 = this.a(var1, var3, var7, var8, var5);
      int var10 = -1;
      if (var6 != null) {
         var10 = var6.d;
      }

      if (var9) {
         var10 = -999;
      }

      bjr var12;
      Iterator var13;
      if (this.R && var6 != null && var5 == 0 && this.t.a(bmb.b, var6)) {
         if (y()) {
            if (!this.S.a()) {
               var13 = this.t.a.iterator();

               while(var13.hasNext()) {
                  var12 = (bjr)var13.next();
                  if (var12 != null && var12.a((bfw)this.i.s) && var12.f() && var12.c == var6.c && bic.a(var12, this.S, true)) {
                     this.a(var12, var12.d, var5, bik.b);
                  }
               }
            }
         } else {
            this.a(var6, var10, var5, bik.g);
         }

         this.R = false;
         this.P = 0L;
      } else {
         if (this.z && this.M != var5) {
            this.z = false;
            this.y.clear();
            this.N = true;
            return true;
         }

         if (this.N) {
            this.N = false;
            return true;
         }

         boolean var11;
         if (this.A != null && this.i.k.Y) {
            if (var5 == 0 || var5 == 1) {
               if (this.F.a() && var6 != this.A) {
                  this.F = this.A.e();
               }

               var11 = bic.a(var6, this.F, false);
               if (var10 != -1 && !this.F.a() && var11) {
                  this.a(this.A, this.A.d, var5, bik.a);
                  this.a((bjr)var6, var10, 0, (bik)bik.a);
                  if (this.i.s.bm.m().a()) {
                     this.J = bmb.b;
                  } else {
                     this.a(this.A, this.A.d, var5, bik.a);
                     this.G = afm.c(var1 - (double)var7);
                     this.H = afm.c(var3 - (double)var8);
                     this.B = this.A;
                     this.J = this.F;
                     this.I = x.b();
                  }
               } else if (!this.F.a()) {
                  this.G = afm.c(var1 - (double)var7);
                  this.H = afm.c(var3 - (double)var8);
                  this.B = this.A;
                  this.J = this.F;
                  this.I = x.b();
               }

               this.F = bmb.b;
               this.A = null;
            }
         } else if (this.z && !this.y.isEmpty()) {
            this.a((bjr)null, -999, bic.b(0, this.L), (bik)bik.f);
            var13 = this.y.iterator();

            while(var13.hasNext()) {
               var12 = (bjr)var13.next();
               this.a(var12, var12.d, bic.b(1, this.L), bik.f);
            }

            this.a((bjr)null, -999, bic.b(2, this.L), (bik)bik.f);
         } else if (!this.i.s.bm.m().a()) {
            if (this.i.k.ar.a(var5)) {
               this.a(var6, var10, var5, bik.d);
            } else {
               var11 = var10 != -999 && (deo.a(djz.C().aD().i(), 340) || deo.a(djz.C().aD().i(), 344));
               if (var11) {
                  this.S = var6 != null && var6.f() ? var6.e().i() : bmb.b;
               }

               this.a(var6, var10, var5, var11 ? bik.b : bik.a);
            }
         }
      }

      if (this.i.s.bm.m().a()) {
         this.P = 0L;
      }

      this.z = false;
      return true;
   }

   private boolean a(bjr var1, double var2, double var4) {
      return this.a(var1.e, var1.f, 16, 16, var2, var4);
   }

   protected boolean a(int var1, int var2, int var3, int var4, double var5, double var7) {
      int var9 = this.w;
      int var10 = this.x;
      var5 -= (double)var9;
      var7 -= (double)var10;
      return var5 >= (double)(var1 - 1) && var5 < (double)(var1 + var3 + 1) && var7 >= (double)(var2 - 1) && var7 < (double)(var2 + var4 + 1);
   }

   protected void a(bjr var1, int var2, int var3, bik var4) {
      if (var1 != null) {
         var2 = var1.d;
      }

      this.i.q.a(this.t.b, var2, var3, var4, this.i.s);
   }

   public boolean a(int var1, int var2, int var3) {
      if (super.a(var1, var2, var3)) {
         return true;
      } else if (this.i.k.am.a(var1, var2)) {
         this.at_();
         return true;
      } else {
         this.b(var1, var2);
         if (this.v != null && this.v.f()) {
            if (this.i.k.ar.a(var1, var2)) {
               this.a((bjr)this.v, this.v.d, 0, (bik)bik.d);
            } else if (this.i.k.ao.a(var1, var2)) {
               this.a(this.v, this.v.d, x() ? 1 : 0, bik.e);
            }
         }

         return true;
      }
   }

   protected boolean b(int var1, int var2) {
      if (this.i.s.bm.m().a() && this.v != null) {
         if (this.i.k.an.a(var1, var2)) {
            this.a((bjr)this.v, this.v.d, 40, (bik)bik.c);
            return true;
         }

         for(int var3 = 0; var3 < 9; ++var3) {
            if (this.i.k.aC[var3].a(var1, var2)) {
               this.a(this.v, this.v.d, var3, bik.c);
               return true;
            }
         }
      }

      return false;
   }

   public void e() {
      if (this.i.s != null) {
         this.t.b((bfw)this.i.s);
      }
   }

   public boolean ay_() {
      return false;
   }

   public void d() {
      super.d();
      if (!this.i.s.aX() || this.i.s.y) {
         this.i.s.m();
      }

   }

   public T h() {
      return this.t;
   }

   public void at_() {
      this.i.s.m();
      super.at_();
   }
}
