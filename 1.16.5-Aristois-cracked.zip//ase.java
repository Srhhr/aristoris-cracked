import com.google.common.collect.ImmutableMap;
import java.util.function.Predicate;

public class ase<E extends aqm> extends arv<E> {
   private final Predicate<E> b;
   private final ayd<?> c;

   public ase(Predicate<E> var1, ayd<?> var2) {
      super(ImmutableMap.of(var2, aye.a));
      this.b = var1;
      this.c = var2;
   }

   protected boolean a(aag var1, E var2) {
      return this.b.test(var2);
   }

   protected void a(aag var1, E var2, long var3) {
      var2.cJ().b(this.c);
   }
}
