import com.google.common.collect.ImmutableList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import java.util.stream.Stream;
import javax.annotation.Nullable;

public class bai extends azx implements aqs {
   protected static final us<Byte> b;
   private int c;
   private int d;
   private static final afh bo;
   private int bp;
   private UUID bq;

   public bai(aqe<? extends bai> var1, brx var2) {
      super(var1, var2);
      this.G = 1.0F;
   }

   protected void o() {
      this.bk.a(1, new awf(this, 1.0D, true));
      this.bk.a(2, new awl(this, 0.9D, 32.0F));
      this.bk.a(2, new awg(this, 0.6D, false));
      this.bk.a(4, new avx(this, 0.6D));
      this.bk.a(5, new awn(this));
      this.bk.a(7, new awd(this, bfw.class, 6.0F));
      this.bk.a(8, new aws(this));
      this.bl.a(1, new axo(this));
      this.bl.a(2, new axp(this, new Class[0]));
      this.bl.a(3, new axq(this, bfw.class, 10, true, false, this::a_));
      this.bl.a(3, new axq(this, aqn.class, 5, false, false, (var0) -> {
         return var0 instanceof bdi && !(var0 instanceof bdc);
      }));
      this.bl.a(4, new axw(this, false));
   }

   protected void e() {
      super.e();
      this.R.a((us)b, (byte)0);
   }

   public static ark.a m() {
      return aqn.p().a(arl.a, 100.0D).a(arl.d, 0.25D).a(arl.c, 1.0D).a(arl.f, 15.0D);
   }

   protected int l(int var1) {
      return var1;
   }

   protected void C(aqa var1) {
      if (var1 instanceof bdi && !(var1 instanceof bdc) && this.cY().nextInt(20) == 0) {
         this.h((aqm)var1);
      }

      super.C(var1);
   }

   public void k() {
      super.k();
      if (this.c > 0) {
         --this.c;
      }

      if (this.d > 0) {
         --this.d;
      }

      if (c(this.cC()) > 2.500000277905201E-7D && this.J.nextInt(5) == 0) {
         int var1 = afm.c(this.cD());
         int var2 = afm.c(this.cE() - 0.20000000298023224D);
         int var3 = afm.c(this.cH());
         ceh var4 = this.l.d_(new fx(var1, var2, var3));
         if (!var4.g()) {
            this.l.a(new hc(hh.d, var4), this.cD() + ((double)this.J.nextFloat() - 0.5D) * (double)this.cy(), this.cE() + 0.1D, this.cH() + ((double)this.J.nextFloat() - 0.5D) * (double)this.cy(), 4.0D * ((double)this.J.nextFloat() - 0.5D), 0.5D, ((double)this.J.nextFloat() - 0.5D) * 4.0D);
         }
      }

      if (!this.l.v) {
         this.a((aag)this.l, true);
      }

   }

   public boolean a(aqe<?> var1) {
      if (this.eN() && var1 == aqe.bc) {
         return false;
      } else {
         return var1 == aqe.m ? false : super.a(var1);
      }
   }

   public void b(md var1) {
      super.b(var1);
      var1.a("PlayerCreated", this.eN());
      this.c(var1);
   }

   public void a(md var1) {
      super.a(var1);
      this.u(var1.q("PlayerCreated"));
      this.a((aag)this.l, var1);
   }

   public void G_() {
      this.a_(bo.a(this.J));
   }

   public void a_(int var1) {
      this.bp = var1;
   }

   public int E_() {
      return this.bp;
   }

   public void a(@Nullable UUID var1) {
      this.bq = var1;
   }

   public UUID F_() {
      return this.bq;
   }

   private float eO() {
      return (float)this.b(arl.f);
   }

   public boolean B(aqa var1) {
      this.c = 10;
      this.l.a(this, (byte)4);
      float var2 = this.eO();
      float var3 = (int)var2 > 0 ? var2 / 2.0F + (float)this.J.nextInt((int)var2) : var2;
      boolean var4 = var1.a(apk.c(this), var3);
      if (var4) {
         var1.f(var1.cC().b(0.0D, 0.4000000059604645D, 0.0D));
         this.a(this, var1);
      }

      this.a(adq.gx, 1.0F, 1.0F);
      return var4;
   }

   public boolean a(apk var1, float var2) {
      bai.a var3 = this.eK();
      boolean var4 = super.a(var1, var2);
      if (var4 && this.eK() != var3) {
         this.a(adq.gy, 1.0F, 1.0F);
      }

      return var4;
   }

   public bai.a eK() {
      return bai.a.a(this.dk() / this.dx());
   }

   public void a(byte var1) {
      if (var1 == 4) {
         this.c = 10;
         this.a(adq.gx, 1.0F, 1.0F);
      } else if (var1 == 11) {
         this.d = 400;
      } else if (var1 == 34) {
         this.d = 0;
      } else {
         super.a(var1);
      }

   }

   public int eL() {
      return this.c;
   }

   public void t(boolean var1) {
      if (var1) {
         this.d = 400;
         this.l.a(this, (byte)11);
      } else {
         this.d = 0;
         this.l.a(this, (byte)34);
      }

   }

   protected adp e(apk var1) {
      return adq.gA;
   }

   protected adp dq() {
      return adq.gz;
   }

   protected aou b(bfw var1, aot var2) {
      bmb var3 = var1.b((aot)var2);
      blx var4 = var3.b();
      if (var4 != bmd.kh) {
         return aou.c;
      } else {
         float var5 = this.dk();
         this.b(25.0F);
         if (this.dk() == var5) {
            return aou.c;
         } else {
            float var6 = 1.0F + (this.J.nextFloat() - this.J.nextFloat()) * 0.2F;
            this.a(adq.gB, 1.0F, var6);
            if (!var1.bC.d) {
               var3.g(1);
            }

            return aou.a(this.l.v);
         }
      }
   }

   protected void b(fx var1, ceh var2) {
      this.a(adq.gC, 1.0F, 1.0F);
   }

   public int eM() {
      return this.d;
   }

   public boolean eN() {
      return ((Byte)this.R.a(b) & 1) != 0;
   }

   public void u(boolean var1) {
      byte var2 = (Byte)this.R.a(b);
      if (var1) {
         this.R.b(b, (byte)(var2 | 1));
      } else {
         this.R.b(b, (byte)(var2 & -2));
      }

   }

   public void a(apk var1) {
      super.a(var1);
   }

   public boolean a(brz var1) {
      fx var2 = this.cB();
      fx var3 = var2.c();
      ceh var4 = var1.d_(var3);
      if (!var4.a(var1, var3, this)) {
         return false;
      } else {
         for(int var5 = 1; var5 < 3; ++var5) {
            fx var6 = var2.b(var5);
            ceh var7 = var1.d_(var6);
            if (!bsg.a((brc)var1, (fx)var6, (ceh)var7, (cux)var7.m(), (aqe)aqe.K)) {
               return false;
            }
         }

         return bsg.a((brc)var1, (fx)var2, (ceh)var1.d_(var2), (cux)cuy.a.h(), (aqe)aqe.K) && var1.j(this);
      }
   }

   public dcn cf() {
      return new dcn(0.0D, (double)(0.875F * this.ce()), (double)(this.cy() * 0.4F));
   }

   static {
      b = uv.a(bai.class, uu.a);
      bo = afu.a(20, 39);
   }

   public static enum a {
      a(1.0F),
      b(0.75F),
      c(0.5F),
      d(0.25F);

      private static final List<bai.a> e = (List)Stream.of(values()).sorted(Comparator.comparingDouble((var0) -> {
         return (double)var0.f;
      })).collect(ImmutableList.toImmutableList());
      private final float f;

      private a(float var3) {
         this.f = var3;
      }

      public static bai.a a(float var0) {
         Iterator var1 = e.iterator();

         bai.a var2;
         do {
            if (!var1.hasNext()) {
               return a;
            }

            var2 = (bai.a)var1.next();
         } while(!(var0 < var2.f));

         return var2;
      }
   }
}
