public enum cez implements afs {
   a("single", 0),
   b("left", 2),
   c("right", 1);

   public static final cez[] d = values();
   private final String e;
   private final int f;

   private cez(String var3, int var4) {
      this.e = var3;
      this.f = var4;
   }

   public String a() {
      return this.e;
   }

   public cez b() {
      return d[this.f];
   }
}
