import com.google.common.collect.Lists;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Nullable;

public class ccg extends ccj implements cdm {
   private final List<ccg.a> a = Lists.newArrayList();
   @Nullable
   private fx b = null;

   public ccg() {
      super(cck.G);
   }

   public void X_() {
      if (this.d()) {
         this.a((bfw)null, this.d.d_(this.o()), ccg.b.c);
      }

      super.X_();
   }

   public boolean d() {
      if (this.d == null) {
         return false;
      } else {
         Iterator var1 = fx.a(this.e.b(-1, -1, -1), this.e.b(1, 1, 1)).iterator();

         fx var2;
         do {
            if (!var1.hasNext()) {
               return false;
            }

            var2 = (fx)var1.next();
         } while(!(this.d.d_(var2).b() instanceof bws));

         return true;
      }
   }

   public boolean f() {
      return this.a.isEmpty();
   }

   public boolean h() {
      return this.a.size() == 3;
   }

   public void a(@Nullable bfw var1, ceh var2, ccg.b var3) {
      List<aqa> var4 = this.a(var2, var3);
      if (var1 != null) {
         Iterator var5 = var4.iterator();

         while(var5.hasNext()) {
            aqa var6 = (aqa)var5.next();
            if (var6 instanceof baa) {
               baa var7 = (baa)var6;
               if (var1.cA().g(var6.cA()) <= 16.0D) {
                  if (!this.k()) {
                     var7.h((aqm)var1);
                  } else {
                     var7.t(400);
                  }
               }
            }
         }
      }

   }

   private List<aqa> a(ceh var1, ccg.b var2) {
      List<aqa> var3 = Lists.newArrayList();
      this.a.removeIf((var4) -> {
         return this.a(var1, var4, var3, var2);
      });
      return var3;
   }

   public void a(aqa var1, boolean var2) {
      this.a(var1, var2, 0);
   }

   public int j() {
      return this.a.size();
   }

   public static int a(ceh var0) {
      return (Integer)var0.c(buk.b);
   }

   public boolean k() {
      return buy.a(this.d, this.o());
   }

   protected void l() {
      rz.a(this);
   }

   public void a(aqa var1, boolean var2, int var3) {
      if (this.a.size() < 3) {
         var1.l();
         var1.be();
         md var4 = new md();
         var1.d(var4);
         this.a.add(new ccg.a(var4, var3, var2 ? 2400 : 600));
         if (this.d != null) {
            if (var1 instanceof baa) {
               baa var5 = (baa)var1;
               if (var5.eL() && (!this.x() || this.d.t.nextBoolean())) {
                  this.b = var5.eK();
               }
            }

            fx var6 = this.o();
            this.d.a((bfw)null, (double)var6.u(), (double)var6.v(), (double)var6.w(), adq.aF, adr.e, 1.0F, 1.0F);
         }

         var1.ad();
      }
   }

   private boolean a(ceh var1, ccg.a var2, @Nullable List<aqa> var3, ccg.b var4) {
      if ((this.d.N() || this.d.X()) && var4 != ccg.b.c) {
         return false;
      } else {
         fx var5 = this.o();
         md var6 = var2.a;
         var6.r("Passengers");
         var6.r("Leash");
         var6.r("UUID");
         gc var7 = (gc)var1.c(buk.a);
         fx var8 = var5.a(var7);
         boolean var9 = !this.d.d_(var8).k(this.d, var8).b();
         if (var9 && var4 != ccg.b.c) {
            return false;
         } else {
            aqa var10 = aqe.a(var6, this.d, (var0) -> {
               return var0;
            });
            if (var10 != null) {
               if (!var10.X().a((ael)aee.d)) {
                  return false;
               } else {
                  if (var10 instanceof baa) {
                     baa var11 = (baa)var10;
                     if (this.x() && !var11.eL() && this.d.t.nextFloat() < 0.9F) {
                        var11.g(this.b);
                     }

                     if (var4 == ccg.b.a) {
                        var11.fb();
                        if (var1.b().a((ael)aed.aj)) {
                           int var12 = a(var1);
                           if (var12 < 5) {
                              int var13 = this.d.t.nextInt(100) == 0 ? 2 : 1;
                              if (var12 + var13 > 5) {
                                 --var13;
                              }

                              this.d.a(this.o(), (ceh)var1.a(buk.b, var12 + var13));
                           }
                        }
                     }

                     this.a(var2.b, var11);
                     if (var3 != null) {
                        var3.add(var11);
                     }

                     float var21 = var10.cy();
                     double var22 = var9 ? 0.0D : 0.55D + (double)(var21 / 2.0F);
                     double var15 = (double)var5.u() + 0.5D + var22 * (double)var7.i();
                     double var17 = (double)var5.v() + 0.5D - (double)(var10.cz() / 2.0F);
                     double var19 = (double)var5.w() + 0.5D + var22 * (double)var7.k();
                     var10.b(var15, var17, var19, var10.p, var10.q);
                  }

                  this.d.a((bfw)null, (fx)var5, adq.aG, adr.e, 1.0F, 1.0F);
                  return this.d.c((aqa)var10);
               }
            } else {
               return false;
            }
         }
      }
   }

   private void a(int var1, baa var2) {
      int var3 = var2.i();
      if (var3 < 0) {
         var2.c_(Math.min(0, var3 + var1));
      } else if (var3 > 0) {
         var2.c_(Math.max(0, var3 - var1));
      }

      var2.s(Math.max(0, var2.eQ() - var1));
      var2.eO();
   }

   private boolean x() {
      return this.b != null;
   }

   private void y() {
      Iterator<ccg.a> var1 = this.a.iterator();

      ccg.a var3;
      for(ceh var2 = this.p(); var1.hasNext(); var3.b++) {
         var3 = (ccg.a)var1.next();
         if (var3.b > var3.c) {
            ccg.b var4 = var3.a.q("HasNectar") ? ccg.b.a : ccg.b.b;
            if (this.a(var2, (ccg.a)var3, (List)null, (ccg.b)var4)) {
               var1.remove();
            }
         }
      }

   }

   public void aj_() {
      if (!this.d.v) {
         this.y();
         fx var1 = this.o();
         if (this.a.size() > 0 && this.d.u_().nextDouble() < 0.005D) {
            double var2 = (double)var1.u() + 0.5D;
            double var4 = (double)var1.v();
            double var6 = (double)var1.w() + 0.5D;
            this.d.a((bfw)null, var2, var4, var6, adq.aI, adr.e, 1.0F, 1.0F);
         }

         this.l();
      }
   }

   public void a(ceh var1, md var2) {
      super.a(var1, var2);
      this.a.clear();
      mj var3 = var2.d("Bees", 10);

      for(int var4 = 0; var4 < var3.size(); ++var4) {
         md var5 = var3.a(var4);
         ccg.a var6 = new ccg.a(var5.p("EntityData"), var5.h("TicksInHive"), var5.h("MinOccupationTicks"));
         this.a.add(var6);
      }

      this.b = null;
      if (var2.e("FlowerPos")) {
         this.b = mp.b(var2.p("FlowerPos"));
      }

   }

   public md a(md var1) {
      super.a(var1);
      var1.a((String)"Bees", (mt)this.m());
      if (this.x()) {
         var1.a((String)"FlowerPos", (mt)mp.a(this.b));
      }

      return var1;
   }

   public mj m() {
      mj var1 = new mj();
      Iterator var2 = this.a.iterator();

      while(var2.hasNext()) {
         ccg.a var3 = (ccg.a)var2.next();
         var3.a.r("UUID");
         md var4 = new md();
         var4.a((String)"EntityData", (mt)var3.a);
         var4.b("TicksInHive", var3.b);
         var4.b("MinOccupationTicks", var3.c);
         var1.add(var4);
      }

      return var1;
   }

   static class a {
      private final md a;
      private int b;
      private final int c;

      private a(md var1, int var2, int var3) {
         var1.r("UUID");
         this.a = var1;
         this.b = var2;
         this.c = var3;
      }

      // $FF: synthetic method
      a(md var1, int var2, int var3, Object var4) {
         this(var1, var2, var3);
      }
   }

   public static enum b {
      a,
      b,
      c;
   }
}
