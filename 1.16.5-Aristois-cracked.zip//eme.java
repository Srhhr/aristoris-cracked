public interface eme {
   void a();
}
