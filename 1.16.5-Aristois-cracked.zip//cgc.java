import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import javax.annotation.Nullable;

public class cgc extends cgh {
   private static final bsv[] b;

   public cgc(brx var1, brd var2) {
      super(var1, var2, new cfx(var1.r().b(gm.ay), b));
   }

   public ceh d_(fx var1) {
      return bup.la.n();
   }

   @Nullable
   public ceh a(fx var1, ceh var2, boolean var3) {
      return null;
   }

   public cux b(fx var1) {
      return cuy.a.h();
   }

   @Nullable
   public cuo e() {
      return null;
   }

   public int g(fx var1) {
      return 0;
   }

   public void a(aqa var1) {
   }

   public void b(aqa var1) {
   }

   public void a(aqa var1, int var2) {
   }

   @Nullable
   public ccj a(fx var1, cgh.a var2) {
      return null;
   }

   public void a(ccj var1) {
   }

   public void a(fx var1, ccj var2) {
   }

   public void d(fx var1) {
   }

   public void s() {
   }

   public void a(@Nullable aqa var1, dci var2, List<aqa> var3, Predicate<? super aqa> var4) {
   }

   public <T extends aqa> void a(Class<? extends T> var1, dci var2, List<T> var3, Predicate<? super T> var4) {
   }

   public boolean t() {
      return true;
   }

   public boolean a(int var1, int var2) {
      return true;
   }

   public zr.b u() {
      return zr.b.b;
   }

   static {
      b = (bsv[])x.a((Object)(new bsv[cfx.a]), (Consumer)((var0) -> {
         Arrays.fill(var0, kt.a);
      }));
   }
}
