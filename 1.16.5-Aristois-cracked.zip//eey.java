import java.util.Random;

public class eey extends eeu<bcu> {
   public eey(eet var1) {
      super(var1);
      this.c = 0.5F;
   }

   public void a(bcu var1, float var2, float var3, dfm var4, eag var5, int var6) {
      ceh var7 = var1.i();
      if (var7.h() == bzh.c) {
         brx var8 = var1.h();
         if (var7 != var8.d_(var1.cB()) && var7.h() != bzh.a) {
            var4.a();
            fx var9 = new fx(var1.cD(), var1.cc().e, var1.cH());
            var4.a(-0.5D, 0.0D, -0.5D);
            eax var10 = djz.C().ab();
            var10.b().a(var8, var10.a(var7), var7, var9, var4, var5.getBuffer(eab.b(var7)), false, new Random(), var7.a(var1.g()), ejw.a);
            var4.b();
            super.a(var1, var2, var3, var4, var5, var6);
         }
      }
   }

   public vk a(bcu var1) {
      return ekb.d;
   }
}
