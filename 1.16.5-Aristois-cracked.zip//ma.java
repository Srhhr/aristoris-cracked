import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import org.apache.commons.lang3.ArrayUtils;

public class ma extends mc<mb> {
   public static final mv<ma> a = new mv<ma>() {
      public ma a(DataInput var1, int var2, mm var3) throws IOException {
         var3.a(192L);
         int var4 = var1.readInt();
         var3.a(8L * (long)var4);
         byte[] var5 = new byte[var4];
         var1.readFully(var5);
         return new ma(var5);
      }

      public String a() {
         return "BYTE[]";
      }

      public String b() {
         return "TAG_Byte_Array";
      }

      // $FF: synthetic method
      public mt b(DataInput var1, int var2, mm var3) throws IOException {
         return this.a(var1, var2, var3);
      }
   };
   private byte[] b;

   public ma(byte[] var1) {
      this.b = var1;
   }

   public ma(List<Byte> var1) {
      this(a(var1));
   }

   private static byte[] a(List<Byte> var0) {
      byte[] var1 = new byte[var0.size()];

      for(int var2 = 0; var2 < var0.size(); ++var2) {
         Byte var3 = (Byte)var0.get(var2);
         var1[var2] = var3 == null ? 0 : var3;
      }

      return var1;
   }

   public void a(DataOutput var1) throws IOException {
      var1.writeInt(this.b.length);
      var1.write(this.b);
   }

   public byte a() {
      return 7;
   }

   public mv<ma> b() {
      return a;
   }

   public String toString() {
      StringBuilder var1 = new StringBuilder("[B;");

      for(int var2 = 0; var2 < this.b.length; ++var2) {
         if (var2 != 0) {
            var1.append(',');
         }

         var1.append(this.b[var2]).append('B');
      }

      return var1.append(']').toString();
   }

   public mt c() {
      byte[] var1 = new byte[this.b.length];
      System.arraycopy(this.b, 0, var1, 0, this.b.length);
      return new ma(var1);
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else {
         return var1 instanceof ma && Arrays.equals(this.b, ((ma)var1).b);
      }
   }

   public int hashCode() {
      return Arrays.hashCode(this.b);
   }

   public nr a(String var1, int var2) {
      nr var3 = (new oe("B")).a(g);
      nx var4 = (new oe("[")).a(var3).c(";");

      for(int var5 = 0; var5 < this.b.length; ++var5) {
         nx var6 = (new oe(String.valueOf(this.b[var5]))).a(f);
         var4.c(" ").a((nr)var6).a((nr)var3);
         if (var5 != this.b.length - 1) {
            var4.c(",");
         }
      }

      var4.c("]");
      return var4;
   }

   public byte[] d() {
      return this.b;
   }

   public int size() {
      return this.b.length;
   }

   public mb a(int var1) {
      return mb.a(this.b[var1]);
   }

   public mb a(int var1, mb var2) {
      byte var3 = this.b[var1];
      this.b[var1] = var2.h();
      return mb.a(var3);
   }

   public void b(int var1, mb var2) {
      this.b = ArrayUtils.add(this.b, var1, var2.h());
   }

   public boolean a(int var1, mt var2) {
      if (var2 instanceof mq) {
         this.b[var1] = ((mq)var2).h();
         return true;
      } else {
         return false;
      }
   }

   public boolean b(int var1, mt var2) {
      if (var2 instanceof mq) {
         this.b = ArrayUtils.add(this.b, var1, ((mq)var2).h());
         return true;
      } else {
         return false;
      }
   }

   public mb b(int var1) {
      byte var2 = this.b[var1];
      this.b = ArrayUtils.remove(this.b, var1);
      return mb.a(var2);
   }

   public byte d_() {
      return 1;
   }

   public void clear() {
      this.b = new byte[0];
   }

   // $FF: synthetic method
   public mt c(int var1) {
      return this.b(var1);
   }

   // $FF: synthetic method
   public void c(int var1, mt var2) {
      this.b(var1, (mb)var2);
   }

   // $FF: synthetic method
   public mt d(int var1, mt var2) {
      return this.a(var1, (mb)var2);
   }

   // $FF: synthetic method
   public Object remove(int var1) {
      return this.b(var1);
   }

   // $FF: synthetic method
   public void add(int var1, Object var2) {
      this.b(var1, (mb)var2);
   }

   // $FF: synthetic method
   public Object set(int var1, Object var2) {
      return this.a(var1, (mb)var2);
   }

   // $FF: synthetic method
   public Object get(int var1) {
      return this.a(var1);
   }
}
