public class djf extends dja {
   private final long c;
   private final int d;
   private final Runnable e;

   public djf(long var1, int var3, Runnable var4) {
      this.c = var1;
      this.d = var3;
      this.e = var4;
   }

   public void run() {
      dgb var1 = dgb.a();
      this.b(new of("mco.minigame.world.slot.screen.title"));

      for(int var2 = 0; var2 < 25; ++var2) {
         try {
            if (this.c()) {
               return;
            }

            if (var1.a(this.c, this.d)) {
               this.e.run();
               break;
            }
         } catch (dhj var4) {
            if (this.c()) {
               return;
            }

            a(var4.e);
         } catch (Exception var5) {
            if (this.c()) {
               return;
            }

            a.error("Couldn't switch world!");
            this.a(var5.toString());
         }
      }

   }
}
