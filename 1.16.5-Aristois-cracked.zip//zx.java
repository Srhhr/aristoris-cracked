import java.util.UUID;

public class zx extends aai {
   private boolean c;
   private boolean d;
   private int e;
   private int f;

   public zx(aag var1) {
      super(var1);
   }

   public void a() {
      super.a();
      ++this.f;
      long var1 = this.a.T();
      long var3 = var1 / 24000L + 1L;
      if (!this.c && this.f > 20) {
         this.c = true;
         this.b.b.a((oj)(new pq(pq.f, 0.0F)));
      }

      this.d = var1 > 120500L;
      if (this.d) {
         ++this.e;
      }

      if (var1 % 24000L == 500L) {
         if (var3 <= 6L) {
            if (var3 == 6L) {
               this.b.b.a((oj)(new pq(pq.f, 104.0F)));
            } else {
               this.b.a((nr)(new of("demo.day." + var3)), (UUID)x.b);
            }
         }
      } else if (var3 == 1L) {
         if (var1 == 100L) {
            this.b.b.a((oj)(new pq(pq.f, 101.0F)));
         } else if (var1 == 175L) {
            this.b.b.a((oj)(new pq(pq.f, 102.0F)));
         } else if (var1 == 250L) {
            this.b.b.a((oj)(new pq(pq.f, 103.0F)));
         }
      } else if (var3 == 5L && var1 % 24000L == 22000L) {
         this.b.a((nr)(new of("demo.day.warning")), (UUID)x.b);
      }

   }

   private void f() {
      if (this.e > 100) {
         this.b.a((nr)(new of("demo.reminder")), (UUID)x.b);
         this.e = 0;
      }

   }

   public void a(fx var1, sz.a var2, gc var3, int var4) {
      if (this.d) {
         this.f();
      } else {
         super.a(var1, var2, var3, var4);
      }
   }

   public aou a(aah var1, brx var2, bmb var3, aot var4) {
      if (this.d) {
         this.f();
         return aou.c;
      } else {
         return super.a(var1, var2, var3, var4);
      }
   }

   public aou a(aah var1, brx var2, bmb var3, aot var4, dcj var5) {
      if (this.d) {
         this.f();
         return aou.c;
      } else {
         return super.a(var1, var2, var3, var4, var5);
      }
   }
}
