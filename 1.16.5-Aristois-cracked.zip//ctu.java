import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

public class ctu implements ctv {
   public static final Codec<ctu> a = RecordCodecBuilder.create((var0) -> {
      return var0.group(ceh.b.fieldOf("top_material").forGetter((var0x) -> {
         return var0x.b;
      }), ceh.b.fieldOf("under_material").forGetter((var0x) -> {
         return var0x.c;
      }), ceh.b.fieldOf("underwater_material").forGetter((var0x) -> {
         return var0x.d;
      })).apply(var0, ctu::new);
   });
   private final ceh b;
   private final ceh c;
   private final ceh d;

   public ctu(ceh var1, ceh var2, ceh var3) {
      this.b = var1;
      this.c = var2;
      this.d = var3;
   }

   public ceh a() {
      return this.b;
   }

   public ceh b() {
      return this.c;
   }

   public ceh c() {
      return this.d;
   }
}
