import com.mojang.blaze3d.systems.RenderSystem;
import java.util.Iterator;

public class dqr extends dpp<bjg> {
   private static final vk A = new vk("textures/gui/container/villager2.png");
   private static final nr B = new of("merchant.trades");
   private static final nr C = new oe(" - ");
   private static final nr D = new of("merchant.deprecated");
   private int E;
   private final dqr.a[] F = new dqr.a[7];
   private int G;
   private boolean H;

   public dqr(bjg var1, bfv var2, nr var3) {
      super(var1, var2, var3);
      this.b = 276;
      this.r = 107;
   }

   private void i() {
      ((bjg)this.t).d(this.E);
      ((bjg)this.t).g(this.E);
      this.i.w().a((oj)(new th(this.E)));
   }

   protected void b() {
      super.b();
      int var1 = (this.k - this.b) / 2;
      int var2 = (this.l - this.c) / 2;
      int var3 = var2 + 16 + 2;

      for(int var4 = 0; var4 < 7; ++var4) {
         this.F[var4] = (dqr.a)this.a((dlh)(new dqr.a(var1 + 5, var3, var4, (var1x) -> {
            if (var1x instanceof dqr.a) {
               this.E = ((dqr.a)var1x).a() + this.G;
               this.i();
            }

         })));
         var3 += 20;
      }

   }

   protected void b(dfm var1, int var2, int var3) {
      int var4 = ((bjg)this.t).g();
      if (var4 > 0 && var4 <= 5 && ((bjg)this.t).j()) {
         nr var5 = this.d.e().a(C).a((nr)(new of("merchant.level." + var4)));
         int var6 = this.o.a((nu)var5);
         int var7 = 49 + this.b / 2 - var6 / 2;
         this.o.b(var1, (nr)var5, (float)var7, 6.0F, 4210752);
      } else {
         this.o.b(var1, this.d, (float)(49 + this.b / 2 - this.o.a((nu)this.d) / 2), 6.0F, 4210752);
      }

      this.o.b(var1, this.u.d(), (float)this.r, (float)this.s, 4210752);
      int var8 = this.o.a((nu)B);
      this.o.b(var1, B, (float)(5 - var8 / 2 + 48), 6.0F, 4210752);
   }

   protected void a(dfm var1, float var2, int var3, int var4) {
      RenderSystem.color4f(1.0F, 1.0F, 1.0F, 1.0F);
      this.i.M().a(A);
      int var5 = (this.k - this.b) / 2;
      int var6 = (this.l - this.c) / 2;
      a(var1, var5, var6, this.v(), 0.0F, 0.0F, this.b, this.c, 256, 512);
      bqw var7 = ((bjg)this.t).i();
      if (!var7.isEmpty()) {
         int var8 = this.E;
         if (var8 < 0 || var8 >= var7.size()) {
            return;
         }

         bqv var9 = (bqv)var7.get(var8);
         if (var9.p()) {
            this.i.M().a(A);
            RenderSystem.color4f(1.0F, 1.0F, 1.0F, 1.0F);
            a(var1, this.w + 83 + 99, this.x + 35, this.v(), 311.0F, 0.0F, 28, 21, 256, 512);
         }
      }

   }

   private void a(dfm var1, int var2, int var3, bqv var4) {
      this.i.M().a(A);
      int var5 = ((bjg)this.t).g();
      int var6 = ((bjg)this.t).e();
      if (var5 < 5) {
         a(var1, var2 + 136, var3 + 16, this.v(), 0.0F, 186.0F, 102, 5, 256, 512);
         int var7 = bfk.b(var5);
         if (var6 >= var7 && bfk.d(var5)) {
            int var8 = true;
            float var9 = 100.0F / (float)(bfk.c(var5) - var7);
            int var10 = Math.min(afm.d(var9 * (float)(var6 - var7)), 100);
            a(var1, var2 + 136, var3 + 16, this.v(), 0.0F, 191.0F, var10 + 1, 5, 256, 512);
            int var11 = ((bjg)this.t).f();
            if (var11 > 0) {
               int var12 = Math.min(afm.d((float)var11 * var9), 100 - var10);
               a(var1, var2 + 136 + var10 + 1, var3 + 16 + 1, this.v(), 2.0F, 182.0F, var12, 3, 256, 512);
            }

         }
      }
   }

   private void a(dfm var1, int var2, int var3, bqw var4) {
      int var5 = var4.size() + 1 - 7;
      if (var5 > 1) {
         int var6 = 139 - (27 + (var5 - 1) * 139 / var5);
         int var7 = 1 + var6 / var5 + 139 / var5;
         int var8 = true;
         int var9 = Math.min(113, this.G * var7);
         if (this.G == var5 - 1) {
            var9 = 113;
         }

         a(var1, var2 + 94, var3 + 18 + var9, this.v(), 0.0F, 199.0F, 6, 27, 256, 512);
      } else {
         a(var1, var2 + 94, var3 + 18, this.v(), 6.0F, 199.0F, 6, 27, 256, 512);
      }

   }

   public void a(dfm var1, int var2, int var3, float var4) {
      this.a((dfm)var1);
      super.a(var1, var2, var3, var4);
      bqw var5 = ((bjg)this.t).i();
      if (!var5.isEmpty()) {
         int var6 = (this.k - this.b) / 2;
         int var7 = (this.l - this.c) / 2;
         int var8 = var7 + 16 + 1;
         int var9 = var6 + 5 + 5;
         RenderSystem.pushMatrix();
         RenderSystem.enableRescaleNormal();
         this.i.M().a(A);
         this.a(var1, var6, var7, var5);
         int var10 = 0;
         Iterator var11 = var5.iterator();

         while(true) {
            bqv var12;
            while(var11.hasNext()) {
               var12 = (bqv)var11.next();
               if (this.a(var5.size()) && (var10 < this.G || var10 >= 7 + this.G)) {
                  ++var10;
               } else {
                  bmb var13 = var12.a();
                  bmb var14 = var12.b();
                  bmb var15 = var12.c();
                  bmb var16 = var12.d();
                  this.j.b = 100.0F;
                  int var17 = var8 + 2;
                  this.a(var1, var14, var13, var9, var17);
                  if (!var15.a()) {
                     this.j.c(var15, var6 + 5 + 35, var17);
                     this.j.a(this.o, var15, var6 + 5 + 35, var17);
                  }

                  this.a(var1, var12, var6, var17);
                  this.j.c(var16, var6 + 5 + 68, var17);
                  this.j.a(this.o, var16, var6 + 5 + 68, var17);
                  this.j.b = 0.0F;
                  var8 += 20;
                  ++var10;
               }
            }

            int var18 = this.E;
            var12 = (bqv)var5.get(var18);
            if (((bjg)this.t).j()) {
               this.a(var1, var6, var7, var12);
            }

            if (var12.p() && this.a(186, 35, 22, 21, (double)var2, (double)var3) && ((bjg)this.t).h()) {
               this.b(var1, D, var2, var3);
            }

            dqr.a[] var19 = this.F;
            int var20 = var19.length;

            for(int var21 = 0; var21 < var20; ++var21) {
               dqr.a var22 = var19[var21];
               if (var22.g()) {
                  var22.a(var1, var2, var3);
               }

               var22.p = var22.a < ((bjg)this.t).i().size();
            }

            RenderSystem.popMatrix();
            RenderSystem.enableDepthTest();
            break;
         }
      }

      this.a(var1, var2, var3);
   }

   private void a(dfm var1, bqv var2, int var3, int var4) {
      RenderSystem.enableBlend();
      this.i.M().a(A);
      if (var2.p()) {
         a(var1, var3 + 5 + 35 + 20, var4 + 3, this.v(), 25.0F, 171.0F, 10, 9, 256, 512);
      } else {
         a(var1, var3 + 5 + 35 + 20, var4 + 3, this.v(), 15.0F, 171.0F, 10, 9, 256, 512);
      }

   }

   private void a(dfm var1, bmb var2, bmb var3, int var4, int var5) {
      this.j.c(var2, var4, var5);
      if (var3.E() == var2.E()) {
         this.j.a(this.o, var2, var4, var5);
      } else {
         this.j.a(this.o, var3, var4, var5, var3.E() == 1 ? "1" : null);
         this.j.a(this.o, var2, var4 + 14, var5, var2.E() == 1 ? "1" : null);
         this.i.M().a(A);
         this.d(this.v() + 300);
         a(var1, var4 + 7, var5 + 12, this.v(), 0.0F, 176.0F, 9, 2, 256, 512);
         this.d(this.v() - 300);
      }

   }

   private boolean a(int var1) {
      return var1 > 7;
   }

   public boolean a(double var1, double var3, double var5) {
      int var7 = ((bjg)this.t).i().size();
      if (this.a(var7)) {
         int var8 = var7 - 7;
         this.G = (int)((double)this.G - var5);
         this.G = afm.a(this.G, 0, var8);
      }

      return true;
   }

   public boolean a(double var1, double var3, int var5, double var6, double var8) {
      int var10 = ((bjg)this.t).i().size();
      if (this.H) {
         int var11 = this.x + 18;
         int var12 = var11 + 139;
         int var13 = var10 - 7;
         float var14 = ((float)var3 - (float)var11 - 13.5F) / ((float)(var12 - var11) - 27.0F);
         var14 = var14 * (float)var13 + 0.5F;
         this.G = afm.a((int)var14, 0, var13);
         return true;
      } else {
         return super.a(var1, var3, var5, var6, var8);
      }
   }

   public boolean a(double var1, double var3, int var5) {
      this.H = false;
      int var6 = (this.k - this.b) / 2;
      int var7 = (this.l - this.c) / 2;
      if (this.a(((bjg)this.t).i().size()) && var1 > (double)(var6 + 94) && var1 < (double)(var6 + 94 + 6) && var3 > (double)(var7 + 18) && var3 <= (double)(var7 + 18 + 139 + 1)) {
         this.H = true;
      }

      return super.a(var1, var3, var5);
   }

   class a extends dlj {
      final int a;

      public a(int var2, int var3, int var4, dlj.a var5) {
         super(var2, var3, 89, 20, oe.d, var5);
         this.a = var4;
         this.p = false;
      }

      public int a() {
         return this.a;
      }

      public void a(dfm var1, int var2, int var3) {
         if (this.n && ((bjg)dqr.this.t).i().size() > this.a + dqr.this.G) {
            bmb var4;
            if (var2 < this.l + 20) {
               var4 = ((bqv)((bjg)dqr.this.t).i().get(this.a + dqr.this.G)).b();
               dqr.this.a(var1, var4, var2, var3);
            } else if (var2 < this.l + 50 && var2 > this.l + 30) {
               var4 = ((bqv)((bjg)dqr.this.t).i().get(this.a + dqr.this.G)).c();
               if (!var4.a()) {
                  dqr.this.a(var1, var4, var2, var3);
               }
            } else if (var2 > this.l + 65) {
               var4 = ((bqv)((bjg)dqr.this.t).i().get(this.a + dqr.this.G)).d();
               dqr.this.a(var1, var4, var2, var3);
            }
         }

      }
   }
}
