import com.google.common.collect.Lists;
import java.util.Iterator;
import java.util.List;
import java.util.function.Predicate;

public class bnu {
   private static final List<bnu.a<bnt>> a = Lists.newArrayList();
   private static final List<bnu.a<blx>> b = Lists.newArrayList();
   private static final List<bon> c = Lists.newArrayList();
   private static final Predicate<bmb> d = (var0) -> {
      Iterator var1 = c.iterator();

      bon var2;
      do {
         if (!var1.hasNext()) {
            return false;
         }

         var2 = (bon)var1.next();
      } while(!var2.a(var0));

      return true;
   };

   public static boolean a(bmb var0) {
      return b(var0) || c(var0);
   }

   protected static boolean b(bmb var0) {
      int var1 = 0;

      for(int var2 = b.size(); var1 < var2; ++var1) {
         if (((bnu.a)b.get(var1)).b.a(var0)) {
            return true;
         }
      }

      return false;
   }

   protected static boolean c(bmb var0) {
      int var1 = 0;

      for(int var2 = a.size(); var1 < var2; ++var1) {
         if (((bnu.a)a.get(var1)).b.a(var0)) {
            return true;
         }
      }

      return false;
   }

   public static boolean a(bnt var0) {
      int var1 = 0;

      for(int var2 = a.size(); var1 < var2; ++var1) {
         if (((bnu.a)a.get(var1)).c == var0) {
            return true;
         }
      }

      return false;
   }

   public static boolean a(bmb var0, bmb var1) {
      if (!d.test(var0)) {
         return false;
      } else {
         return b(var0, var1) || c(var0, var1);
      }
   }

   protected static boolean b(bmb var0, bmb var1) {
      blx var2 = var0.b();
      int var3 = 0;

      for(int var4 = b.size(); var3 < var4; ++var3) {
         bnu.a<blx> var5 = (bnu.a)b.get(var3);
         if (var5.a == var2 && var5.b.a(var1)) {
            return true;
         }
      }

      return false;
   }

   protected static boolean c(bmb var0, bmb var1) {
      bnt var2 = bnv.d(var0);
      int var3 = 0;

      for(int var4 = a.size(); var3 < var4; ++var3) {
         bnu.a<bnt> var5 = (bnu.a)a.get(var3);
         if (var5.a == var2 && var5.b.a(var1)) {
            return true;
         }
      }

      return false;
   }

   public static bmb d(bmb var0, bmb var1) {
      if (!var1.a()) {
         bnt var2 = bnv.d(var1);
         blx var3 = var1.b();
         int var4 = 0;

         int var5;
         bnu.a var6;
         for(var5 = b.size(); var4 < var5; ++var4) {
            var6 = (bnu.a)b.get(var4);
            if (var6.a == var3 && var6.b.a(var0)) {
               return bnv.a(new bmb((brw)var6.c), var2);
            }
         }

         var4 = 0;

         for(var5 = a.size(); var4 < var5; ++var4) {
            var6 = (bnu.a)a.get(var4);
            if (var6.a == var2 && var6.b.a(var0)) {
               return bnv.a(new bmb(var3), (bnt)var6.c);
            }
         }
      }

      return var1;
   }

   public static void a() {
      a(bmd.nv);
      a(bmd.qj);
      a(bmd.qm);
      a(bmd.nv, bmd.kU, bmd.qj);
      a(bmd.qj, bmd.qi, bmd.qm);
      a(bnw.b, bmd.nE, bnw.c);
      a(bnw.b, bmd.ns, bnw.c);
      a(bnw.b, bmd.pA, bnw.c);
      a(bnw.b, bmd.nz, bnw.c);
      a(bnw.b, bmd.nx, bnw.c);
      a(bnw.b, bmd.mM, bnw.c);
      a(bnw.b, bmd.nA, bnw.c);
      a(bnw.b, bmd.mk, bnw.d);
      a(bnw.b, bmd.lP, bnw.c);
      a(bnw.b, bmd.nu, bnw.e);
      a(bnw.e, bmd.pd, bnw.f);
      a(bnw.f, bmd.lP, bnw.g);
      a(bnw.f, bmd.ny, bnw.h);
      a(bnw.g, bmd.ny, bnw.i);
      a(bnw.h, bmd.lP, bnw.i);
      a(bnw.e, bmd.nA, bnw.m);
      a(bnw.m, bmd.lP, bnw.n);
      a(bnw.e, bmd.pA, bnw.j);
      a(bnw.j, bmd.lP, bnw.k);
      a(bnw.j, bmd.mk, bnw.l);
      a(bnw.j, bmd.ny, bnw.r);
      a(bnw.k, bmd.ny, bnw.s);
      a(bnw.r, bmd.lP, bnw.s);
      a(bnw.r, bmd.mk, bnw.t);
      a(bnw.e, bmd.jY, bnw.u);
      a(bnw.u, bmd.lP, bnw.v);
      a(bnw.u, bmd.mk, bnw.w);
      a(bnw.o, bmd.ny, bnw.r);
      a(bnw.p, bmd.ny, bnw.s);
      a(bnw.e, bmd.mM, bnw.o);
      a(bnw.o, bmd.lP, bnw.p);
      a(bnw.o, bmd.mk, bnw.q);
      a(bnw.e, bmd.mo, bnw.x);
      a(bnw.x, bmd.lP, bnw.y);
      a(bnw.e, bmd.nE, bnw.z);
      a(bnw.z, bmd.mk, bnw.A);
      a(bnw.z, bmd.ny, bnw.B);
      a(bnw.A, bmd.ny, bnw.C);
      a(bnw.B, bmd.mk, bnw.C);
      a(bnw.D, bmd.ny, bnw.B);
      a(bnw.E, bmd.ny, bnw.B);
      a(bnw.F, bmd.ny, bnw.C);
      a(bnw.e, bmd.nx, bnw.D);
      a(bnw.D, bmd.lP, bnw.E);
      a(bnw.D, bmd.mk, bnw.F);
      a(bnw.e, bmd.ns, bnw.G);
      a(bnw.G, bmd.lP, bnw.H);
      a(bnw.G, bmd.mk, bnw.I);
      a(bnw.e, bmd.nz, bnw.J);
      a(bnw.J, bmd.lP, bnw.K);
      a(bnw.J, bmd.mk, bnw.L);
      a(bnw.b, bmd.ny, bnw.M);
      a(bnw.M, bmd.lP, bnw.N);
      a(bnw.e, bmd.qN, bnw.P);
      a(bnw.P, bmd.lP, bnw.Q);
   }

   private static void a(blx var0, blx var1, blx var2) {
      if (!(var0 instanceof bmn)) {
         throw new IllegalArgumentException("Expected a potion, got: " + gm.T.b((Object)var0));
      } else if (!(var2 instanceof bmn)) {
         throw new IllegalArgumentException("Expected a potion, got: " + gm.T.b((Object)var2));
      } else {
         b.add(new bnu.a(var0, bon.a(var1), var2));
      }
   }

   private static void a(blx var0) {
      if (!(var0 instanceof bmn)) {
         throw new IllegalArgumentException("Expected a potion, got: " + gm.T.b((Object)var0));
      } else {
         c.add(bon.a(var0));
      }
   }

   private static void a(bnt var0, blx var1, bnt var2) {
      a.add(new bnu.a(var0, bon.a(var1), var2));
   }

   static class a<T> {
      private final T a;
      private final bon b;
      private final T c;

      public a(T var1, bon var2, T var3) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
      }
   }
}
