import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

public class cog extends coi {
   public static final Codec<cog> a = RecordCodecBuilder.create((var0) -> {
      return var0.group(coi.e.listOf().fieldOf("elements").forGetter((var0x) -> {
         return var0x.b;
      }), d()).apply(var0, cog::new);
   });
   private final List<coi> b;

   public cog(List<coi> var1, cok.a var2) {
      super(var2);
      if (var1.isEmpty()) {
         throw new IllegalArgumentException("Elements are empty");
      } else {
         this.b = var1;
         this.b(var2);
      }
   }

   public List<ctb.c> a(csw var1, fx var2, bzm var3, Random var4) {
      return ((coi)this.b.get(0)).a(var1, var2, var3, var4);
   }

   public cra a(csw var1, fx var2, bzm var3) {
      cra var4 = cra.a();
      Iterator var5 = this.b.iterator();

      while(var5.hasNext()) {
         coi var6 = (coi)var5.next();
         cra var7 = var6.a(var1, var2, var3);
         var4.c(var7);
      }

      return var4;
   }

   public boolean a(csw var1, bsr var2, bsn var3, cfy var4, fx var5, fx var6, bzm var7, cra var8, Random var9, boolean var10) {
      Iterator var11 = this.b.iterator();

      coi var12;
      do {
         if (!var11.hasNext()) {
            return true;
         }

         var12 = (coi)var11.next();
      } while(var12.a(var1, var2, var3, var4, var5, var6, var7, var8, var9, var10));

      return false;
   }

   public coj<?> a() {
      return coj.b;
   }

   public coi a(cok.a var1) {
      super.a(var1);
      this.b(var1);
      return this;
   }

   public String toString() {
      return "List[" + (String)this.b.stream().map(Object::toString).collect(Collectors.joining(", ")) + "]";
   }

   private void b(cok.a var1) {
      this.b.forEach((var1x) -> {
         var1x.a(var1);
      });
   }
}
