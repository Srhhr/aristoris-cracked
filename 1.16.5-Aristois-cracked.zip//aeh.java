import java.util.Map;
import java.util.stream.Collectors;

public class aeh {
   private static volatile aen a = aen.a(aem.a((Map)aed.b().stream().collect(Collectors.toMap(ael.e::a, (var0) -> {
      return var0;
   }))), aem.a((Map)aeg.b().stream().collect(Collectors.toMap(ael.e::a, (var0) -> {
      return var0;
   }))), aem.a((Map)aef.b().stream().collect(Collectors.toMap(ael.e::a, (var0) -> {
      return var0;
   }))), aem.a((Map)aee.b().stream().collect(Collectors.toMap(ael.e::a, (var0) -> {
      return var0;
   }))));

   public static aen a() {
      return a;
   }

   public static void a(aen var0) {
      a = var0;
   }
}
