import com.google.common.collect.ImmutableMap;

public class atz<E extends aqn> extends arv<E> {
   public atz() {
      super(ImmutableMap.of(ayd.L, aye.a));
   }

   protected void a(aag var1, E var2, long var3) {
      arw.a((aqm)var2, (ayd)ayd.L).ifPresent((var2x) -> {
         if (var2x.dl() && (var2x.X() != aqe.bc || var1.V().b(brt.F))) {
            var2.cJ().b(ayd.L);
         }

      });
   }
}
