public class ado {
   public static final adn a;
   public static final adn b;
   public static final adn c;
   public static final adn d;
   public static final adn e;
   public static final adn f;
   public static final adn g;

   public static adn a(adp var0) {
      return new adn(var0, 12000, 24000, false);
   }

   static {
      a = new adn(adq.in, 20, 600, true);
      b = new adn(adq.hV, 12000, 24000, false);
      c = new adn(adq.hW, 0, 0, true);
      d = new adn(adq.ik, 0, 0, true);
      e = new adn(adq.il, 6000, 24000, true);
      f = a(adq.it);
      g = a(adq.im);
   }
}
