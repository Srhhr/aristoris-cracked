import com.google.gson.JsonObject;
import com.mojang.brigadier.arguments.ArgumentType;
import java.util.function.Supplier;

public class fl<T extends ArgumentType<?>> implements fj<T> {
   private final Supplier<T> a;

   public fl(Supplier<T> var1) {
      this.a = var1;
   }

   public void a(T var1, nf var2) {
   }

   public T b(nf var1) {
      return (ArgumentType)this.a.get();
   }

   public void a(T var1, JsonObject var2) {
   }
}
