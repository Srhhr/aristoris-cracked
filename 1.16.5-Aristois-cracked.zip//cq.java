import com.google.gson.JsonObject;

public class cq extends ck<cq.a> {
   public static final vk a = new vk("tick");

   public vk a() {
      return a;
   }

   public cq.a a(JsonObject var1, bg.b var2, ax var3) {
      return new cq.a(var2);
   }

   public void a(aah var1) {
      this.a(var1, (var0) -> {
         return true;
      });
   }

   // $FF: synthetic method
   public al b(JsonObject var1, bg.b var2, ax var3) {
      return this.a(var1, var2, var3);
   }

   public static class a extends al {
      public a(bg.b var1) {
         super(cq.a, var1);
      }
   }
}
