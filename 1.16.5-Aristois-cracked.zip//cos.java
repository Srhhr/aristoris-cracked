import com.mojang.serialization.Codec;

public class cos<P extends cor> {
   public static final cos<cot> a;
   public static final cos<coq> b;
   public static final cos<cop> c;
   public static final cos<coo> d;
   public static final cos<com> e;
   private final Codec<P> f;

   private static <P extends cor> cos<P> a(String var0, Codec<P> var1) {
      return (cos)gm.a((gm)gm.aZ, (String)var0, (Object)(new cos(var1)));
   }

   private cos(Codec<P> var1) {
      this.f = var1;
   }

   public Codec<P> a() {
      return this.f;
   }

   static {
      a = a("trunk_vine", cot.a);
      b = a("leave_vine", coq.a);
      c = a("cocoa", cop.a);
      d = a("beehive", coo.a);
      e = a("alter_ground", com.a);
   }
}
