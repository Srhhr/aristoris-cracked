import javax.annotation.Nullable;

public class bnr extends blx {
   public bnr(blx.a var1) {
      super(var1);
   }

   public aou a(boa var1) {
      brx var2 = var1.p();
      fx var3 = var1.a();
      ceh var4 = var2.d_(var3);
      if (var4.a(bup.lY)) {
         return bxy.a(var2, var3, var4, var1.m()) ? aou.a(var2.v) : aou.c;
      } else {
         return aou.c;
      }
   }

   public aov<bmb> a(brx var1, bfw var2, aot var3) {
      bmb var4 = var2.b((aot)var3);
      var2.a(var4, var3);
      var2.b(aea.c.b(this));
      return aov.a(var4, var1.s_());
   }

   public static boolean a(@Nullable md var0) {
      if (var0 == null) {
         return false;
      } else if (!var0.c("pages", 9)) {
         return false;
      } else {
         mj var1 = var0.d("pages", 8);

         for(int var2 = 0; var2 < var1.size(); ++var2) {
            String var3 = var1.j(var2);
            if (var3.length() > 32767) {
               return false;
            }
         }

         return true;
      }
   }
}
