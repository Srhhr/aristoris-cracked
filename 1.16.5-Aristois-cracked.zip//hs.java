import java.util.function.Consumer;

public class hs implements Consumer<Consumer<y>> {
   public void a(Consumer<y> var1) {
      y var2 = y.a.a().a((brw)bup.i, new of("advancements.story.root.title"), new of("advancements.story.root.description"), new vk("textures/gui/advancements/backgrounds/stone.png"), ai.a, false, false, false).a((String)"crafting_table", (ag)bn.a.a(bup.bV)).a(var1, "story/root");
      y var3 = y.a.a().a(var2).a((brw)bmd.kn, new of("advancements.story.mine_stone.title"), new of("advancements.story.mine_stone.description"), (vk)null, ai.a, true, true, false).a((String)"get_stone", (ag)bn.a.a(bq.a.a().a((ael)aeg.ab).b())).a(var1, "story/mine_stone");
      y var4 = y.a.a().a(var3).a((brw)bmd.ks, new of("advancements.story.upgrade_tools.title"), new of("advancements.story.upgrade_tools.description"), (vk)null, ai.a, true, true, false).a((String)"stone_pickaxe", (ag)bn.a.a(bmd.ks)).a(var1, "story/upgrade_tools");
      y var5 = y.a.a().a(var4).a((brw)bmd.kh, new of("advancements.story.smelt_iron.title"), new of("advancements.story.smelt_iron.description"), (vk)null, ai.a, true, true, false).a((String)"iron", (ag)bn.a.a(bmd.kh)).a(var1, "story/smelt_iron");
      y var6 = y.a.a().a(var5).a((brw)bmd.kC, new of("advancements.story.iron_tools.title"), new of("advancements.story.iron_tools.description"), (vk)null, ai.a, true, true, false).a((String)"iron_pickaxe", (ag)bn.a.a(bmd.kC)).a(var1, "story/iron_tools");
      y var7 = y.a.a().a(var6).a((brw)bmd.kg, new of("advancements.story.mine_diamond.title"), new of("advancements.story.mine_diamond.description"), (vk)null, ai.a, true, true, false).a((String)"diamond", (ag)bn.a.a(bmd.kg)).a(var1, "story/mine_diamond");
      y var8 = y.a.a().a(var5).a((brw)bmd.lM, new of("advancements.story.lava_bucket.title"), new of("advancements.story.lava_bucket.description"), (vk)null, ai.a, true, true, false).a((String)"lava_bucket", (ag)bn.a.a(bmd.lM)).a(var1, "story/lava_bucket");
      y var9 = y.a.a().a(var5).a((brw)bmd.lh, new of("advancements.story.obtain_armor.title"), new of("advancements.story.obtain_armor.description"), (vk)null, ai.a, true, true, false).a(aj.b).a((String)"iron_helmet", (ag)bn.a.a(bmd.lg)).a((String)"iron_chestplate", (ag)bn.a.a(bmd.lh)).a((String)"iron_leggings", (ag)bn.a.a(bmd.li)).a((String)"iron_boots", (ag)bn.a.a(bmd.lj)).a(var1, "story/obtain_armor");
      y.a.a().a(var7).a((brw)bmd.pq, new of("advancements.story.enchant_item.title"), new of("advancements.story.enchant_item.description"), (vk)null, ai.a, true, true, false).a((String)"enchanted_item", (ag)ba.a.c()).a(var1, "story/enchant_item");
      y var10 = y.a.a().a(var8).a((brw)bup.bK, new of("advancements.story.form_obsidian.title"), new of("advancements.story.form_obsidian.description"), (vk)null, ai.a, true, true, false).a((String)"obsidian", (ag)bn.a.a(bup.bK)).a(var1, "story/form_obsidian");
      y.a.a().a(var9).a((brw)bmd.qn, new of("advancements.story.deflect_arrow.title"), new of("advancements.story.deflect_arrow.description"), (vk)null, ai.a, true, true, false).a((String)"deflected_projectile", (ag)bf.a.a(av.a.a().a(aw.a.a().a(true)).a(true))).a(var1, "story/deflect_arrow");
      y.a.a().a(var7).a((brw)bmd.ll, new of("advancements.story.shiny_gear.title"), new of("advancements.story.shiny_gear.description"), (vk)null, ai.a, true, true, false).a(aj.b).a((String)"diamond_helmet", (ag)bn.a.a(bmd.lk)).a((String)"diamond_chestplate", (ag)bn.a.a(bmd.ll)).a((String)"diamond_leggings", (ag)bn.a.a(bmd.lm)).a((String)"diamond_boots", (ag)bn.a.a(bmd.ln)).a(var1, "story/shiny_gear");
      y var11 = y.a.a().a(var10).a((brw)bmd.ka, new of("advancements.story.enter_the_nether.title"), new of("advancements.story.enter_the_nether.description"), (vk)null, ai.a, true, true, false).a((String)"entered_nether", (ag)aq.a.a(brx.h)).a(var1, "story/enter_the_nether");
      y.a.a().a(var11).a((brw)bmd.lA, new of("advancements.story.cure_zombie_villager.title"), new of("advancements.story.cure_zombie_villager.description"), (vk)null, ai.c, true, true, false).a((String)"cured_zombie", (ag)au.a.c()).a(var1, "story/cure_zombie_villager");
      y var12 = y.a.a().a(var11).a((brw)bmd.nD, new of("advancements.story.follow_ender_eye.title"), new of("advancements.story.follow_ender_eye.description"), (vk)null, ai.a, true, true, false).a((String)"in_stronghold", (ag)bx.a.a(bw.a(cla.k))).a(var1, "story/follow_ender_eye");
      y.a.a().a(var12).a((brw)bup.ee, new of("advancements.story.enter_the_end.title"), new of("advancements.story.enter_the_end.description"), (vk)null, ai.a, true, true, false).a((String)"entered_end", (ag)aq.a.a(brx.i)).a(var1, "story/enter_the_end");
   }

   // $FF: synthetic method
   public void accept(Object var1) {
      this.a((Consumer)var1);
   }
}
