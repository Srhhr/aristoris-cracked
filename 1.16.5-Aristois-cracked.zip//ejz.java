import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;

public class ejz {
   private static final Comparator<ejz.a> a = Comparator.comparing((var0) -> {
      return -var0.c;
   }).thenComparing((var0) -> {
      return -var0.b;
   }).thenComparing((var0) -> {
      return var0.a.a();
   });
   private final int b;
   private final Set<ejz.a> c = Sets.newHashSetWithExpectedSize(256);
   private final List<ejz.b> d = Lists.newArrayListWithCapacity(256);
   private int e;
   private int f;
   private final int g;
   private final int h;

   public ejz(int var1, int var2, int var3) {
      this.b = var3;
      this.g = var1;
      this.h = var2;
   }

   public int a() {
      return this.e;
   }

   public int b() {
      return this.f;
   }

   public void a(ekc.a var1) {
      ejz.a var2 = new ejz.a(var1, this.b);
      this.c.add(var2);
   }

   public void c() {
      List<ejz.a> var1 = Lists.newArrayList(this.c);
      var1.sort(a);
      Iterator var2 = var1.iterator();

      ejz.a var3;
      do {
         if (!var2.hasNext()) {
            this.e = afm.c(this.e);
            this.f = afm.c(this.f);
            return;
         }

         var3 = (ejz.a)var2.next();
      } while(this.a(var3));

      throw new eka(var3.a, (Collection)var1.stream().map((var0) -> {
         return var0.a;
      }).collect(ImmutableList.toImmutableList()));
   }

   public void a(ejz.c var1) {
      Iterator var2 = this.d.iterator();

      while(var2.hasNext()) {
         ejz.b var3 = (ejz.b)var2.next();
         var3.a((var2x) -> {
            ejz.a var3 = var2x.a();
            ekc.a var4 = var3.a;
            var1.load(var4, this.e, this.f, var2x.b(), var2x.c());
         });
      }

   }

   private static int b(int var0, int var1) {
      return (var0 >> var1) + ((var0 & (1 << var1) - 1) == 0 ? 0 : 1) << var1;
   }

   private boolean a(ejz.a var1) {
      Iterator var2 = this.d.iterator();

      ejz.b var3;
      do {
         if (!var2.hasNext()) {
            return this.b(var1);
         }

         var3 = (ejz.b)var2.next();
      } while(!var3.a(var1));

      return true;
   }

   private boolean b(ejz.a var1) {
      int var3 = afm.c(this.e);
      int var4 = afm.c(this.f);
      int var5 = afm.c(this.e + var1.b);
      int var6 = afm.c(this.f + var1.c);
      boolean var7 = var5 <= this.g;
      boolean var8 = var6 <= this.h;
      if (!var7 && !var8) {
         return false;
      } else {
         boolean var9 = var7 && var3 != var5;
         boolean var10 = var8 && var4 != var6;
         boolean var2;
         if (var9 ^ var10) {
            var2 = var9;
         } else {
            var2 = var7 && var3 <= var4;
         }

         ejz.b var11;
         if (var2) {
            if (this.f == 0) {
               this.f = var1.c;
            }

            var11 = new ejz.b(this.e, 0, var1.b, this.f);
            this.e += var1.b;
         } else {
            var11 = new ejz.b(0, this.f, this.e, var1.c);
            this.f += var1.c;
         }

         var11.a(var1);
         this.d.add(var11);
         return true;
      }
   }

   public static class b {
      private final int a;
      private final int b;
      private final int c;
      private final int d;
      private List<ejz.b> e;
      private ejz.a f;

      public b(int var1, int var2, int var3, int var4) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
         this.d = var4;
      }

      public ejz.a a() {
         return this.f;
      }

      public int b() {
         return this.a;
      }

      public int c() {
         return this.b;
      }

      public boolean a(ejz.a var1) {
         if (this.f != null) {
            return false;
         } else {
            int var2 = var1.b;
            int var3 = var1.c;
            if (var2 <= this.c && var3 <= this.d) {
               if (var2 == this.c && var3 == this.d) {
                  this.f = var1;
                  return true;
               } else {
                  if (this.e == null) {
                     this.e = Lists.newArrayListWithCapacity(1);
                     this.e.add(new ejz.b(this.a, this.b, var2, var3));
                     int var4 = this.c - var2;
                     int var5 = this.d - var3;
                     if (var5 > 0 && var4 > 0) {
                        int var6 = Math.max(this.d, var4);
                        int var7 = Math.max(this.c, var5);
                        if (var6 >= var7) {
                           this.e.add(new ejz.b(this.a, this.b + var3, var2, var5));
                           this.e.add(new ejz.b(this.a + var2, this.b, var4, this.d));
                        } else {
                           this.e.add(new ejz.b(this.a + var2, this.b, var4, var3));
                           this.e.add(new ejz.b(this.a, this.b + var3, this.c, var5));
                        }
                     } else if (var4 == 0) {
                        this.e.add(new ejz.b(this.a, this.b + var3, var2, var5));
                     } else if (var5 == 0) {
                        this.e.add(new ejz.b(this.a + var2, this.b, var4, var3));
                     }
                  }

                  Iterator var8 = this.e.iterator();

                  ejz.b var9;
                  do {
                     if (!var8.hasNext()) {
                        return false;
                     }

                     var9 = (ejz.b)var8.next();
                  } while(!var9.a(var1));

                  return true;
               }
            } else {
               return false;
            }
         }
      }

      public void a(Consumer<ejz.b> var1) {
         if (this.f != null) {
            var1.accept(this);
         } else if (this.e != null) {
            Iterator var2 = this.e.iterator();

            while(var2.hasNext()) {
               ejz.b var3 = (ejz.b)var2.next();
               var3.a(var1);
            }
         }

      }

      public String toString() {
         return "Slot{originX=" + this.a + ", originY=" + this.b + ", width=" + this.c + ", height=" + this.d + ", texture=" + this.f + ", subSlots=" + this.e + '}';
      }
   }

   static class a {
      public final ekc.a a;
      public final int b;
      public final int c;

      public a(ekc.a var1, int var2) {
         this.a = var1;
         this.b = ejz.b(var1.b(), var2);
         this.c = ejz.b(var1.c(), var2);
      }

      public String toString() {
         return "Holder{width=" + this.b + ", height=" + this.c + '}';
      }
   }

   public interface c {
      void load(ekc.a var1, int var2, int var3, int var4, int var5);
   }
}
