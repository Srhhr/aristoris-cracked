import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public abstract class eoo extends dot {
   public eoo() {
      super(dkz.a);
   }

   protected static int j(int var0) {
      return 40 + var0 * 13;
   }

   public void d() {
      Iterator var1 = this.m.iterator();

      while(var1.hasNext()) {
         dlh var2 = (dlh)var1.next();
         if (var2 instanceof dmc) {
            ((dmc)var2).d();
         }
      }

   }

   public void A() {
      Stream var10000 = this.e.stream();
      eom.class.getClass();
      var10000 = var10000.filter(eom.class::isInstance);
      eom.class.getClass();
      List<String> var1 = (List)var10000.map(eom.class::cast).map(eom::a).collect(Collectors.toList());
      eoj.a((Iterable)var1);
   }
}
