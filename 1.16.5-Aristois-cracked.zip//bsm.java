public class bsm extends afz.a {
   private final md b;

   public bsm() {
      super(1);
      this.b = new md();
      this.b.a("id", "minecraft:pig");
   }

   public bsm(md var1) {
      this(var1.c("Weight", 99) ? var1.h("Weight") : 1, var1.p("Entity"));
   }

   public bsm(int var1, md var2) {
      super(var1);
      this.b = var2;
      vk var3 = vk.a(var2.l("id"));
      if (var3 != null) {
         var2.a("id", var3.toString());
      } else {
         var2.a("id", "minecraft:pig");
      }

   }

   public md a() {
      md var1 = new md();
      var1.a((String)"Entity", (mt)this.b);
      var1.b("Weight", this.a);
      return var1;
   }

   public md b() {
      return this.b;
   }
}
