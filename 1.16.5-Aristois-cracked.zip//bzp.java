import java.util.Iterator;
import java.util.Random;

public class bzp extends buo implements bzu {
   private static final ddh d;
   private static final ddh e;
   private static final ddh f = buo.a(0.0D, 0.0D, 0.0D, 16.0D, 2.0D, 16.0D);
   private static final ddh g = dde.b().a(0.0D, -1.0D, 0.0D);
   public static final cfg a;
   public static final cey b;
   public static final cey c;

   protected bzp(ceg.c var1) {
      super(var1);
      this.j((ceh)((ceh)((ceh)((ceh)this.n.b()).a(a, 7)).a(b, false)).a(c, false));
   }

   protected void a(cei.a<buo, ceh> var1) {
      var1.a(a, b, c);
   }

   public ddh b(ceh var1, brc var2, fx var3, dcs var4) {
      if (!var4.a(var1.b().h())) {
         return (Boolean)var1.c(c) ? e : d;
      } else {
         return dde.b();
      }
   }

   public ddh a_(ceh var1, brc var2, fx var3) {
      return dde.b();
   }

   public boolean a(ceh var1, bny var2) {
      return var2.m().b() == this.h();
   }

   public ceh a(bny var1) {
      fx var2 = var1.a();
      brx var3 = var1.p();
      int var4 = a((brc)var3, (fx)var2);
      return (ceh)((ceh)((ceh)this.n().a(b, var3.b(var2).a() == cuy.c)).a(a, var4)).a(c, this.a(var3, var2, var4));
   }

   public void b(ceh var1, brx var2, fx var3, ceh var4, boolean var5) {
      if (!var2.v) {
         var2.J().a(var3, this, 1);
      }

   }

   public ceh a(ceh var1, gc var2, ceh var3, bry var4, fx var5, fx var6) {
      if ((Boolean)var1.c(b)) {
         var4.I().a(var5, cuy.c, cuy.c.a((brz)var4));
      }

      if (!var4.s_()) {
         var4.J().a(var5, this, 1);
      }

      return var1;
   }

   public void a(ceh var1, aag var2, fx var3, Random var4) {
      int var5 = a((brc)var2, (fx)var3);
      ceh var6 = (ceh)((ceh)var1.a(a, var5)).a(c, this.a(var2, var3, var5));
      if ((Integer)var6.c(a) == 7) {
         if ((Integer)var1.c(a) == 7) {
            var2.c((aqa)(new bcu(var2, (double)var3.u() + 0.5D, (double)var3.v(), (double)var3.w() + 0.5D, (ceh)var6.a(b, false))));
         } else {
            var2.b(var3, true);
         }
      } else if (var1 != var6) {
         var2.a(var3, var6, 3);
      }

   }

   public boolean a(ceh var1, brz var2, fx var3) {
      return a((brc)var2, (fx)var3) < 7;
   }

   public ddh c(ceh var1, brc var2, fx var3, dcs var4) {
      if (var4.a(dde.b(), var3, true) && !var4.b()) {
         return d;
      } else {
         return (Integer)var1.c(a) != 0 && (Boolean)var1.c(c) && var4.a(g, var3, true) ? f : dde.a();
      }
   }

   public cux d(ceh var1) {
      return (Boolean)var1.c(b) ? cuy.c.a(false) : super.d(var1);
   }

   private boolean a(brc var1, fx var2, int var3) {
      return var3 > 0 && !var1.d_(var2.c()).a(this);
   }

   public static int a(brc var0, fx var1) {
      fx.a var2 = var1.i().c(gc.a);
      ceh var3 = var0.d_(var2);
      int var4 = 7;
      if (var3.a(bup.lQ)) {
         var4 = (Integer)var3.c(a);
      } else if (var3.d(var0, var2, gc.b)) {
         return 0;
      }

      Iterator var5 = gc.c.a.iterator();

      while(var5.hasNext()) {
         gc var6 = (gc)var5.next();
         ceh var7 = var0.d_(var2.a(var1, var6));
         if (var7.a(bup.lQ)) {
            var4 = Math.min(var4, (Integer)var7.c(a) + 1);
            if (var4 == 1) {
               break;
            }
         }
      }

      return var4;
   }

   static {
      a = cex.aB;
      b = cex.C;
      c = cex.b;
      ddh var0 = buo.a(0.0D, 14.0D, 0.0D, 16.0D, 16.0D, 16.0D);
      ddh var1 = buo.a(0.0D, 0.0D, 0.0D, 2.0D, 16.0D, 2.0D);
      ddh var2 = buo.a(14.0D, 0.0D, 0.0D, 16.0D, 16.0D, 2.0D);
      ddh var3 = buo.a(0.0D, 0.0D, 14.0D, 2.0D, 16.0D, 16.0D);
      ddh var4 = buo.a(14.0D, 0.0D, 14.0D, 16.0D, 16.0D, 16.0D);
      d = dde.a(var0, var1, var2, var3, var4);
      ddh var5 = buo.a(0.0D, 0.0D, 0.0D, 2.0D, 2.0D, 16.0D);
      ddh var6 = buo.a(14.0D, 0.0D, 0.0D, 16.0D, 2.0D, 16.0D);
      ddh var7 = buo.a(0.0D, 0.0D, 14.0D, 16.0D, 2.0D, 16.0D);
      ddh var8 = buo.a(0.0D, 0.0D, 0.0D, 16.0D, 2.0D, 2.0D);
      e = dde.a(f, d, var6, var5, var8, var7);
   }
}
