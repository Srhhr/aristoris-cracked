public class cgw {
   public static cgw.a a(md var0) {
      int var1 = var0.h("xPos");
      int var2 = var0.h("zPos");
      cgw.a var3 = new cgw.a(var1, var2);
      var3.g = var0.m("Blocks");
      var3.f = new cgl(var0.m("Data"), 7);
      var3.e = new cgl(var0.m("SkyLight"), 7);
      var3.d = new cgl(var0.m("BlockLight"), 7);
      var3.c = var0.m("HeightMap");
      var3.b = var0.q("TerrainPopulated");
      var3.h = var0.d("Entities", 10);
      var3.i = var0.d("TileEntities", 10);
      var3.j = var0.d("TileTicks", 10);

      try {
         var3.a = var0.i("LastUpdate");
      } catch (ClassCastException var5) {
         var3.a = (long)var0.h("LastUpdate");
      }

      return var3;
   }

   public static void a(gn.b var0, cgw.a var1, md var2, bsy var3) {
      var2.b("xPos", var1.k);
      var2.b("zPos", var1.l);
      var2.a("LastUpdate", var1.a);
      int[] var4 = new int[var1.c.length];

      for(int var5 = 0; var5 < var1.c.length; ++var5) {
         var4[var5] = var1.c[var5];
      }

      var2.a("HeightMap", var4);
      var2.a("TerrainPopulated", var1.b);
      mj var17 = new mj();

      for(int var6 = 0; var6 < 8; ++var6) {
         boolean var7 = true;

         for(int var8 = 0; var8 < 16 && var7; ++var8) {
            for(int var9 = 0; var9 < 16 && var7; ++var9) {
               for(int var10 = 0; var10 < 16; ++var10) {
                  int var11 = var8 << 11 | var10 << 7 | var9 + (var6 << 4);
                  int var12 = var1.g[var11];
                  if (var12 != 0) {
                     var7 = false;
                     break;
                  }
               }
            }
         }

         if (!var7) {
            byte[] var18 = new byte[4096];
            cgb var19 = new cgb();
            cgb var20 = new cgb();
            cgb var21 = new cgb();

            for(int var22 = 0; var22 < 16; ++var22) {
               for(int var13 = 0; var13 < 16; ++var13) {
                  for(int var14 = 0; var14 < 16; ++var14) {
                     int var15 = var22 << 11 | var14 << 7 | var13 + (var6 << 4);
                     int var16 = var1.g[var15];
                     var18[var13 << 8 | var14 << 4 | var22] = (byte)(var16 & 255);
                     var19.a(var22, var13, var14, var1.f.a(var22, var13 + (var6 << 4), var14));
                     var20.a(var22, var13, var14, var1.e.a(var22, var13 + (var6 << 4), var14));
                     var21.a(var22, var13, var14, var1.d.a(var22, var13 + (var6 << 4), var14));
                  }
               }
            }

            md var23 = new md();
            var23.a("Y", (byte)(var6 & 255));
            var23.a("Blocks", var18);
            var23.a("Data", var19.a());
            var23.a("SkyLight", var20.a());
            var23.a("BlockLight", var21.a());
            var17.add(var23);
         }
      }

      var2.a((String)"Sections", (mt)var17);
      var2.a("Biomes", (new cfx(var0.b((vj)gm.ay), new brd(var1.k, var1.l), var3)).a());
      var2.a((String)"Entities", (mt)var1.h);
      var2.a((String)"TileEntities", (mt)var1.i);
      if (var1.j != null) {
         var2.a((String)"TileTicks", (mt)var1.j);
      }

      var2.a("convertedFromAlphaFormat", true);
   }

   public static class a {
      public long a;
      public boolean b;
      public byte[] c;
      public cgl d;
      public cgl e;
      public cgl f;
      public byte[] g;
      public mj h;
      public mj i;
      public mj j;
      public final int k;
      public final int l;

      public a(int var1, int var2) {
         this.k = var1;
         this.l = var2;
      }
   }
}
