public class eha extends edz<bgc> {
   public static final vk a = new vk("textures/entity/projectiles/arrow.png");
   public static final vk e = new vk("textures/entity/projectiles/tipped_arrow.png");

   public eha(eet var1) {
      super(var1);
   }

   public vk a(bgc var1) {
      return var1.u() > 0 ? e : a;
   }
}
