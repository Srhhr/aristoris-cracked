import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;

public class ayc<T> {
   private final T a;
   private long b;

   public ayc(T var1, long var2) {
      this.a = var1;
      this.b = var2;
   }

   public void a() {
      if (this.e()) {
         --this.b;
      }

   }

   public static <T> ayc<T> a(T var0) {
      return new ayc(var0, Long.MAX_VALUE);
   }

   public static <T> ayc<T> a(T var0, long var1) {
      return new ayc(var0, var1);
   }

   public T c() {
      return this.a;
   }

   public boolean d() {
      return this.b <= 0L;
   }

   public String toString() {
      return this.a.toString() + (this.e() ? " (ttl: " + this.b + ")" : "");
   }

   public boolean e() {
      return this.b != Long.MAX_VALUE;
   }

   public static <T> Codec<ayc<T>> a(Codec<T> var0) {
      return RecordCodecBuilder.create((var1) -> {
         return var1.group(var0.fieldOf("value").forGetter((var0x) -> {
            return var0x.a;
         }), Codec.LONG.optionalFieldOf("ttl").forGetter((var0x) -> {
            return var0x.e() ? Optional.of(var0x.b) : Optional.empty();
         })).apply(var1, (var0x, var1x) -> {
            return new ayc(var0x, (Long)var1x.orElse(Long.MAX_VALUE));
         });
      });
   }
}
