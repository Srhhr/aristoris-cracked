import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Lists;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class azd extends azb<aqm> {
   public Set<ayd<?>> a() {
      return ImmutableSet.of(ayd.i);
   }

   protected void a(aag var1, aqm var2) {
      var2.cJ().a((ayd)ayd.i, (Object)this.a(var2));
   }

   private List<aqm> a(aqm var1) {
      return (List)this.c(var1).stream().filter(this::b).collect(Collectors.toList());
   }

   private boolean b(aqm var1) {
      return var1.X() == aqe.aP && var1.w_();
   }

   private List<aqm> c(aqm var1) {
      return (List)var1.cJ().c(ayd.h).orElse(Lists.newArrayList());
   }
}
