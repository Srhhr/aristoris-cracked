import com.mojang.serialization.Codec;
import java.util.Random;

public class ckw extends cjl<cmh> {
   public ckw(Codec<cmh> var1) {
      super(var1);
   }

   public boolean a(bsr var1, cfy var2, Random var3, fx var4, cmh var5) {
      fx.a var6 = new fx.a();
      fx.a var7 = new fx.a();

      for(int var8 = 0; var8 < 16; ++var8) {
         for(int var9 = 0; var9 < 16; ++var9) {
            int var10 = var4.u() + var8;
            int var11 = var4.w() + var9;
            int var12 = var1.a(chn.a.e, var10, var11);
            var6.d(var10, var12, var11);
            var7.g(var6).c(gc.a, 1);
            bsv var13 = var1.v(var6);
            if (var13.a(var1, var7, false)) {
               var1.a(var7, bup.cD.n(), 2);
            }

            if (var13.b(var1, var6)) {
               var1.a(var6, bup.cC.n(), 2);
               ceh var14 = var1.d_(var7);
               if (var14.b(cab.a)) {
                  var1.a(var7, (ceh)var14.a(cab.a, true), 2);
               }
            }
         }
      }

      return true;
   }
}
