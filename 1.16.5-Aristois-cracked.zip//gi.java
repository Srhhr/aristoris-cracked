import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Iterators;
import com.google.common.collect.Maps;
import com.google.common.collect.ImmutableList.Builder;
import com.mojang.serialization.Codec;
import com.mojang.serialization.Lifecycle;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenCustomHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.Random;
import java.util.Set;
import java.util.Map.Entry;
import javax.annotation.Nullable;
import org.apache.commons.lang3.Validate;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class gi<T> extends gs<T> {
   protected static final Logger a = LogManager.getLogger();
   private final ObjectList<T> bf = new ObjectArrayList(256);
   private final Object2IntMap<T> bg = new Object2IntOpenCustomHashMap(x.k());
   private final BiMap<vk, T> bh;
   private final BiMap<vj<T>, T> bi;
   private final Map<T, Lifecycle> bj;
   private Lifecycle bk;
   protected Object[] b;
   private int bl;

   public gi(vj<? extends gm<T>> var1, Lifecycle var2) {
      super(var1, var2);
      this.bg.defaultReturnValue(-1);
      this.bh = HashBiMap.create();
      this.bi = HashBiMap.create();
      this.bj = Maps.newIdentityHashMap();
      this.bk = var2;
   }

   public static <T> MapCodec<gi.a<T>> a(vj<? extends gm<T>> var0, MapCodec<T> var1) {
      return RecordCodecBuilder.mapCodec((var2) -> {
         return var2.group(vk.a.xmap(vj.b(var0), vj::a).fieldOf("name").forGetter((var0x) -> {
            return var0x.a;
         }), Codec.INT.fieldOf("id").forGetter((var0x) -> {
            return var0x.b;
         }), var1.forGetter((var0x) -> {
            return var0x.c;
         })).apply(var2, gi.a::new);
      });
   }

   public <V extends T> V a(int var1, vj<T> var2, V var3, Lifecycle var4) {
      return this.a(var1, var2, var3, var4, true);
   }

   private <V extends T> V a(int var1, vj<T> var2, V var3, Lifecycle var4, boolean var5) {
      Validate.notNull(var2);
      Validate.notNull(var3);
      this.bf.size(Math.max(this.bf.size(), var1 + 1));
      this.bf.set(var1, var3);
      this.bg.put(var3, var1);
      this.b = null;
      if (var5 && this.bi.containsKey(var2)) {
         a.debug("Adding duplicate key '{}' to registry", var2);
      }

      if (this.bh.containsValue(var3)) {
         a.error("Adding duplicate value '{}' to registry", var3);
      }

      this.bh.put(var2.a(), var3);
      this.bi.put(var2, var3);
      this.bj.put(var3, var4);
      this.bk = this.bk.add(var4);
      if (this.bl <= var1) {
         this.bl = var1 + 1;
      }

      return var3;
   }

   public <V extends T> V a(vj<T> var1, V var2, Lifecycle var3) {
      return this.a(this.bl, var1, var2, var3);
   }

   public <V extends T> V a(OptionalInt var1, vj<T> var2, V var3, Lifecycle var4) {
      Validate.notNull(var2);
      Validate.notNull(var3);
      T var5 = this.bi.get(var2);
      int var6;
      if (var5 == null) {
         var6 = var1.isPresent() ? var1.getAsInt() : this.bl;
      } else {
         var6 = this.bg.getInt(var5);
         if (var1.isPresent() && var1.getAsInt() != var6) {
            throw new IllegalStateException("ID mismatch");
         }

         this.bg.removeInt(var5);
         this.bj.remove(var5);
      }

      return this.a(var6, var2, var3, var4, false);
   }

   @Nullable
   public vk b(T var1) {
      return (vk)this.bh.inverse().get(var1);
   }

   public Optional<vj<T>> c(T var1) {
      return Optional.ofNullable(this.bi.inverse().get(var1));
   }

   public int a(@Nullable T var1) {
      return this.bg.getInt(var1);
   }

   @Nullable
   public T a(@Nullable vj<T> var1) {
      return this.bi.get(var1);
   }

   @Nullable
   public T a(int var1) {
      return var1 >= 0 && var1 < this.bf.size() ? this.bf.get(var1) : null;
   }

   public Lifecycle d(T var1) {
      return (Lifecycle)this.bj.get(var1);
   }

   public Lifecycle b() {
      return this.bk;
   }

   public Iterator<T> iterator() {
      return Iterators.filter(this.bf.iterator(), Objects::nonNull);
   }

   @Nullable
   public T a(@Nullable vk var1) {
      return this.bh.get(var1);
   }

   public Set<vk> c() {
      return Collections.unmodifiableSet(this.bh.keySet());
   }

   public Set<Entry<vj<T>, T>> d() {
      return Collections.unmodifiableMap(this.bi).entrySet();
   }

   @Nullable
   public T a(Random var1) {
      if (this.b == null) {
         Collection<?> var2 = this.bh.values();
         if (var2.isEmpty()) {
            return null;
         }

         this.b = var2.toArray(new Object[var2.size()]);
      }

      return x.a(this.b, var1);
   }

   public boolean c(vk var1) {
      return this.bh.containsKey(var1);
   }

   public static <T> Codec<gi<T>> a(vj<? extends gm<T>> var0, Lifecycle var1, Codec<T> var2) {
      return a(var0, var2.fieldOf("element")).codec().listOf().xmap((var2x) -> {
         gi<T> var3 = new gi(var0, var1);
         Iterator var4 = var2x.iterator();

         while(var4.hasNext()) {
            gi.a<T> var5 = (gi.a)var4.next();
            var3.a(var5.b, var5.a, var5.c, var1);
         }

         return var3;
      }, (var0x) -> {
         Builder<gi.a<T>> var1 = ImmutableList.builder();
         Iterator var2 = var0x.iterator();

         while(var2.hasNext()) {
            T var3 = var2.next();
            var1.add(new gi.a((vj)var0x.c(var3).get(), var0x.a(var3), var3));
         }

         return var1.build();
      });
   }

   public static <T> Codec<gi<T>> b(vj<? extends gm<T>> var0, Lifecycle var1, Codec<T> var2) {
      return ve.a(var0, var1, var2);
   }

   public static <T> Codec<gi<T>> c(vj<? extends gm<T>> var0, Lifecycle var1, Codec<T> var2) {
      return Codec.unboundedMap(vk.a.xmap(vj.b(var0), vj::a), var2).xmap((var2x) -> {
         gi<T> var3 = new gi(var0, var1);
         var2x.forEach((var2, var3x) -> {
            var3.a(var2, var3x, var1);
         });
         return var3;
      }, (var0x) -> {
         return ImmutableMap.copyOf(var0x.bi);
      });
   }

   public static class a<T> {
      public final vj<T> a;
      public final int b;
      public final T c;

      public a(vj<T> var1, int var2, T var3) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
      }
   }
}
