import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import javax.annotation.Nullable;

public class bcv extends aqa {
   private static final us<bmb> c;
   private int d;
   private int e;
   private int f;
   private UUID g;
   private UUID ag;
   public final float b;

   public bcv(aqe<? extends bcv> var1, brx var2) {
      super(var1, var2);
      this.f = 5;
      this.b = (float)(Math.random() * 3.141592653589793D * 2.0D);
   }

   public bcv(brx var1, double var2, double var4, double var6) {
      this(aqe.L, var1);
      this.d(var2, var4, var6);
      this.p = this.J.nextFloat() * 360.0F;
      this.n(this.J.nextDouble() * 0.2D - 0.1D, 0.2D, this.J.nextDouble() * 0.2D - 0.1D);
   }

   public bcv(brx var1, double var2, double var4, double var6, bmb var8) {
      this(var1, var2, var4, var6);
      this.b(var8);
   }

   private bcv(bcv var1) {
      super(var1.X(), var1.l);
      this.f = 5;
      this.b(var1.g().i());
      this.u(var1);
      this.d = var1.d;
      this.b = var1.b;
   }

   protected boolean aC() {
      return false;
   }

   protected void e() {
      this.ab().a((us)c, (Object)bmb.b);
   }

   public void j() {
      if (this.g().a()) {
         this.ad();
      } else {
         super.j();
         if (this.e > 0 && this.e != 32767) {
            --this.e;
         }

         this.m = this.cD();
         this.n = this.cE();
         this.o = this.cH();
         dcn var1 = this.cC();
         float var2 = this.ce() - 0.11111111F;
         if (this.aE() && this.b((ael)aef.b) > (double)var2) {
            this.u();
         } else if (this.aQ() && this.b((ael)aef.c) > (double)var2) {
            this.v();
         } else if (!this.aB()) {
            this.f(this.cC().b(0.0D, -0.04D, 0.0D));
         }

         if (this.l.v) {
            this.H = false;
         } else {
            this.H = !this.l.k(this);
            if (this.H) {
               this.l(this.cD(), (this.cc().b + this.cc().e) / 2.0D, this.cH());
            }
         }

         if (!this.t || c(this.cC()) > 9.999999747378752E-6D || (this.K + this.Y()) % 4 == 0) {
            this.a(aqr.a, this.cC());
            float var3 = 0.98F;
            if (this.t) {
               var3 = this.l.d_(new fx(this.cD(), this.cE() - 1.0D, this.cH())).b().j() * 0.98F;
            }

            this.f(this.cC().d((double)var3, 0.98D, (double)var3));
            if (this.t) {
               dcn var4 = this.cC();
               if (var4.c < 0.0D) {
                  this.f(var4.d(1.0D, -0.5D, 1.0D));
               }
            }
         }

         boolean var7 = afm.c(this.m) != afm.c(this.cD()) || afm.c(this.n) != afm.c(this.cE()) || afm.c(this.o) != afm.c(this.cH());
         int var8 = var7 ? 2 : 40;
         if (this.K % var8 == 0) {
            if (this.l.b(this.cB()).a(aef.c) && !this.aD()) {
               this.a(adq.eH, 0.4F, 2.0F + this.J.nextFloat() * 0.4F);
            }

            if (!this.l.v && this.z()) {
               this.x();
            }
         }

         if (this.d != -32768) {
            ++this.d;
         }

         this.Z |= this.aK();
         if (!this.l.v) {
            double var5 = this.cC().d(var1).g();
            if (var5 > 0.01D) {
               this.Z = true;
            }
         }

         if (!this.l.v && this.d >= 6000) {
            this.ad();
         }

      }
   }

   private void u() {
      dcn var1 = this.cC();
      this.n(var1.b * 0.9900000095367432D, var1.c + (double)(var1.c < 0.05999999865889549D ? 5.0E-4F : 0.0F), var1.d * 0.9900000095367432D);
   }

   private void v() {
      dcn var1 = this.cC();
      this.n(var1.b * 0.949999988079071D, var1.c + (double)(var1.c < 0.05999999865889549D ? 5.0E-4F : 0.0F), var1.d * 0.949999988079071D);
   }

   private void x() {
      if (this.z()) {
         List<bcv> var1 = this.l.a(bcv.class, this.cc().c(0.5D, 0.0D, 0.5D), (var1x) -> {
            return var1x != this && var1x.z();
         });
         Iterator var2 = var1.iterator();

         while(var2.hasNext()) {
            bcv var3 = (bcv)var2.next();
            if (var3.z()) {
               this.a(var3);
               if (this.y) {
                  break;
               }
            }
         }

      }
   }

   private boolean z() {
      bmb var1 = this.g();
      return this.aX() && this.e != 32767 && this.d != -32768 && this.d < 6000 && var1.E() < var1.c();
   }

   private void a(bcv var1) {
      bmb var2 = this.g();
      bmb var3 = var1.g();
      if (Objects.equals(this.h(), var1.h()) && a(var2, var3)) {
         if (var3.E() < var2.E()) {
            a(this, var2, var1, var3);
         } else {
            a(var1, var3, this, var2);
         }

      }
   }

   public static boolean a(bmb var0, bmb var1) {
      if (var1.b() != var0.b()) {
         return false;
      } else if (var1.E() + var0.E() > var1.c()) {
         return false;
      } else if (var1.n() ^ var0.n()) {
         return false;
      } else {
         return !var1.n() || var1.o().equals(var0.o());
      }
   }

   public static bmb a(bmb var0, bmb var1, int var2) {
      int var3 = Math.min(Math.min(var0.c(), var2) - var0.E(), var1.E());
      bmb var4 = var0.i();
      var4.f(var3);
      var1.g(var3);
      return var4;
   }

   private static void a(bcv var0, bmb var1, bmb var2) {
      bmb var3 = a(var1, var2, 64);
      var0.b(var3);
   }

   private static void a(bcv var0, bmb var1, bcv var2, bmb var3) {
      a(var0, var1, var3);
      var0.e = Math.max(var0.e, var2.e);
      var0.d = Math.min(var0.d, var2.d);
      if (var3.a()) {
         var2.ad();
      }

   }

   public boolean aD() {
      return this.g().b().u() || super.aD();
   }

   public boolean a(apk var1, float var2) {
      if (this.b((apk)var1)) {
         return false;
      } else if (!this.g().a() && this.g().b() == bmd.pm && var1.d()) {
         return false;
      } else if (!this.g().b().a(var1)) {
         return false;
      } else {
         this.aS();
         this.f = (int)((float)this.f - var2);
         if (this.f <= 0) {
            this.ad();
         }

         return false;
      }
   }

   public void b(md var1) {
      var1.a("Health", (short)this.f);
      var1.a("Age", (short)this.d);
      var1.a("PickupDelay", (short)this.e);
      if (this.i() != null) {
         var1.a("Thrower", this.i());
      }

      if (this.h() != null) {
         var1.a("Owner", this.h());
      }

      if (!this.g().a()) {
         var1.a((String)"Item", (mt)this.g().b(new md()));
      }

   }

   public void a(md var1) {
      this.f = var1.g("Health");
      this.d = var1.g("Age");
      if (var1.e("PickupDelay")) {
         this.e = var1.g("PickupDelay");
      }

      if (var1.b("Owner")) {
         this.ag = var1.a("Owner");
      }

      if (var1.b("Thrower")) {
         this.g = var1.a("Thrower");
      }

      md var2 = var1.p("Item");
      this.b(bmb.a(var2));
      if (this.g().a()) {
         this.ad();
      }

   }

   public void a_(bfw var1) {
      if (!this.l.v) {
         bmb var2 = this.g();
         blx var3 = var2.b();
         int var4 = var2.E();
         if (this.e == 0 && (this.ag == null || this.ag.equals(var1.bS())) && var1.bm.e(var2)) {
            var1.a((aqa)this, var4);
            if (var2.a()) {
               this.ad();
               var2.e(var4);
            }

            var1.a(aea.e.b(var3), var4);
            var1.a((bcv)this);
         }

      }
   }

   public nr R() {
      nr var1 = this.T();
      return (nr)(var1 != null ? var1 : new of(this.g().j()));
   }

   public boolean bL() {
      return false;
   }

   @Nullable
   public aqa b(aag var1) {
      aqa var2 = super.b(var1);
      if (!this.l.v && var2 instanceof bcv) {
         ((bcv)var2).x();
      }

      return var2;
   }

   public bmb g() {
      return (bmb)this.ab().a(c);
   }

   public void b(bmb var1) {
      this.ab().b(c, var1);
   }

   public void a(us<?> var1) {
      super.a(var1);
      if (c.equals(var1)) {
         this.g().a((aqa)this);
      }

   }

   @Nullable
   public UUID h() {
      return this.ag;
   }

   public void b(@Nullable UUID var1) {
      this.ag = var1;
   }

   @Nullable
   public UUID i() {
      return this.g;
   }

   public void c(@Nullable UUID var1) {
      this.g = var1;
   }

   public int k() {
      return this.d;
   }

   public void m() {
      this.e = 10;
   }

   public void n() {
      this.e = 0;
   }

   public void o() {
      this.e = 32767;
   }

   public void a(int var1) {
      this.e = var1;
   }

   public boolean p() {
      return this.e > 0;
   }

   public void r() {
      this.d = -6000;
   }

   public void s() {
      this.o();
      this.d = 5999;
   }

   public float a(float var1) {
      return ((float)this.k() + var1) / 20.0F + this.b;
   }

   public oj<?> P() {
      return new on(this);
   }

   public bcv t() {
      return new bcv(this);
   }

   static {
      c = uv.a(bcv.class, uu.g);
   }
}
