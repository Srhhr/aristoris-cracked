import com.google.gson.JsonSyntaxException;
import com.mojang.blaze3d.systems.RenderSystem;
import java.io.IOException;
import java.util.Locale;
import java.util.Random;
import javax.annotation.Nullable;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class dzz implements aci, AutoCloseable {
   private static final vk c = new vk("textures/misc/nausea.png");
   private static final Logger d = LogManager.getLogger();
   private final djz e;
   private final ach f;
   private final Random g = new Random();
   private float h;
   public final eac a;
   private final dkx i;
   private final eam j;
   private int k;
   private float l;
   private float m;
   private float n;
   private float o;
   private boolean p = true;
   private boolean q = true;
   private long r;
   private long s = x.b();
   private final eaf t;
   private final ejw u = new ejw();
   private boolean v;
   private float w = 1.0F;
   private float x;
   private float y;
   @Nullable
   private bmb z;
   private int A;
   private float B;
   private float C;
   @Nullable
   private eaj D;
   private static final vk[] E = new vk[]{new vk("shaders/post/notch.json"), new vk("shaders/post/fxaa.json"), new vk("shaders/post/art.json"), new vk("shaders/post/bumpy.json"), new vk("shaders/post/blobs2.json"), new vk("shaders/post/pencil.json"), new vk("shaders/post/color_convolve.json"), new vk("shaders/post/deconverge.json"), new vk("shaders/post/flip.json"), new vk("shaders/post/invert.json"), new vk("shaders/post/ntsc.json"), new vk("shaders/post/outline.json"), new vk("shaders/post/phosphor.json"), new vk("shaders/post/scan_pincushion.json"), new vk("shaders/post/sobel.json"), new vk("shaders/post/bits.json"), new vk("shaders/post/desaturate.json"), new vk("shaders/post/green.json"), new vk("shaders/post/blur.json"), new vk("shaders/post/wobble.json"), new vk("shaders/post/blobs.json"), new vk("shaders/post/antialias.json"), new vk("shaders/post/creeper.json"), new vk("shaders/post/spider.json")};
   public static final int b;
   private int F;
   private boolean G;
   private final djk H;

   public dzz(djz var1, ach var2, eam var3) {
      this.F = b;
      this.H = new djk();
      this.e = var1;
      this.f = var2;
      this.a = var1.ae();
      this.i = new dkx(var1.M());
      this.t = new eaf(this, var1);
      this.j = var3;
      this.D = null;
   }

   public void close() {
      this.t.close();
      this.i.close();
      this.u.close();
      this.a();
   }

   public void a() {
      if (this.D != null) {
         this.D.close();
      }

      this.D = null;
      this.F = b;
   }

   public void b() {
      this.G = !this.G;
   }

   public void a(@Nullable aqa var1) {
      if (this.D != null) {
         this.D.close();
      }

      this.D = null;
      if (var1 instanceof bdc) {
         this.a(new vk("shaders/post/creeper.json"));
      } else if (var1 instanceof beb) {
         this.a(new vk("shaders/post/spider.json"));
      } else if (var1 instanceof bdg) {
         this.a(new vk("shaders/post/invert.json"));
      }

   }

   private void a(vk var1) {
      if (this.D != null) {
         this.D.close();
      }

      try {
         this.D = new eaj(this.e.M(), this.f, this.e.f(), var1);
         this.D.a(this.e.aD().k(), this.e.aD().l());
         this.G = true;
      } catch (IOException var3) {
         d.warn("Failed to load shader: {}", var1, var3);
         this.F = b;
         this.G = false;
      } catch (JsonSyntaxException var4) {
         d.warn("Failed to parse shader: {}", var1, var4);
         this.F = b;
         this.G = false;
      }

   }

   public void a(ach var1) {
      if (this.D != null) {
         this.D.close();
      }

      this.D = null;
      if (this.F == b) {
         this.a(this.e.aa());
      } else {
         this.a(E[this.F]);
      }

   }

   public void e() {
      this.n();
      this.t.a();
      if (this.e.aa() == null) {
         this.e.a((aqa)this.e.s);
      }

      this.H.a();
      ++this.k;
      this.a.a();
      this.e.e.a(this.H);
      this.o = this.n;
      if (this.e.j.i().d()) {
         this.n += 0.05F;
         if (this.n > 1.0F) {
            this.n = 1.0F;
         }
      } else if (this.n > 0.0F) {
         this.n -= 0.0125F;
      }

      if (this.A > 0) {
         --this.A;
         if (this.A == 0) {
            this.z = null;
         }
      }

   }

   @Nullable
   public eaj f() {
      return this.D;
   }

   public void a(int var1, int var2) {
      if (this.D != null) {
         this.D.a(var1, var2);
      }

      this.e.e.a(var1, var2);
   }

   public void a(float var1) {
      aqa var2 = this.e.aa();
      if (var2 != null) {
         if (this.e.r != null) {
            this.e.au().a("pick");
            this.e.u = null;
            double var3 = (double)this.e.q.c();
            this.e.v = var2.a(var3, var1, false);
            dcn var5 = var2.j(var1);
            boolean var6 = false;
            int var7 = true;
            double var8 = var3;
            if (this.e.q.h()) {
               var8 = 6.0D;
               var3 = var8;
            } else {
               if (var3 > 3.0D) {
                  var6 = true;
               }

               var3 = var3;
            }

            var8 *= var8;
            if (this.e.v != null) {
               var8 = this.e.v.e().g(var5);
            }

            dcn var10 = var2.f(1.0F);
            dcn var11 = var5.b(var10.b * var3, var10.c * var3, var10.d * var3);
            float var12 = 1.0F;
            dci var13 = var2.cc().b(var10.a(var3)).c(1.0D, 1.0D, 1.0D);
            dck var14 = bgn.a(var2, var5, var11, var13, (var0) -> {
               return !var0.a_() && var0.aT();
            }, var8);
            if (var14 != null) {
               aqa var15 = var14.a();
               dcn var16 = var14.e();
               double var17 = var5.g(var16);
               if (var6 && var17 > 9.0D) {
                  this.e.v = dcj.a(var16, gc.a(var10.b, var10.c, var10.d), new fx(var16));
               } else if (var17 < var8 || this.e.v == null) {
                  this.e.v = var14;
                  if (var15 instanceof aqm || var15 instanceof bcp) {
                     this.e.u = var15;
                  }
               }
            }

            this.e.au().c();
         }
      }
   }

   private void n() {
      float var1 = 1.0F;
      if (this.e.aa() instanceof dzj) {
         dzj var2 = (dzj)this.e.aa();
         var1 = var2.v();
      }

      this.m = this.l;
      this.l += (var1 - this.l) * 0.5F;
      if (this.l > 1.5F) {
         this.l = 1.5F;
      }

      if (this.l < 0.1F) {
         this.l = 0.1F;
      }

   }

   private double b(djk var1, float var2, boolean var3) {
      if (this.v) {
         return 90.0D;
      } else {
         double var4 = 70.0D;
         if (var3) {
            var4 = this.e.k.aO;
            var4 *= (double)afm.g(var2, this.m, this.l);
         }

         if (var1.g() instanceof aqm && ((aqm)var1.g()).dl()) {
            float var6 = Math.min((float)((aqm)var1.g()).aq + var2, 20.0F);
            var4 /= (double)((1.0F - 500.0F / (var6 + 500.0F)) * 2.0F + 1.0F);
         }

         cux var7 = var1.k();
         if (!var7.c()) {
            var4 = var4 * 60.0D / 70.0D;
         }

         return var4;
      }
   }

   private void a(dfm var1, float var2) {
      if (this.e.aa() instanceof aqm) {
         aqm var3 = (aqm)this.e.aa();
         float var4 = (float)var3.an - var2;
         float var5;
         if (var3.dl()) {
            var5 = Math.min((float)var3.aq + var2, 20.0F);
            var1.a(g.f.a(40.0F - 8000.0F / (var5 + 200.0F)));
         }

         if (var4 < 0.0F) {
            return;
         }

         var4 /= (float)var3.ao;
         var4 = afm.a(var4 * var4 * var4 * var4 * 3.1415927F);
         var5 = var3.ap;
         var1.a(g.d.a(-var5));
         var1.a(g.f.a(-var4 * 14.0F));
         var1.a(g.d.a(var5));
      }

   }

   private void b(dfm var1, float var2) {
      if (this.e.aa() instanceof bfw) {
         bfw var3 = (bfw)this.e.aa();
         float var4 = var3.A - var3.z;
         float var5 = -(var3.A + var4 * var2);
         float var6 = afm.g(var2, var3.bs, var3.bt);
         var1.a((double)(afm.a(var5 * 3.1415927F) * var6 * 0.5F), (double)(-Math.abs(afm.b(var5 * 3.1415927F) * var6)), 0.0D);
         var1.a(g.f.a(afm.a(var5 * 3.1415927F) * var6 * 3.0F));
         var1.a(g.b.a(Math.abs(afm.b(var5 * 3.1415927F - 0.2F) * var6) * 5.0F));
      }
   }

   private void a(dfm var1, djk var2, float var3) {
      if (!this.v) {
         this.a(this.a(var2, var3, false));
         dfm.a var4 = var1.c();
         var4.a().a();
         var4.b().c();
         var1.a();
         this.a(var1, var3);
         if (this.e.k.aa) {
            this.b(var1, var3);
         }

         boolean var5 = this.e.aa() instanceof aqm && ((aqm)this.e.aa()).em();
         if (this.e.k.g().a() && !var5 && !this.e.k.aI && this.e.q.l() != bru.e) {
            this.t.c();
            this.a.a(var3, var1, this.j.b(), this.e.s, this.e.ac().a(this.e.s, var3));
            this.t.b();
         }

         var1.b();
         if (this.e.k.g().a() && !var5) {
            eaq.a(this.e, var1);
            this.a(var1, var3);
         }

         if (this.e.k.aa) {
            this.b(var1, var3);
         }

      }
   }

   public void a(b var1) {
      RenderSystem.matrixMode(5889);
      RenderSystem.loadIdentity();
      RenderSystem.multMatrix(var1);
      RenderSystem.matrixMode(5888);
   }

   public b a(djk var1, float var2, boolean var3) {
      dfm var4 = new dfm();
      var4.c().a().a();
      if (this.w != 1.0F) {
         var4.a((double)this.x, (double)(-this.y), 0.0D);
         var4.a(this.w, this.w, 1.0F);
      }

      var4.c().a().a(b.a(this.b(var1, var2, var3), (float)this.e.aD().k() / (float)this.e.aD().l(), 0.05F, this.h * 4.0F));
      return var4.c().a();
   }

   public static float a(aqm var0, float var1) {
      int var2 = var0.b(apw.p).b();
      return var2 > 200 ? 1.0F : 0.7F + afm.a(((float)var2 - var1) * 3.1415927F * 0.2F) * 0.3F;
   }

   public void a(float var1, long var2, boolean var4) {
      if (this.e.ap() || !this.e.k.q || this.e.k.Y && this.e.l.d()) {
         this.s = x.b();
      } else if (x.b() - this.s > 500L) {
         this.e.c(false);
      }

      if (!this.e.x) {
         int var5 = (int)(this.e.l.e() * (double)this.e.aD().o() / (double)this.e.aD().m());
         int var6 = (int)(this.e.l.f() * (double)this.e.aD().p() / (double)this.e.aD().n());
         RenderSystem.viewport(0, 0, this.e.aD().k(), this.e.aD().l());
         if (var4 && this.e.r != null) {
            this.e.au().a("level");
            this.a(var1, var2, new dfm());
            if (this.e.G() && this.r < x.b() - 1000L) {
               this.r = x.b();
               if (!this.e.H().z()) {
                  this.o();
               }
            }

            this.e.e.b();
            if (this.D != null && this.G) {
               RenderSystem.disableBlend();
               RenderSystem.disableDepthTest();
               RenderSystem.disableAlphaTest();
               RenderSystem.enableTexture();
               RenderSystem.matrixMode(5890);
               RenderSystem.pushMatrix();
               RenderSystem.loadIdentity();
               this.D.a(var1);
               RenderSystem.popMatrix();
            }

            this.e.f().a(true);
         }

         dez var7 = this.e.aD();
         RenderSystem.clear(256, djz.a);
         RenderSystem.matrixMode(5889);
         RenderSystem.loadIdentity();
         RenderSystem.ortho(0.0D, (double)var7.k() / var7.s(), (double)var7.l() / var7.s(), 0.0D, 1000.0D, 3000.0D);
         RenderSystem.matrixMode(5888);
         RenderSystem.loadIdentity();
         RenderSystem.translatef(0.0F, 0.0F, -2000.0F);
         dep.d();
         dfm var8 = new dfm();
         if (var4 && this.e.r != null) {
            this.e.au().b("gui");
            if (this.e.s != null) {
               float var9 = afm.g(var1, this.e.s.bQ, this.e.s.bP);
               if (var9 > 0.0F && this.e.s.a((aps)apw.i) && this.e.k.aP < 1.0F) {
                  this.c(var9 * (1.0F - this.e.k.aP));
               }
            }

            if (!this.e.k.aI || this.e.y != null) {
               RenderSystem.defaultAlphaFunc();
               this.a(this.e.aD().o(), this.e.aD().p(), var1);
               this.e.j.a(var8, var1);
               RenderSystem.clear(256, djz.a);
            }

            this.e.au().c();
         }

         l var10;
         m var11;
         if (this.e.z != null) {
            try {
               this.e.z.a(var8, var5, var6, this.e.ak());
            } catch (Throwable var13) {
               var10 = l.a(var13, "Rendering overlay");
               var11 = var10.a("Overlay render details");
               var11.a("Overlay name", () -> {
                  return this.e.z.getClass().getCanonicalName();
               });
               throw new u(var10);
            }
         } else if (this.e.y != null) {
            try {
               this.e.y.a(var8, var5, var6, this.e.ak());
            } catch (Throwable var12) {
               var10 = l.a(var12, "Rendering screen");
               var11 = var10.a("Screen render details");
               var11.a("Screen name", () -> {
                  return this.e.y.getClass().getCanonicalName();
               });
               var11.a("Mouse location", () -> {
                  return String.format(Locale.ROOT, "Scaled: (%d, %d). Absolute: (%f, %f)", var5, var6, this.e.l.e(), this.e.l.f());
               });
               var11.a("Screen size", () -> {
                  return String.format(Locale.ROOT, "Scaled: (%d, %d). Absolute: (%d, %d). Scale factor of %f", this.e.aD().o(), this.e.aD().p(), this.e.aD().k(), this.e.aD().l(), this.e.aD().s());
               });
               throw new u(var10);
            }
         }

      }
   }

   private void o() {
      if (this.e.e.h() > 10 && this.e.e.n() && !this.e.H().z()) {
         det var1 = dkh.a(this.e.aD().k(), this.e.aD().l(), this.e.f());
         x.g().execute(() -> {
            int var2 = var1.a();
            int var3 = var1.b();
            int var4 = 0;
            int var5 = 0;
            if (var2 > var3) {
               var4 = (var2 - var3) / 2;
               var2 = var3;
            } else {
               var5 = (var3 - var2) / 2;
               var3 = var2;
            }

            try {
               det var6 = new det(64, 64, false);
               Throwable var7 = null;

               try {
                  var1.a(var4, var5, var2, var3, var6);
                  var6.a(this.e.H().A());
               } catch (Throwable var25) {
                  var7 = var25;
                  throw var25;
               } finally {
                  if (var6 != null) {
                     if (var7 != null) {
                        try {
                           var6.close();
                        } catch (Throwable var24) {
                           var7.addSuppressed(var24);
                        }
                     } else {
                        var6.close();
                     }
                  }

               }
            } catch (IOException var27) {
               d.warn("Couldn't save auto screenshot", var27);
            } finally {
               var1.close();
            }

         });
      }

   }

   private boolean p() {
      if (!this.q) {
         return false;
      } else {
         aqa var1 = this.e.aa();
         boolean var2 = var1 instanceof bfw && !this.e.k.aI;
         if (var2 && !((bfw)var1).bC.e) {
            bmb var3 = ((aqm)var1).dD();
            dcl var4 = this.e.v;
            if (var4 != null && var4.c() == dcl.a.b) {
               fx var5 = ((dcj)var4).a();
               ceh var6 = this.e.r.d_(var5);
               if (this.e.q.l() == bru.e) {
                  var2 = var6.b(this.e.r, var5) != null;
               } else {
                  cel var7 = new cel(this.e.r, var5, false);
                  var2 = !var3.a() && (var3.a(this.e.r.p(), var7) || var3.b(this.e.r.p(), var7));
               }
            }
         }

         return var2;
      }
   }

   public void a(float var1, long var2, dfm var4) {
      this.t.a(var1);
      if (this.e.aa() == null) {
         this.e.a((aqa)this.e.s);
      }

      this.a(var1);
      this.e.au().a("center");
      boolean var5 = this.p();
      this.e.au().b("camera");
      djk var6 = this.H;
      this.h = (float)(this.e.k.b * 16);
      dfm var7 = new dfm();
      var7.c().a().a(this.a(var6, var1, true));
      this.a(var7, var1);
      if (this.e.k.aa) {
         this.b(var7, var1);
      }

      float var8 = afm.g(var1, this.e.s.bQ, this.e.s.bP) * this.e.k.aP * this.e.k.aP;
      if (var8 > 0.0F) {
         int var9 = this.e.s.a((aps)apw.i) ? 7 : 20;
         float var10 = 5.0F / (var8 * var8 + 5.0F) - var8 * 0.04F;
         var10 *= var10;
         g var11 = new g(0.0F, afm.a / 2.0F, afm.a / 2.0F);
         var7.a(var11.a(((float)this.k + var1) * (float)var9));
         var7.a(1.0F / var10, 1.0F, 1.0F);
         float var12 = -((float)this.k + var1) * (float)var9;
         var7.a(var11.a(var12));
      }

      b var13 = var7.c().a();
      this.a(var13);
      var6.a(this.e.r, (aqa)(this.e.aa() == null ? this.e.s : this.e.aa()), !this.e.k.g().a(), this.e.k.g().b(), var1);
      var4.a(g.b.a(var6.d()));
      var4.a(g.d.a(var6.e() + 180.0F));
      this.e.e.a(var4, var1, var2, var5, var6, this, this.t, var13);
      this.e.au().b("hand");
      if (this.p) {
         RenderSystem.clear(256, djz.a);
         this.a(var4, var6, var1);
      }

      this.e.au().c();
   }

   public void g() {
      this.z = null;
      this.i.a();
      this.H.o();
   }

   public dkx h() {
      return this.i;
   }

   public void a(bmb var1) {
      this.z = var1;
      this.A = 40;
      this.B = this.g.nextFloat() * 2.0F - 1.0F;
      this.C = this.g.nextFloat() * 2.0F - 1.0F;
   }

   private void a(int var1, int var2, float var3) {
      if (this.z != null && this.A > 0) {
         int var4 = 40 - this.A;
         float var5 = ((float)var4 + var3) / 40.0F;
         float var6 = var5 * var5;
         float var7 = var5 * var6;
         float var8 = 10.25F * var7 * var6 - 24.95F * var6 * var6 + 25.5F * var7 - 13.8F * var6 + 4.0F * var5;
         float var9 = var8 * 3.1415927F;
         float var10 = this.B * (float)(var1 / 4);
         float var11 = this.C * (float)(var2 / 4);
         RenderSystem.enableAlphaTest();
         RenderSystem.pushMatrix();
         RenderSystem.pushLightingAttributes();
         RenderSystem.enableDepthTest();
         RenderSystem.disableCull();
         dfm var12 = new dfm();
         var12.a();
         var12.a((double)((float)(var1 / 2) + var10 * afm.e(afm.a(var9 * 2.0F))), (double)((float)(var2 / 2) + var11 * afm.e(afm.a(var9 * 2.0F))), -50.0D);
         float var13 = 50.0F + 175.0F * afm.a(var9);
         var12.a(var13, -var13, var13);
         var12.a(g.d.a(900.0F * afm.e(afm.a(var9))));
         var12.a(g.b.a(6.0F * afm.b(var5 * 8.0F)));
         var12.a(g.f.a(6.0F * afm.b(var5 * 8.0F)));
         eag.a var14 = this.j.b();
         this.e.ad().a((bmb)this.z, (ebm.b)ebm.b.i, 15728880, ejw.a, var12, (eag)var14);
         var12.b();
         var14.a();
         RenderSystem.popAttributes();
         RenderSystem.popMatrix();
         RenderSystem.enableCull();
         RenderSystem.disableDepthTest();
      }
   }

   private void c(float var1) {
      int var2 = this.e.aD().o();
      int var3 = this.e.aD().p();
      double var4 = afm.d((double)var1, 2.0D, 1.0D);
      float var6 = 0.2F * var1;
      float var7 = 0.4F * var1;
      float var8 = 0.2F * var1;
      double var9 = (double)var2 * var4;
      double var11 = (double)var3 * var4;
      double var13 = ((double)var2 - var9) / 2.0D;
      double var15 = ((double)var3 - var11) / 2.0D;
      RenderSystem.disableDepthTest();
      RenderSystem.depthMask(false);
      RenderSystem.enableBlend();
      RenderSystem.blendFuncSeparate(dem.r.e, dem.j.e, dem.r.e, dem.j.e);
      RenderSystem.color4f(var6, var7, var8, 1.0F);
      this.e.M().a(c);
      dfo var17 = dfo.a();
      dfh var18 = var17.c();
      var18.a(7, dfk.n);
      var18.a(var13, var15 + var11, -90.0D).a(0.0F, 1.0F).d();
      var18.a(var13 + var9, var15 + var11, -90.0D).a(1.0F, 1.0F).d();
      var18.a(var13 + var9, var15, -90.0D).a(1.0F, 0.0F).d();
      var18.a(var13, var15, -90.0D).a(0.0F, 0.0F).d();
      var17.b();
      RenderSystem.color4f(1.0F, 1.0F, 1.0F, 1.0F);
      RenderSystem.defaultBlendFunc();
      RenderSystem.disableBlend();
      RenderSystem.depthMask(true);
      RenderSystem.enableDepthTest();
   }

   public float b(float var1) {
      return afm.g(var1, this.o, this.n);
   }

   public float j() {
      return this.h;
   }

   public djk k() {
      return this.H;
   }

   public eaf l() {
      return this.t;
   }

   public ejw m() {
      return this.u;
   }

   static {
      b = E.length;
   }
}
