public class eel extends efw<baf, dtx<baf>> {
   private static final vk a = new vk("textures/entity/dolphin.png");

   public eel(eet var1) {
      super(var1, new dtx(), 0.7F);
      this.a((eit)(new eib(this)));
   }

   public vk a(baf var1) {
      return a;
   }
}
