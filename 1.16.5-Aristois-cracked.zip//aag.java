import com.google.common.annotations.VisibleForTesting;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Queues;
import com.google.common.collect.Sets;
import it.unimi.dsi.fastutil.ints.Int2ObjectLinkedOpenHashMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap.Entry;
import it.unimi.dsi.fastutil.longs.LongSet;
import it.unimi.dsi.fastutil.longs.LongSets;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import it.unimi.dsi.fastutil.objects.ObjectLinkedOpenHashSet;
import java.io.IOException;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Queue;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Executor;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class aag extends brx implements bsr {
   public static final fx a = new fx(100, 50, 0);
   private static final Logger x = LogManager.getLogger();
   private final Int2ObjectMap<aqa> y = new Int2ObjectLinkedOpenHashMap();
   private final Map<UUID, aqa> z = Maps.newHashMap();
   private final Queue<aqa> A = Queues.newArrayDeque();
   private final List<aah> B = Lists.newArrayList();
   private final aae C;
   boolean b;
   private final MinecraftServer D;
   private final cym E;
   public boolean c;
   private boolean F;
   private int G;
   private final cxl H;
   private final bsl<buo> I;
   private final bsl<cuw> J;
   private final Set<ayj> K;
   protected final bhd d;
   private final ObjectLinkedOpenHashSet<brb> L;
   private boolean M;
   private final List<brj> N;
   @Nullable
   private final chg O;
   private final bsn P;
   private final boolean Q;

   public aag(MinecraftServer var1, Executor var2, cyg.a var3, cym var4, vj<brx> var5, chd var6, aap var7, cfy var8, boolean var9, long var10, List<brj> var12, boolean var13) {
      super(var4, var5, var6, var1::aQ, false, var9, var10);
      this.I = new bsl(this, (var0) -> {
         return var0 == null || var0.n().g();
      }, gm.Q::b, this::b);
      this.J = new bsl(this, (var0) -> {
         return var0 == null || var0 == cuy.a;
      }, gm.O::b, this::a);
      this.K = Sets.newHashSet();
      this.L = new ObjectLinkedOpenHashSet();
      this.Q = var13;
      this.D = var1;
      this.N = var12;
      this.E = var4;
      this.C = new aae(this, var3, var1.az(), var1.aW(), var2, var8, var1.ae().p(), var1.aV(), var7, () -> {
         return var1.E().s();
      });
      this.H = new cxl(this);
      this.Q();
      this.R();
      this.f().a(var1.au());
      this.d = (bhd)this.s().a(() -> {
         return new bhd(this);
      }, bhd.a(this.k()));
      if (!var1.O()) {
         var4.a(var1.s());
      }

      this.P = new bsn(this, var1.aX().A());
      if (this.k().l()) {
         this.O = new chg(this, var1.aX().A().a(), var1.aX().C());
      } else {
         this.O = null;
      }

   }

   public void a(int var1, int var2, boolean var3, boolean var4) {
      this.E.a(var1);
      this.E.f(var2);
      this.E.e(var2);
      this.E.b(var3);
      this.E.a(var4);
   }

   public bsv a(int var1, int var2, int var3) {
      return this.i().g().d().b(var1, var2, var3);
   }

   public bsn a() {
      return this.P;
   }

   public void a(BooleanSupplier var1) {
      anw var2 = this.Z();
      this.M = true;
      var2.a("world border");
      this.f().s();
      var2.b("weather");
      boolean var3 = this.X();
      if (this.k().b()) {
         if (this.V().b(brt.t)) {
            int var4 = this.E.h();
            int var5 = this.E.j();
            int var6 = this.E.l();
            boolean var7 = this.u.i();
            boolean var8 = this.u.k();
            if (var4 > 0) {
               --var4;
               var5 = var7 ? 0 : 1;
               var6 = var8 ? 0 : 1;
               var7 = false;
               var8 = false;
            } else {
               if (var5 > 0) {
                  --var5;
                  if (var5 == 0) {
                     var7 = !var7;
                  }
               } else if (var7) {
                  var5 = this.t.nextInt(12000) + 3600;
               } else {
                  var5 = this.t.nextInt(168000) + 12000;
               }

               if (var6 > 0) {
                  --var6;
                  if (var6 == 0) {
                     var8 = !var8;
                  }
               } else if (var8) {
                  var6 = this.t.nextInt(12000) + 12000;
               } else {
                  var6 = this.t.nextInt(168000) + 12000;
               }
            }

            this.E.e(var5);
            this.E.f(var6);
            this.E.a(var4);
            this.E.a(var7);
            this.E.b(var8);
         }

         this.r = this.s;
         if (this.u.i()) {
            this.s = (float)((double)this.s + 0.01D);
         } else {
            this.s = (float)((double)this.s - 0.01D);
         }

         this.s = afm.a(this.s, 0.0F, 1.0F);
         this.p = this.q;
         if (this.u.k()) {
            this.q = (float)((double)this.q + 0.01D);
         } else {
            this.q = (float)((double)this.q - 0.01D);
         }

         this.q = afm.a(this.q, 0.0F, 1.0F);
      }

      if (this.p != this.q) {
         this.D.ae().a((oj)(new pq(pq.h, this.q)), (vj)this.Y());
      }

      if (this.r != this.s) {
         this.D.ae().a((oj)(new pq(pq.i, this.s)), (vj)this.Y());
      }

      if (var3 != this.X()) {
         if (var3) {
            this.D.ae().a((oj)(new pq(pq.c, 0.0F)));
         } else {
            this.D.ae().a((oj)(new pq(pq.b, 0.0F)));
         }

         this.D.ae().a((oj)(new pq(pq.h, this.q)));
         this.D.ae().a((oj)(new pq(pq.i, this.s)));
      }

      if (this.F && this.B.stream().noneMatch((var0) -> {
         return !var0.a_() && !var0.eB();
      })) {
         this.F = false;
         if (this.V().b(brt.j)) {
            long var9 = this.u.f() + 24000L;
            this.a(var9 - var9 % 24000L);
         }

         this.ah();
         if (this.V().b(brt.t)) {
            this.ai();
         }
      }

      this.Q();
      this.b();
      var2.b("chunkSource");
      this.i().a(var1);
      var2.b("tickPending");
      if (!this.ab()) {
         this.I.b();
         this.J.b();
      }

      var2.b("raid");
      this.d.a();
      var2.b("blockEvents");
      this.ak();
      this.M = false;
      var2.b("entities");
      boolean var10 = !this.B.isEmpty() || !this.w().isEmpty();
      if (var10) {
         this.p_();
      }

      if (var10 || this.G++ < 300) {
         if (this.O != null) {
            this.O.b();
         }

         this.b = true;
         ObjectIterator var11 = this.y.int2ObjectEntrySet().iterator();

         label164:
         while(true) {
            aqa var13;
            while(true) {
               if (!var11.hasNext()) {
                  this.b = false;

                  aqa var14;
                  while((var14 = (aqa)this.A.poll()) != null) {
                     this.o(var14);
                  }

                  this.O();
                  break label164;
               }

               Entry<aqa> var12 = (Entry)var11.next();
               var13 = (aqa)var12.getValue();
               aqa var15 = var13.ct();
               if (!this.D.X() && (var13 instanceof azz || var13 instanceof bay)) {
                  var13.ad();
               }

               if (!this.D.Y() && var13 instanceof bfi) {
                  var13.ad();
               }

               var2.a("checkDespawn");
               if (!var13.y) {
                  var13.cI();
               }

               var2.c();
               if (var15 == null) {
                  break;
               }

               if (var15.y || !var15.w(var13)) {
                  var13.l();
                  break;
               }
            }

            var2.a("tick");
            if (!var13.y && !(var13 instanceof bbp)) {
               this.a((Consumer)(this::a), (aqa)var13);
            }

            var2.c();
            var2.a("remove");
            if (var13.y) {
               this.p(var13);
               var11.remove();
               this.h(var13);
            }

            var2.c();
         }
      }

      var2.c();
   }

   protected void b() {
      if (this.Q) {
         long var1 = this.u.e() + 1L;
         this.E.a(var1);
         this.E.u().a(this.D, var1);
         if (this.u.q().b(brt.j)) {
            this.a(this.u.f() + 1L);
         }

      }
   }

   public void a(long var1) {
      this.E.b(var1);
   }

   public void a(boolean var1, boolean var2) {
      Iterator var3 = this.N.iterator();

      while(var3.hasNext()) {
         brj var4 = (brj)var3.next();
         var4.a(this, var1, var2);
      }

   }

   private void ah() {
      ((List)this.B.stream().filter(aqm::em).collect(Collectors.toList())).forEach((var0) -> {
         var0.a(false, false);
      });
   }

   public void a(cgh var1, int var2) {
      brd var3 = var1.g();
      boolean var4 = this.X();
      int var5 = var3.d();
      int var6 = var3.e();
      anw var7 = this.Z();
      var7.a("thunder");
      fx var8;
      if (var4 && this.W() && this.t.nextInt(100000) == 0) {
         var8 = this.a(this.a(var5, 0, var6, 15));
         if (this.t(var8)) {
            aos var9 = this.d((fx)var8);
            boolean var10 = this.V().b(brt.d) && this.t.nextDouble() < (double)var9.b() * 0.01D;
            if (var10) {
               bbh var11 = (bbh)aqe.aw.a((brx)this);
               var11.t(true);
               var11.c_(0);
               var11.d((double)var8.u(), (double)var8.v(), (double)var8.w());
               this.c((aqa)var11);
            }

            aql var22 = (aql)aqe.P.a((brx)this);
            var22.d(dcn.c((gr)var8));
            var22.a(var10);
            this.c((aqa)var22);
         }
      }

      var7.b("iceandsnow");
      if (this.t.nextInt(16) == 0) {
         var8 = this.a((chn.a)chn.a.e, (fx)this.a(var5, 0, var6, 15));
         fx var18 = var8.c();
         bsv var20 = this.v(var8);
         if (var20.a(this, var18)) {
            this.a((fx)var18, (ceh)bup.cD.n());
         }

         if (var4 && var20.b(this, var8)) {
            this.a((fx)var8, (ceh)bup.cC.n());
         }

         if (var4 && this.v(var18).c() == bsv.e.b) {
            this.d_(var18).b().c((brx)this, var18);
         }
      }

      var7.b("tickBlocks");
      if (var2 > 0) {
         cgi[] var17 = var1.d();
         int var19 = var17.length;

         for(int var21 = 0; var21 < var19; ++var21) {
            cgi var23 = var17[var21];
            if (var23 != cgh.a && var23.d()) {
               int var12 = var23.g();

               for(int var13 = 0; var13 < var2; ++var13) {
                  fx var14 = this.a(var5, var12, var6, 15);
                  var7.a("randomTick");
                  ceh var15 = var23.a(var14.u() - var5, var14.v() - var12, var14.w() - var6);
                  if (var15.n()) {
                     var15.b(this, var14, this.t);
                  }

                  cux var16 = var15.m();
                  if (var16.f()) {
                     var16.b(this, var14, this.t);
                  }

                  var7.c();
               }
            }
         }
      }

      var7.c();
   }

   protected fx a(fx var1) {
      fx var2 = this.a((chn.a)chn.a.e, (fx)var1);
      dci var3 = (new dci(var2, new fx(var2.u(), this.L(), var2.w()))).g(3.0D);
      List<aqm> var4 = this.a((Class)aqm.class, (dci)var3, (Predicate)((var1x) -> {
         return var1x != null && var1x.aX() && this.e((fx)var1x.cB());
      }));
      if (!var4.isEmpty()) {
         return ((aqm)var4.get(this.t.nextInt(var4.size()))).cB();
      } else {
         if (var2.v() == -1) {
            var2 = var2.b(2);
         }

         return var2;
      }
   }

   public boolean m_() {
      return this.M;
   }

   public void n_() {
      this.F = false;
      if (!this.B.isEmpty()) {
         int var1 = 0;
         int var2 = 0;
         Iterator var3 = this.B.iterator();

         while(var3.hasNext()) {
            aah var4 = (aah)var3.next();
            if (var4.a_()) {
               ++var1;
            } else if (var4.em()) {
               ++var2;
            }
         }

         this.F = var2 > 0 && var2 >= this.B.size() - var1;
      }

   }

   public wa o_() {
      return this.D.aH();
   }

   private void ai() {
      this.E.f(0);
      this.E.b(false);
      this.E.e(0);
      this.E.a(false);
   }

   public void p_() {
      this.G = 0;
   }

   private void a(bsp<cuw> var1) {
      cux var2 = this.b((fx)var1.a);
      if (var2.a() == var1.b()) {
         var2.a((brx)this, var1.a);
      }

   }

   private void b(bsp<buo> var1) {
      ceh var2 = this.d_(var1.a);
      if (var2.a((buo)var1.b())) {
         var2.a(this, var1.a, this.t);
      }

   }

   public void a(aqa var1) {
      if (!(var1 instanceof bfw) && !this.i().a(var1)) {
         this.b(var1);
      } else {
         var1.g(var1.cD(), var1.cE(), var1.cH());
         var1.r = var1.p;
         var1.s = var1.q;
         if (var1.U) {
            ++var1.K;
            anw var2 = this.Z();
            var2.a(() -> {
               return gm.S.b((Object)var1.X()).toString();
            });
            var2.c("tickNonPassenger");
            var1.j();
            var2.c();
         }

         this.b(var1);
         if (var1.U) {
            Iterator var4 = var1.cn().iterator();

            while(var4.hasNext()) {
               aqa var3 = (aqa)var4.next();
               this.a(var1, var3);
            }
         }

      }
   }

   public void a(aqa var1, aqa var2) {
      if (!var2.y && var2.ct() == var1) {
         if (var2 instanceof bfw || this.i().a(var2)) {
            var2.g(var2.cD(), var2.cE(), var2.cH());
            var2.r = var2.p;
            var2.s = var2.q;
            if (var2.U) {
               ++var2.K;
               anw var3 = this.Z();
               var3.a(() -> {
                  return gm.S.b((Object)var2.X()).toString();
               });
               var3.c("tickPassenger");
               var2.ba();
               var3.c();
            }

            this.b(var2);
            if (var2.U) {
               Iterator var5 = var2.cn().iterator();

               while(var5.hasNext()) {
                  aqa var4 = (aqa)var5.next();
                  this.a(var2, var4);
               }
            }

         }
      } else {
         var2.l();
      }
   }

   public void b(aqa var1) {
      if (var1.cl()) {
         this.Z().a("chunkCheck");
         int var2 = afm.c(var1.cD() / 16.0D);
         int var3 = afm.c(var1.cE() / 16.0D);
         int var4 = afm.c(var1.cH() / 16.0D);
         if (!var1.U || var1.V != var2 || var1.W != var3 || var1.X != var4) {
            if (var1.U && this.b(var1.V, var1.X)) {
               this.d(var1.V, var1.X).a(var1, var1.W);
            }

            if (!var1.ck() && !this.b(var2, var4)) {
               if (var1.U) {
                  x.warn("Entity {} left loaded chunk area", var1);
               }

               var1.U = false;
            } else {
               this.d(var2, var4).a(var1);
            }
         }

         this.Z().c();
      }
   }

   public boolean a(bfw var1, fx var2) {
      return !this.D.a(this, var2, var1) && this.f().a(var2);
   }

   public void a(@Nullable afn var1, boolean var2, boolean var3) {
      aae var4 = this.i();
      if (!var3) {
         if (var1 != null) {
            var1.a(new of("menu.savingLevel"));
         }

         this.aj();
         if (var1 != null) {
            var1.c(new of("menu.savingChunks"));
         }

         var4.a(var2);
      }
   }

   private void aj() {
      if (this.O != null) {
         this.D.aX().a(this.O.a());
      }

      this.i().i().a();
   }

   public List<aqa> a(@Nullable aqe<?> var1, Predicate<? super aqa> var2) {
      List<aqa> var3 = Lists.newArrayList();
      aae var4 = this.i();
      ObjectIterator var5 = this.y.values().iterator();

      while(true) {
         aqa var6;
         do {
            if (!var5.hasNext()) {
               return var3;
            }

            var6 = (aqa)var5.next();
         } while(var1 != null && var6.X() != var1);

         if (var4.b(afm.c(var6.cD()) >> 4, afm.c(var6.cH()) >> 4) && var2.test(var6)) {
            var3.add(var6);
         }
      }
   }

   public List<bbr> g() {
      List<bbr> var1 = Lists.newArrayList();
      ObjectIterator var2 = this.y.values().iterator();

      while(var2.hasNext()) {
         aqa var3 = (aqa)var2.next();
         if (var3 instanceof bbr && var3.aX()) {
            var1.add((bbr)var3);
         }
      }

      return var1;
   }

   public List<aah> a(Predicate<? super aah> var1) {
      List<aah> var2 = Lists.newArrayList();
      Iterator var3 = this.B.iterator();

      while(var3.hasNext()) {
         aah var4 = (aah)var3.next();
         if (var1.test(var4)) {
            var2.add(var4);
         }
      }

      return var2;
   }

   @Nullable
   public aah q_() {
      List<aah> var1 = this.a(aqm::aX);
      return var1.isEmpty() ? null : (aah)var1.get(this.t.nextInt(var1.size()));
   }

   public boolean c(aqa var1) {
      return this.m(var1);
   }

   public boolean d(aqa var1) {
      return this.m(var1);
   }

   public void e(aqa var1) {
      boolean var2 = var1.k;
      var1.k = true;
      this.d(var1);
      var1.k = var2;
      this.b(var1);
   }

   public void a(aah var1) {
      this.f(var1);
      this.b((aqa)var1);
   }

   public void b(aah var1) {
      this.f(var1);
      this.b((aqa)var1);
   }

   public void c(aah var1) {
      this.f(var1);
   }

   public void d(aah var1) {
      this.f(var1);
   }

   private void f(aah var1) {
      aqa var2 = (aqa)this.z.get(var1.bS());
      if (var2 != null) {
         x.warn("Force-added player with duplicate UUID {}", var1.bS().toString());
         var2.V();
         this.e((aah)var2);
      }

      this.B.add(var1);
      this.n_();
      cfw var3 = this.a(afm.c(var1.cD() / 16.0D), afm.c(var1.cH() / 16.0D), cga.m, true);
      if (var3 instanceof cgh) {
         var3.a((aqa)var1);
      }

      this.o(var1);
   }

   private boolean m(aqa var1) {
      if (var1.y) {
         x.warn("Tried to add entity {} but it was marked as removed already", aqe.a(var1.X()));
         return false;
      } else if (this.n(var1)) {
         return false;
      } else {
         cfw var2 = this.a(afm.c(var1.cD() / 16.0D), afm.c(var1.cH() / 16.0D), cga.m, var1.k);
         if (!(var2 instanceof cgh)) {
            return false;
         } else {
            var2.a(var1);
            this.o(var1);
            return true;
         }
      }
   }

   public boolean f(aqa var1) {
      if (this.n(var1)) {
         return false;
      } else {
         this.o(var1);
         return true;
      }
   }

   private boolean n(aqa var1) {
      UUID var2 = var1.bS();
      aqa var3 = this.c(var2);
      if (var3 == null) {
         return false;
      } else {
         x.warn("Trying to add entity with duplicated UUID {}. Existing {}#{}, new: {}#{}", var2, aqe.a(var3.X()), var3.Y(), aqe.a(var1.X()), var1.Y());
         return true;
      }
   }

   @Nullable
   private aqa c(UUID var1) {
      aqa var2 = (aqa)this.z.get(var1);
      if (var2 != null) {
         return var2;
      } else {
         if (this.b) {
            Iterator var3 = this.A.iterator();

            while(var3.hasNext()) {
               aqa var4 = (aqa)var3.next();
               if (var4.bS().equals(var1)) {
                  return var4;
               }
            }
         }

         return null;
      }
   }

   public boolean g(aqa var1) {
      if (var1.cp().anyMatch(this::n)) {
         return false;
      } else {
         this.l(var1);
         return true;
      }
   }

   public void a(cgh var1) {
      this.m.addAll(var1.y().values());
      aes[] var2 = var1.z();
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         aes<aqa> var5 = var2[var4];
         Iterator var6 = var5.iterator();

         while(var6.hasNext()) {
            aqa var7 = (aqa)var6.next();
            if (!(var7 instanceof aah)) {
               if (this.b) {
                  throw (IllegalStateException)x.c((Throwable)(new IllegalStateException("Removing entity while ticking!")));
               }

               this.y.remove(var7.Y());
               this.h(var7);
            }
         }
      }

   }

   public void h(aqa var1) {
      if (var1 instanceof bbr) {
         bbp[] var2 = ((bbr)var1).eJ();
         int var3 = var2.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            bbp var5 = var2[var4];
            var5.ad();
         }
      }

      this.z.remove(var1.bS());
      this.i().b(var1);
      if (var1 instanceof aah) {
         aah var6 = (aah)var1;
         this.B.remove(var6);
      }

      this.o_().a((aqa)var1);
      if (var1 instanceof aqn) {
         this.K.remove(((aqn)var1).x());
      }

   }

   private void o(aqa var1) {
      if (this.b) {
         this.A.add(var1);
      } else {
         this.y.put(var1.Y(), var1);
         if (var1 instanceof bbr) {
            bbp[] var2 = ((bbr)var1).eJ();
            int var3 = var2.length;

            for(int var4 = 0; var4 < var3; ++var4) {
               bbp var5 = var2[var4];
               this.y.put(var5.Y(), var5);
            }
         }

         this.z.put(var1.bS(), var1);
         this.i().c(var1);
         if (var1 instanceof aqn) {
            this.K.add(((aqn)var1).x());
         }
      }

   }

   public void i(aqa var1) {
      if (this.b) {
         throw (IllegalStateException)x.c((Throwable)(new IllegalStateException("Removing entity while ticking!")));
      } else {
         this.p(var1);
         this.y.remove(var1.Y());
         this.h(var1);
      }
   }

   private void p(aqa var1) {
      cfw var2 = this.a(var1.V, var1.X, cga.m, false);
      if (var2 instanceof cgh) {
         ((cgh)var2).b(var1);
      }

   }

   public void e(aah var1) {
      var1.ad();
      this.i(var1);
      this.n_();
   }

   public void a(int var1, fx var2, int var3) {
      Iterator var4 = this.D.ae().s().iterator();

      while(var4.hasNext()) {
         aah var5 = (aah)var4.next();
         if (var5 != null && var5.l == this && var5.Y() != var1) {
            double var6 = (double)var2.u() - var5.cD();
            double var8 = (double)var2.v() - var5.cE();
            double var10 = (double)var2.w() - var5.cH();
            if (var6 * var6 + var8 * var8 + var10 * var10 < 1024.0D) {
               var5.b.a((oj)(new ov(var1, var2, var3)));
            }
         }
      }

   }

   public void a(@Nullable bfw var1, double var2, double var4, double var6, adp var8, adr var9, float var10, float var11) {
      this.D.ae().a(var1, var2, var4, var6, var10 > 1.0F ? (double)(16.0F * var10) : 16.0D, this.Y(), new rn(var8, var9, var2, var4, var6, var10, var11));
   }

   public void a(@Nullable bfw var1, aqa var2, adp var3, adr var4, float var5, float var6) {
      this.D.ae().a(var1, var2.cD(), var2.cE(), var2.cH(), var5 > 1.0F ? (double)(16.0F * var5) : 16.0D, this.Y(), new rm(var3, var4, var2, var5, var6));
   }

   public void b(int var1, fx var2, int var3) {
      this.D.ae().a((oj)(new pu(var1, var2, var3, true)));
   }

   public void a(@Nullable bfw var1, int var2, fx var3, int var4) {
      this.D.ae().a(var1, (double)var3.u(), (double)var3.v(), (double)var3.w(), 64.0D, this.Y(), new pu(var2, var3, var4, false));
   }

   public void a(fx var1, ceh var2, ceh var3, int var4) {
      this.i().b(var1);
      ddh var5 = var2.k(this, var1);
      ddh var6 = var3.k(this, var1);
      if (dde.c(var5, var6, dcr.g)) {
         Iterator var7 = this.K.iterator();

         while(var7.hasNext()) {
            ayj var8 = (ayj)var7.next();
            if (!var8.i()) {
               var8.b(var1);
            }
         }

      }
   }

   public void a(aqa var1, byte var2) {
      this.i().a((aqa)var1, (oj)(new pn(var1, var2)));
   }

   public aae i() {
      return this.C;
   }

   public brp a(@Nullable aqa var1, @Nullable apk var2, @Nullable brq var3, double var4, double var6, double var8, float var10, boolean var11, brp.a var12) {
      brp var13 = new brp(this, var1, var2, var3, var4, var6, var8, var10, var11, var12);
      var13.a();
      var13.a(false);
      if (var12 == brp.a.a) {
         var13.e();
      }

      Iterator var14 = this.B.iterator();

      while(var14.hasNext()) {
         aah var15 = (aah)var14.next();
         if (var15.h(var4, var6, var8) < 4096.0D) {
            var15.b.a((oj)(new po(var4, var6, var8, var10, var13.f(), (dcn)var13.c().get(var15))));
         }
      }

      return var13;
   }

   public void a(fx var1, buo var2, int var3, int var4) {
      this.L.add(new brb(var1, var2, var3, var4));
   }

   private void ak() {
      while(!this.L.isEmpty()) {
         brb var1 = (brb)this.L.removeFirst();
         if (this.a(var1)) {
            this.D.ae().a((bfw)null, (double)var1.a().u(), (double)var1.a().v(), (double)var1.a().w(), 64.0D, this.Y(), new ox(var1.a(), var1.b(), var1.c(), var1.d()));
         }
      }

   }

   private boolean a(brb var1) {
      ceh var2 = this.d_(var1.a());
      return var2.a(var1.b()) ? var2.a(this, var1.a(), var1.c(), var1.d()) : false;
   }

   public bsl<buo> j() {
      return this.I;
   }

   public bsl<cuw> r_() {
      return this.J;
   }

   @Nonnull
   public MinecraftServer l() {
      return this.D;
   }

   public cxl m() {
      return this.H;
   }

   public csw n() {
      return this.D.aW();
   }

   public <T extends hf> int a(T var1, double var2, double var4, double var6, int var8, double var9, double var11, double var13, double var15) {
      pv var17 = new pv(var1, false, var2, var4, var6, (float)var9, (float)var11, (float)var13, (float)var15, var8);
      int var18 = 0;

      for(int var19 = 0; var19 < this.B.size(); ++var19) {
         aah var20 = (aah)this.B.get(var19);
         if (this.a(var20, false, var2, var4, var6, var17)) {
            ++var18;
         }
      }

      return var18;
   }

   public <T extends hf> boolean a(aah var1, T var2, boolean var3, double var4, double var6, double var8, int var10, double var11, double var13, double var15, double var17) {
      oj<?> var19 = new pv(var2, var3, var4, var6, var8, (float)var11, (float)var13, (float)var15, (float)var17, var10);
      return this.a(var1, var3, var4, var6, var8, var19);
   }

   private boolean a(aah var1, boolean var2, double var3, double var5, double var7, oj<?> var9) {
      if (var1.u() != this) {
         return false;
      } else {
         fx var10 = var1.cB();
         if (var10.a(new dcn(var3, var5, var7), var2 ? 512.0D : 32.0D)) {
            var1.b.a(var9);
            return true;
         } else {
            return false;
         }
      }
   }

   @Nullable
   public aqa a(int var1) {
      return (aqa)this.y.get(var1);
   }

   @Nullable
   public aqa a(UUID var1) {
      return (aqa)this.z.get(var1);
   }

   @Nullable
   public fx a(cla<?> var1, fx var2, int var3, boolean var4) {
      return !this.D.aX().A().b() ? null : this.i().g().a(this, var1, var2, var3, var4);
   }

   @Nullable
   public fx a(bsv var1, fx var2, int var3, int var4) {
      return this.i().g().d().a(var2.u(), var2.v(), var2.w(), var3, var4, (var1x) -> {
         return var1x == var1;
      }, this.t, true);
   }

   public bor o() {
      return this.D.aF();
   }

   public aen p() {
      return this.D.aG();
   }

   public boolean q() {
      return this.c;
   }

   public gn r() {
      return this.D.aY();
   }

   public cyc s() {
      return this.i().i();
   }

   @Nullable
   public cxx a(String var1) {
      return (cxx)this.l().E().s().b(() -> {
         return new cxx(var1);
      }, var1);
   }

   public void a(cxx var1) {
      this.l().E().s().a((cxs)var1);
   }

   public int t() {
      return ((cxw)this.l().E().s().a(cxw::new, "idcounts")).a();
   }

   public void a(fx var1, float var2) {
      brd var3 = new brd(new fx(this.u.a(), 0, this.u.c()));
      this.u.a(var1, var2);
      this.i().b(aal.a, var3, 11, afx.a);
      this.i().a(aal.a, new brd(var1), 11, afx.a);
      this.l().ae().a((oj)(new qy(var1, var2)));
   }

   public fx u() {
      fx var1 = new fx(this.u.a(), this.u.b(), this.u.c());
      if (!this.f().a(var1)) {
         var1 = this.a((chn.a)chn.a.e, (fx)(new fx(this.f().a(), 0.0D, this.f().b())));
      }

      return var1;
   }

   public float v() {
      return this.u.d();
   }

   public LongSet w() {
      brs var1 = (brs)this.s().b(brs::new, "chunks");
      return (LongSet)(var1 != null ? LongSets.unmodifiable(var1.a()) : LongSets.EMPTY_SET);
   }

   public boolean a(int var1, int var2, boolean var3) {
      brs var4 = (brs)this.s().a(brs::new, "chunks");
      brd var5 = new brd(var1, var2);
      long var6 = var5.a();
      boolean var8;
      if (var3) {
         var8 = var4.a().add(var6);
         if (var8) {
            this.d(var1, var2);
         }
      } else {
         var8 = var4.a().remove(var6);
      }

      var4.a(var8);
      if (var8) {
         this.i().a(var5, var3);
      }

      return var8;
   }

   public List<aah> x() {
      return this.B;
   }

   public void a(fx var1, ceh var2, ceh var3) {
      Optional<azr> var4 = azr.b(var2);
      Optional<azr> var5 = azr.b(var3);
      if (!Objects.equals(var4, var5)) {
         fx var6 = var1.h();
         var4.ifPresent((var2x) -> {
            this.l().execute(() -> {
               this.y().a(var6);
               rz.b(this, var6);
            });
         });
         var5.ifPresent((var2x) -> {
            this.l().execute(() -> {
               this.y().a(var6, var2x);
               rz.a(this, var6);
            });
         });
      }
   }

   public azo y() {
      return this.i().j();
   }

   public boolean a_(fx var1) {
      return this.a((fx)var1, (int)1);
   }

   public boolean a(gp var1) {
      return this.a_(var1.q());
   }

   public boolean a(fx var1, int var2) {
      if (var2 > 6) {
         return false;
      } else {
         return this.b(gp.a(var1)) <= var2;
      }
   }

   public int b(gp var1) {
      return this.y().a(var1);
   }

   public bhd z() {
      return this.d;
   }

   @Nullable
   public bhb b_(fx var1) {
      return this.d.a(var1, 9216);
   }

   public boolean c_(fx var1) {
      return this.b_(var1) != null;
   }

   public void a(azl var1, aqa var2, aqz var3) {
      var3.a(var1, var2);
   }

   public void a(Path var1) throws IOException {
      zs var2 = this.i().a;
      Writer var3 = Files.newBufferedWriter(var1.resolve("stats.txt"));
      Throwable var4 = null;

      try {
         var3.write(String.format("spawning_chunks: %d\n", var2.e().b()));
         bsg.d var5 = this.i().k();
         if (var5 != null) {
            ObjectIterator var6 = var5.b().object2IntEntrySet().iterator();

            while(var6.hasNext()) {
               it.unimi.dsi.fastutil.objects.Object2IntMap.Entry<aqo> var7 = (it.unimi.dsi.fastutil.objects.Object2IntMap.Entry)var6.next();
               var3.write(String.format("spawn_count.%s: %d\n", ((aqo)var7.getKey()).b(), var7.getIntValue()));
            }
         }

         var3.write(String.format("entities: %d\n", this.y.size()));
         var3.write(String.format("block_entities: %d\n", this.j.size()));
         var3.write(String.format("block_ticks: %d\n", this.j().a()));
         var3.write(String.format("fluid_ticks: %d\n", this.r_().a()));
         var3.write("distance_manager: " + var2.e().c() + "\n");
         var3.write(String.format("pending_tasks: %d\n", this.i().f()));
      } catch (Throwable var121) {
         var4 = var121;
         throw var121;
      } finally {
         if (var3 != null) {
            if (var4 != null) {
               try {
                  var3.close();
               } catch (Throwable var109) {
                  var4.addSuppressed(var109);
               }
            } else {
               var3.close();
            }
         }

      }

      l var123 = new l("Level dump", new Exception("dummy"));
      this.a((l)var123);
      Writer var124 = Files.newBufferedWriter(var1.resolve("example_crash.txt"));
      Throwable var125 = null;

      try {
         var124.write(var123.e());
      } catch (Throwable var116) {
         var125 = var116;
         throw var116;
      } finally {
         if (var124 != null) {
            if (var125 != null) {
               try {
                  var124.close();
               } catch (Throwable var108) {
                  var125.addSuppressed(var108);
               }
            } else {
               var124.close();
            }
         }

      }

      Path var126 = var1.resolve("chunks.csv");
      Writer var127 = Files.newBufferedWriter(var126);
      Throwable var128 = null;

      try {
         var2.a((Writer)var127);
      } catch (Throwable var115) {
         var128 = var115;
         throw var115;
      } finally {
         if (var127 != null) {
            if (var128 != null) {
               try {
                  var127.close();
               } catch (Throwable var112) {
                  var128.addSuppressed(var112);
               }
            } else {
               var127.close();
            }
         }

      }

      Path var129 = var1.resolve("entities.csv");
      Writer var130 = Files.newBufferedWriter(var129);
      Throwable var131 = null;

      try {
         a((Writer)var130, (Iterable)this.y.values());
      } catch (Throwable var114) {
         var131 = var114;
         throw var114;
      } finally {
         if (var130 != null) {
            if (var131 != null) {
               try {
                  var130.close();
               } catch (Throwable var110) {
                  var131.addSuppressed(var110);
               }
            } else {
               var130.close();
            }
         }

      }

      Path var132 = var1.resolve("block_entities.csv");
      Writer var133 = Files.newBufferedWriter(var132);
      Throwable var8 = null;

      try {
         this.a((Writer)var133);
      } catch (Throwable var113) {
         var8 = var113;
         throw var113;
      } finally {
         if (var133 != null) {
            if (var8 != null) {
               try {
                  var133.close();
               } catch (Throwable var111) {
                  var8.addSuppressed(var111);
               }
            } else {
               var133.close();
            }
         }

      }

   }

   private static void a(Writer var0, Iterable<aqa> var1) throws IOException {
      aew var2 = aew.a().a("x").a("y").a("z").a("uuid").a("type").a("alive").a("display_name").a("custom_name").a(var0);
      Iterator var3 = var1.iterator();

      while(var3.hasNext()) {
         aqa var4 = (aqa)var3.next();
         nr var5 = var4.T();
         nr var6 = var4.d();
         var2.a(var4.cD(), var4.cE(), var4.cH(), var4.bS(), gm.S.b((Object)var4.X()), var4.aX(), var6.getString(), var5 != null ? var5.getString() : null);
      }

   }

   private void a(Writer var1) throws IOException {
      aew var2 = aew.a().a("x").a("y").a("z").a("type").a(var1);
      Iterator var3 = this.j.iterator();

      while(var3.hasNext()) {
         ccj var4 = (ccj)var3.next();
         fx var5 = var4.o();
         var2.a(var5.u(), var5.v(), var5.w(), gm.W.b((Object)var4.u()));
      }

   }

   @VisibleForTesting
   public void a(cra var1) {
      this.L.removeIf((var1x) -> {
         return var1.b((gr)var1x.a());
      });
   }

   public void a(fx var1, buo var2) {
      if (!this.ab()) {
         this.b((fx)var1, (buo)var2);
      }

   }

   public float a(gc var1, boolean var2) {
      return 1.0F;
   }

   public Iterable<aqa> A() {
      return Iterables.unmodifiableIterable(this.y.values());
   }

   public String toString() {
      return "ServerLevel[" + this.E.g() + "]";
   }

   public boolean B() {
      return this.D.aX().A().h();
   }

   public long C() {
      return this.D.aX().A().a();
   }

   @Nullable
   public chg D() {
      return this.O;
   }

   public Stream<? extends crv<?>> a(gp var1, cla<?> var2) {
      return this.a().a(var1, var2);
   }

   public aag E() {
      return this;
   }

   @VisibleForTesting
   public String F() {
      return String.format("players: %s, entities: %d [%s], block_entities: %d [%s], block_ticks: %d, fluid_ticks: %d, chunk_source: %s", this.B.size(), this.y.size(), a((Collection)this.y.values(), (Function)((var0) -> {
         return gm.S.b((Object)var0.X());
      })), this.k.size(), a((Collection)this.k, (Function)((var0) -> {
         return gm.W.b((Object)var0.u());
      })), this.j().a(), this.r_().a(), this.P());
   }

   private static <T> String a(Collection<T> var0, Function<T, vk> var1) {
      try {
         Object2IntOpenHashMap<vk> var2 = new Object2IntOpenHashMap();
         Iterator var3 = var0.iterator();

         while(var3.hasNext()) {
            T var4 = var3.next();
            vk var5 = (vk)var1.apply(var4);
            var2.addTo(var5, 1);
         }

         return (String)var2.object2IntEntrySet().stream().sorted(Comparator.comparing(it.unimi.dsi.fastutil.objects.Object2IntMap.Entry::getIntValue).reversed()).limit(5L).map((var0x) -> {
            return var0x.getKey() + ":" + var0x.getIntValue();
         }).collect(Collectors.joining(","));
      } catch (Exception var6) {
         return "";
      }
   }

   public static void a(aag var0) {
      fx var1 = a;
      int var2 = var1.u();
      int var3 = var1.v() - 2;
      int var4 = var1.w();
      fx.b(var2 - 2, var3 + 1, var4 - 2, var2 + 2, var3 + 3, var4 + 2).forEach((var1x) -> {
         var0.a((fx)var1x, (ceh)bup.a.n());
      });
      fx.b(var2 - 2, var3, var4 - 2, var2 + 2, var3, var4 + 2).forEach((var1x) -> {
         var0.a((fx)var1x, (ceh)bup.bK.n());
      });
   }

   // $FF: synthetic method
   public ddn G() {
      return this.o_();
   }

   // $FF: synthetic method
   public cfz H() {
      return this.i();
   }

   // $FF: synthetic method
   public bso I() {
      return this.r_();
   }

   // $FF: synthetic method
   public bso J() {
      return this.j();
   }
}
