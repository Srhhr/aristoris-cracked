import com.google.common.collect.Lists;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.Random;
import java.util.Set;

public class coz extends coy {
   public static final Codec<coz> b = RecordCodecBuilder.create((var0) -> {
      return a(var0).apply(var0, coz::new);
   });

   public coz(int var1, int var2, int var3) {
      super(var1, var2, var3);
   }

   protected cpc<?> a() {
      return cpc.d;
   }

   public List<cnl.b> a(bsb var1, Random var2, int var3, fx var4, Set<fx> var5, cra var6, cmz var7) {
      List<cnl.b> var8 = Lists.newArrayList();
      var8.addAll(super.a(var1, var2, var3, var4, var5, var6, var7));

      for(int var9 = var3 - 2 - var2.nextInt(4); var9 > var3 / 2; var9 -= 2 + var2.nextInt(4)) {
         float var10 = var2.nextFloat() * 6.2831855F;
         int var11 = 0;
         int var12 = 0;

         for(int var13 = 0; var13 < 5; ++var13) {
            var11 = (int)(1.5F + afm.b(var10) * (float)var13);
            var12 = (int)(1.5F + afm.a(var10) * (float)var13);
            fx var14 = var4.b(var11, var9 - 3 + var13 / 2, var12);
            a(var1, var2, var14, var5, var6, var7);
         }

         var8.add(new cnl.b(var4.b(var11, var9, var12), -2, false));
      }

      return var8;
   }
}
