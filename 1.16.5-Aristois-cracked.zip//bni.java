public class bni extends blx {
   private final bnh a;

   public bni(bnh var1, blx.a var2) {
      super(var2.b(var1.a()));
      this.a = var1;
   }

   public bnh g() {
      return this.a;
   }

   public int c() {
      return this.a.e();
   }

   public boolean a(bmb var1, bmb var2) {
      return this.a.f().a(var2) || super.a(var1, var2);
   }
}
