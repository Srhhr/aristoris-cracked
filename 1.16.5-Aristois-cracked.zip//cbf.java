import java.util.Random;
import javax.annotation.Nullable;

public class cbf extends buo {
   private static final ddh c = buo.a(3.0D, 0.0D, 3.0D, 12.0D, 7.0D, 12.0D);
   private static final ddh d = buo.a(1.0D, 0.0D, 1.0D, 15.0D, 7.0D, 15.0D);
   public static final cfg a;
   public static final cfg b;

   public cbf(ceg.c var1) {
      super(var1);
      this.j((ceh)((ceh)((ceh)this.n.b()).a(a, 0)).a(b, 1));
   }

   public void a(brx var1, fx var2, aqa var3) {
      this.a(var1, var2, var3, 100);
      super.a(var1, var2, var3);
   }

   public void a(brx var1, fx var2, aqa var3, float var4) {
      if (!(var3 instanceof bej)) {
         this.a(var1, var2, var3, 3);
      }

      super.a(var1, var2, var3, var4);
   }

   private void a(brx var1, fx var2, aqa var3, int var4) {
      if (this.a(var1, var3)) {
         if (!var1.v && var1.t.nextInt(var4) == 0) {
            ceh var5 = var1.d_(var2);
            if (var5.a(bup.kf)) {
               this.a(var1, var2, var5);
            }
         }

      }
   }

   private void a(brx var1, fx var2, ceh var3) {
      var1.a((bfw)null, (fx)var2, adq.pw, adr.e, 0.7F, 0.9F + var1.t.nextFloat() * 0.2F);
      int var4 = (Integer)var3.c(b);
      if (var4 <= 1) {
         var1.b(var2, false);
      } else {
         var1.a(var2, (ceh)var3.a(b, var4 - 1), 2);
         var1.c(2001, var2, buo.i(var3));
      }

   }

   public void b(ceh var1, aag var2, fx var3, Random var4) {
      if (this.a((brx)var2) && a((brc)var2, (fx)var3)) {
         int var5 = (Integer)var1.c(a);
         if (var5 < 2) {
            var2.a((bfw)null, var3, adq.px, adr.e, 0.7F, 0.9F + var4.nextFloat() * 0.2F);
            var2.a(var3, (ceh)var1.a(a, var5 + 1), 2);
         } else {
            var2.a((bfw)null, var3, adq.py, adr.e, 0.7F, 0.9F + var4.nextFloat() * 0.2F);
            var2.a(var3, false);

            for(int var6 = 0; var6 < (Integer)var1.c(b); ++var6) {
               var2.c(2001, var3, buo.i(var1));
               bax var7 = (bax)aqe.aN.a((brx)var2);
               var7.c_(-24000);
               var7.g(var3);
               var7.b((double)var3.u() + 0.3D + (double)var6 * 0.2D, (double)var3.v(), (double)var3.w() + 0.3D, 0.0F, 0.0F);
               var2.c((aqa)var7);
            }
         }
      }

   }

   public static boolean a(brc var0, fx var1) {
      return b(var0, var1.c());
   }

   public static boolean b(brc var0, fx var1) {
      return var0.d_(var1).a(aed.C);
   }

   public void b(ceh var1, brx var2, fx var3, ceh var4, boolean var5) {
      if (a((brc)var2, (fx)var3) && !var2.v) {
         var2.c(2005, var3, 0);
      }

   }

   private boolean a(brx var1) {
      float var2 = var1.f(1.0F);
      if ((double)var2 < 0.69D && (double)var2 > 0.65D) {
         return true;
      } else {
         return var1.t.nextInt(500) == 0;
      }
   }

   public void a(brx var1, bfw var2, fx var3, ceh var4, @Nullable ccj var5, bmb var6) {
      super.a(var1, var2, var3, var4, var5, var6);
      this.a(var1, var3, var4);
   }

   public boolean a(ceh var1, bny var2) {
      return var2.m().b() == this.h() && (Integer)var1.c(b) < 4 ? true : super.a((ceh)var1, (bny)var2);
   }

   @Nullable
   public ceh a(bny var1) {
      ceh var2 = var1.p().d_(var1.a());
      return var2.a(this) ? (ceh)var2.a(b, Math.min(4, (Integer)var2.c(b) + 1)) : super.a(var1);
   }

   public ddh b(ceh var1, brc var2, fx var3, dcs var4) {
      return (Integer)var1.c(b) > 1 ? d : c;
   }

   protected void a(cei.a<buo, ceh> var1) {
      var1.a(a, b);
   }

   private boolean a(brx var1, aqa var2) {
      if (!(var2 instanceof bax) && !(var2 instanceof azu)) {
         if (!(var2 instanceof aqm)) {
            return false;
         } else {
            return var2 instanceof bfw || var1.V().b(brt.b);
         }
      } else {
         return false;
      }
   }

   static {
      a = cex.ap;
      b = cex.ao;
   }
}
