import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Lists;
import com.google.common.collect.UnmodifiableIterator;
import com.google.common.collect.ImmutableMap.Builder;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.mojang.datafixers.DataFixer;
import it.unimi.dsi.fastutil.objects.Object2FloatMap;
import it.unimi.dsi.fastutil.objects.Object2FloatMaps;
import it.unimi.dsi.fastutil.objects.Object2FloatOpenCustomHashMap;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.ListIterator;
import java.util.concurrent.ThreadFactory;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class aoi {
   private static final Logger a = LogManager.getLogger();
   private static final ThreadFactory b = (new ThreadFactoryBuilder()).setDaemon(true).build();
   private final ImmutableSet<vj<brx>> c;
   private final boolean d;
   private final cyg.a e;
   private final Thread f;
   private final DataFixer g;
   private volatile boolean h = true;
   private volatile boolean i;
   private volatile float j;
   private volatile int k;
   private volatile int l;
   private volatile int m;
   private final Object2FloatMap<vj<brx>> n = Object2FloatMaps.synchronize(new Object2FloatOpenCustomHashMap(x.k()));
   private volatile nr o = new of("optimizeWorld.stage.counting");
   private static final Pattern p = Pattern.compile("^r\\.(-?[0-9]+)\\.(-?[0-9]+)\\.mca$");
   private final cyc q;

   public aoi(cyg.a var1, DataFixer var2, ImmutableSet<vj<brx>> var3, boolean var4) {
      this.c = var3;
      this.d = var4;
      this.g = var2;
      this.e = var1;
      this.q = new cyc(new File(this.e.a(brx.g), "data"), var2);
      this.f = b.newThread(this::i);
      this.f.setUncaughtExceptionHandler((var1x, var2x) -> {
         a.error("Error upgrading world", var2x);
         this.o = new of("optimizeWorld.stage.failed");
         this.i = true;
      });
      this.f.start();
   }

   public void a() {
      this.h = false;

      try {
         this.f.join();
      } catch (InterruptedException var2) {
      }

   }

   private void i() {
      this.k = 0;
      Builder<vj<brx>, ListIterator<brd>> var1 = ImmutableMap.builder();

      List var4;
      for(UnmodifiableIterator var2 = this.c.iterator(); var2.hasNext(); this.k += var4.size()) {
         vj<brx> var3 = (vj)var2.next();
         var4 = this.b(var3);
         var1.put(var3, var4.listIterator());
      }

      if (this.k == 0) {
         this.i = true;
      } else {
         float var25 = (float)this.k;
         ImmutableMap<vj<brx>, ListIterator<brd>> var26 = var1.build();
         Builder<vj<brx>, cgu> var27 = ImmutableMap.builder();
         UnmodifiableIterator var5 = this.c.iterator();

         while(var5.hasNext()) {
            vj<brx> var6 = (vj)var5.next();
            File var7 = this.e.a(var6);
            var27.put(var6, new cgu(new File(var7, "region"), this.g, true));
         }

         ImmutableMap<vj<brx>, cgu> var28 = var27.build();
         long var29 = x.b();
         this.o = new of("optimizeWorld.stage.upgrading");

         while(this.h) {
            boolean var8 = false;
            float var9 = 0.0F;

            float var32;
            for(UnmodifiableIterator var10 = this.c.iterator(); var10.hasNext(); var9 += var32) {
               vj<brx> var11 = (vj)var10.next();
               ListIterator<brd> var12 = (ListIterator)var26.get(var11);
               cgu var13 = (cgu)var28.get(var11);
               if (var12.hasNext()) {
                  brd var14 = (brd)var12.next();
                  boolean var15 = false;

                  try {
                     md var16 = var13.e(var14);
                     if (var16 != null) {
                        int var33 = cgu.a(var16);
                        md var18 = var13.a(var11, () -> {
                           return this.q;
                        }, var16);
                        md var19 = var18.p("Level");
                        brd var20 = new brd(var19.h("xPos"), var19.h("zPos"));
                        if (!var20.equals(var14)) {
                           a.warn("Chunk {} has invalid position {}", var14, var20);
                        }

                        boolean var21 = var33 < w.a().getWorldVersion();
                        if (this.d) {
                           var21 = var21 || var19.e("Heightmaps");
                           var19.r("Heightmaps");
                           var21 = var21 || var19.e("isLightOn");
                           var19.r("isLightOn");
                        }

                        if (var21) {
                           var13.a(var14, var18);
                           var15 = true;
                        }
                     }
                  } catch (u var23) {
                     Throwable var17 = var23.getCause();
                     if (!(var17 instanceof IOException)) {
                        throw var23;
                     }

                     a.error("Error upgrading chunk {}", var14, var17);
                  } catch (IOException var24) {
                     a.error("Error upgrading chunk {}", var14, var24);
                  }

                  if (var15) {
                     ++this.l;
                  } else {
                     ++this.m;
                  }

                  var8 = true;
               }

               var32 = (float)var12.nextIndex() / var25;
               this.n.put(var11, var32);
            }

            this.j = var9;
            if (!var8) {
               this.h = false;
            }
         }

         this.o = new of("optimizeWorld.stage.finished");
         UnmodifiableIterator var30 = var28.values().iterator();

         while(var30.hasNext()) {
            cgu var31 = (cgu)var30.next();

            try {
               var31.close();
            } catch (IOException var22) {
               a.error("Error upgrading chunk", var22);
            }
         }

         this.q.a();
         var29 = x.b() - var29;
         a.info("World optimizaton finished after {} ms", var29);
         this.i = true;
      }
   }

   private List<brd> b(vj<brx> var1) {
      File var2 = this.e.a(var1);
      File var3 = new File(var2, "region");
      File[] var4 = var3.listFiles((var0, var1x) -> {
         return var1x.endsWith(".mca");
      });
      if (var4 == null) {
         return ImmutableList.of();
      } else {
         List<brd> var5 = Lists.newArrayList();
         File[] var6 = var4;
         int var7 = var4.length;

         for(int var8 = 0; var8 < var7; ++var8) {
            File var9 = var6[var8];
            Matcher var10 = p.matcher(var9.getName());
            if (var10.matches()) {
               int var11 = Integer.parseInt(var10.group(1)) << 5;
               int var12 = Integer.parseInt(var10.group(2)) << 5;

               try {
                  cgy var13 = new cgy(var9, var3, true);
                  Throwable var14 = null;

                  try {
                     for(int var15 = 0; var15 < 32; ++var15) {
                        for(int var16 = 0; var16 < 32; ++var16) {
                           brd var17 = new brd(var15 + var11, var16 + var12);
                           if (var13.b(var17)) {
                              var5.add(var17);
                           }
                        }
                     }
                  } catch (Throwable var26) {
                     var14 = var26;
                     throw var26;
                  } finally {
                     if (var13 != null) {
                        if (var14 != null) {
                           try {
                              var13.close();
                           } catch (Throwable var25) {
                              var14.addSuppressed(var25);
                           }
                        } else {
                           var13.close();
                        }
                     }

                  }
               } catch (Throwable var28) {
               }
            }
         }

         return var5;
      }
   }

   public boolean b() {
      return this.i;
   }

   public ImmutableSet<vj<brx>> c() {
      return this.c;
   }

   public float a(vj<brx> var1) {
      return this.n.getFloat(var1);
   }

   public float d() {
      return this.j;
   }

   public int e() {
      return this.k;
   }

   public int f() {
      return this.l;
   }

   public int g() {
      return this.m;
   }

   public nr h() {
      return this.o;
   }
}
