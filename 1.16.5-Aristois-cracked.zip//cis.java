import com.mojang.serialization.Codec;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class cis extends cjl<cmh> {
   public cis(Codec<cmh> var1) {
      super(var1);
   }

   public boolean a(bsr var1, cfy var2, Random var3, fx var4, cmh var5) {
      brd var6 = new brd(var4);
      List<Integer> var7 = (List)IntStream.rangeClosed(var6.d(), var6.f()).boxed().collect(Collectors.toList());
      Collections.shuffle(var7, var3);
      List<Integer> var8 = (List)IntStream.rangeClosed(var6.e(), var6.g()).boxed().collect(Collectors.toList());
      Collections.shuffle(var8, var3);
      fx.a var9 = new fx.a();
      Iterator var10 = var7.iterator();

      while(var10.hasNext()) {
         Integer var11 = (Integer)var10.next();
         Iterator var12 = var8.iterator();

         while(var12.hasNext()) {
            Integer var13 = (Integer)var12.next();
            var9.d(var11, 0, var13);
            fx var14 = var1.a(chn.a.f, var9);
            if (var1.w(var14) || var1.d_(var14).k(var1, var14).b()) {
               var1.a(var14, bup.bR.n(), 2);
               cdd.a(var1, var3, var14, cyq.b);
               ceh var15 = bup.bL.n();
               Iterator var16 = gc.c.a.iterator();

               while(var16.hasNext()) {
                  gc var17 = (gc)var16.next();
                  fx var18 = var14.a(var17);
                  if (var15.a(var1, var18)) {
                     var1.a(var18, var15, 2);
                  }
               }

               return true;
            }
         }
      }

      return false;
   }
}
