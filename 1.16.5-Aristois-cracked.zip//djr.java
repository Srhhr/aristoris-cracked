import java.util.Optional;
import javax.annotation.Nullable;

public class djr extends dkf {
   public djr(dez var1) {
      this(var1, var1.t());
   }

   private djr(dez var1, @Nullable der var2) {
      super("options.fullscreen.resolution", -1.0D, var2 != null ? (double)(var2.e() - 1) : -1.0D, 1.0F, (var2x) -> {
         if (var2 == null) {
            return -1.0D;
         } else {
            Optional<dey> var3 = var1.f();
            return (Double)var3.map((var1x) -> {
               return (double)var2.a(var1x);
            }).orElse(-1.0D);
         }
      }, (var2x, var3) -> {
         if (var2 != null) {
            if (var3 == -1.0D) {
               var1.a(Optional.empty());
            } else {
               var1.a(Optional.of(var2.a(var3.intValue())));
            }

         }
      }, (var1x, var2x) -> {
         if (var2 == null) {
            return new of("options.fullscreen.unavailable");
         } else {
            double var3 = var2x.a(var1x);
            return var3 == -1.0D ? var2x.a(new of("options.fullscreen.current")) : var2x.a(new oe(var2.a((int)var3).toString()));
         }
      });
   }
}
