import com.google.gson.JsonObject;
import java.util.function.Predicate;

public class cn extends ck<cn.a> {
   private static final vk a = new vk("summoned_entity");

   public vk a() {
      return a;
   }

   public cn.a a(JsonObject var1, bg.b var2, ax var3) {
      bg.b var4 = bg.b.a(var1, "entity", var3);
      return new cn.a(var2, var4);
   }

   public void a(aah var1, aqa var2) {
      cyv var3 = bg.b(var1, var2);
      this.a((aah)var1, (Predicate)((var1x) -> {
         return var1x.a(var3);
      }));
   }

   // $FF: synthetic method
   public al b(JsonObject var1, bg.b var2, ax var3) {
      return this.a(var1, var2, var3);
   }

   public static class a extends al {
      private final bg.b a;

      public a(bg.b var1, bg.b var2) {
         super(cn.a, var1);
         this.a = var2;
      }

      public static cn.a a(bg.a var0) {
         return new cn.a(bg.b.a, bg.b.a(var0.b()));
      }

      public boolean a(cyv var1) {
         return this.a.a(var1);
      }

      public JsonObject a(ci var1) {
         JsonObject var2 = super.a(var1);
         var2.add("entity", this.a.a(var1));
         return var2;
      }
   }
}
