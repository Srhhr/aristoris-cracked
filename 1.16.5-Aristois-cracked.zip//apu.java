import com.google.common.collect.ComparisonChain;
import javax.annotation.Nullable;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class apu implements Comparable<apu> {
   private static final Logger a = LogManager.getLogger();
   private final aps b;
   private int c;
   private int d;
   private boolean e;
   private boolean f;
   private boolean g;
   private boolean h;
   private boolean i;
   @Nullable
   private apu j;

   public apu(aps var1) {
      this(var1, 0, 0);
   }

   public apu(aps var1, int var2) {
      this(var1, var2, 0);
   }

   public apu(aps var1, int var2, int var3) {
      this(var1, var2, var3, false, true);
   }

   public apu(aps var1, int var2, int var3, boolean var4, boolean var5) {
      this(var1, var2, var3, var4, var5, var5);
   }

   public apu(aps var1, int var2, int var3, boolean var4, boolean var5, boolean var6) {
      this(var1, var2, var3, var4, var5, var6, (apu)null);
   }

   public apu(aps var1, int var2, int var3, boolean var4, boolean var5, boolean var6, @Nullable apu var7) {
      this.b = var1;
      this.c = var2;
      this.d = var3;
      this.f = var4;
      this.h = var5;
      this.i = var6;
      this.j = var7;
   }

   public apu(apu var1) {
      this.b = var1.b;
      this.a(var1);
   }

   void a(apu var1) {
      this.c = var1.c;
      this.d = var1.d;
      this.f = var1.f;
      this.h = var1.h;
      this.i = var1.i;
   }

   public boolean b(apu var1) {
      if (this.b != var1.b) {
         a.warn("This method should only be called for matching effects!");
      }

      boolean var2 = false;
      if (var1.d > this.d) {
         if (var1.c < this.c) {
            apu var3 = this.j;
            this.j = new apu(this);
            this.j.j = var3;
         }

         this.d = var1.d;
         this.c = var1.c;
         var2 = true;
      } else if (var1.c > this.c) {
         if (var1.d == this.d) {
            this.c = var1.c;
            var2 = true;
         } else if (this.j == null) {
            this.j = new apu(var1);
         } else {
            this.j.b(var1);
         }
      }

      if (!var1.f && this.f || var2) {
         this.f = var1.f;
         var2 = true;
      }

      if (var1.h != this.h) {
         this.h = var1.h;
         var2 = true;
      }

      if (var1.i != this.i) {
         this.i = var1.i;
         var2 = true;
      }

      return var2;
   }

   public aps a() {
      return this.b;
   }

   public int b() {
      return this.c;
   }

   public int c() {
      return this.d;
   }

   public boolean d() {
      return this.f;
   }

   public boolean e() {
      return this.h;
   }

   public boolean f() {
      return this.i;
   }

   public boolean a(aqm var1, Runnable var2) {
      if (this.c > 0) {
         if (this.b.a(this.c, this.d)) {
            this.a(var1);
         }

         this.i();
         if (this.c == 0 && this.j != null) {
            this.a(this.j);
            this.j = this.j.j;
            var2.run();
         }
      }

      return this.c > 0;
   }

   private int i() {
      if (this.j != null) {
         this.j.i();
      }

      return --this.c;
   }

   public void a(aqm var1) {
      if (this.c > 0) {
         this.b.a(var1, this.d);
      }

   }

   public String g() {
      return this.b.c();
   }

   public String toString() {
      String var1;
      if (this.d > 0) {
         var1 = this.g() + " x " + (this.d + 1) + ", Duration: " + this.c;
      } else {
         var1 = this.g() + ", Duration: " + this.c;
      }

      if (this.e) {
         var1 = var1 + ", Splash: true";
      }

      if (!this.h) {
         var1 = var1 + ", Particles: false";
      }

      if (!this.i) {
         var1 = var1 + ", Show Icon: false";
      }

      return var1;
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof apu)) {
         return false;
      } else {
         apu var2 = (apu)var1;
         return this.c == var2.c && this.d == var2.d && this.e == var2.e && this.f == var2.f && this.b.equals(var2.b);
      }
   }

   public int hashCode() {
      int var1 = this.b.hashCode();
      var1 = 31 * var1 + this.c;
      var1 = 31 * var1 + this.d;
      var1 = 31 * var1 + (this.e ? 1 : 0);
      var1 = 31 * var1 + (this.f ? 1 : 0);
      return var1;
   }

   public md a(md var1) {
      var1.a("Id", (byte)aps.a(this.a()));
      this.c(var1);
      return var1;
   }

   private void c(md var1) {
      var1.a("Amplifier", (byte)this.c());
      var1.b("Duration", this.b());
      var1.a("Ambient", this.d());
      var1.a("ShowParticles", this.e());
      var1.a("ShowIcon", this.f());
      if (this.j != null) {
         md var2 = new md();
         this.j.a(var2);
         var1.a((String)"HiddenEffect", (mt)var2);
      }

   }

   public static apu b(md var0) {
      int var1 = var0.f("Id");
      aps var2 = aps.a(var1);
      return var2 == null ? null : a(var2, var0);
   }

   private static apu a(aps var0, md var1) {
      int var2 = var1.f("Amplifier");
      int var3 = var1.h("Duration");
      boolean var4 = var1.q("Ambient");
      boolean var5 = true;
      if (var1.c("ShowParticles", 1)) {
         var5 = var1.q("ShowParticles");
      }

      boolean var6 = var5;
      if (var1.c("ShowIcon", 1)) {
         var6 = var1.q("ShowIcon");
      }

      apu var7 = null;
      if (var1.c("HiddenEffect", 10)) {
         var7 = a(var0, var1.p("HiddenEffect"));
      }

      return new apu(var0, var3, var2 < 0 ? 0 : var2, var4, var5, var6, var7);
   }

   public void b(boolean var1) {
      this.g = var1;
   }

   public boolean h() {
      return this.g;
   }

   public int c(apu var1) {
      int var2 = true;
      return (this.b() <= 32147 || var1.b() <= 32147) && (!this.d() || !var1.d()) ? ComparisonChain.start().compare(this.d(), var1.d()).compare(this.b(), var1.b()).compare(this.a().f(), var1.a().f()).result() : ComparisonChain.start().compare(this.d(), var1.d()).compare(this.a().f(), var1.a().f()).result();
   }

   // $FF: synthetic method
   public int compareTo(Object var1) {
      return this.c((apu)var1);
   }
}
