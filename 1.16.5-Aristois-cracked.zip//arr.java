import com.google.common.collect.ImmutableMap;
import java.util.Optional;
import net.minecraft.server.MinecraftServer;

public class arr extends arv<bfj> {
   public arr() {
      super(ImmutableMap.of(ayd.d, aye.a));
   }

   protected boolean a(aag var1, bfj var2) {
      fx var3 = ((gf)var2.cJ().c(ayd.d).get()).b();
      return var3.a(var2.cA(), 2.0D) || var2.eZ();
   }

   protected void a(aag var1, bfj var2, long var3) {
      gf var5 = (gf)var2.cJ().c(ayd.d).get();
      var2.cJ().b(ayd.d);
      var2.cJ().a((ayd)ayd.c, (Object)var5);
      var1.a((aqa)var2, (byte)14);
      if (var2.eX().b() == bfm.a) {
         MinecraftServer var6 = var1.l();
         Optional.ofNullable(var6.a(var5.a())).flatMap((var1x) -> {
            return var1x.y().c(var5.b());
         }).flatMap((var0) -> {
            return gm.ai.g().filter((var1) -> {
               return var1.b() == var0;
            }).findFirst();
         }).ifPresent((var2x) -> {
            var2.a(var2.eX().a(var2x));
            var2.c(var1);
         });
      }
   }
}
