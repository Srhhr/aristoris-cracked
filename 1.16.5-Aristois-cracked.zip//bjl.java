import java.util.Collection;
import java.util.Collections;
import javax.annotation.Nullable;

public interface bjl {
   void a(@Nullable boq<?> var1);

   @Nullable
   boq<?> ak_();

   default void b(bfw var1) {
      boq<?> var2 = this.ak_();
      if (var2 != null && !var2.af_()) {
         var1.a((Collection)Collections.singleton(var2));
         this.a((boq)null);
      }

   }

   default boolean a(brx var1, aah var2, boq<?> var3) {
      if (!var3.af_() && var1.V().b(brt.u) && !var2.B().b(var3)) {
         return false;
      } else {
         this.a(var3);
         return true;
      }
   }
}
