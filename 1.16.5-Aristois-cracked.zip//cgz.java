import it.unimi.dsi.fastutil.longs.Long2ObjectLinkedOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.io.DataInput;
import java.io.DataInputStream;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import javax.annotation.Nullable;

public final class cgz implements AutoCloseable {
   private final Long2ObjectLinkedOpenHashMap<cgy> a = new Long2ObjectLinkedOpenHashMap();
   private final File b;
   private final boolean c;

   cgz(File var1, boolean var2) {
      this.b = var1;
      this.c = var2;
   }

   private cgy b(brd var1) throws IOException {
      long var2 = brd.a(var1.h(), var1.i());
      cgy var4 = (cgy)this.a.getAndMoveToFirst(var2);
      if (var4 != null) {
         return var4;
      } else {
         if (this.a.size() >= 256) {
            ((cgy)this.a.removeLast()).close();
         }

         if (!this.b.exists()) {
            this.b.mkdirs();
         }

         File var5 = new File(this.b, "r." + var1.h() + "." + var1.i() + ".mca");
         cgy var6 = new cgy(var5, this.b, this.c);
         this.a.putAndMoveToFirst(var2, var6);
         return var6;
      }
   }

   @Nullable
   public md a(brd var1) throws IOException {
      cgy var2 = this.b(var1);
      DataInputStream var3 = var2.a(var1);
      Throwable var4 = null;

      md var5;
      try {
         if (var3 != null) {
            var5 = mn.a((DataInput)var3);
            return var5;
         }

         var5 = null;
      } catch (Throwable var15) {
         var4 = var15;
         throw var15;
      } finally {
         if (var3 != null) {
            if (var4 != null) {
               try {
                  var3.close();
               } catch (Throwable var14) {
                  var4.addSuppressed(var14);
               }
            } else {
               var3.close();
            }
         }

      }

      return var5;
   }

   protected void a(brd var1, md var2) throws IOException {
      cgy var3 = this.b(var1);
      DataOutputStream var4 = var3.c(var1);
      Throwable var5 = null;

      try {
         mn.a((md)var2, (DataOutput)var4);
      } catch (Throwable var14) {
         var5 = var14;
         throw var14;
      } finally {
         if (var4 != null) {
            if (var5 != null) {
               try {
                  var4.close();
               } catch (Throwable var13) {
                  var5.addSuppressed(var13);
               }
            } else {
               var4.close();
            }
         }

      }

   }

   public void close() throws IOException {
      aey<IOException> var1 = new aey();
      ObjectIterator var2 = this.a.values().iterator();

      while(var2.hasNext()) {
         cgy var3 = (cgy)var2.next();

         try {
            var3.close();
         } catch (IOException var5) {
            var1.a(var5);
         }
      }

      var1.a();
   }

   public void a() throws IOException {
      ObjectIterator var1 = this.a.values().iterator();

      while(var1.hasNext()) {
         cgy var2 = (cgy)var1.next();
         var2.a();
      }

   }
}
