public abstract class boc implements boq<aon> {
   protected final bot<?> a;
   protected final vk b;
   protected final String c;
   protected final bon d;
   protected final bmb e;
   protected final float f;
   protected final int g;

   public boc(bot<?> var1, vk var2, String var3, bon var4, bmb var5, float var6, int var7) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
      this.e = var5;
      this.f = var6;
      this.g = var7;
   }

   public boolean a(aon var1, brx var2) {
      return this.d.a(var1.a(0));
   }

   public bmb a(aon var1) {
      return this.e.i();
   }

   public boolean a(int var1, int var2) {
      return true;
   }

   public gj<bon> a() {
      gj<bon> var1 = gj.a();
      var1.add(this.d);
      return var1;
   }

   public float b() {
      return this.f;
   }

   public bmb c() {
      return this.e;
   }

   public String d() {
      return this.c;
   }

   public int e() {
      return this.g;
   }

   public vk f() {
      return this.b;
   }

   public bot<?> g() {
      return this.a;
   }
}
