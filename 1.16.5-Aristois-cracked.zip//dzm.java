import com.google.common.collect.Lists;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import java.util.function.BiPredicate;
import javax.annotation.Nullable;

public class dzm extends dzj {
   public final dwu e;
   private final aeb bR;
   private final djm bS;
   private final List<eme> bT = Lists.newArrayList();
   private int bU = 0;
   private double bV;
   private double bW;
   private double bX;
   private float bY;
   private float bZ;
   private boolean ca;
   private boolean cb;
   private boolean cc;
   private boolean cd;
   private int ce;
   private boolean cf;
   private String cg;
   public dzk f;
   protected final djz g;
   protected int bJ;
   public int bK;
   public float bL;
   public float bM;
   public float bN;
   public float bO;
   private int ch;
   private float ci;
   public float bP;
   public float bQ;
   private boolean cj;
   private aot ck;
   private boolean cl;
   private boolean cm = true;
   private int cn;
   private boolean co;
   private int cp;
   private boolean cq = true;

   public dzm(djz var1, dwt var2, dwu var3, aeb var4, djm var5, boolean var6, boolean var7) {
      super(var2, var3.g());
      this.g = var1;
      this.e = var3;
      this.bR = var4;
      this.bS = var5;
      this.cc = var6;
      this.cd = var7;
      this.bT.add(new emv(this, var1.W()));
      this.bT.add(new emj(this));
      this.bT.add(new emi(this, var1.W(), var2.d()));
   }

   public boolean a(apk var1, float var2) {
      return false;
   }

   public void b(float var1) {
   }

   public boolean a(aqa var1, boolean var2) {
      if (!super.a(var1, var2)) {
         return false;
      } else {
         if (var1 instanceof bhl) {
            this.g.W().a((emt)(new emo(this, (bhl)var1)));
         }

         if (var1 instanceof bhn) {
            this.r = var1.p;
            this.p = var1.p;
            this.m(var1.p);
         }

         return true;
      }
   }

   public void bf() {
      super.bf();
      this.cl = false;
   }

   public float g(float var1) {
      return this.q;
   }

   public float h(float var1) {
      return this.br() ? super.h(var1) : this.p;
   }

   public void j() {
      if (this.l.C(new fx(this.cD(), 0.0D, this.cH()))) {
         super.j();
         if (this.br()) {
            this.e.a((oj)(new st.c(this.p, this.q, this.t)));
            this.e.a((oj)(new tb(this.aR, this.aT, this.f.g, this.f.h)));
            aqa var1 = this.cr();
            if (var1 != this && var1.cs()) {
               this.e.a((oj)(new su(var1)));
            }
         } else {
            this.O();
         }

         Iterator var3 = this.bT.iterator();

         while(var3.hasNext()) {
            eme var2 = (eme)var3.next();
            var2.a();
         }

      }
   }

   public float w() {
      Iterator var1 = this.bT.iterator();

      eme var2;
      do {
         if (!var1.hasNext()) {
            return 0.0F;
         }

         var2 = (eme)var1.next();
      } while(!(var2 instanceof emi));

      return ((emi)var2).b();
   }

   private void O() {
      boolean var1 = this.bA();
      if (var1 != this.cd) {
         ta.a var2 = var1 ? ta.a.d : ta.a.e;
         this.e.a((oj)(new ta(this, var2)));
         this.cd = var1;
      }

      boolean var16 = this.bu();
      if (var16 != this.cc) {
         ta.a var3 = var16 ? ta.a.a : ta.a.b;
         this.e.a((oj)(new ta(this, var3)));
         this.cc = var16;
      }

      if (this.K()) {
         double var17 = this.cD() - this.bV;
         double var5 = this.cE() - this.bW;
         double var7 = this.cH() - this.bX;
         double var9 = (double)(this.p - this.bY);
         double var11 = (double)(this.q - this.bZ);
         ++this.ce;
         boolean var13 = var17 * var17 + var5 * var5 + var7 * var7 > 9.0E-4D || this.ce >= 20;
         boolean var14 = var9 != 0.0D || var11 != 0.0D;
         if (this.br()) {
            dcn var15 = this.cC();
            this.e.a((oj)(new st.b(var15.b, -999.0D, var15.d, this.p, this.q, this.t)));
            var13 = false;
         } else if (var13 && var14) {
            this.e.a((oj)(new st.b(this.cD(), this.cE(), this.cH(), this.p, this.q, this.t)));
         } else if (var13) {
            this.e.a((oj)(new st.a(this.cD(), this.cE(), this.cH(), this.t)));
         } else if (var14) {
            this.e.a((oj)(new st.c(this.p, this.q, this.t)));
         } else if (this.ca != this.t) {
            this.e.a((oj)(new st(this.t)));
         }

         if (var13) {
            this.bV = this.cD();
            this.bW = this.cE();
            this.bX = this.cH();
            this.ce = 0;
         }

         if (var14) {
            this.bY = this.p;
            this.bZ = this.q;
         }

         this.ca = this.t;
         this.cm = this.g.k.J;
      }

   }

   public boolean a(boolean var1) {
      sz.a var2 = var1 ? sz.a.d : sz.a.e;
      this.e.a((oj)(new sz(var2, fx.b, gc.a)));
      return this.bm.a(this.bm.d, var1 && !this.bm.f().a() ? this.bm.f().E() : 1) != bmb.b;
   }

   public void f(String var1) {
      this.e.a((oj)(new se(var1)));
   }

   public void a(aot var1) {
      super.a(var1);
      this.e.a((oj)(new tq(var1)));
   }

   public void ey() {
      this.e.a((oj)(new sf(sf.a.a)));
   }

   protected void e(apk var1, float var2) {
      if (!this.b(var1)) {
         this.c(this.dk() - var2);
      }
   }

   public void m() {
      this.e.a((oj)(new sl(this.bp.b)));
      this.x();
   }

   public void x() {
      this.bm.g(bmb.b);
      super.m();
      this.g.a((dot)null);
   }

   public void v(float var1) {
      if (this.cf) {
         float var2 = this.dk() - var1;
         if (var2 <= 0.0F) {
            this.c(var1);
            if (var2 < 0.0F) {
               this.P = 10;
            }
         } else {
            this.aP = var2;
            this.c(this.dk());
            this.P = 20;
            this.e(apk.n, var2);
            this.ao = 10;
            this.an = this.ao;
         }
      } else {
         this.c(var1);
         this.cf = true;
      }

   }

   public void t() {
      this.e.a((oj)(new sy(this.bC)));
   }

   public boolean ez() {
      return true;
   }

   public boolean ee() {
      return !this.bC.b && super.ee();
   }

   public boolean aO() {
      return !this.bC.b && super.aO();
   }

   public boolean cN() {
      return !this.bC.b && super.cN();
   }

   protected void z() {
      this.e.a((oj)(new ta(this, ta.a.f, afm.d(this.I() * 100.0F))));
   }

   public void A() {
      this.e.a((oj)(new ta(this, ta.a.h)));
   }

   public void g(String var1) {
      this.cg = var1;
   }

   public String B() {
      return this.cg;
   }

   public aeb D() {
      return this.bR;
   }

   public djm F() {
      return this.bS;
   }

   public void a(boq<?> var1) {
      if (this.bS.d(var1)) {
         this.bS.e(var1);
         this.e.a((oj)(new td(var1)));
      }

   }

   protected int y() {
      return this.bU;
   }

   public void a(int var1) {
      this.bU = var1;
   }

   public void a(nr var1, boolean var2) {
      if (var2) {
         this.g.j.a(var1, false);
      } else {
         this.g.j.c().a(var1);
      }

   }

   private void b(double var1, double var3) {
      fx var5 = new fx(var1, this.cE(), var3);
      if (this.g(var5)) {
         double var6 = var1 - (double)var5.u();
         double var8 = var3 - (double)var5.w();
         gc var10 = null;
         double var11 = Double.MAX_VALUE;
         gc[] var13 = new gc[]{gc.e, gc.f, gc.c, gc.d};
         gc[] var14 = var13;
         int var15 = var13.length;

         for(int var16 = 0; var16 < var15; ++var16) {
            gc var17 = var14[var16];
            double var18 = var17.n().a(var6, 0.0D, var8);
            double var20 = var17.e() == gc.b.a ? 1.0D - var18 : var18;
            if (var20 < var11 && !this.g(var5.a(var17))) {
               var11 = var20;
               var10 = var17;
            }
         }

         if (var10 != null) {
            dcn var22 = this.cC();
            if (var10.n() == gc.a.a) {
               this.n(0.1D * (double)var10.i(), var22.c, var22.d);
            } else {
               this.n(var22.b, var22.c, 0.1D * (double)var10.k());
            }
         }

      }
   }

   private boolean g(fx var1) {
      dci var2 = this.cc();
      dci var3 = (new dci((double)var1.u(), var2.b, (double)var1.w(), (double)var1.u() + 1.0D, var2.e, (double)var1.w() + 1.0D)).h(1.0E-7D);
      return !this.l.a((aqa)this, (dci)var3, (BiPredicate)((var1x, var2x) -> {
         return var1x.o(this.l, var2x);
      }));
   }

   public void g(boolean var1) {
      super.g(var1);
      this.bK = 0;
   }

   public void a(float var1, int var2, int var3) {
      this.bF = var1;
      this.bE = var2;
      this.bD = var3;
   }

   public void a(nr var1, UUID var2) {
      this.g.j.c().a(var1);
   }

   public void a(byte var1) {
      if (var1 >= 24 && var1 <= 28) {
         this.a(var1 - 24);
      } else {
         super.a(var1);
      }

   }

   public void b(boolean var1) {
      this.cq = var1;
   }

   public boolean G() {
      return this.cq;
   }

   public void a(adp var1, float var2, float var3) {
      this.l.a(this.cD(), this.cE(), this.cH(), var1, this.cu(), var2, var3, false);
   }

   public void a(adp var1, adr var2, float var3, float var4) {
      this.l.a(this.cD(), this.cE(), this.cH(), var1, var2, var3, var4, false);
   }

   public boolean dS() {
      return true;
   }

   public void c(aot var1) {
      bmb var2 = this.b(var1);
      if (!var2.a() && !this.dW()) {
         super.c(var1);
         this.cj = true;
         this.ck = var1;
      }
   }

   public boolean dW() {
      return this.cj;
   }

   public void ec() {
      super.ec();
      this.cj = false;
   }

   public aot dX() {
      return this.ck;
   }

   public void a(us<?> var1) {
      super.a(var1);
      if (ag.equals(var1)) {
         boolean var2 = ((Byte)this.R.a(ag) & 1) > 0;
         aot var3 = ((Byte)this.R.a(ag) & 2) > 0 ? aot.b : aot.a;
         if (var2 && !this.cj) {
            this.c(var3);
         } else if (!var2 && this.cj) {
            this.ec();
         }
      }

      if (S.equals(var1) && this.ef() && !this.co) {
         this.g.W().a((emt)(new emk(this)));
      }

   }

   public boolean H() {
      aqa var1 = this.ct();
      return this.br() && var1 instanceof aqw && ((aqw)var1).P_();
   }

   public float I() {
      return this.ci;
   }

   public void a(cdf var1) {
      this.g.a((dot)(new dqv(var1)));
   }

   public void a(bqy var1) {
      this.g.a((dot)(new dqs(var1)));
   }

   public void a(cco var1) {
      this.g.a((dot)(new dpy(var1)));
   }

   public void a(cdj var1) {
      this.g.a((dot)(new dqz(var1)));
   }

   public void a(ccz var1) {
      this.g.a((dot)(new dqn(var1)));
   }

   public void a(bmb var1, aot var2) {
      blx var3 = var1.b();
      if (var3 == bmd.oT) {
         this.g.a((dot)(new dpu(this, var1, var2)));
      }

   }

   public void a(aqa var1) {
      this.g.f.a((aqa)var1, (hf)hh.g);
   }

   public void b(aqa var1) {
      this.g.f.a((aqa)var1, (hf)hh.r);
   }

   public boolean bu() {
      return this.f != null && this.f.h;
   }

   public boolean bz() {
      return this.cb;
   }

   public boolean J() {
      return this.bz() || this.bD();
   }

   public void dP() {
      super.dP();
      if (this.K()) {
         this.aR = this.f.a;
         this.aT = this.f.b;
         this.aQ = this.f.g;
         this.bN = this.bL;
         this.bO = this.bM;
         this.bM = (float)((double)this.bM + (double)(this.q - this.bM) * 0.5D);
         this.bL = (float)((double)this.bL + (double)(this.p - this.bL) * 0.5D);
      }

   }

   protected boolean K() {
      return this.g.aa() == this;
   }

   public void k() {
      ++this.bK;
      if (this.bJ > 0) {
         --this.bJ;
      }

      this.Q();
      boolean var1 = this.f.g;
      boolean var2 = this.f.h;
      boolean var3 = this.eY();
      this.cb = !this.bC.b && !this.bB() && this.c((aqx)aqx.f) && (this.bu() || !this.em() && !this.c((aqx)aqx.a));
      this.f.a(this.J());
      this.g.ao().a(this.f);
      if (this.dW() && !this.br()) {
         dzk var10000 = this.f;
         var10000.a *= 0.2F;
         var10000 = this.f;
         var10000.b *= 0.2F;
         this.bJ = 0;
      }

      boolean var4 = false;
      if (this.cn > 0) {
         --this.cn;
         var4 = true;
         this.f.g = true;
      }

      if (!this.H) {
         this.b(this.cD() - (double)this.cy() * 0.35D, this.cH() + (double)this.cy() * 0.35D);
         this.b(this.cD() - (double)this.cy() * 0.35D, this.cH() - (double)this.cy() * 0.35D);
         this.b(this.cD() + (double)this.cy() * 0.35D, this.cH() - (double)this.cy() * 0.35D);
         this.b(this.cD() + (double)this.cy() * 0.35D, this.cH() + (double)this.cy() * 0.35D);
      }

      if (var2) {
         this.bJ = 0;
      }

      boolean var5 = (float)this.eI().a() > 6.0F || this.bC.c;
      if ((this.t || this.aI()) && !var2 && !var3 && this.eY() && !this.bA() && var5 && !this.dW() && !this.a((aps)apw.o)) {
         if (this.bJ <= 0 && !this.g.k.al.d()) {
            this.bJ = 7;
         } else {
            this.g(true);
         }
      }

      if (!this.bA() && (!this.aE() || this.aI()) && this.eY() && var5 && !this.dW() && !this.a((aps)apw.o) && this.g.k.al.d()) {
         this.g(true);
      }

      boolean var6;
      if (this.bA()) {
         var6 = !this.f.b() || !var5;
         boolean var7 = var6 || this.u || this.aE() && !this.aI();
         if (this.bB()) {
            if (!this.t && !this.f.h && var6 || !this.aE()) {
               this.g(false);
            }
         } else if (var7) {
            this.g(false);
         }
      }

      var6 = false;
      if (this.bC.c) {
         if (this.g.q.j()) {
            if (!this.bC.b) {
               this.bC.b = true;
               var6 = true;
               this.t();
            }
         } else if (!var1 && this.f.g && !var4) {
            if (this.br == 0) {
               this.br = 7;
            } else if (!this.bB()) {
               this.bC.b = !this.bC.b;
               var6 = true;
               this.t();
               this.br = 0;
            }
         }
      }

      if (this.f.g && !var6 && !var1 && !this.bC.b && !this.br() && !this.c_()) {
         bmb var8 = this.b(aqf.e);
         if (var8.b() == bmd.qo && bld.d(var8) && this.eD()) {
            this.e.a((oj)(new ta(this, ta.a.i)));
         }
      }

      this.co = this.ef();
      if (this.aE() && this.f.h && this.cT()) {
         this.dL();
      }

      int var9;
      if (this.a((ael)aef.b)) {
         var9 = this.a_() ? 10 : 1;
         this.cp = afm.a(this.cp + var9, 0, 600);
      } else if (this.cp > 0) {
         this.a((ael)aef.b);
         this.cp = afm.a(this.cp - 10, 0, 600);
      }

      if (this.bC.b && this.K()) {
         var9 = 0;
         if (this.f.h) {
            --var9;
         }

         if (this.f.g) {
            ++var9;
         }

         if (var9 != 0) {
            this.f(this.cC().b(0.0D, (double)((float)var9 * this.bC.a() * 3.0F), 0.0D));
         }
      }

      if (this.H()) {
         aqw var10 = (aqw)this.ct();
         if (this.ch < 0) {
            ++this.ch;
            if (this.ch == 0) {
               this.ci = 0.0F;
            }
         }

         if (var1 && !this.f.g) {
            this.ch = -10;
            var10.b_(afm.d(this.I() * 100.0F));
            this.z();
         } else if (!var1 && this.f.g) {
            this.ch = 0;
            this.ci = 0.0F;
         } else if (var1) {
            ++this.ch;
            if (this.ch < 10) {
               this.ci = (float)this.ch * 0.1F;
            } else {
               this.ci = 0.8F + 2.0F / (float)(this.ch - 9) * 0.1F;
            }
         }
      } else {
         this.ci = 0.0F;
      }

      super.k();
      if (this.t && this.bC.b && !this.g.q.j()) {
         this.bC.b = false;
         this.t();
      }

   }

   private void Q() {
      this.bQ = this.bP;
      if (this.aa) {
         if (this.g.y != null && !this.g.y.ay_()) {
            if (this.g.y instanceof dpp) {
               this.m();
            }

            this.g.a((dot)null);
         }

         if (this.bP == 0.0F) {
            this.g.W().a((emt)emp.b(adq.lP, this.J.nextFloat() * 0.4F + 0.8F, 0.25F));
         }

         this.bP += 0.0125F;
         if (this.bP >= 1.0F) {
            this.bP = 1.0F;
         }

         this.aa = false;
      } else if (this.a((aps)apw.i) && this.b(apw.i).b() > 60) {
         this.bP += 0.006666667F;
         if (this.bP > 1.0F) {
            this.bP = 1.0F;
         }
      } else {
         if (this.bP > 0.0F) {
            this.bP -= 0.05F;
         }

         if (this.bP < 0.0F) {
            this.bP = 0.0F;
         }
      }

      this.E();
   }

   public void ba() {
      super.ba();
      this.cl = false;
      if (this.ct() instanceof bhn) {
         bhn var1 = (bhn)this.ct();
         var1.a(this.f.e, this.f.f, this.f.c, this.f.d);
         this.cl |= this.f.e || this.f.f || this.f.c || this.f.d;
      }

   }

   public boolean L() {
      return this.cl;
   }

   @Nullable
   public apu c(@Nullable aps var1) {
      if (var1 == apw.i) {
         this.bQ = 0.0F;
         this.bP = 0.0F;
      }

      return super.c(var1);
   }

   public void a(aqr var1, dcn var2) {
      double var3 = this.cD();
      double var5 = this.cH();
      super.a(var1, var2);
      this.g((float)(this.cD() - var3), (float)(this.cH() - var5));
   }

   public boolean M() {
      return this.cm;
   }

   protected void g(float var1, float var2) {
      if (this.eW()) {
         dcn var3 = this.cA();
         dcn var4 = var3.b((double)var1, 0.0D, (double)var2);
         dcn var5 = new dcn((double)var1, 0.0D, (double)var2);
         float var6 = this.dN();
         float var7 = (float)var5.g();
         float var11;
         if (var7 <= 0.001F) {
            dcm var8 = this.f.a();
            float var9 = var6 * var8.i;
            float var10 = var6 * var8.j;
            var11 = afm.a(this.p * 0.017453292F);
            float var12 = afm.b(this.p * 0.017453292F);
            var5 = new dcn((double)(var9 * var12 - var10 * var11), var5.c, (double)(var10 * var12 + var9 * var11));
            var7 = (float)var5.g();
            if (var7 <= 0.001F) {
               return;
            }
         }

         float var40 = afm.i(var7);
         dcn var41 = var5.a((double)var40);
         dcn var42 = this.bj();
         var11 = (float)(var42.b * var41.b + var42.d * var41.d);
         if (!(var11 < -0.15F)) {
            dcs var43 = dcs.a((aqa)this);
            fx var13 = new fx(this.cD(), this.cc().e, this.cH());
            ceh var14 = this.l.d_(var13);
            if (var14.b(this.l, var13, var43).b()) {
               var13 = var13.b();
               ceh var15 = this.l.d_(var13);
               if (var15.b(this.l, var13, var43).b()) {
                  float var16 = 7.0F;
                  float var17 = 1.2F;
                  if (this.a((aps)apw.h)) {
                     var17 += (float)(this.b(apw.h).c() + 1) * 0.75F;
                  }

                  float var18 = Math.max(var6 * 7.0F, 1.0F / var40);
                  dcn var20 = var4.e(var41.a((double)var18));
                  float var21 = this.cy();
                  float var22 = this.cz();
                  dci var23 = (new dci(var3, var20.b(0.0D, (double)var22, 0.0D))).c((double)var21, 0.0D, (double)var21);
                  dcn var19 = var3.b(0.0D, 0.5099999904632568D, 0.0D);
                  var20 = var20.b(0.0D, 0.5099999904632568D, 0.0D);
                  dcn var24 = var41.c(new dcn(0.0D, 1.0D, 0.0D));
                  dcn var25 = var24.a((double)(var21 * 0.5F));
                  dcn var26 = var19.d(var25);
                  dcn var27 = var20.d(var25);
                  dcn var28 = var19.e(var25);
                  dcn var29 = var20.e(var25);
                  Iterator<dci> var30 = this.l.d(this, var23, (var0) -> {
                     return true;
                  }).flatMap((var0) -> {
                     return var0.d().stream();
                  }).iterator();
                  float var32 = Float.MIN_VALUE;

                  label73:
                  while(var30.hasNext()) {
                     dci var34 = (dci)var30.next();
                     if (var34.a(var26, var27) || var34.a(var28, var29)) {
                        var32 = (float)var34.e;
                        dcn var31 = var34.f();
                        fx var35 = new fx(var31);
                        int var36 = 1;

                        while(true) {
                           if (!((float)var36 < var17)) {
                              break label73;
                           }

                           fx var37 = var35.b(var36);
                           ceh var38 = this.l.d_(var37);
                           ddh var33;
                           if (!(var33 = var38.b(this.l, var37, var43)).b()) {
                              var32 = (float)var33.c(gc.a.b) + (float)var37.v();
                              if ((double)var32 - this.cE() > (double)var17) {
                                 return;
                              }
                           }

                           if (var36 > 1) {
                              var13 = var13.b();
                              ceh var39 = this.l.d_(var13);
                              if (!var39.b(this.l, var13, var43).b()) {
                                 return;
                              }
                           }

                           ++var36;
                        }
                     }
                  }

                  if (var32 != Float.MIN_VALUE) {
                     float var44 = (float)((double)var32 - this.cE());
                     if (!(var44 <= 0.5F) && !(var44 > var17)) {
                        this.cn = 1;
                     }
                  }
               }
            }
         }
      }
   }

   private boolean eW() {
      return this.M() && this.cn <= 0 && this.t && !this.es() && !this.br() && this.eX() && (double)this.aq() >= 1.0D;
   }

   private boolean eX() {
      dcm var1 = this.f.a();
      return var1.i != 0.0F || var1.j != 0.0F;
   }

   private boolean eY() {
      double var1 = 0.8D;
      return this.aI() ? this.f.b() : (double)this.f.b >= 0.8D;
   }

   public float N() {
      if (!this.a((ael)aef.b)) {
         return 0.0F;
      } else {
         float var1 = 600.0F;
         float var2 = 100.0F;
         if ((float)this.cp >= 600.0F) {
            return 1.0F;
         } else {
            float var3 = afm.a((float)this.cp / 100.0F, 0.0F, 1.0F);
            float var4 = (float)this.cp < 100.0F ? 0.0F : afm.a(((float)this.cp - 100.0F) / 500.0F, 0.0F, 1.0F);
            return var3 * 0.6F + var4 * 0.39999998F;
         }
      }
   }

   public boolean aI() {
      return this.bB;
   }

   protected boolean et() {
      boolean var1 = this.bB;
      boolean var2 = super.et();
      if (this.a_()) {
         return this.bB;
      } else {
         if (!var1 && var2) {
            this.l.a(this.cD(), this.cE(), this.cH(), adq.q, adr.i, 1.0F, 1.0F, false);
            this.g.W().a((emt)(new emw.b(this)));
         }

         if (var1 && !var2) {
            this.l.a(this.cD(), this.cE(), this.cH(), adq.r, adr.i, 1.0F, 1.0F, false);
         }

         return this.bB;
      }
   }

   public dcn o(float var1) {
      if (this.g.k.g().a()) {
         float var2 = afm.g(var1 * 0.5F, this.p, this.r) * 0.017453292F;
         float var3 = afm.g(var1 * 0.5F, this.q, this.s) * 0.017453292F;
         double var4 = this.dV() == aqi.b ? -1.0D : 1.0D;
         dcn var6 = new dcn(0.39D * var4, -0.6D, 0.3D);
         return var6.a(-var3).b(-var2).e(this.j(var1));
      } else {
         return super.o(var1);
      }
   }
}
