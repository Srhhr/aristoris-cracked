import com.google.common.collect.Lists;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class bme extends blx {
   private static final Logger a = LogManager.getLogger();

   public bme(blx.a var1) {
      super(var1);
   }

   public aov<bmb> a(brx var1, bfw var2, aot var3) {
      bmb var4 = var2.b((aot)var3);
      md var5 = var4.o();
      if (!var2.bC.d) {
         var2.a((aot)var3, (bmb)bmb.b);
      }

      if (var5 != null && var5.c("Recipes", 9)) {
         if (!var1.v) {
            mj var6 = var5.d("Recipes", 8);
            List<boq<?>> var7 = Lists.newArrayList();
            bor var8 = var1.l().aF();

            for(int var9 = 0; var9 < var6.size(); ++var9) {
               String var10 = var6.j(var9);
               Optional<? extends boq<?>> var11 = var8.a(new vk(var10));
               if (!var11.isPresent()) {
                  a.error("Invalid recipe: {}", var10);
                  return aov.d(var4);
               }

               var7.add(var11.get());
            }

            var2.a((Collection)var7);
            var2.b(aea.c.b(this));
         }

         return aov.a(var4, var1.s_());
      } else {
         a.error("Tag not valid: {}", var5);
         return aov.d(var4);
      }
   }
}
