public enum bzh {
   a,
   b,
   c;
}
