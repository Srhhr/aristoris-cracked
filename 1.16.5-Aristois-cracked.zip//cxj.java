import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.Object2BooleanMap;
import it.unimi.dsi.fastutil.objects.Object2BooleanOpenHashMap;
import java.util.EnumSet;
import java.util.Iterator;
import javax.annotation.Nullable;

public class cxj extends cxc {
   protected float j;
   private final Long2ObjectMap<cwz> k = new Long2ObjectOpenHashMap();
   private final Object2BooleanMap<dci> l = new Object2BooleanOpenHashMap();

   public void a(bsi var1, aqn var2) {
      super.a(var1, var2);
      this.j = var2.a(cwz.h);
   }

   public void a() {
      this.b.a(cwz.h, this.j);
      this.k.clear();
      this.l.clear();
      super.a();
   }

   public cxb b() {
      fx.a var2 = new fx.a();
      int var1 = afm.c(this.b.cE());
      ceh var3 = this.a.d_(var2.c(this.b.cD(), (double)var1, this.b.cH()));
      fx var4;
      if (!this.b.a((cuw)var3.m().a())) {
         if (this.e() && this.b.aE()) {
            while(true) {
               if (var3.b() != bup.A && var3.m() != cuy.c.a(false)) {
                  --var1;
                  break;
               }

               ++var1;
               var3 = this.a.d_(var2.c(this.b.cD(), (double)var1, this.b.cH()));
            }
         } else if (this.b.ao()) {
            var1 = afm.c(this.b.cE() + 0.5D);
         } else {
            for(var4 = this.b.cB(); (this.a.d_(var4).g() || this.a.d_(var4).a(this.a, var4, cxe.a)) && var4.v() > 0; var4 = var4.c()) {
            }

            var1 = var4.b().v();
         }
      } else {
         while(true) {
            if (!this.b.a((cuw)var3.m().a())) {
               --var1;
               break;
            }

            ++var1;
            var3 = this.a.d_(var2.c(this.b.cD(), (double)var1, this.b.cH()));
         }
      }

      var4 = this.b.cB();
      cwz var5 = this.a(this.b, var4.u(), var1, var4.w());
      if (this.b.a(var5) < 0.0F) {
         dci var6 = this.b.cc();
         if (this.b(var2.c(var6.a, (double)var1, var6.c)) || this.b(var2.c(var6.a, (double)var1, var6.f)) || this.b(var2.c(var6.d, (double)var1, var6.c)) || this.b(var2.c(var6.d, (double)var1, var6.f))) {
            cxb var7 = this.a((fx)var2);
            var7.l = this.a(this.b, var7.a());
            var7.k = this.b.a(var7.l);
            return var7;
         }
      }

      cxb var8 = this.a(var4.u(), var1, var4.w());
      var8.l = this.a(this.b, var8.a());
      var8.k = this.b.a(var8.l);
      return var8;
   }

   private boolean b(fx var1) {
      cwz var2 = this.a(this.b, var1);
      return this.b.a(var2) >= 0.0F;
   }

   public cxh a(double var1, double var3, double var5) {
      return new cxh(this.a(afm.c(var1), afm.c(var3), afm.c(var5)));
   }

   public int a(cxb[] var1, cxb var2) {
      int var3 = 0;
      int var4 = 0;
      cwz var5 = this.a(this.b, var2.a, var2.b + 1, var2.c);
      cwz var6 = this.a(this.b, var2.a, var2.b, var2.c);
      if (this.b.a(var5) >= 0.0F && var6 != cwz.w) {
         var4 = afm.d(Math.max(1.0F, this.b.G));
      }

      double var7 = a((brc)this.a, (fx)(new fx(var2.a, var2.b, var2.c)));
      cxb var9 = this.a(var2.a, var2.b, var2.c + 1, var4, var7, gc.d, var6);
      if (this.a(var9, var2)) {
         var1[var3++] = var9;
      }

      cxb var10 = this.a(var2.a - 1, var2.b, var2.c, var4, var7, gc.e, var6);
      if (this.a(var10, var2)) {
         var1[var3++] = var10;
      }

      cxb var11 = this.a(var2.a + 1, var2.b, var2.c, var4, var7, gc.f, var6);
      if (this.a(var11, var2)) {
         var1[var3++] = var11;
      }

      cxb var12 = this.a(var2.a, var2.b, var2.c - 1, var4, var7, gc.c, var6);
      if (this.a(var12, var2)) {
         var1[var3++] = var12;
      }

      cxb var13 = this.a(var2.a - 1, var2.b, var2.c - 1, var4, var7, gc.c, var6);
      if (this.a(var2, var10, var12, var13)) {
         var1[var3++] = var13;
      }

      cxb var14 = this.a(var2.a + 1, var2.b, var2.c - 1, var4, var7, gc.c, var6);
      if (this.a(var2, var11, var12, var14)) {
         var1[var3++] = var14;
      }

      cxb var15 = this.a(var2.a - 1, var2.b, var2.c + 1, var4, var7, gc.d, var6);
      if (this.a(var2, var10, var9, var15)) {
         var1[var3++] = var15;
      }

      cxb var16 = this.a(var2.a + 1, var2.b, var2.c + 1, var4, var7, gc.d, var6);
      if (this.a(var2, var11, var9, var16)) {
         var1[var3++] = var16;
      }

      return var3;
   }

   private boolean a(cxb var1, cxb var2) {
      return var1 != null && !var1.i && (var1.k >= 0.0F || var2.k < 0.0F);
   }

   private boolean a(cxb var1, @Nullable cxb var2, @Nullable cxb var3, @Nullable cxb var4) {
      if (var4 != null && var3 != null && var2 != null) {
         if (var4.i) {
            return false;
         } else if (var3.b <= var1.b && var2.b <= var1.b) {
            if (var2.l != cwz.d && var3.l != cwz.d && var4.l != cwz.d) {
               boolean var5 = var3.l == cwz.f && var2.l == cwz.f && (double)this.b.cy() < 0.5D;
               return var4.k >= 0.0F && (var3.b < var1.b || var3.k >= 0.0F || var5) && (var2.b < var1.b || var2.k >= 0.0F || var5);
            } else {
               return false;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private boolean a(cxb var1) {
      dcn var2 = new dcn((double)var1.a - this.b.cD(), (double)var1.b - this.b.cE(), (double)var1.c - this.b.cH());
      dci var3 = this.b.cc();
      int var4 = afm.f(var2.f() / var3.a());
      var2 = var2.a((double)(1.0F / (float)var4));

      for(int var5 = 1; var5 <= var4; ++var5) {
         var3 = var3.c(var2);
         if (this.a(var3)) {
            return false;
         }
      }

      return true;
   }

   public static double a(brc var0, fx var1) {
      fx var2 = var1.c();
      ddh var3 = var0.d_(var2).k(var0, var2);
      return (double)var2.v() + (var3.b() ? 0.0D : var3.c(gc.a.b));
   }

   @Nullable
   private cxb a(int var1, int var2, int var3, int var4, double var5, gc var7, cwz var8) {
      cxb var9 = null;
      fx.a var10 = new fx.a();
      double var11 = a((brc)this.a, (fx)var10.d(var1, var2, var3));
      if (var11 - var5 > 1.125D) {
         return null;
      } else {
         cwz var13 = this.a(this.b, var1, var2, var3);
         float var14 = this.b.a(var13);
         double var15 = (double)this.b.cy() / 2.0D;
         if (var14 >= 0.0F) {
            var9 = this.a(var1, var2, var3);
            var9.l = var13;
            var9.k = Math.max(var9.k, var14);
         }

         if (var8 == cwz.f && var9 != null && var9.k >= 0.0F && !this.a(var9)) {
            var9 = null;
         }

         if (var13 == cwz.c) {
            return var9;
         } else {
            if ((var9 == null || var9.k < 0.0F) && var4 > 0 && var13 != cwz.f && var13 != cwz.k && var13 != cwz.e) {
               var9 = this.a(var1, var2 + 1, var3, var4 - 1, var5, var7, var8);
               if (var9 != null && (var9.l == cwz.b || var9.l == cwz.c) && this.b.cy() < 1.0F) {
                  double var17 = (double)(var1 - var7.i()) + 0.5D;
                  double var19 = (double)(var3 - var7.k()) + 0.5D;
                  dci var21 = new dci(var17 - var15, a((brc)this.a, (fx)var10.c(var17, (double)(var2 + 1), var19)) + 0.001D, var19 - var15, var17 + var15, (double)this.b.cz() + a((brc)this.a, (fx)var10.c((double)var9.a, (double)var9.b, (double)var9.c)) - 0.002D, var19 + var15);
                  if (this.a(var21)) {
                     var9 = null;
                  }
               }
            }

            if (var13 == cwz.h && !this.e()) {
               if (this.a(this.b, var1, var2 - 1, var3) != cwz.h) {
                  return var9;
               }

               while(var2 > 0) {
                  --var2;
                  var13 = this.a(this.b, var1, var2, var3);
                  if (var13 != cwz.h) {
                     return var9;
                  }

                  var9 = this.a(var1, var2, var3);
                  var9.l = var13;
                  var9.k = Math.max(var9.k, this.b.a(var13));
               }
            }

            if (var13 == cwz.b) {
               int var22 = 0;
               int var18 = var2;

               while(var13 == cwz.b) {
                  --var2;
                  cxb var23;
                  if (var2 < 0) {
                     var23 = this.a(var1, var18, var3);
                     var23.l = cwz.a;
                     var23.k = -1.0F;
                     return var23;
                  }

                  if (var22++ >= this.b.bP()) {
                     var23 = this.a(var1, var2, var3);
                     var23.l = cwz.a;
                     var23.k = -1.0F;
                     return var23;
                  }

                  var13 = this.a(this.b, var1, var2, var3);
                  var14 = this.b.a(var13);
                  if (var13 != cwz.b && var14 >= 0.0F) {
                     var9 = this.a(var1, var2, var3);
                     var9.l = var13;
                     var9.k = Math.max(var9.k, var14);
                     break;
                  }

                  if (var14 < 0.0F) {
                     var23 = this.a(var1, var2, var3);
                     var23.l = cwz.a;
                     var23.k = -1.0F;
                     return var23;
                  }
               }
            }

            if (var13 == cwz.f) {
               var9 = this.a(var1, var2, var3);
               var9.i = true;
               var9.l = var13;
               var9.k = var13.a();
            }

            return var9;
         }
      }
   }

   private boolean a(dci var1) {
      return (Boolean)this.l.computeIfAbsent(var1, (var2) -> {
         return !this.a.a_(this.b, var1);
      });
   }

   public cwz a(brc var1, int var2, int var3, int var4, aqn var5, int var6, int var7, int var8, boolean var9, boolean var10) {
      EnumSet<cwz> var11 = EnumSet.noneOf(cwz.class);
      cwz var12 = cwz.a;
      fx var13 = var5.cB();
      var12 = this.a(var1, var2, var3, var4, var6, var7, var8, var9, var10, var11, var12, var13);
      if (var11.contains(cwz.f)) {
         return cwz.f;
      } else if (var11.contains(cwz.k)) {
         return cwz.k;
      } else {
         cwz var14 = cwz.a;
         Iterator var15 = var11.iterator();

         while(var15.hasNext()) {
            cwz var16 = (cwz)var15.next();
            if (var5.a(var16) < 0.0F) {
               return var16;
            }

            if (var5.a(var16) >= var5.a(var14)) {
               var14 = var16;
            }
         }

         if (var12 == cwz.b && var5.a(var14) == 0.0F && var6 <= 1) {
            return cwz.b;
         } else {
            return var14;
         }
      }
   }

   public cwz a(brc var1, int var2, int var3, int var4, int var5, int var6, int var7, boolean var8, boolean var9, EnumSet<cwz> var10, cwz var11, fx var12) {
      for(int var13 = 0; var13 < var5; ++var13) {
         for(int var14 = 0; var14 < var6; ++var14) {
            for(int var15 = 0; var15 < var7; ++var15) {
               int var16 = var13 + var2;
               int var17 = var14 + var3;
               int var18 = var15 + var4;
               cwz var19 = this.a(var1, var16, var17, var18);
               var19 = this.a(var1, var8, var9, var12, var19);
               if (var13 == 0 && var14 == 0 && var15 == 0) {
                  var11 = var19;
               }

               var10.add(var19);
            }
         }
      }

      return var11;
   }

   protected cwz a(brc var1, boolean var2, boolean var3, fx var4, cwz var5) {
      if (var5 == cwz.s && var2 && var3) {
         var5 = cwz.d;
      }

      if (var5 == cwz.r && !var3) {
         var5 = cwz.a;
      }

      if (var5 == cwz.j && !(var1.d_(var4).b() instanceof bug) && !(var1.d_(var4.c()).b() instanceof bug)) {
         var5 = cwz.k;
      }

      if (var5 == cwz.v) {
         var5 = cwz.a;
      }

      return var5;
   }

   private cwz a(aqn var1, fx var2) {
      return this.a(var1, var2.u(), var2.v(), var2.w());
   }

   private cwz a(aqn var1, int var2, int var3, int var4) {
      return (cwz)this.k.computeIfAbsent(fx.a(var2, var3, var4), (var5) -> {
         return this.a(this.a, var2, var3, var4, var1, this.d, this.e, this.f, this.d(), this.c());
      });
   }

   public cwz a(brc var1, int var2, int var3, int var4) {
      return a(var1, new fx.a(var2, var3, var4));
   }

   public static cwz a(brc var0, fx.a var1) {
      int var2 = var1.u();
      int var3 = var1.v();
      int var4 = var1.w();
      cwz var5 = b(var0, var1);
      if (var5 == cwz.b && var3 >= 1) {
         cwz var6 = b(var0, var1.d(var2, var3 - 1, var4));
         var5 = var6 != cwz.c && var6 != cwz.b && var6 != cwz.h && var6 != cwz.g ? cwz.c : cwz.b;
         if (var6 == cwz.m) {
            var5 = cwz.m;
         }

         if (var6 == cwz.o) {
            var5 = cwz.o;
         }

         if (var6 == cwz.q) {
            var5 = cwz.q;
         }

         if (var6 == cwz.w) {
            var5 = cwz.w;
         }
      }

      if (var5 == cwz.c) {
         var5 = a(var0, var1.d(var2, var3, var4), var5);
      }

      return var5;
   }

   public static cwz a(brc var0, fx.a var1, cwz var2) {
      int var3 = var1.u();
      int var4 = var1.v();
      int var5 = var1.w();

      for(int var6 = -1; var6 <= 1; ++var6) {
         for(int var7 = -1; var7 <= 1; ++var7) {
            for(int var8 = -1; var8 <= 1; ++var8) {
               if (var6 != 0 || var8 != 0) {
                  var1.d(var3 + var6, var4 + var7, var5 + var8);
                  ceh var9 = var0.d_(var1);
                  if (var9.a(bup.cF)) {
                     return cwz.n;
                  }

                  if (var9.a(bup.mg)) {
                     return cwz.p;
                  }

                  if (a(var9)) {
                     return cwz.l;
                  }

                  if (var0.b((fx)var1).a(aef.b)) {
                     return cwz.i;
                  }
               }
            }
         }
      }

      return var2;
   }

   protected static cwz b(brc var0, fx var1) {
      ceh var2 = var0.d_(var1);
      buo var3 = var2.b();
      cva var4 = var2.c();
      if (var2.g()) {
         return cwz.b;
      } else if (!var2.a(aed.J) && !var2.a(bup.dU)) {
         if (var2.a(bup.cF)) {
            return cwz.o;
         } else if (var2.a(bup.mg)) {
            return cwz.q;
         } else if (var2.a(bup.ne)) {
            return cwz.w;
         } else if (var2.a(bup.eh)) {
            return cwz.x;
         } else {
            cux var5 = var0.b(var1);
            if (var5.a(aef.b)) {
               return cwz.h;
            } else if (var5.a(aef.c)) {
               return cwz.g;
            } else if (a(var2)) {
               return cwz.m;
            } else if (bwb.l(var2) && !(Boolean)var2.c(bwb.b)) {
               return cwz.s;
            } else if (var3 instanceof bwb && var4 == cva.J && !(Boolean)var2.c(bwb.b)) {
               return cwz.t;
            } else if (var3 instanceof bwb && (Boolean)var2.c(bwb.b)) {
               return cwz.r;
            } else if (var3 instanceof bug) {
               return cwz.j;
            } else if (var3 instanceof bxx) {
               return cwz.v;
            } else if (!var3.a((ael)aed.M) && !var3.a((ael)aed.F) && (!(var3 instanceof bwr) || (Boolean)var2.c(bwr.a))) {
               return !var2.a(var0, var1, cxe.a) ? cwz.a : cwz.b;
            } else {
               return cwz.f;
            }
         }
      } else {
         return cwz.e;
      }
   }

   private static boolean a(ceh var0) {
      return var0.a(aed.an) || var0.a(bup.B) || var0.a(bup.iJ) || buy.g(var0);
   }
}
