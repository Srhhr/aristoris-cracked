public interface byc {
   boolean a(brc var1, fx var2, ceh var3, cuw var4);

   boolean a(bry var1, fx var2, ceh var3, cux var4);
}
