import com.google.common.base.Splitter;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import it.unimi.dsi.fastutil.objects.Object2LongMap;
import it.unimi.dsi.fastutil.objects.Object2LongMaps;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ans implements anv {
   private static final Logger a = LogManager.getLogger();
   private static final anx b = new anx() {
      public long a() {
         return 0L;
      }

      public long b() {
         return 0L;
      }

      public Object2LongMap<String> c() {
         return Object2LongMaps.emptyMap();
      }
   };
   private static final Splitter c = Splitter.on('\u001e');
   private static final Comparator<Entry<String, ans.a>> d = Entry.comparingByValue(Comparator.comparingLong((var0) -> {
      return var0.b;
   })).reversed();
   private final Map<String, ? extends anx> e;
   private final long f;
   private final int g;
   private final long h;
   private final int i;
   private final int j;

   public ans(Map<String, ? extends anx> var1, long var2, int var4, long var5, int var7) {
      this.e = var1;
      this.f = var2;
      this.g = var4;
      this.h = var5;
      this.i = var7;
      this.j = var7 - var4;
   }

   private anx c(String var1) {
      anx var2 = (anx)this.e.get(var1);
      return var2 != null ? var2 : b;
   }

   public List<any> a(String var1) {
      anx var3 = this.c("root");
      long var4 = var3.a();
      anx var6 = this.c(var1);
      long var7 = var6.a();
      long var9 = var6.b();
      List<any> var11 = Lists.newArrayList();
      if (!var1.isEmpty()) {
         var1 = var1 + '\u001e';
      }

      long var12 = 0L;
      Iterator var14 = this.e.keySet().iterator();

      while(var14.hasNext()) {
         String var15 = (String)var14.next();
         if (a(var1, var15)) {
            var12 += this.c(var15).a();
         }
      }

      float var25 = (float)var12;
      if (var12 < var7) {
         var12 = var7;
      }

      if (var4 < var12) {
         var4 = var12;
      }

      Iterator var26 = this.e.keySet().iterator();

      while(var26.hasNext()) {
         String var16 = (String)var26.next();
         if (a(var1, var16)) {
            anx var17 = this.c(var16);
            long var18 = var17.a();
            double var20 = (double)var18 * 100.0D / (double)var12;
            double var22 = (double)var18 * 100.0D / (double)var4;
            String var24 = var16.substring(var1.length());
            var11.add(new any(var24, var20, var22, var17.b()));
         }
      }

      if ((float)var12 > var25) {
         var11.add(new any("unspecified", (double)((float)var12 - var25) * 100.0D / (double)var12, (double)((float)var12 - var25) * 100.0D / (double)var4, var9));
      }

      Collections.sort(var11);
      var11.add(0, new any(var1, 100.0D, (double)var12 * 100.0D / (double)var4, var9));
      return var11;
   }

   private static boolean a(String var0, String var1) {
      return var1.length() > var0.length() && var1.startsWith(var0) && var1.indexOf(30, var0.length() + 1) < 0;
   }

   private Map<String, ans.a> h() {
      Map<String, ans.a> var1 = Maps.newTreeMap();
      this.e.forEach((var1x, var2) -> {
         Object2LongMap<String> var3 = var2.c();
         if (!var3.isEmpty()) {
            List<String> var4 = c.splitToList(var1x);
            var3.forEach((var2x, var3x) -> {
               ((ans.a)var1.computeIfAbsent(var2x, (var0) -> {
                  return new ans.a();
               })).a(var4.iterator(), var3x);
            });
         }

      });
      return var1;
   }

   public long a() {
      return this.f;
   }

   public int b() {
      return this.g;
   }

   public long c() {
      return this.h;
   }

   public int d() {
      return this.i;
   }

   public boolean a(File var1) {
      var1.getParentFile().mkdirs();
      OutputStreamWriter var2 = null;

      boolean var4;
      try {
         var2 = new OutputStreamWriter(new FileOutputStream(var1), StandardCharsets.UTF_8);
         var2.write(this.a(this.g(), this.f()));
         boolean var3 = true;
         return var3;
      } catch (Throwable var8) {
         a.error("Could not save profiler results to {}", var1, var8);
         var4 = false;
      } finally {
         IOUtils.closeQuietly(var2);
      }

      return var4;
   }

   protected String a(long var1, int var3) {
      StringBuilder var4 = new StringBuilder();
      var4.append("---- Minecraft Profiler Results ----\n");
      var4.append("// ");
      var4.append(i());
      var4.append("\n\n");
      var4.append("Version: ").append(w.a().getId()).append('\n');
      var4.append("Time span: ").append(var1 / 1000000L).append(" ms\n");
      var4.append("Tick span: ").append(var3).append(" ticks\n");
      var4.append("// This is approximately ").append(String.format(Locale.ROOT, "%.2f", (float)var3 / ((float)var1 / 1.0E9F))).append(" ticks per second. It should be ").append(20).append(" ticks per second\n\n");
      var4.append("--- BEGIN PROFILE DUMP ---\n\n");
      this.a(0, "root", var4);
      var4.append("--- END PROFILE DUMP ---\n\n");
      Map<String, ans.a> var5 = this.h();
      if (!var5.isEmpty()) {
         var4.append("--- BEGIN COUNTER DUMP ---\n\n");
         this.a(var5, var4, var3);
         var4.append("--- END COUNTER DUMP ---\n\n");
      }

      return var4.toString();
   }

   private static StringBuilder a(StringBuilder var0, int var1) {
      var0.append(String.format("[%02d] ", var1));

      for(int var2 = 0; var2 < var1; ++var2) {
         var0.append("|   ");
      }

      return var0;
   }

   private void a(int var1, String var2, StringBuilder var3) {
      List<any> var4 = this.a(var2);
      Object2LongMap<String> var5 = ((anx)ObjectUtils.firstNonNull(new anx[]{(anx)this.e.get(var2), b})).c();
      var5.forEach((var3x, var4x) -> {
         a(var3, var1).append('#').append(var3x).append(' ').append(var4x).append('/').append(var4x / (long)this.j).append('\n');
      });
      if (var4.size() >= 3) {
         for(int var6 = 1; var6 < var4.size(); ++var6) {
            any var7 = (any)var4.get(var6);
            a(var3, var1).append(var7.d).append('(').append(var7.c).append('/').append(String.format(Locale.ROOT, "%.0f", (float)var7.c / (float)this.j)).append(')').append(" - ").append(String.format(Locale.ROOT, "%.2f", var7.a)).append("%/").append(String.format(Locale.ROOT, "%.2f", var7.b)).append("%\n");
            if (!"unspecified".equals(var7.d)) {
               try {
                  this.a(var1 + 1, var2 + '\u001e' + var7.d, var3);
               } catch (Exception var9) {
                  var3.append("[[ EXCEPTION ").append(var9).append(" ]]");
               }
            }
         }

      }
   }

   private void a(int var1, String var2, ans.a var3, int var4, StringBuilder var5) {
      a(var5, var1).append(var2).append(" total:").append(var3.a).append('/').append(var3.b).append(" average: ").append(var3.a / (long)var4).append('/').append(var3.b / (long)var4).append('\n');
      var3.c.entrySet().stream().sorted(d).forEach((var4x) -> {
         this.a(var1 + 1, (String)var4x.getKey(), (ans.a)var4x.getValue(), var4, var5);
      });
   }

   private void a(Map<String, ans.a> var1, StringBuilder var2, int var3) {
      var1.forEach((var3x, var4) -> {
         var2.append("-- Counter: ").append(var3x).append(" --\n");
         this.a(0, "root", (ans.a)var4.c.get("root"), var3, var2);
         var2.append("\n\n");
      });
   }

   private static String i() {
      String[] var0 = new String[]{"Shiny numbers!", "Am I not running fast enough? :(", "I'm working as hard as I can!", "Will I ever be good enough for you? :(", "Speedy. Zoooooom!", "Hello world", "40% better than a crash report.", "Now with extra numbers", "Now with less numbers", "Now with the same numbers", "You should add flames to things, it makes them go faster!", "Do you feel the need for... optimization?", "*cracks redstone whip*", "Maybe if you treated it better then it'll have more motivation to work faster! Poor server."};

      try {
         return var0[(int)(x.c() % (long)var0.length)];
      } catch (Throwable var2) {
         return "Witty comment unavailable :(";
      }
   }

   public int f() {
      return this.j;
   }

   static class a {
      private long a;
      private long b;
      private final Map<String, ans.a> c;

      private a() {
         this.c = Maps.newHashMap();
      }

      public void a(Iterator<String> var1, long var2) {
         this.b += var2;
         if (!var1.hasNext()) {
            this.a += var2;
         } else {
            ((ans.a)this.c.computeIfAbsent(var1.next(), (var0) -> {
               return new ans.a();
            })).a(var1, var2);
         }

      }

      // $FF: synthetic method
      a(Object var1) {
         this();
      }
   }
}
