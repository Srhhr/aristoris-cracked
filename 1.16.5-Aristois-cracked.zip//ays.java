import com.google.common.collect.ImmutableSet;
import java.util.Set;

public class ays extends azb<aqm> {
   public Set<ayd<?>> a() {
      return ImmutableSet.of(ayd.x, ayd.y);
   }

   protected void a(aag var1, aqm var2) {
      arf<?> var3 = var2.cJ();
      apk var4 = var2.dm();
      if (var4 != null) {
         var3.a((ayd)ayd.x, (Object)var2.dm());
         aqa var5 = var4.k();
         if (var5 instanceof aqm) {
            var3.a((ayd)ayd.y, (Object)((aqm)var5));
         }
      } else {
         var3.b(ayd.x);
      }

      var3.c(ayd.y).ifPresent((var2x) -> {
         if (!var2x.aX() || var2x.l != var1) {
            var3.b(ayd.y);
         }

      });
   }
}
