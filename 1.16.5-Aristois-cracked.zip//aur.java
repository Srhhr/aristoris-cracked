import com.google.common.collect.ImmutableMap;
import java.util.Optional;

public class aur extends arv<bfj> {
   private long b;

   public aur() {
      super(ImmutableMap.of(ayd.c, aye.a, ayd.n, aye.c));
   }

   protected boolean b(aag var1, bfj var2) {
      if (var1.T() - this.b < 300L) {
         return false;
      } else if (var1.t.nextInt(2) != 0) {
         return false;
      } else {
         this.b = var1.T();
         gf var3 = (gf)var2.cJ().c(ayd.c).get();
         return var3.a() == var1.Y() && var3.b().a(var2.cA(), 1.73D);
      }
   }

   protected void a(aag var1, bfj var2, long var3) {
      arf<bfj> var5 = var2.cJ();
      var5.a((ayd)ayd.H, (Object)var3);
      var5.c(ayd.c).ifPresent((var1x) -> {
         var5.a((ayd)ayd.n, (Object)(new arx(var1x.b())));
      });
      var2.fd();
      this.a(var1, var2);
      if (var2.fc()) {
         var2.fb();
      }

   }

   protected void a(aag var1, bfj var2) {
   }

   protected boolean b(aag var1, bfj var2, long var3) {
      Optional<gf> var5 = var2.cJ().c(ayd.c);
      if (!var5.isPresent()) {
         return false;
      } else {
         gf var6 = (gf)var5.get();
         return var6.a() == var1.Y() && var6.b().a(var2.cA(), 1.73D);
      }
   }

   // $FF: synthetic method
   protected boolean a(aag var1, aqm var2) {
      return this.b(var1, (bfj)var2);
   }
}
