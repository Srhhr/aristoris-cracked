import java.io.File;
import java.util.Collections;
import java.util.List;

public class anr implements anv {
   public static final anr a = new anr();

   private anr() {
   }

   public List<any> a(String var1) {
      return Collections.emptyList();
   }

   public boolean a(File var1) {
      return false;
   }

   public long a() {
      return 0L;
   }

   public int b() {
      return 0;
   }

   public long c() {
      return 0L;
   }

   public int d() {
      return 0;
   }
}
