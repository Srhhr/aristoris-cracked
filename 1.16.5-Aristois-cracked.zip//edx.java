public class edx extends eeu<apz> {
   public edx(eet var1) {
      super(var1);
   }

   public vk a(apz var1) {
      return ekb.d;
   }
}
