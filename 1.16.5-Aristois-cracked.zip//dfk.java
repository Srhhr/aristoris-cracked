import com.google.common.collect.ImmutableList;

public class dfk {
   public static final dfs a;
   public static final dfs b;
   public static final dfs c;
   public static final dfs d;
   public static final dfs e;
   public static final dfs f;
   public static final dfs g;
   public static final dfr h;
   public static final dfr i;
   @Deprecated
   public static final dfr j;
   public static final dfr k;
   public static final dfr l;
   public static final dfr m;
   public static final dfr n;
   public static final dfr o;
   @Deprecated
   public static final dfr p;
   public static final dfr q;
   @Deprecated
   public static final dfr r;
   @Deprecated
   public static final dfr s;

   static {
      a = new dfs(0, dfs.a.a, dfs.b.a, 3);
      b = new dfs(0, dfs.a.b, dfs.b.c, 4);
      c = new dfs(0, dfs.a.a, dfs.b.d, 2);
      d = new dfs(1, dfs.a.e, dfs.b.d, 2);
      e = new dfs(2, dfs.a.e, dfs.b.d, 2);
      f = new dfs(0, dfs.a.c, dfs.b.b, 3);
      g = new dfs(0, dfs.a.c, dfs.b.e, 1);
      h = new dfr(ImmutableList.builder().add(a).add(b).add(c).add(e).add(f).add(g).build());
      i = new dfr(ImmutableList.builder().add(a).add(b).add(c).add(d).add(e).add(f).add(g).build());
      j = new dfr(ImmutableList.builder().add(a).add(c).add(b).add(e).build());
      k = new dfr(ImmutableList.builder().add(a).build());
      l = new dfr(ImmutableList.builder().add(a).add(b).build());
      m = new dfr(ImmutableList.builder().add(a).add(b).add(e).build());
      n = new dfr(ImmutableList.builder().add(a).add(c).build());
      o = new dfr(ImmutableList.builder().add(a).add(b).add(c).build());
      p = new dfr(ImmutableList.builder().add(a).add(c).add(b).build());
      q = new dfr(ImmutableList.builder().add(a).add(b).add(c).add(e).build());
      r = new dfr(ImmutableList.builder().add(a).add(c).add(e).add(b).build());
      s = new dfr(ImmutableList.builder().add(a).add(c).add(b).add(f).add(g).build());
   }
}
