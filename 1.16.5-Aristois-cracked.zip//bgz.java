public class bgz extends bgb {
   private static final us<Boolean> e;

   public bgz(aqe<? extends bgz> var1, brx var2) {
      super(var1, var2);
   }

   public bgz(brx var1, aqm var2, double var3, double var5, double var7) {
      super(aqe.aV, var2, var3, var5, var7, var1);
   }

   public bgz(brx var1, double var2, double var4, double var6, double var8, double var10, double var12) {
      super(aqe.aV, var2, var4, var6, var8, var10, var12, var1);
   }

   protected float i() {
      return this.k() ? 0.73F : super.i();
   }

   public boolean bq() {
      return false;
   }

   public float a(brp var1, brc var2, fx var3, ceh var4, cux var5, float var6) {
      return this.k() && bcl.c(var4) ? Math.min(0.8F, var6) : var6;
   }

   protected void a(dck var1) {
      super.a((dck)var1);
      if (!this.l.v) {
         aqa var2 = var1.a();
         aqa var3 = this.v();
         boolean var4;
         if (var3 instanceof aqm) {
            aqm var5 = (aqm)var3;
            var4 = var2.a(apk.a((bgz)this, (aqa)var5), 8.0F);
            if (var4) {
               if (var2.aX()) {
                  this.a(var5, var2);
               } else {
                  var5.b(5.0F);
               }
            }
         } else {
            var4 = var2.a(apk.o, 5.0F);
         }

         if (var4 && var2 instanceof aqm) {
            int var6 = 0;
            if (this.l.ad() == aor.c) {
               var6 = 10;
            } else if (this.l.ad() == aor.d) {
               var6 = 40;
            }

            if (var6 > 0) {
               ((aqm)var2).c(new apu(apw.t, 20 * var6, 1));
            }
         }

      }
   }

   protected void a(dcl var1) {
      super.a((dcl)var1);
      if (!this.l.v) {
         brp.a var2 = this.l.V().b(brt.b) ? brp.a.c : brp.a.a;
         this.l.a(this, this.cD(), this.cE(), this.cH(), 1.0F, false, var2);
         this.ad();
      }

   }

   public boolean aT() {
      return false;
   }

   public boolean a(apk var1, float var2) {
      return false;
   }

   protected void e() {
      this.R.a((us)e, (Object)false);
   }

   public boolean k() {
      return (Boolean)this.R.a(e);
   }

   public void a(boolean var1) {
      this.R.b(e, var1);
   }

   protected boolean W_() {
      return false;
   }

   static {
      e = uv.a(bgz.class, uu.i);
   }
}
