public class bdy extends bcz {
   public bdy(aqe<? extends bdy> var1, brx var2) {
      super(var1, var2);
   }

   protected adp I() {
      return adq.ns;
   }

   protected adp e(apk var1) {
      return adq.nC;
   }

   protected adp dq() {
      return adq.nt;
   }

   adp eK() {
      return adq.nE;
   }

   protected void a(apk var1, int var2, boolean var3) {
      super.a(var1, var2, var3);
      aqa var4 = var1.k();
      if (var4 instanceof bdc) {
         bdc var5 = (bdc)var4;
         if (var5.eN()) {
            var5.eO();
            this.a(bmd.pe);
         }
      }

   }
}
