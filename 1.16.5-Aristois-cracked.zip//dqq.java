public interface dqq<T extends bic> {
   T h();
}
