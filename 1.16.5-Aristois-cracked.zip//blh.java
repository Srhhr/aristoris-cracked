import java.util.List;

public class blh extends blx {
   public blh(blx.a var1) {
      super(var1);
   }

   public aou a(boa var1) {
      brx var2 = var1.p();
      fx var3 = var1.a();
      ceh var4 = var2.d_(var3);
      if (!var4.a(bup.bK) && !var4.a(bup.z)) {
         return aou.d;
      } else {
         fx var5 = var3.b();
         if (!var2.w(var5)) {
            return aou.d;
         } else {
            double var6 = (double)var5.u();
            double var8 = (double)var5.v();
            double var10 = (double)var5.w();
            List<aqa> var12 = var2.a((aqa)null, (dci)(new dci(var6, var8, var10, var6 + 1.0D, var8 + 2.0D, var10 + 1.0D)));
            if (!var12.isEmpty()) {
               return aou.d;
            } else {
               if (var2 instanceof aag) {
                  bbq var13 = new bbq(var2, var6 + 0.5D, var8, var10 + 0.5D);
                  var13.a(false);
                  var2.c((aqa)var13);
                  chg var14 = ((aag)var2).D();
                  if (var14 != null) {
                     var14.e();
                  }
               }

               var1.m().g(1);
               return aou.a(var2.v);
            }
         }
      }
   }

   public boolean e(bmb var1) {
      return true;
   }
}
