public class bxu extends bxg implements byc {
   protected bxu(ceg.c var1) {
      super(var1, gc.b, dde.b(), true);
   }

   protected bxh c() {
      return (bxh)bup.kc;
   }

   public cux d(ceh var1) {
      return cuy.c.a(false);
   }

   public boolean a(brc var1, fx var2, ceh var3, cuw var4) {
      return false;
   }

   public boolean a(bry var1, fx var2, ceh var3, cux var4) {
      return false;
   }
}
