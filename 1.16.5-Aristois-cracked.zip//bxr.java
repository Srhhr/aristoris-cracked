import javax.annotation.Nullable;

public class bxr extends buo implements bwm {
   public static final cfe<ge> a;

   protected bxr(ceg.c var1) {
      super(var1);
      this.j((ceh)((ceh)this.n.b()).a(a, ge.k));
   }

   protected void a(cei.a<buo, ceh> var1) {
      var1.a(a);
   }

   public ceh a(ceh var1, bzm var2) {
      return (ceh)var1.a(a, var2.a().a((ge)var1.c(a)));
   }

   public ceh a(ceh var1, byg var2) {
      return (ceh)var1.a(a, var2.a().a((ge)var1.c(a)));
   }

   public ceh a(bny var1) {
      gc var2 = var1.j();
      gc var3;
      if (var2.n() == gc.a.b) {
         var3 = var1.f().f();
      } else {
         var3 = gc.b;
      }

      return (ceh)this.n().a(a, ge.a(var2, var3));
   }

   @Nullable
   public ccj a(brc var1) {
      return new ccz();
   }

   public aou a(ceh var1, brx var2, fx var3, bfw var4, aot var5, dcj var6) {
      ccj var7 = var2.c(var3);
      if (var7 instanceof ccz && var4.eV()) {
         var4.a((ccz)var7);
         return aou.a(var2.v);
      } else {
         return aou.c;
      }
   }

   public static boolean a(ctb.c var0, ctb.c var1) {
      gc var2 = h(var0.b);
      gc var3 = h(var1.b);
      gc var4 = l(var0.b);
      gc var5 = l(var1.b);
      ccz.a var6 = (ccz.a)ccz.a.a(var0.c.l("joint")).orElseGet(() -> {
         return var2.n().d() ? ccz.a.b : ccz.a.a;
      });
      boolean var7 = var6 == ccz.a.a;
      return var2 == var3.f() && (var7 || var4 == var5) && var0.c.l("target").equals(var1.c.l("name"));
   }

   public static gc h(ceh var0) {
      return ((ge)var0.c(a)).b();
   }

   public static gc l(ceh var0) {
      return ((ge)var0.c(a)).c();
   }

   static {
      a = cex.P;
   }
}
