import java.time.LocalDate;
import java.time.temporal.ChronoField;
import javax.annotation.Nullable;

public abstract class bcz extends bdq implements bdu {
   private final aww<bcz> b = new aww(this, 1.0D, 20, 15.0F);
   private final awf c = new awf(this, 1.2D, false) {
      public void d() {
         super.d();
         bcz.this.s(false);
      }

      public void c() {
         super.c();
         bcz.this.s(true);
      }
   };

   protected bcz(aqe<? extends bcz> var1, brx var2) {
      super(var1, var2);
      this.eL();
   }

   protected void o() {
      this.bk.a(2, new awz(this));
      this.bk.a(3, new avo(this, 1.0D));
      this.bk.a(3, new avd(this, baz.class, 6.0F, 1.0D, 1.2D));
      this.bk.a(5, new axk(this, 1.0D));
      this.bk.a(6, new awd(this, bfw.class, 8.0F));
      this.bk.a(6, new aws(this));
      this.bl.a(1, new axp(this, new Class[0]));
      this.bl.a(2, new axq(this, bfw.class, true));
      this.bl.a(3, new axq(this, bai.class, true));
      this.bl.a(3, new axq(this, bax.class, 10, true, false, bax.bo));
   }

   public static ark.a m() {
      return bdq.eR().a(arl.d, 0.25D);
   }

   protected void b(fx var1, ceh var2) {
      this.a(this.eK(), 0.15F, 1.0F);
   }

   abstract adp eK();

   public aqq dC() {
      return aqq.b;
   }

   public void k() {
      boolean var1 = this.eG();
      if (var1) {
         bmb var2 = this.b(aqf.f);
         if (!var2.a()) {
            if (var2.e()) {
               var2.b(var2.g() + this.J.nextInt(2));
               if (var2.g() >= var2.h()) {
                  this.c(aqf.f);
                  this.a(aqf.f, bmb.b);
               }
            }

            var1 = false;
         }

         if (var1) {
            this.f(8);
         }
      }

      super.k();
   }

   public void ba() {
      super.ba();
      if (this.ct() instanceof aqu) {
         aqu var1 = (aqu)this.ct();
         this.aA = var1.aA;
      }

   }

   protected void a(aos var1) {
      super.a(var1);
      this.a(aqf.a, new bmb(bmd.kc));
   }

   @Nullable
   public arc a(bsk var1, aos var2, aqp var3, @Nullable arc var4, @Nullable md var5) {
      var4 = super.a(var1, var2, var3, var4, var5);
      this.a(var2);
      this.b(var2);
      this.eL();
      this.p(this.J.nextFloat() < 0.55F * var2.d());
      if (this.b(aqf.f).a()) {
         LocalDate var6 = LocalDate.now();
         int var7 = var6.get(ChronoField.DAY_OF_MONTH);
         int var8 = var6.get(ChronoField.MONTH_OF_YEAR);
         if (var8 == 10 && var7 == 31 && this.J.nextFloat() < 0.25F) {
            this.a(aqf.f, new bmb(this.J.nextFloat() < 0.1F ? bup.cV : bup.cU));
            this.bn[aqf.f.b()] = 0.0F;
         }
      }

      return var4;
   }

   public void eL() {
      if (this.l != null && !this.l.v) {
         this.bk.a((avv)this.c);
         this.bk.a((avv)this.b);
         bmb var1 = this.b(bgn.a((aqm)this, (blx)bmd.kc));
         if (var1.b() == bmd.kc) {
            int var2 = 20;
            if (this.l.ad() != aor.d) {
               var2 = 40;
            }

            this.b.a(var2);
            this.bk.a(4, this.b);
         } else {
            this.bk.a(4, this.c);
         }

      }
   }

   public void a(aqm var1, float var2) {
      bmb var3 = this.f(this.b(bgn.a((aqm)this, (blx)bmd.kc)));
      bga var4 = this.b(var3, var2);
      double var5 = var1.cD() - this.cD();
      double var7 = var1.e(0.3333333333333333D) - var4.cE();
      double var9 = var1.cH() - this.cH();
      double var11 = (double)afm.a(var5 * var5 + var9 * var9);
      var4.c(var5, var7 + var11 * 0.20000000298023224D, var9, 1.6F, (float)(14 - this.l.ad().a() * 4));
      this.a(adq.nD, 1.0F, 1.0F / (this.cY().nextFloat() * 0.4F + 0.8F));
      this.l.c((aqa)var4);
   }

   protected bga b(bmb var1, float var2) {
      return bgn.a(this, var1, var2);
   }

   public boolean a(bmo var1) {
      return var1 == bmd.kc;
   }

   public void a(md var1) {
      super.a(var1);
      this.eL();
   }

   public void a(aqf var1, bmb var2) {
      super.a(var1, var2);
      if (!this.l.v) {
         this.eL();
      }

   }

   protected float b(aqx var1, aqb var2) {
      return 1.74F;
   }

   public double bb() {
      return -0.6D;
   }
}
