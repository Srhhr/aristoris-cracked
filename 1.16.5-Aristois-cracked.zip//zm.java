import com.google.common.collect.Lists;
import com.mojang.util.QueueLogAppender;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Collection;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class zm extends JComponent {
   private static final Font a = new Font("Monospaced", 0, 12);
   private static final Logger b = LogManager.getLogger();
   private final zg c;
   private Thread d;
   private final Collection<Runnable> e = Lists.newArrayList();
   private final AtomicBoolean f = new AtomicBoolean();

   public static zm a(final zg var0) {
      try {
         UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
      } catch (Exception var3) {
      }

      final JFrame var1 = new JFrame("Minecraft server");
      final zm var2 = new zm(var0);
      var1.setDefaultCloseOperation(2);
      var1.add(var2);
      var1.pack();
      var1.setLocationRelativeTo((Component)null);
      var1.setVisible(true);
      var1.addWindowListener(new WindowAdapter() {
         public void windowClosing(WindowEvent var1x) {
            if (!var2.f.getAndSet(true)) {
               var1.setTitle("Minecraft server - shutting down!");
               var0.a(true);
               var2.f();
            }

         }
      });
      var2.a(var1::dispose);
      var2.a();
      return var2;
   }

   private zm(zg var1) {
      this.c = var1;
      this.setPreferredSize(new Dimension(854, 480));
      this.setLayout(new BorderLayout());

      try {
         this.add(this.e(), "Center");
         this.add(this.c(), "West");
      } catch (Exception var3) {
         b.error("Couldn't build server GUI", var3);
      }

   }

   public void a(Runnable var1) {
      this.e.add(var1);
   }

   private JComponent c() {
      JPanel var1 = new JPanel(new BorderLayout());
      zo var2 = new zo(this.c);
      this.e.add(var2::a);
      var1.add(var2, "North");
      var1.add(this.d(), "Center");
      var1.setBorder(new TitledBorder(new EtchedBorder(), "Stats"));
      return var1;
   }

   private JComponent d() {
      JList<?> var1 = new zn(this.c);
      JScrollPane var2 = new JScrollPane(var1, 22, 30);
      var2.setBorder(new TitledBorder(new EtchedBorder(), "Players"));
      return var2;
   }

   private JComponent e() {
      JPanel var1 = new JPanel(new BorderLayout());
      JTextArea var2 = new JTextArea();
      JScrollPane var3 = new JScrollPane(var2, 22, 30);
      var2.setEditable(false);
      var2.setFont(a);
      JTextField var4 = new JTextField();
      var4.addActionListener((var2x) -> {
         String var3 = var4.getText().trim();
         if (!var3.isEmpty()) {
            this.c.a(var3, this.c.aE());
         }

         var4.setText("");
      });
      var2.addFocusListener(new FocusAdapter() {
         public void focusGained(FocusEvent var1) {
         }
      });
      var1.add(var3, "Center");
      var1.add(var4, "South");
      var1.setBorder(new TitledBorder(new EtchedBorder(), "Log and chat"));
      this.d = new Thread(() -> {
         String var3x;
         while((var3x = QueueLogAppender.getNextLogEvent("ServerGuiConsole")) != null) {
            this.a(var2, var3, var3x);
         }

      });
      this.d.setUncaughtExceptionHandler(new o(b));
      this.d.setDaemon(true);
      return var1;
   }

   public void a() {
      this.d.start();
   }

   public void b() {
      if (!this.f.getAndSet(true)) {
         this.f();
      }

   }

   private void f() {
      this.e.forEach(Runnable::run);
   }

   public void a(JTextArea var1, JScrollPane var2, String var3) {
      if (!SwingUtilities.isEventDispatchThread()) {
         SwingUtilities.invokeLater(() -> {
            this.a(var1, var2, var3);
         });
      } else {
         Document var4 = var1.getDocument();
         JScrollBar var5 = var2.getVerticalScrollBar();
         boolean var6 = false;
         if (var2.getViewport().getView() == var1) {
            var6 = (double)var5.getValue() + var5.getSize().getHeight() + (double)(a.getSize() * 4) > (double)var5.getMaximum();
         }

         try {
            var4.insertString(var4.getLength(), var3, (AttributeSet)null);
         } catch (BadLocationException var8) {
         }

         if (var6) {
            var5.setValue(Integer.MAX_VALUE);
         }

      }
   }
}
