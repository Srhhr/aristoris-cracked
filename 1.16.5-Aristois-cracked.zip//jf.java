import com.google.gson.JsonObject;
import javax.annotation.Nullable;

public interface jf {
   void a(JsonObject var1);

   default JsonObject a() {
      JsonObject var1 = new JsonObject();
      var1.addProperty("type", gm.ae.b((Object)this.c()).toString());
      this.a(var1);
      return var1;
   }

   vk b();

   bos<?> c();

   @Nullable
   JsonObject d();

   @Nullable
   vk e();
}
