import com.mojang.blaze3d.systems.RenderSystem;
import java.util.Locale;

public class dfc {
   private static dfc a;
   private final int b;
   private final int c;
   private final int d;
   private final int e;
   private final int f;
   private final boolean g;
   private final boolean h;

   private dfc(boolean var1, boolean var2, int var3, int var4, int var5, int var6, int var7) {
      this.g = var1;
      this.b = var3;
      this.d = var4;
      this.c = var5;
      this.e = var6;
      this.h = var2;
      this.f = var7;
   }

   public dfc() {
      this(false, true, 1, 0, 1, 0, 32774);
   }

   public dfc(int var1, int var2, int var3) {
      this(false, false, var1, var2, var1, var2, var3);
   }

   public dfc(int var1, int var2, int var3, int var4, int var5) {
      this(true, false, var1, var2, var3, var4, var5);
   }

   public void a() {
      if (!this.equals(a)) {
         if (a == null || this.h != a.b()) {
            a = this;
            if (this.h) {
               RenderSystem.disableBlend();
               return;
            }

            RenderSystem.enableBlend();
         }

         RenderSystem.blendEquation(this.f);
         if (this.g) {
            RenderSystem.blendFuncSeparate(this.b, this.d, this.c, this.e);
         } else {
            RenderSystem.blendFunc(this.b, this.d);
         }

      }
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof dfc)) {
         return false;
      } else {
         dfc var2 = (dfc)var1;
         if (this.f != var2.f) {
            return false;
         } else if (this.e != var2.e) {
            return false;
         } else if (this.d != var2.d) {
            return false;
         } else if (this.h != var2.h) {
            return false;
         } else if (this.g != var2.g) {
            return false;
         } else if (this.c != var2.c) {
            return false;
         } else {
            return this.b == var2.b;
         }
      }
   }

   public int hashCode() {
      int var1 = this.b;
      var1 = 31 * var1 + this.c;
      var1 = 31 * var1 + this.d;
      var1 = 31 * var1 + this.e;
      var1 = 31 * var1 + this.f;
      var1 = 31 * var1 + (this.g ? 1 : 0);
      var1 = 31 * var1 + (this.h ? 1 : 0);
      return var1;
   }

   public boolean b() {
      return this.h;
   }

   public static int a(String var0) {
      String var1 = var0.trim().toLowerCase(Locale.ROOT);
      if ("add".equals(var1)) {
         return 32774;
      } else if ("subtract".equals(var1)) {
         return 32778;
      } else if ("reversesubtract".equals(var1)) {
         return 32779;
      } else if ("reverse_subtract".equals(var1)) {
         return 32779;
      } else if ("min".equals(var1)) {
         return 32775;
      } else {
         return "max".equals(var1) ? '耈' : '耆';
      }
   }

   public static int b(String var0) {
      String var1 = var0.trim().toLowerCase(Locale.ROOT);
      var1 = var1.replaceAll("_", "");
      var1 = var1.replaceAll("one", "1");
      var1 = var1.replaceAll("zero", "0");
      var1 = var1.replaceAll("minus", "-");
      if ("0".equals(var1)) {
         return 0;
      } else if ("1".equals(var1)) {
         return 1;
      } else if ("srccolor".equals(var1)) {
         return 768;
      } else if ("1-srccolor".equals(var1)) {
         return 769;
      } else if ("dstcolor".equals(var1)) {
         return 774;
      } else if ("1-dstcolor".equals(var1)) {
         return 775;
      } else if ("srcalpha".equals(var1)) {
         return 770;
      } else if ("1-srcalpha".equals(var1)) {
         return 771;
      } else if ("dstalpha".equals(var1)) {
         return 772;
      } else {
         return "1-dstalpha".equals(var1) ? 773 : -1;
      }
   }
}
