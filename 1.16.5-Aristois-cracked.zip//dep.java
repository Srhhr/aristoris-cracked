import com.mojang.blaze3d.systems.RenderSystem;
import java.util.function.Consumer;

public class dep {
   private static final g a = (g)x.a((Object)(new g(0.2F, 1.0F, -0.7F)), (Consumer)(g::d));
   private static final g b = (g)x.a((Object)(new g(-0.2F, 1.0F, 0.7F)), (Consumer)(g::d));
   private static final g c = (g)x.a((Object)(new g(0.2F, 1.0F, -0.7F)), (Consumer)(g::d));
   private static final g d = (g)x.a((Object)(new g(-0.2F, -1.0F, 0.7F)), (Consumer)(g::d));

   public static void a() {
      RenderSystem.enableLighting();
      RenderSystem.enableColorMaterial();
      RenderSystem.colorMaterial(1032, 5634);
   }

   public static void b() {
      RenderSystem.disableLighting();
      RenderSystem.disableColorMaterial();
   }

   public static void a(b var0) {
      RenderSystem.setupLevelDiffuseLighting(c, d, var0);
   }

   public static void b(b var0) {
      RenderSystem.setupLevelDiffuseLighting(a, b, var0);
   }

   public static void c() {
      RenderSystem.setupGuiFlatDiffuseLighting(a, b);
   }

   public static void d() {
      RenderSystem.setupGui3DDiffuseLighting(a, b);
   }
}
