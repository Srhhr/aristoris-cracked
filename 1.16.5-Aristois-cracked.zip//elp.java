import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

public enum elp implements elv {
   a(0, 0),
   b(0, 90),
   c(0, 180),
   d(0, 270),
   e(90, 0),
   f(90, 90),
   g(90, 180),
   h(90, 270),
   i(180, 0),
   j(180, 90),
   k(180, 180),
   l(180, 270),
   m(270, 0),
   n(270, 90),
   o(270, 180),
   p(270, 270);

   private static final Map<Integer, elp> q = (Map)Arrays.stream(values()).collect(Collectors.toMap((var0) -> {
      return var0.t;
   }, (var0) -> {
      return var0;
   }));
   private final f r;
   private final c s;
   private final int t;

   private static int b(int var0, int var1) {
      return var0 * 360 + var1;
   }

   private elp(int var3, int var4) {
      this.t = b(var3, var4);
      d var5 = new d(new g(0.0F, 1.0F, 0.0F), (float)(-var4), true);
      var5.a(new d(new g(1.0F, 0.0F, 0.0F), (float)(-var3), true));
      c var6 = c.a;

      int var7;
      for(var7 = 0; var7 < var4; var7 += 90) {
         var6 = var6.a(c.u);
      }

      for(var7 = 0; var7 < var3; var7 += 90) {
         var6 = var6.a(c.s);
      }

      this.r = new f((g)null, var5, (g)null, (d)null);
      this.s = var6;
   }

   public f b() {
      return this.r;
   }

   public static elp a(int var0, int var1) {
      return (elp)q.get(b(afm.b(var0, 360), afm.b(var1, 360)));
   }
}
