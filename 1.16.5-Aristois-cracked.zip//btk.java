import com.google.common.collect.ImmutableList;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;

public class btk extends bsy {
   public static final Codec<btk> e = RecordCodecBuilder.create((var0) -> {
      return var0.group(vg.a(gm.ay).forGetter((var0x) -> {
         return var0x.g;
      }), Codec.LONG.fieldOf("seed").stable().forGetter((var0x) -> {
         return var0x.h;
      })).apply(var0, var0.stable(btk::new));
   });
   private final cud f;
   private final gm<bsv> g;
   private final long h;
   private final bsv i;
   private final bsv j;
   private final bsv k;
   private final bsv l;
   private final bsv m;

   public btk(gm<bsv> var1, long var2) {
      this(var1, var2, (bsv)var1.d(btb.j), (bsv)var1.d(btb.Q), (bsv)var1.d(btb.P), (bsv)var1.d(btb.O), (bsv)var1.d(btb.R));
   }

   private btk(gm<bsv> var1, long var2, bsv var4, bsv var5, bsv var6, bsv var7, bsv var8) {
      super((List)ImmutableList.of(var4, var5, var6, var7, var8));
      this.g = var1;
      this.h = var2;
      this.i = var4;
      this.j = var5;
      this.k = var6;
      this.l = var7;
      this.m = var8;
      chx var9 = new chx(var2);
      var9.a(17292);
      this.f = new cud(var9);
   }

   protected Codec<? extends bsy> a() {
      return e;
   }

   public bsy a(long var1) {
      return new btk(this.g, var1, this.i, this.j, this.k, this.l, this.m);
   }

   public bsv b(int var1, int var2, int var3) {
      int var4 = var1 >> 2;
      int var5 = var3 >> 2;
      if ((long)var4 * (long)var4 + (long)var5 * (long)var5 <= 4096L) {
         return this.i;
      } else {
         float var6 = a(this.f, var4 * 2 + 1, var5 * 2 + 1);
         if (var6 > 40.0F) {
            return this.j;
         } else if (var6 >= 0.0F) {
            return this.k;
         } else {
            return var6 < -20.0F ? this.l : this.m;
         }
      }
   }

   public boolean b(long var1) {
      return this.h == var1;
   }

   public static float a(cud var0, int var1, int var2) {
      int var3 = var1 / 2;
      int var4 = var2 / 2;
      int var5 = var1 % 2;
      int var6 = var2 % 2;
      float var7 = 100.0F - afm.c((float)(var1 * var1 + var2 * var2)) * 8.0F;
      var7 = afm.a(var7, -100.0F, 80.0F);

      for(int var8 = -12; var8 <= 12; ++var8) {
         for(int var9 = -12; var9 <= 12; ++var9) {
            long var10 = (long)(var3 + var8);
            long var12 = (long)(var4 + var9);
            if (var10 * var10 + var12 * var12 > 4096L && var0.a((double)var10, (double)var12) < -0.8999999761581421D) {
               float var14 = (afm.e((float)var10) * 3439.0F + afm.e((float)var12) * 147.0F) % 13.0F + 9.0F;
               float var15 = (float)(var5 - var8 * 2);
               float var16 = (float)(var6 - var9 * 2);
               float var17 = 100.0F - afm.c(var15 * var15 + var16 * var16) * var14;
               var17 = afm.a(var17, -100.0F, 80.0F);
               var7 = Math.max(var7, var17);
            }
         }
      }

      return var7;
   }
}
