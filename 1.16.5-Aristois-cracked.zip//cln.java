import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Random;

public class cln extends cll {
   public static final Codec<cln> b = RecordCodecBuilder.create((var0) -> {
      return var0.group(Codec.INT.fieldOf("min_size").forGetter((var0x) -> {
         return var0x.c;
      }), Codec.INT.fieldOf("extra_size").forGetter((var0x) -> {
         return var0x.d;
      })).apply(var0, cln::new);
   });
   private final int c;
   private final int d;

   public cln(int var1, int var2) {
      this.c = var1;
      this.d = var2;
   }

   protected clm<?> a() {
      return clm.c;
   }

   public void a(bry var1, fx var2, ceh var3, Random var4) {
      fx.a var5 = var2.i();
      int var6 = this.c + var4.nextInt(var4.nextInt(this.d + 1) + 1);

      for(int var7 = 0; var7 < var6; ++var7) {
         var1.a(var5, var3, 2);
         var5.c(gc.b);
      }

   }
}
