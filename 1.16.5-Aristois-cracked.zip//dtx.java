import com.google.common.collect.ImmutableList;

public class dtx<T extends aqa> extends dur<T> {
   private final dwn a;
   private final dwn b;
   private final dwn f;

   public dtx() {
      this.r = 64;
      this.s = 64;
      float var1 = 18.0F;
      float var2 = -8.0F;
      this.a = new dwn(this, 22, 0);
      this.a.a(-4.0F, -7.0F, 0.0F, 8.0F, 7.0F, 13.0F);
      this.a.a(0.0F, 22.0F, -5.0F);
      dwn var3 = new dwn(this, 51, 0);
      var3.a(-0.5F, 0.0F, 8.0F, 1.0F, 4.0F, 5.0F);
      var3.d = 1.0471976F;
      this.a.b(var3);
      dwn var4 = new dwn(this, 48, 20);
      var4.g = true;
      var4.a(-0.5F, -4.0F, 0.0F, 1.0F, 4.0F, 7.0F);
      var4.a(2.0F, -2.0F, 4.0F);
      var4.d = 1.0471976F;
      var4.f = 2.0943952F;
      this.a.b(var4);
      dwn var5 = new dwn(this, 48, 20);
      var5.a(-0.5F, -4.0F, 0.0F, 1.0F, 4.0F, 7.0F);
      var5.a(-2.0F, -2.0F, 4.0F);
      var5.d = 1.0471976F;
      var5.f = -2.0943952F;
      this.a.b(var5);
      this.b = new dwn(this, 0, 19);
      this.b.a(-2.0F, -2.5F, 0.0F, 4.0F, 5.0F, 11.0F);
      this.b.a(0.0F, -2.5F, 11.0F);
      this.b.d = -0.10471976F;
      this.a.b(this.b);
      this.f = new dwn(this, 19, 20);
      this.f.a(-5.0F, -0.5F, 0.0F, 10.0F, 1.0F, 6.0F);
      this.f.a(0.0F, 0.0F, 9.0F);
      this.f.d = 0.0F;
      this.b.b(this.f);
      dwn var6 = new dwn(this, 0, 0);
      var6.a(-4.0F, -3.0F, -3.0F, 8.0F, 7.0F, 6.0F);
      var6.a(0.0F, -4.0F, -3.0F);
      dwn var7 = new dwn(this, 0, 13);
      var7.a(-1.0F, 2.0F, -7.0F, 2.0F, 2.0F, 4.0F);
      var6.b(var7);
      this.a.b(var6);
   }

   public Iterable<dwn> a() {
      return ImmutableList.of(this.a);
   }

   public void a(T var1, float var2, float var3, float var4, float var5, float var6) {
      this.a.d = var6 * 0.017453292F;
      this.a.e = var5 * 0.017453292F;
      if (aqa.c(var1.cC()) > 1.0E-7D) {
         dwn var10000 = this.a;
         var10000.d += -0.05F + -0.05F * afm.b(var4 * 0.3F);
         this.b.d = -0.1F * afm.b(var4 * 0.3F);
         this.f.d = -0.2F * afm.b(var4 * 0.3F);
      }

   }
}
