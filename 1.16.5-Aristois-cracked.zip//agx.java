import com.mojang.datafixers.DSL;
import com.mojang.datafixers.DataFix;
import com.mojang.datafixers.TypeRewriteRule;
import com.mojang.datafixers.schemas.Schema;
import com.mojang.datafixers.types.Type;
import com.mojang.datafixers.util.Pair;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;

public abstract class agx extends DataFix {
   private final String a;

   public agx(Schema var1, String var2) {
      super(var1, false);
      this.a = var2;
   }

   public TypeRewriteRule makeRule() {
      Type<?> var1 = this.getInputSchema().getType(akn.q);
      Type<Pair<String, String>> var2 = DSL.named(akn.q.typeName(), aln.a());
      if (!Objects.equals(var1, var2)) {
         throw new IllegalStateException("block type is not what was expected.");
      } else {
         TypeRewriteRule var3 = this.fixTypeEverywhere(this.a + " for block", var2, (var1x) -> {
            return (var1) -> {
               return var1.mapSecond(this::a);
            };
         });
         TypeRewriteRule var4 = this.fixTypeEverywhereTyped(this.a + " for block_state", this.getInputSchema().getType(akn.m), (var1x) -> {
            return var1x.update(DSL.remainderFinder(), (var1) -> {
               Optional<String> var2 = var1.get("Name").asString().result();
               return var2.isPresent() ? var1.set("Name", var1.createString(this.a((String)var2.get()))) : var1;
            });
         });
         return TypeRewriteRule.seq(var3, var4);
      }
   }

   protected abstract String a(String var1);

   public static DataFix a(Schema var0, String var1, final Function<String, String> var2) {
      return new agx(var0, var1) {
         protected String a(String var1) {
            return (String)var2.apply(var1);
         }
      };
   }
}
