public interface bdi {
}
