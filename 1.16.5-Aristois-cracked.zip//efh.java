public class efh<T extends aqn, M extends dum<T>> extends efw<T, M> {
   private static final vk a = new vk("textures/entity/steve.png");

   public efh(eet var1, M var2, float var3) {
      this(var1, var2, var3, 1.0F, 1.0F, 1.0F);
   }

   public efh(eet var1, M var2, float var3, float var4, float var5, float var6) {
      super(var1, var2, var3);
      this.a((eit)(new ehz(this, var4, var5, var6)));
      this.a((eit)(new eid(this)));
      this.a((eit)(new ein(this)));
   }

   public vk a(T var1) {
      return a;
   }
}
