import com.google.common.collect.Maps;
import java.util.Iterator;
import java.util.Map;
import java.util.stream.Stream;

public class cya {
   private final Map<String, cya.a> a = Maps.newHashMap();
   private final cyc b;

   public cya(cyc var1) {
      this.b = var1;
   }

   private cya.a a(String var1, String var2) {
      cya.a var3 = new cya.a(var2);
      this.a.put(var1, var3);
      return var3;
   }

   public md a(vk var1) {
      String var2 = var1.b();
      String var3 = a(var2);
      cya.a var4 = (cya.a)this.b.b(() -> {
         return this.a(var2, var3);
      }, var3);
      return var4 != null ? var4.a(var1.a()) : new md();
   }

   public void a(vk var1, md var2) {
      String var3 = var1.b();
      String var4 = a(var3);
      ((cya.a)this.b.a(() -> {
         return this.a(var3, var4);
      }, var4)).a(var1.a(), var2);
   }

   public Stream<vk> a() {
      return this.a.entrySet().stream().flatMap((var0) -> {
         return ((cya.a)var0.getValue()).b((String)var0.getKey());
      });
   }

   private static String a(String var0) {
      return "command_storage_" + var0;
   }

   static class a extends cxs {
      private final Map<String, md> a = Maps.newHashMap();

      public a(String var1) {
         super(var1);
      }

      public void a(md var1) {
         md var2 = var1.p("contents");
         Iterator var3 = var2.d().iterator();

         while(var3.hasNext()) {
            String var4 = (String)var3.next();
            this.a.put(var4, var2.p(var4));
         }

      }

      public md b(md var1) {
         md var2 = new md();
         this.a.forEach((var1x, var2x) -> {
            var2.a((String)var1x, (mt)var2x.g());
         });
         var1.a((String)"contents", (mt)var2);
         return var1;
      }

      public md a(String var1) {
         md var2 = (md)this.a.get(var1);
         return var2 != null ? var2 : new md();
      }

      public void a(String var1, md var2) {
         if (var2.isEmpty()) {
            this.a.remove(var1);
         } else {
            this.a.put(var1, var2);
         }

         this.b();
      }

      public Stream<vk> b(String var1) {
         return this.a.keySet().stream().map((var1x) -> {
            return new vk(var1, var1x);
         });
      }
   }
}
