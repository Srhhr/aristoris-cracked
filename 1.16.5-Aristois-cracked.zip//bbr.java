import com.google.common.collect.Lists;
import java.util.Iterator;
import java.util.List;
import java.util.function.Predicate;
import javax.annotation.Nullable;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class bbr extends aqn implements bdi {
   private static final Logger bv = LogManager.getLogger();
   public static final us<Integer> b;
   private static final azg bw;
   public final double[][] c = new double[64][3];
   public int d = -1;
   private final bbp[] bx;
   public final bbp bo = new bbp(this, "head", 1.0F, 1.0F);
   private final bbp by = new bbp(this, "neck", 3.0F, 3.0F);
   private final bbp bz = new bbp(this, "body", 5.0F, 3.0F);
   private final bbp bA = new bbp(this, "tail", 2.0F, 2.0F);
   private final bbp bB = new bbp(this, "tail", 2.0F, 2.0F);
   private final bbp bC = new bbp(this, "tail", 2.0F, 2.0F);
   private final bbp bD = new bbp(this, "wing", 4.0F, 2.0F);
   private final bbp bE = new bbp(this, "wing", 4.0F, 2.0F);
   public float bp;
   public float bq;
   public boolean br;
   public int bs;
   public float bt;
   @Nullable
   public bbq bu;
   @Nullable
   private final chg bF;
   private final bci bG;
   private int bH = 100;
   private int bI;
   private final cxb[] bJ = new cxb[24];
   private final int[] bK = new int[24];
   private final cwy bL = new cwy();

   public bbr(aqe<? extends bbr> var1, brx var2) {
      super(aqe.t, var2);
      this.bx = new bbp[]{this.bo, this.by, this.bz, this.bA, this.bB, this.bC, this.bD, this.bE};
      this.c(this.dx());
      this.H = true;
      this.Y = true;
      if (var2 instanceof aag) {
         this.bF = ((aag)var2).D();
      } else {
         this.bF = null;
      }

      this.bG = new bci(this);
   }

   public static ark.a m() {
      return aqn.p().a(arl.a, 200.0D);
   }

   protected void e() {
      super.e();
      this.ab().a((us)b, (Object)bch.k.b());
   }

   public double[] a(int var1, float var2) {
      if (this.dl()) {
         var2 = 0.0F;
      }

      var2 = 1.0F - var2;
      int var3 = this.d - var1 & 63;
      int var4 = this.d - var1 - 1 & 63;
      double[] var5 = new double[3];
      double var6 = this.c[var3][0];
      double var8 = afm.g(this.c[var4][0] - var6);
      var5[0] = var6 + var8 * (double)var2;
      var6 = this.c[var3][1];
      var8 = this.c[var4][1] - var6;
      var5[1] = var6 + var8 * (double)var2;
      var5[2] = afm.d((double)var2, this.c[var3][2], this.c[var4][2]);
      return var5;
   }

   public void k() {
      float var1;
      float var2;
      if (this.l.v) {
         this.c(this.dk());
         if (!this.aA()) {
            var1 = afm.b(this.bq * 6.2831855F);
            var2 = afm.b(this.bp * 6.2831855F);
            if (var2 <= -0.3F && var1 >= -0.3F) {
               this.l.a(this.cD(), this.cE(), this.cH(), adq.ds, this.cu(), 5.0F, 0.8F + this.J.nextFloat() * 0.3F, false);
            }

            if (!this.bG.a().a() && --this.bH < 0) {
               this.l.a(this.cD(), this.cE(), this.cH(), adq.dt, this.cu(), 2.5F, 0.8F + this.J.nextFloat() * 0.3F, false);
               this.bH = 200 + this.J.nextInt(200);
            }
         }
      }

      this.bp = this.bq;
      if (this.dl()) {
         var1 = (this.J.nextFloat() - 0.5F) * 8.0F;
         var2 = (this.J.nextFloat() - 0.5F) * 4.0F;
         float var32 = (this.J.nextFloat() - 0.5F) * 8.0F;
         this.l.a(hh.w, this.cD() + (double)var1, this.cE() + 2.0D + (double)var2, this.cH() + (double)var32, 0.0D, 0.0D, 0.0D);
      } else {
         this.eN();
         dcn var26 = this.cC();
         var2 = 0.2F / (afm.a(c(var26)) * 10.0F + 1.0F);
         var2 *= (float)Math.pow(2.0D, var26.c);
         if (this.bG.a().a()) {
            this.bq += 0.1F;
         } else if (this.br) {
            this.bq += var2 * 0.5F;
         } else {
            this.bq += var2;
         }

         this.p = afm.g(this.p);
         if (this.eD()) {
            this.bq = 0.5F;
         } else {
            if (this.d < 0) {
               for(int var3 = 0; var3 < this.c.length; ++var3) {
                  this.c[var3][0] = (double)this.p;
                  this.c[var3][1] = this.cE();
               }
            }

            if (++this.d == this.c.length) {
               this.d = 0;
            }

            this.c[this.d][0] = (double)this.p;
            this.c[this.d][1] = this.cE();
            double var5;
            double var7;
            double var9;
            float var20;
            float var21;
            if (this.l.v) {
               if (this.aU > 0) {
                  double var27 = this.cD() + (this.aV - this.cD()) / (double)this.aU;
                  var5 = this.cE() + (this.aW - this.cE()) / (double)this.aU;
                  var7 = this.cH() + (this.aX - this.cH()) / (double)this.aU;
                  var9 = afm.g(this.aY - (double)this.p);
                  this.p = (float)((double)this.p + var9 / (double)this.aU);
                  this.q = (float)((double)this.q + (this.aZ - (double)this.q) / (double)this.aU);
                  --this.aU;
                  this.d(var27, var5, var7);
                  this.a(this.p, this.q);
               }

               this.bG.a().b();
            } else {
               bcb var28 = this.bG.a();
               var28.c();
               if (this.bG.a() != var28) {
                  var28 = this.bG.a();
                  var28.c();
               }

               dcn var4 = var28.g();
               if (var4 != null) {
                  var5 = var4.b - this.cD();
                  var7 = var4.c - this.cE();
                  var9 = var4.d - this.cH();
                  double var11 = var5 * var5 + var7 * var7 + var9 * var9;
                  float var13 = var28.f();
                  double var14 = (double)afm.a(var5 * var5 + var9 * var9);
                  if (var14 > 0.0D) {
                     var7 = afm.a(var7 / var14, (double)(-var13), (double)var13);
                  }

                  this.f(this.cC().b(0.0D, var7 * 0.01D, 0.0D));
                  this.p = afm.g(this.p);
                  double var16 = afm.a(afm.g(180.0D - afm.d(var5, var9) * 57.2957763671875D - (double)this.p), -50.0D, 50.0D);
                  dcn var18 = var4.a(this.cD(), this.cE(), this.cH()).d();
                  dcn var19 = (new dcn((double)afm.a(this.p * 0.017453292F), this.cC().c, (double)(-afm.b(this.p * 0.017453292F)))).d();
                  var20 = Math.max(((float)var19.b(var18) + 0.5F) / 1.5F, 0.0F);
                  this.bt *= 0.8F;
                  this.bt = (float)((double)this.bt + var16 * (double)var28.h());
                  this.p += this.bt * 0.1F;
                  var21 = (float)(2.0D / (var11 + 1.0D));
                  float var22 = 0.06F;
                  this.a(0.06F * (var20 * var21 + (1.0F - var21)), new dcn(0.0D, 0.0D, -1.0D));
                  if (this.br) {
                     this.a(aqr.a, this.cC().a(0.800000011920929D));
                  } else {
                     this.a(aqr.a, this.cC());
                  }

                  dcn var23 = this.cC().d();
                  double var24 = 0.8D + 0.15D * (var23.b(var19) + 1.0D) / 2.0D;
                  this.f(this.cC().d(var24, 0.9100000262260437D, var24));
               }
            }

            this.aA = this.p;
            dcn[] var30 = new dcn[this.bx.length];

            for(int var29 = 0; var29 < this.bx.length; ++var29) {
               var30[var29] = new dcn(this.bx[var29].cD(), this.bx[var29].cE(), this.bx[var29].cH());
            }

            float var31 = (float)(this.a(5, 1.0F)[1] - this.a(10, 1.0F)[1]) * 10.0F * 0.017453292F;
            float var33 = afm.b(var31);
            float var6 = afm.a(var31);
            float var34 = this.p * 0.017453292F;
            float var8 = afm.a(var34);
            float var35 = afm.b(var34);
            this.a(this.bz, (double)(var8 * 0.5F), 0.0D, (double)(-var35 * 0.5F));
            this.a(this.bD, (double)(var35 * 4.5F), 2.0D, (double)(var8 * 4.5F));
            this.a(this.bE, (double)(var35 * -4.5F), 2.0D, (double)(var8 * -4.5F));
            if (!this.l.v && this.an == 0) {
               this.a(this.l.a((aqa)this, (dci)this.bD.cc().c(4.0D, 2.0D, 4.0D).d(0.0D, -2.0D, 0.0D), (Predicate)aqd.e));
               this.a(this.l.a((aqa)this, (dci)this.bE.cc().c(4.0D, 2.0D, 4.0D).d(0.0D, -2.0D, 0.0D), (Predicate)aqd.e));
               this.b(this.l.a((aqa)this, (dci)this.bo.cc().g(1.0D), (Predicate)aqd.e));
               this.b(this.l.a((aqa)this, (dci)this.by.cc().g(1.0D), (Predicate)aqd.e));
            }

            float var10 = afm.a(this.p * 0.017453292F - this.bt * 0.01F);
            float var36 = afm.b(this.p * 0.017453292F - this.bt * 0.01F);
            float var12 = this.eM();
            this.a(this.bo, (double)(var10 * 6.5F * var33), (double)(var12 + var6 * 6.5F), (double)(-var36 * 6.5F * var33));
            this.a(this.by, (double)(var10 * 5.5F * var33), (double)(var12 + var6 * 5.5F), (double)(-var36 * 5.5F * var33));
            double[] var37 = this.a(5, 1.0F);

            int var38;
            for(var38 = 0; var38 < 3; ++var38) {
               bbp var15 = null;
               if (var38 == 0) {
                  var15 = this.bA;
               }

               if (var38 == 1) {
                  var15 = this.bB;
               }

               if (var38 == 2) {
                  var15 = this.bC;
               }

               double[] var39 = this.a(12 + var38 * 2, 1.0F);
               float var17 = this.p * 0.017453292F + this.i(var39[0] - var37[0]) * 0.017453292F;
               float var40 = afm.a(var17);
               float var41 = afm.b(var17);
               var20 = 1.5F;
               var21 = (float)(var38 + 1) * 2.0F;
               this.a(var15, (double)(-(var8 * 1.5F + var40 * var21) * var33), var39[1] - var37[1] - (double)((var21 + 1.5F) * var6) + 1.5D, (double)((var35 * 1.5F + var41 * var21) * var33));
            }

            if (!this.l.v) {
               this.br = this.b(this.bo.cc()) | this.b(this.by.cc()) | this.b(this.bz.cc());
               if (this.bF != null) {
                  this.bF.b(this);
               }
            }

            for(var38 = 0; var38 < this.bx.length; ++var38) {
               this.bx[var38].m = var30[var38].b;
               this.bx[var38].n = var30[var38].c;
               this.bx[var38].o = var30[var38].d;
               this.bx[var38].D = var30[var38].b;
               this.bx[var38].E = var30[var38].c;
               this.bx[var38].F = var30[var38].d;
            }

         }
      }
   }

   private void a(bbp var1, double var2, double var4, double var6) {
      var1.d(this.cD() + var2, this.cE() + var4, this.cH() + var6);
   }

   private float eM() {
      if (this.bG.a().a()) {
         return -1.0F;
      } else {
         double[] var1 = this.a(5, 1.0F);
         double[] var2 = this.a(0, 1.0F);
         return (float)(var1[1] - var2[1]);
      }
   }

   private void eN() {
      if (this.bu != null) {
         if (this.bu.y) {
            this.bu = null;
         } else if (this.K % 10 == 0 && this.dk() < this.dx()) {
            this.c(this.dk() + 1.0F);
         }
      }

      if (this.J.nextInt(10) == 0) {
         List<bbq> var1 = this.l.a((Class)bbq.class, (dci)this.cc().g(32.0D));
         bbq var2 = null;
         double var3 = Double.MAX_VALUE;
         Iterator var5 = var1.iterator();

         while(var5.hasNext()) {
            bbq var6 = (bbq)var5.next();
            double var7 = var6.h(this);
            if (var7 < var3) {
               var3 = var7;
               var2 = var6;
            }
         }

         this.bu = var2;
      }

   }

   private void a(List<aqa> var1) {
      double var2 = (this.bz.cc().a + this.bz.cc().d) / 2.0D;
      double var4 = (this.bz.cc().c + this.bz.cc().f) / 2.0D;
      Iterator var6 = var1.iterator();

      while(var6.hasNext()) {
         aqa var7 = (aqa)var6.next();
         if (var7 instanceof aqm) {
            double var8 = var7.cD() - var2;
            double var10 = var7.cH() - var4;
            double var12 = Math.max(var8 * var8 + var10 * var10, 0.1D);
            var7.i(var8 / var12 * 4.0D, 0.20000000298023224D, var10 / var12 * 4.0D);
            if (!this.bG.a().a() && ((aqm)var7).da() < var7.K - 2) {
               var7.a(apk.c(this), 5.0F);
               this.a(this, var7);
            }
         }
      }

   }

   private void b(List<aqa> var1) {
      Iterator var2 = var1.iterator();

      while(var2.hasNext()) {
         aqa var3 = (aqa)var2.next();
         if (var3 instanceof aqm) {
            var3.a(apk.c(this), 10.0F);
            this.a(this, var3);
         }
      }

   }

   private float i(double var1) {
      return (float)afm.g(var1);
   }

   private boolean b(dci var1) {
      int var2 = afm.c(var1.a);
      int var3 = afm.c(var1.b);
      int var4 = afm.c(var1.c);
      int var5 = afm.c(var1.d);
      int var6 = afm.c(var1.e);
      int var7 = afm.c(var1.f);
      boolean var8 = false;
      boolean var9 = false;

      for(int var10 = var2; var10 <= var5; ++var10) {
         for(int var11 = var3; var11 <= var6; ++var11) {
            for(int var12 = var4; var12 <= var7; ++var12) {
               fx var13 = new fx(var10, var11, var12);
               ceh var14 = this.l.d_(var13);
               buo var15 = var14.b();
               if (!var14.g() && var14.c() != cva.n) {
                  if (this.l.V().b(brt.b) && !aed.ag.a(var15)) {
                     var9 = this.l.a(var13, false) || var9;
                  } else {
                     var8 = true;
                  }
               }
            }
         }
      }

      if (var9) {
         fx var16 = new fx(var2 + this.J.nextInt(var5 - var2 + 1), var3 + this.J.nextInt(var6 - var3 + 1), var4 + this.J.nextInt(var7 - var4 + 1));
         this.l.c(2008, var16, 0);
      }

      return var8;
   }

   public boolean a(bbp var1, apk var2, float var3) {
      if (this.bG.a().i() == bch.j) {
         return false;
      } else {
         var3 = this.bG.a().a(var2, var3);
         if (var1 != this.bo) {
            var3 = var3 / 4.0F + Math.min(var3, 1.0F);
         }

         if (var3 < 0.01F) {
            return false;
         } else {
            if (var2.k() instanceof bfw || var2.d()) {
               float var4 = this.dk();
               this.f(var2, var3);
               if (this.dl() && !this.bG.a().a()) {
                  this.c(1.0F);
                  this.bG.a(bch.j);
               }

               if (this.bG.a().a()) {
                  this.bI = (int)((float)this.bI + (var4 - this.dk()));
                  if ((float)this.bI > 0.25F * this.dx()) {
                     this.bI = 0;
                     this.bG.a(bch.e);
                  }
               }
            }

            return true;
         }
      }
   }

   public boolean a(apk var1, float var2) {
      if (var1 instanceof apl && ((apl)var1).y()) {
         this.a(this.bz, var1, var2);
      }

      return false;
   }

   protected boolean f(apk var1, float var2) {
      return super.a((apk)var1, var2);
   }

   public void aa() {
      this.ad();
      if (this.bF != null) {
         this.bF.b(this);
         this.bF.a(this);
      }

   }

   protected void cU() {
      if (this.bF != null) {
         this.bF.b(this);
      }

      ++this.bs;
      if (this.bs >= 180 && this.bs <= 200) {
         float var1 = (this.J.nextFloat() - 0.5F) * 8.0F;
         float var2 = (this.J.nextFloat() - 0.5F) * 4.0F;
         float var3 = (this.J.nextFloat() - 0.5F) * 8.0F;
         this.l.a(hh.v, this.cD() + (double)var1, this.cE() + 2.0D + (double)var2, this.cH() + (double)var3, 0.0D, 0.0D, 0.0D);
      }

      boolean var4 = this.l.V().b(brt.e);
      int var5 = 500;
      if (this.bF != null && !this.bF.d()) {
         var5 = 12000;
      }

      if (!this.l.v) {
         if (this.bs > 150 && this.bs % 5 == 0 && var4) {
            this.a(afm.d((float)var5 * 0.08F));
         }

         if (this.bs == 1 && !this.aA()) {
            this.l.b(1028, this.cB(), 0);
         }
      }

      this.a(aqr.a, new dcn(0.0D, 0.10000000149011612D, 0.0D));
      this.p += 20.0F;
      this.aA = this.p;
      if (this.bs == 200 && !this.l.v) {
         if (var4) {
            this.a(afm.d((float)var5 * 0.2F));
         }

         if (this.bF != null) {
            this.bF.a(this);
         }

         this.ad();
      }

   }

   private void a(int var1) {
      while(var1 > 0) {
         int var2 = aqg.a(var1);
         var1 -= var2;
         this.l.c((aqa)(new aqg(this.l, this.cD(), this.cE(), this.cH(), var2)));
      }

   }

   public int eI() {
      if (this.bJ[0] == null) {
         for(int var1 = 0; var1 < 24; ++var1) {
            int var2 = 5;
            int var4;
            int var5;
            if (var1 < 12) {
               var4 = afm.d(60.0F * afm.b(2.0F * (-3.1415927F + 0.2617994F * (float)var1)));
               var5 = afm.d(60.0F * afm.a(2.0F * (-3.1415927F + 0.2617994F * (float)var1)));
            } else {
               int var3;
               if (var1 < 20) {
                  var3 = var1 - 12;
                  var4 = afm.d(40.0F * afm.b(2.0F * (-3.1415927F + 0.3926991F * (float)var3)));
                  var5 = afm.d(40.0F * afm.a(2.0F * (-3.1415927F + 0.3926991F * (float)var3)));
                  var2 += 10;
               } else {
                  var3 = var1 - 20;
                  var4 = afm.d(20.0F * afm.b(2.0F * (-3.1415927F + 0.7853982F * (float)var3)));
                  var5 = afm.d(20.0F * afm.a(2.0F * (-3.1415927F + 0.7853982F * (float)var3)));
               }
            }

            int var6 = Math.max(this.l.t_() + 10, this.l.a((chn.a)chn.a.f, (fx)(new fx(var4, 0, var5))).v() + var2);
            this.bJ[var1] = new cxb(var4, var6, var5);
         }

         this.bK[0] = 6146;
         this.bK[1] = 8197;
         this.bK[2] = 8202;
         this.bK[3] = 16404;
         this.bK[4] = 32808;
         this.bK[5] = 32848;
         this.bK[6] = 65696;
         this.bK[7] = 131392;
         this.bK[8] = 131712;
         this.bK[9] = 263424;
         this.bK[10] = 526848;
         this.bK[11] = 525313;
         this.bK[12] = 1581057;
         this.bK[13] = 3166214;
         this.bK[14] = 2138120;
         this.bK[15] = 6373424;
         this.bK[16] = 4358208;
         this.bK[17] = 12910976;
         this.bK[18] = 9044480;
         this.bK[19] = 9706496;
         this.bK[20] = 15216640;
         this.bK[21] = 13688832;
         this.bK[22] = 11763712;
         this.bK[23] = 8257536;
      }

      return this.p(this.cD(), this.cE(), this.cH());
   }

   public int p(double var1, double var3, double var5) {
      float var7 = 10000.0F;
      int var8 = 0;
      cxb var9 = new cxb(afm.c(var1), afm.c(var3), afm.c(var5));
      int var10 = 0;
      if (this.bF == null || this.bF.c() == 0) {
         var10 = 12;
      }

      for(int var11 = var10; var11 < 24; ++var11) {
         if (this.bJ[var11] != null) {
            float var12 = this.bJ[var11].b(var9);
            if (var12 < var7) {
               var7 = var12;
               var8 = var11;
            }
         }
      }

      return var8;
   }

   @Nullable
   public cxd a(int var1, int var2, @Nullable cxb var3) {
      cxb var5;
      for(int var4 = 0; var4 < 24; ++var4) {
         var5 = this.bJ[var4];
         var5.i = false;
         var5.g = 0.0F;
         var5.e = 0.0F;
         var5.f = 0.0F;
         var5.h = null;
         var5.d = -1;
      }

      cxb var13 = this.bJ[var1];
      var5 = this.bJ[var2];
      var13.e = 0.0F;
      var13.f = var13.a(var5);
      var13.g = var13.f;
      this.bL.a();
      this.bL.a(var13);
      cxb var6 = var13;
      int var7 = 0;
      if (this.bF == null || this.bF.c() == 0) {
         var7 = 12;
      }

      while(!this.bL.e()) {
         cxb var8 = this.bL.c();
         if (var8.equals(var5)) {
            if (var3 != null) {
               var3.h = var5;
               var5 = var3;
            }

            return this.a(var13, var5);
         }

         if (var8.a(var5) < var6.a(var5)) {
            var6 = var8;
         }

         var8.i = true;
         int var9 = 0;

         int var10;
         for(var10 = 0; var10 < 24; ++var10) {
            if (this.bJ[var10] == var8) {
               var9 = var10;
               break;
            }
         }

         for(var10 = var7; var10 < 24; ++var10) {
            if ((this.bK[var9] & 1 << var10) > 0) {
               cxb var11 = this.bJ[var10];
               if (!var11.i) {
                  float var12 = var8.e + var8.a(var11);
                  if (!var11.c() || var12 < var11.e) {
                     var11.h = var8;
                     var11.e = var12;
                     var11.f = var11.a(var5);
                     if (var11.c()) {
                        this.bL.a(var11, var11.e + var11.f);
                     } else {
                        var11.g = var11.e + var11.f;
                        this.bL.a(var11);
                     }
                  }
               }
            }
         }
      }

      if (var6 == var13) {
         return null;
      } else {
         bv.debug("Failed to find path from {} to {}", var1, var2);
         if (var3 != null) {
            var3.h = var6;
            var6 = var3;
         }

         return this.a(var13, var6);
      }
   }

   private cxd a(cxb var1, cxb var2) {
      List<cxb> var3 = Lists.newArrayList();
      cxb var4 = var2;
      var3.add(0, var2);

      while(var4.h != null) {
         var4 = var4.h;
         var3.add(0, var4);
      }

      return new cxd(var3, new fx(var2.a, var2.b, var2.c), true);
   }

   public void b(md var1) {
      super.b(var1);
      var1.b("DragonPhase", this.bG.a().i().b());
   }

   public void a(md var1) {
      super.a(var1);
      if (var1.e("DragonPhase")) {
         this.bG.a(bch.a(var1.h("DragonPhase")));
      }

   }

   public void cI() {
   }

   public bbp[] eJ() {
      return this.bx;
   }

   public boolean aT() {
      return false;
   }

   public adr cu() {
      return adr.f;
   }

   protected adp I() {
      return adq.dp;
   }

   protected adp e(apk var1) {
      return adq.du;
   }

   protected float dG() {
      return 5.0F;
   }

   public float a(int var1, double[] var2, double[] var3) {
      bcb var4 = this.bG.a();
      bch<? extends bcb> var5 = var4.i();
      double var6;
      if (var5 != bch.d && var5 != bch.e) {
         if (var4.a()) {
            var6 = (double)var1;
         } else if (var1 == 6) {
            var6 = 0.0D;
         } else {
            var6 = var3[1] - var2[1];
         }
      } else {
         fx var8 = this.l.a((chn.a)chn.a.f, (fx)cjk.a);
         float var9 = Math.max(afm.a(var8.a(this.cA(), true)) / 4.0F, 1.0F);
         var6 = (double)((float)var1 / var9);
      }

      return (float)var6;
   }

   public dcn x(float var1) {
      bcb var2 = this.bG.a();
      bch<? extends bcb> var3 = var2.i();
      dcn var4;
      float var6;
      if (var3 != bch.d && var3 != bch.e) {
         if (var2.a()) {
            float var10 = this.q;
            var6 = 1.5F;
            this.q = -45.0F;
            var4 = this.f(var1);
            this.q = var10;
         } else {
            var4 = this.f(var1);
         }
      } else {
         fx var5 = this.l.a((chn.a)chn.a.f, (fx)cjk.a);
         var6 = Math.max(afm.a(var5.a(this.cA(), true)) / 4.0F, 1.0F);
         float var7 = 6.0F / var6;
         float var8 = this.q;
         float var9 = 1.5F;
         this.q = -var7 * 1.5F * 5.0F;
         var4 = this.f(var1);
         this.q = var8;
      }

      return var4;
   }

   public void a(bbq var1, fx var2, apk var3) {
      bfw var4;
      if (var3.k() instanceof bfw) {
         var4 = (bfw)var3.k();
      } else {
         var4 = this.l.a(bw, (double)var2.u(), (double)var2.v(), (double)var2.w());
      }

      if (var1 == this.bu) {
         this.a(this.bo, apk.d(var4), 10.0F);
      }

      this.bG.a().a(var1, var2, var3, var4);
   }

   public void a(us<?> var1) {
      if (b.equals(var1) && this.l.v) {
         this.bG.a(bch.a((Integer)this.ab().a(b)));
      }

      super.a((us)var1);
   }

   public bci eK() {
      return this.bG;
   }

   @Nullable
   public chg eL() {
      return this.bF;
   }

   public boolean c(apu var1) {
      return false;
   }

   protected boolean n(aqa var1) {
      return false;
   }

   public boolean bO() {
      return false;
   }

   static {
      b = uv.a(bbr.class, uu.b);
      bw = (new azg()).a(64.0D);
   }
}
