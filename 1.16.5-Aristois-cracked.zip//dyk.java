import com.mojang.blaze3d.systems.RenderSystem;

public interface dyk {
   dyk a = new dyk() {
      public void a(dfh var1, ekd var2) {
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         RenderSystem.depthMask(true);
         var2.a(ekb.d);
         var1.a(7, dfk.j);
      }

      public void a(dfo var1) {
         var1.b();
      }

      public String toString() {
         return "TERRAIN_SHEET";
      }
   };
   dyk b = new dyk() {
      public void a(dfh var1, ekd var2) {
         RenderSystem.disableBlend();
         RenderSystem.depthMask(true);
         var2.a(ekb.e);
         var1.a(7, dfk.j);
      }

      public void a(dfo var1) {
         var1.b();
      }

      public String toString() {
         return "PARTICLE_SHEET_OPAQUE";
      }
   };
   dyk c = new dyk() {
      public void a(dfh var1, ekd var2) {
         RenderSystem.depthMask(true);
         var2.a(ekb.e);
         RenderSystem.enableBlend();
         RenderSystem.blendFuncSeparate(dem.r.l, dem.j.j, dem.r.e, dem.j.j);
         RenderSystem.alphaFunc(516, 0.003921569F);
         var1.a(7, dfk.j);
      }

      public void a(dfo var1) {
         var1.b();
      }

      public String toString() {
         return "PARTICLE_SHEET_TRANSLUCENT";
      }
   };
   dyk d = new dyk() {
      public void a(dfh var1, ekd var2) {
         RenderSystem.disableBlend();
         RenderSystem.depthMask(true);
         var2.a(ekb.e);
         var1.a(7, dfk.j);
      }

      public void a(dfo var1) {
         var1.b();
      }

      public String toString() {
         return "PARTICLE_SHEET_LIT";
      }
   };
   dyk e = new dyk() {
      public void a(dfh var1, ekd var2) {
         RenderSystem.depthMask(true);
         RenderSystem.disableBlend();
      }

      public void a(dfo var1) {
      }

      public String toString() {
         return "CUSTOM";
      }
   };
   dyk f = new dyk() {
      public void a(dfh var1, ekd var2) {
      }

      public void a(dfo var1) {
      }

      public String toString() {
         return "NO_RENDER";
      }
   };

   void a(dfh var1, ekd var2);

   void a(dfo var1);
}
