import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class crr {
   private static final fx a = new fx(4, 0, 15);
   private static final vk[] b = new vk[]{new vk("shipwreck/with_mast"), new vk("shipwreck/sideways_full"), new vk("shipwreck/sideways_fronthalf"), new vk("shipwreck/sideways_backhalf"), new vk("shipwreck/rightsideup_full"), new vk("shipwreck/rightsideup_fronthalf"), new vk("shipwreck/rightsideup_backhalf"), new vk("shipwreck/with_mast_degraded"), new vk("shipwreck/rightsideup_full_degraded"), new vk("shipwreck/rightsideup_fronthalf_degraded"), new vk("shipwreck/rightsideup_backhalf_degraded")};
   private static final vk[] c = new vk[]{new vk("shipwreck/with_mast"), new vk("shipwreck/upsidedown_full"), new vk("shipwreck/upsidedown_fronthalf"), new vk("shipwreck/upsidedown_backhalf"), new vk("shipwreck/sideways_full"), new vk("shipwreck/sideways_fronthalf"), new vk("shipwreck/sideways_backhalf"), new vk("shipwreck/rightsideup_full"), new vk("shipwreck/rightsideup_fronthalf"), new vk("shipwreck/rightsideup_backhalf"), new vk("shipwreck/with_mast_degraded"), new vk("shipwreck/upsidedown_full_degraded"), new vk("shipwreck/upsidedown_fronthalf_degraded"), new vk("shipwreck/upsidedown_backhalf_degraded"), new vk("shipwreck/sideways_full_degraded"), new vk("shipwreck/sideways_fronthalf_degraded"), new vk("shipwreck/sideways_backhalf_degraded"), new vk("shipwreck/rightsideup_full_degraded"), new vk("shipwreck/rightsideup_fronthalf_degraded"), new vk("shipwreck/rightsideup_backhalf_degraded")};

   public static void a(csw var0, fx var1, bzm var2, List<cru> var3, Random var4, cms var5) {
      vk var6 = (vk)x.a((Object[])(var5.b ? b : c), (Random)var4);
      var3.add(new crr.a(var0, var6, var1, var2, var5.b));
   }

   public static class a extends crx {
      private final bzm d;
      private final vk e;
      private final boolean f;

      public a(csw var1, vk var2, fx var3, bzm var4, boolean var5) {
         super(clb.ab, 0);
         this.c = var3;
         this.d = var4;
         this.e = var2;
         this.f = var5;
         this.a(var1);
      }

      public a(csw var1, md var2) {
         super(clb.ab, var2);
         this.e = new vk(var2.l("Template"));
         this.f = var2.q("isBeached");
         this.d = bzm.valueOf(var2.l("Rot"));
         this.a(var1);
      }

      protected void a(md var1) {
         super.a(var1);
         var1.a("Template", this.e.toString());
         var1.a("isBeached", this.f);
         var1.a("Rot", this.d.name());
      }

      private void a(csw var1) {
         ctb var2 = var1.a(this.e);
         csx var3 = (new csx()).a(this.d).a(byg.a).a(crr.a).a((csy)cse.d);
         this.a(var2, this.c, var3);
      }

      protected void a(String var1, fx var2, bsk var3, Random var4, cra var5) {
         if ("map_chest".equals(var1)) {
            cdd.a(var3, var4, var2.c(), cyq.H);
         } else if ("treasure_chest".equals(var1)) {
            cdd.a(var3, var4, var2.c(), cyq.J);
         } else if ("supply_chest".equals(var1)) {
            cdd.a(var3, var4, var2.c(), cyq.I);
         }

      }

      public boolean a(bsr var1, bsn var2, cfy var3, Random var4, cra var5, brd var6, fx var7) {
         int var8 = 256;
         int var9 = 0;
         fx var10 = this.a.a();
         chn.a var11 = this.f ? chn.a.a : chn.a.c;
         int var12 = var10.u() * var10.w();
         if (var12 == 0) {
            var9 = var1.a(var11, this.c.u(), this.c.w());
         } else {
            fx var13 = this.c.b(var10.u() - 1, 0, var10.w() - 1);

            int var16;
            for(Iterator var14 = fx.a(this.c, var13).iterator(); var14.hasNext(); var8 = Math.min(var8, var16)) {
               fx var15 = (fx)var14.next();
               var16 = var1.a(var11, var15.u(), var15.w());
               var9 += var16;
            }

            var9 /= var12;
         }

         int var17 = this.f ? var8 - var10.v() / 2 - var4.nextInt(3) : var9;
         this.c = new fx(this.c.u(), var17, this.c.w());
         return super.a(var1, var2, var3, var4, var5, var6, var7);
      }
   }
}
