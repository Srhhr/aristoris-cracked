import java.util.Random;
import javax.annotation.Nullable;

public class awy extends awj {
   private final buo g;
   private final aqn h;
   private int i;

   public awy(buo var1, aqu var2, double var3, int var5) {
      super(var2, var3, 24, var5);
      this.g = var1;
      this.h = var2;
   }

   public boolean a() {
      if (!this.h.l.V().b(brt.b)) {
         return false;
      } else if (this.c > 0) {
         --this.c;
         return false;
      } else if (this.n()) {
         this.c = 20;
         return true;
      } else {
         this.c = this.a(this.a);
         return false;
      }
   }

   private boolean n() {
      return this.e != null && this.a((brz)this.a.l, (fx)this.e) ? true : this.m();
   }

   public void d() {
      super.d();
      this.h.C = 1.0F;
   }

   public void c() {
      super.c();
      this.i = 0;
   }

   public void a(bry var1, fx var2) {
   }

   public void a(brx var1, fx var2) {
   }

   public void e() {
      super.e();
      brx var1 = this.h.l;
      fx var2 = this.h.cB();
      fx var3 = this.a((fx)var2, (brc)var1);
      Random var4 = this.h.cY();
      if (this.l() && var3 != null) {
         dcn var5;
         double var6;
         if (this.i > 0) {
            var5 = this.h.cC();
            this.h.n(var5.b, 0.3D, var5.d);
            if (!var1.v) {
               var6 = 0.08D;
               ((aag)var1).a(new he(hh.I, new bmb(bmd.mg)), (double)var3.u() + 0.5D, (double)var3.v() + 0.7D, (double)var3.w() + 0.5D, 3, ((double)var4.nextFloat() - 0.5D) * 0.08D, ((double)var4.nextFloat() - 0.5D) * 0.08D, ((double)var4.nextFloat() - 0.5D) * 0.08D, 0.15000000596046448D);
            }
         }

         if (this.i % 2 == 0) {
            var5 = this.h.cC();
            this.h.n(var5.b, -0.3D, var5.d);
            if (this.i % 6 == 0) {
               this.a((bry)var1, (fx)this.e);
            }
         }

         if (this.i > 60) {
            var1.a(var3, false);
            if (!var1.v) {
               for(int var12 = 0; var12 < 20; ++var12) {
                  var6 = var4.nextGaussian() * 0.02D;
                  double var8 = var4.nextGaussian() * 0.02D;
                  double var10 = var4.nextGaussian() * 0.02D;
                  ((aag)var1).a(hh.P, (double)var3.u() + 0.5D, (double)var3.v(), (double)var3.w() + 0.5D, 1, var6, var8, var10, 0.15000000596046448D);
               }

               this.a(var1, var3);
            }
         }

         ++this.i;
      }

   }

   @Nullable
   private fx a(fx var1, brc var2) {
      if (var2.d_(var1).a(this.g)) {
         return var1;
      } else {
         fx[] var3 = new fx[]{var1.c(), var1.f(), var1.g(), var1.d(), var1.e(), var1.c().c()};
         fx[] var4 = var3;
         int var5 = var3.length;

         for(int var6 = 0; var6 < var5; ++var6) {
            fx var7 = var4[var6];
            if (var2.d_(var7).a(this.g)) {
               return var7;
            }
         }

         return null;
      }
   }

   protected boolean a(brz var1, fx var2) {
      cfw var3 = var1.a(var2.u() >> 4, var2.w() >> 4, cga.m, false);
      if (var3 == null) {
         return false;
      } else {
         return var3.d_(var2).a(this.g) && var3.d_(var2.b()).g() && var3.d_(var2.b(2)).g();
      }
   }
}
