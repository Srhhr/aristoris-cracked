import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class dhl {
   private static final Logger a = LogManager.getLogger();
   private final ScheduledExecutorService b = Executors.newScheduledThreadPool(3);
   private volatile boolean c = true;
   private final Runnable d = new dhl.c();
   private final Runnable e = new dhl.b();
   private final Runnable f = new dhl.e();
   private final Runnable g = new dhl.a();
   private final Runnable h = new dhl.f();
   private final Set<dgq> i = Sets.newHashSet();
   private List<dgq> j = Lists.newArrayList();
   private dgv k;
   private int l;
   private boolean m;
   private boolean n;
   private String o;
   private ScheduledFuture<?> p;
   private ScheduledFuture<?> q;
   private ScheduledFuture<?> r;
   private ScheduledFuture<?> s;
   private ScheduledFuture<?> t;
   private final Map<dhl.d, Boolean> u = new ConcurrentHashMap(dhl.d.values().length);

   public boolean a() {
      return this.c;
   }

   public synchronized void b() {
      if (this.c) {
         this.c = false;
         this.o();
         this.n();
      }

   }

   public synchronized void c() {
      if (this.c) {
         this.c = false;
         this.o();
         this.u.put(dhl.d.b, false);
         this.q = this.b.scheduleAtFixedRate(this.e, 0L, 10L, TimeUnit.SECONDS);
         this.u.put(dhl.d.c, false);
         this.r = this.b.scheduleAtFixedRate(this.f, 0L, 60L, TimeUnit.SECONDS);
         this.u.put(dhl.d.e, false);
         this.t = this.b.scheduleAtFixedRate(this.h, 0L, 300L, TimeUnit.SECONDS);
      }

   }

   public boolean a(dhl.d var1) {
      Boolean var2 = (Boolean)this.u.get(var1);
      return var2 == null ? false : var2;
   }

   public void d() {
      Iterator var1 = this.u.keySet().iterator();

      while(var1.hasNext()) {
         dhl.d var2 = (dhl.d)var1.next();
         this.u.put(var2, false);
      }

   }

   public synchronized void e() {
      this.l();
      this.b();
   }

   public synchronized List<dgq> f() {
      return Lists.newArrayList(this.j);
   }

   public synchronized int g() {
      return this.l;
   }

   public synchronized boolean h() {
      return this.m;
   }

   public synchronized dgv i() {
      return this.k;
   }

   public synchronized boolean j() {
      return this.n;
   }

   public synchronized String k() {
      return this.o;
   }

   public synchronized void l() {
      this.c = true;
      this.o();
   }

   private void n() {
      dhl.d[] var1 = dhl.d.values();
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         dhl.d var4 = var1[var3];
         this.u.put(var4, false);
      }

      this.p = this.b.scheduleAtFixedRate(this.d, 0L, 60L, TimeUnit.SECONDS);
      this.q = this.b.scheduleAtFixedRate(this.e, 0L, 10L, TimeUnit.SECONDS);
      this.r = this.b.scheduleAtFixedRate(this.f, 0L, 60L, TimeUnit.SECONDS);
      this.s = this.b.scheduleAtFixedRate(this.g, 0L, 10L, TimeUnit.SECONDS);
      this.t = this.b.scheduleAtFixedRate(this.h, 0L, 300L, TimeUnit.SECONDS);
   }

   private void o() {
      try {
         if (this.p != null) {
            this.p.cancel(false);
         }

         if (this.q != null) {
            this.q.cancel(false);
         }

         if (this.r != null) {
            this.r.cancel(false);
         }

         if (this.s != null) {
            this.s.cancel(false);
         }

         if (this.t != null) {
            this.t.cancel(false);
         }
      } catch (Exception var2) {
         a.error("Failed to cancel Realms tasks", var2);
      }

   }

   private synchronized void a(List<dgq> var1) {
      int var2 = 0;
      Iterator var3 = this.i.iterator();

      while(var3.hasNext()) {
         dgq var4 = (dgq)var3.next();
         if (var1.remove(var4)) {
            ++var2;
         }
      }

      if (var2 == 0) {
         this.i.clear();
      }

      this.j = var1;
   }

   public synchronized void a(dgq var1) {
      this.j.remove(var1);
      this.i.add(var1);
   }

   private boolean p() {
      return !this.c;
   }

   public static enum d {
      a,
      b,
      c,
      d,
      e;
   }

   class f implements Runnable {
      private f() {
      }

      public void run() {
         if (dhl.this.p()) {
            this.a();
         }

      }

      private void a() {
         try {
            dgb var1 = dgb.a();
            dgp var2 = null;

            try {
               var2 = var1.m();
            } catch (Exception var5) {
            }

            diq.a var3 = diq.a();
            if (var2 != null) {
               String var4 = var2.a;
               if (var4 != null && !var4.equals(var3.a)) {
                  var3.b = true;
                  var3.a = var4;
                  diq.a(var3);
               }
            }

            dhl.this.n = var3.b;
            dhl.this.o = var3.a;
            dhl.this.u.put(dhl.d.e, true);
         } catch (Exception var6) {
            dhl.a.error("Couldn't get unread news", var6);
         }

      }

      // $FF: synthetic method
      f(Object var2) {
         this();
      }
   }

   class a implements Runnable {
      private a() {
      }

      public void run() {
         if (dhl.this.p()) {
            this.a();
         }

      }

      private void a() {
         try {
            dgb var1 = dgb.a();
            dhl.this.k = var1.f();
            dhl.this.u.put(dhl.d.d, true);
         } catch (Exception var2) {
            dhl.a.error("Couldn't get live stats", var2);
         }

      }

      // $FF: synthetic method
      a(Object var2) {
         this();
      }
   }

   class e implements Runnable {
      private e() {
      }

      public void run() {
         if (dhl.this.p()) {
            this.a();
         }

      }

      private void a() {
         try {
            dgb var1 = dgb.a();
            dhl.this.m = var1.n();
            dhl.this.u.put(dhl.d.c, true);
         } catch (Exception var2) {
            dhl.a.error("Couldn't get trial availability", var2);
         }

      }

      // $FF: synthetic method
      e(Object var2) {
         this();
      }
   }

   class b implements Runnable {
      private b() {
      }

      public void run() {
         if (dhl.this.p()) {
            this.a();
         }

      }

      private void a() {
         try {
            dgb var1 = dgb.a();
            dhl.this.l = var1.j();
            dhl.this.u.put(dhl.d.b, true);
         } catch (Exception var2) {
            dhl.a.error("Couldn't get pending invite count", var2);
         }

      }

      // $FF: synthetic method
      b(Object var2) {
         this();
      }
   }

   class c implements Runnable {
      private c() {
      }

      public void run() {
         if (dhl.this.p()) {
            this.a();
         }

      }

      private void a() {
         try {
            dgb var1 = dgb.a();
            List<dgq> var2 = var1.e().a;
            if (var2 != null) {
               var2.sort(new dgq.a(djz.C().J().c()));
               dhl.this.a(var2);
               dhl.this.u.put(dhl.d.a, true);
            } else {
               dhl.a.warn("Realms server list was null or empty");
            }
         } catch (Exception var3) {
            dhl.this.u.put(dhl.d.a, true);
            dhl.a.error("Couldn't get server list", var3);
         }

      }

      // $FF: synthetic method
      c(Object var2) {
         this();
      }
   }
}
