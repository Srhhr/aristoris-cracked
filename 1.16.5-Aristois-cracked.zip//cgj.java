import javax.annotation.Nullable;

public interface cgj {
   @Nullable
   brc c(int var1, int var2);

   default void a(bsf var1, gp var2) {
   }

   brc m();
}
