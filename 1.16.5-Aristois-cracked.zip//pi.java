import java.io.IOException;

public class pi implements oj<om> {
   private int a;
   private int b;
   private bmb c;

   public pi() {
      this.c = bmb.b;
   }

   public pi(int var1, int var2, bmb var3) {
      this.c = bmb.b;
      this.a = var1;
      this.b = var2;
      this.c = var3.i();
   }

   public void a(om var1) {
      var1.a(this);
   }

   public void a(nf var1) throws IOException {
      this.a = var1.readByte();
      this.b = var1.readShort();
      this.c = var1.n();
   }

   public void b(nf var1) throws IOException {
      var1.writeByte(this.a);
      var1.writeShort(this.b);
      var1.a(this.c);
   }

   public int b() {
      return this.a;
   }

   public int c() {
      return this.b;
   }

   public bmb d() {
      return this.c;
   }
}
