public class bkc extends blx {
   public bkc(blx.a var1) {
      super(var1);
   }

   public bga a(brx var1, bmb var2, aqm var3) {
      bgc var4 = new bgc(var1, var3);
      var4.b(var2);
      return var4;
   }
}
