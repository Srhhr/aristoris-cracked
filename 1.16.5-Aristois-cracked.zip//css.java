import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Random;

public class css extends csu {
   public static final Codec<css> a = RecordCodecBuilder.create((var0) -> {
      return var0.group(ceh.b.fieldOf("block_state").forGetter((var0x) -> {
         return var0x.b;
      }), Codec.FLOAT.fieldOf("probability").forGetter((var0x) -> {
         return var0x.d;
      })).apply(var0, css::new);
   });
   private final ceh b;
   private final float d;

   public css(ceh var1, float var2) {
      this.b = var1;
      this.d = var2;
   }

   public boolean a(ceh var1, Random var2) {
      return var1 == this.b && var2.nextFloat() < this.d;
   }

   protected csv<?> a() {
      return csv.f;
   }
}
