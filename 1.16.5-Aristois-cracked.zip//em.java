public interface em {
   dcn a(db var1);

   dcm b(db var1);

   default fx c(db var1) {
      return new fx(this.a(var1));
   }

   boolean a();

   boolean b();

   boolean c();
}
