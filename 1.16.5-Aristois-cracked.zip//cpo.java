import com.mojang.serialization.Codec;
import java.util.Random;
import java.util.stream.Stream;

public class cpo<DC extends clw> implements chk<cpo<?>> {
   public static final Codec<cpo<?>> a;
   private final cqc<DC> b;
   private final DC c;

   public cpo(cqc<DC> var1, DC var2) {
      this.b = var1;
      this.c = var2;
   }

   public Stream<fx> a(cpv var1, Random var2, fx var3) {
      return this.b.a(var1, var2, this.c, var3);
   }

   public String toString() {
      return String.format("[%s %s]", gm.aK.b((Object)this.b), this.c);
   }

   public cpo<?> b(cpo<?> var1) {
      return new cpo(cqc.B, new cpu(var1, this));
   }

   public DC b() {
      return this.c;
   }

   // $FF: synthetic method
   public Object a(cpo var1) {
      return this.b(var1);
   }

   static {
      a = gm.aK.dispatch("type", (var0) -> {
         return var0.b;
      }, cqc::a);
   }
}
