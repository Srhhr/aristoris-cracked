public interface cvj<R extends cvf> extends cvk {
   void a(long var1, long var3);

   R a(cwv var1);

   default R a(cwv var1, R var2) {
      return this.a(var1);
   }

   default R a(cwv var1, R var2, R var3) {
      return this.a(var1);
   }

   default int a(int var1, int var2) {
      return this.a(2) == 0 ? var1 : var2;
   }

   default int a(int var1, int var2, int var3, int var4) {
      int var5 = this.a(4);
      if (var5 == 0) {
         return var1;
      } else if (var5 == 1) {
         return var2;
      } else {
         return var5 == 2 ? var3 : var4;
      }
   }
}
