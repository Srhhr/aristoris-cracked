public class dyl extends dzb {
   private final dyw a;

   private dyl(dwt var1, double var2, double var4, double var6, double var8, double var10, double var12, dyw var14) {
      super(var1, var2, var4, var6, 0.0D, 0.0D, 0.0D);
      this.a = var14;
      float var15 = 2.5F;
      this.j *= 0.10000000149011612D;
      this.k *= 0.10000000149011612D;
      this.l *= 0.10000000149011612D;
      this.j += var8;
      this.k += var10;
      this.l += var12;
      float var16 = 1.0F - (float)(Math.random() * 0.30000001192092896D);
      this.v = var16;
      this.w = var16;
      this.x = var16;
      this.B *= 1.875F;
      int var17 = (int)(8.0D / (Math.random() * 0.8D + 0.3D));
      this.t = (int)Math.max((float)var17 * 2.5F, 1.0F);
      this.n = false;
      this.b(var14);
   }

   public dyk b() {
      return dyk.c;
   }

   public float b(float var1) {
      return this.B * afm.a(((float)this.s + var1) / (float)this.t * 32.0F, 0.0F, 1.0F);
   }

   public void a() {
      this.d = this.g;
      this.e = this.h;
      this.f = this.i;
      if (this.s++ >= this.t) {
         this.j();
      } else {
         this.b(this.a);
         this.a(this.j, this.k, this.l);
         this.j *= 0.9599999785423279D;
         this.k *= 0.9599999785423279D;
         this.l *= 0.9599999785423279D;
         bfw var1 = this.c.a(this.g, this.h, this.i, 2.0D, false);
         if (var1 != null) {
            double var2 = var1.cE();
            if (this.h > var2) {
               this.h += (var2 - this.h) * 0.2D;
               this.k += (var1.cC().c - this.k) * 0.2D;
               this.b(this.g, this.h, this.i);
            }
         }

         if (this.m) {
            this.j *= 0.699999988079071D;
            this.l *= 0.699999988079071D;
         }

      }
   }

   // $FF: synthetic method
   dyl(dwt var1, double var2, double var4, double var6, double var8, double var10, double var12, dyw var14, Object var15) {
      this(var1, var2, var4, var6, var8, var10, var12, var14);
   }

   public static class b implements dyj<hi> {
      private final dyw a;

      public b(dyw var1) {
         this.a = var1;
      }

      public dyg a(hi var1, dwt var2, double var3, double var5, double var7, double var9, double var11, double var13) {
         dyg var15 = new dyl(var2, var3, var5, var7, var9, var11, var13, this.a);
         var15.a(200.0F, 50.0F, 120.0F);
         var15.e(0.4F);
         return var15;
      }
   }

   public static class a implements dyj<hi> {
      private final dyw a;

      public a(dyw var1) {
         this.a = var1;
      }

      public dyg a(hi var1, dwt var2, double var3, double var5, double var7, double var9, double var11, double var13) {
         return new dyl(var2, var3, var5, var7, var9, var11, var13, this.a);
      }
   }
}
