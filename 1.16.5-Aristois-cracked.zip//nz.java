import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;

public class nz extends nn implements nt {
   private final String d;
   @Nullable
   private final fc e;
   private final String f;

   @Nullable
   private static fc d(String var0) {
      try {
         return (new fd(new StringReader(var0))).t();
      } catch (CommandSyntaxException var2) {
         return null;
      }
   }

   public nz(String var1, String var2) {
      this(var1, d(var1), var2);
   }

   private nz(String var1, @Nullable fc var2, String var3) {
      this.d = var1;
      this.e = var2;
      this.f = var3;
   }

   public String h() {
      return this.d;
   }

   public String j() {
      return this.f;
   }

   private String a(db var1) throws CommandSyntaxException {
      if (this.e != null) {
         List<? extends aqa> var2 = this.e.b(var1);
         if (!var2.isEmpty()) {
            if (var2.size() != 1) {
               throw dk.a.create();
            }

            return ((aqa)var2.get(0)).bU();
         }
      }

      return this.d;
   }

   private String a(String var1, db var2) {
      MinecraftServer var3 = var2.j();
      if (var3 != null) {
         ddn var4 = var3.aH();
         ddk var5 = var4.d(this.f);
         if (var4.b(var1, var5)) {
            ddm var6 = var4.c(var1, var5);
            return Integer.toString(var6.b());
         }
      }

      return "";
   }

   public nz k() {
      return new nz(this.d, this.e, this.f);
   }

   public nx a(@Nullable db var1, @Nullable aqa var2, int var3) throws CommandSyntaxException {
      if (var1 == null) {
         return new oe("");
      } else {
         String var4 = this.a(var1);
         String var5 = var2 != null && var4.equals("*") ? var2.bU() : var4;
         return new oe(this.a(var5, var1));
      }
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof nz)) {
         return false;
      } else {
         nz var2 = (nz)var1;
         return this.d.equals(var2.d) && this.f.equals(var2.f) && super.equals(var1);
      }
   }

   public String toString() {
      return "ScoreComponent{name='" + this.d + '\'' + "objective='" + this.f + '\'' + ", siblings=" + this.a + ", style=" + this.c() + '}';
   }

   // $FF: synthetic method
   public nn d() {
      return this.k();
   }

   // $FF: synthetic method
   public nx g() {
      return this.k();
   }
}
