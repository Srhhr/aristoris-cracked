public class ccv extends ccj implements cdc, cdm {
   public float a;
   public float b;
   public int c;
   private int g;

   public ccv() {
      super(cck.d);
   }

   public void aj_() {
      if (++this.g % 20 * 4 == 0) {
         this.d.a(this.e, (buo)bup.ek, 1, this.c);
      }

      this.b = this.a;
      int var1 = this.e.u();
      int var2 = this.e.v();
      int var3 = this.e.w();
      float var4 = 0.1F;
      double var7;
      if (this.c > 0 && this.a == 0.0F) {
         double var5 = (double)var1 + 0.5D;
         var7 = (double)var3 + 0.5D;
         this.d.a((bfw)null, var5, (double)var2 + 0.5D, var7, adq.do, adr.e, 0.5F, this.d.t.nextFloat() * 0.1F + 0.9F);
      }

      if (this.c == 0 && this.a > 0.0F || this.c > 0 && this.a < 1.0F) {
         float var11 = this.a;
         if (this.c > 0) {
            this.a += 0.1F;
         } else {
            this.a -= 0.1F;
         }

         if (this.a > 1.0F) {
            this.a = 1.0F;
         }

         float var6 = 0.5F;
         if (this.a < 0.5F && var11 >= 0.5F) {
            var7 = (double)var1 + 0.5D;
            double var9 = (double)var3 + 0.5D;
            this.d.a((bfw)null, var7, (double)var2 + 0.5D, var9, adq.dn, adr.e, 0.5F, this.d.t.nextFloat() * 0.1F + 0.9F);
         }

         if (this.a < 0.0F) {
            this.a = 0.0F;
         }
      }

   }

   public boolean a_(int var1, int var2) {
      if (var1 == 1) {
         this.c = var2;
         return true;
      } else {
         return super.a_(var1, var2);
      }
   }

   public void al_() {
      this.s();
      super.al_();
   }

   public void d() {
      ++this.c;
      this.d.a(this.e, (buo)bup.ek, 1, this.c);
   }

   public void f() {
      --this.c;
      this.d.a(this.e, (buo)bup.ek, 1, this.c);
   }

   public boolean a(bfw var1) {
      if (this.d.c(this.e) != this) {
         return false;
      } else {
         return !(var1.h((double)this.e.u() + 0.5D, (double)this.e.v() + 0.5D, (double)this.e.w() + 0.5D) > 64.0D);
      }
   }

   public float a(float var1) {
      return afm.g(var1, this.b, this.a);
   }
}
