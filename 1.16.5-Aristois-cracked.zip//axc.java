import java.util.EnumSet;
import java.util.Random;
import java.util.function.ToDoubleFunction;
import javax.annotation.Nullable;

public class axc extends avv {
   private final aqu a;
   private final int b;
   @Nullable
   private fx c;

   public axc(aqu var1, int var2) {
      this.a = var1;
      this.b = var2;
      this.a(EnumSet.of(avv.a.a));
   }

   public boolean a() {
      if (this.a.bs()) {
         return false;
      } else if (this.a.l.M()) {
         return false;
      } else if (this.a.cY().nextInt(this.b) != 0) {
         return false;
      } else {
         aag var1 = (aag)this.a.l;
         fx var2 = this.a.cB();
         if (!var1.a((fx)var2, (int)6)) {
            return false;
         } else {
            dcn var3 = azj.a((aqu)this.a, 15, 7, (ToDoubleFunction)((var1x) -> {
               return (double)(-var1.b(gp.a(var1x)));
            }));
            this.c = var3 == null ? null : new fx(var3);
            return this.c != null;
         }
      }
   }

   public boolean b() {
      return this.c != null && !this.a.x().m() && this.a.x().h().equals(this.c);
   }

   public void e() {
      if (this.c != null) {
         ayj var1 = this.a.x();
         if (var1.m() && !this.c.a(this.a.cA(), 10.0D)) {
            dcn var2 = dcn.c((gr)this.c);
            dcn var3 = this.a.cA();
            dcn var4 = var3.d(var2);
            var2 = var4.a(0.4D).e(var2);
            dcn var5 = var2.d(var3).d().a(10.0D).e(var3);
            fx var6 = new fx(var5);
            var6 = this.a.l.a((chn.a)chn.a.f, (fx)var6);
            if (!var1.a((double)var6.u(), (double)var6.v(), (double)var6.w(), 1.0D)) {
               this.g();
            }
         }

      }
   }

   private void g() {
      Random var1 = this.a.cY();
      fx var2 = this.a.l.a((chn.a)chn.a.f, (fx)this.a.cB().b(-8 + var1.nextInt(16), 0, -8 + var1.nextInt(16)));
      this.a.x().a((double)var2.u(), (double)var2.v(), (double)var2.w(), 1.0D);
   }
}
