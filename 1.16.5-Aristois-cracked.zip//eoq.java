import com.google.common.util.concurrent.RateLimiter;
import java.time.Duration;
import java.util.concurrent.atomic.AtomicReference;

public class eoq {
   private final float a;
   private final AtomicReference<eoq.a> b = new AtomicReference();

   public eoq(Duration var1) {
      this.a = 1000.0F / (float)var1.toMillis();
   }

   public void a(String var1) {
      eoq.a var2 = (eoq.a)this.b.updateAndGet((var2x) -> {
         return var2x != null && var1.equals(var2x.a) ? var2x : new eoq.a(var1, RateLimiter.create((double)this.a));
      });
      if (var2.b.tryAcquire(1)) {
         dkz.b.a(no.b, new oe(var1), x.b);
      }

   }

   static class a {
      private final String a;
      private final RateLimiter b;

      a(String var1, RateLimiter var2) {
         this.a = var1;
         this.b = var2;
      }
   }
}
