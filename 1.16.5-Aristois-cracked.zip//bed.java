import com.google.common.collect.Sets;
import com.google.common.collect.UnmodifiableIterator;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;
import javax.annotation.Nullable;

public class bed extends azz implements aqk, ara {
   private static final bon bo;
   private static final bon bp;
   private static final us<Integer> bq;
   private static final us<Boolean> br;
   private static final us<Boolean> bs;
   private final aqj bt;
   private axf bu;
   private awp bv;

   public bed(aqe<? extends bed> var1, brx var2) {
      super(var1, var2);
      this.bt = new aqj(this.R, bq, bs);
      this.i = true;
      this.a(cwz.h, -1.0F);
      this.a(cwz.g, 0.0F);
      this.a(cwz.l, 0.0F);
      this.a(cwz.m, 0.0F);
   }

   public static boolean c(aqe<bed> var0, bry var1, aqp var2, fx var3, Random var4) {
      fx.a var5 = var3.i();

      do {
         var5.c(gc.b);
      } while(var1.b(var5).a(aef.c));

      return var1.d_(var5).g();
   }

   public void a(us<?> var1) {
      if (bq.equals(var1) && this.l.v) {
         this.bt.a();
      }

      super.a((us)var1);
   }

   protected void e() {
      super.e();
      this.R.a((us)bq, (int)0);
      this.R.a((us)br, (Object)false);
      this.R.a((us)bs, (Object)false);
   }

   public void b(md var1) {
      super.b(var1);
      this.bt.a(var1);
   }

   public void a(md var1) {
      super.a(var1);
      this.bt.b(var1);
   }

   public boolean M_() {
      return this.bt.b();
   }

   public boolean L_() {
      return this.aX() && !this.w_();
   }

   public void a(@Nullable adr var1) {
      this.bt.a(true);
      if (var1 != null) {
         this.l.a((bfw)null, (aqa)this, adq.oi, var1, 0.5F, 1.0F);
      }

   }

   protected void o() {
      this.bv = new awp(this, 1.65D);
      this.bk.a(1, this.bv);
      this.bk.a(2, new avi(this, 1.0D));
      this.bu = new axf(this, 1.4D, false, bp);
      this.bk.a(3, this.bu);
      this.bk.a(4, new bed.a(this, 1.5D));
      this.bk.a(5, new avu(this, 1.1D));
      this.bk.a(7, new awt(this, 1.0D, 60));
      this.bk.a(8, new awd(this, bfw.class, 8.0F));
      this.bk.a(8, new aws(this));
      this.bk.a(9, new awd(this, bed.class, 8.0F));
   }

   public void t(boolean var1) {
      this.R.b(br, var1);
   }

   public boolean eK() {
      return this.ct() instanceof bed ? ((bed)this.ct()).eK() : (Boolean)this.R.a(br);
   }

   public boolean a(cuw var1) {
      return var1.a((ael)aef.c);
   }

   public double bc() {
      float var1 = Math.min(0.25F, this.av);
      float var2 = this.aw;
      return (double)this.cz() - 0.19D + (double)(0.12F * afm.b(var2 * 1.5F) * 2.0F * var1);
   }

   public boolean er() {
      aqa var1 = this.cm();
      if (!(var1 instanceof bfw)) {
         return false;
      } else {
         bfw var2 = (bfw)var1;
         return var2.dD().b() == bmd.pl || var2.dE().b() == bmd.pl;
      }
   }

   public boolean a(brz var1) {
      return var1.j(this);
   }

   @Nullable
   public aqa cm() {
      return this.cn().isEmpty() ? null : (aqa)this.cn().get(0);
   }

   public dcn b(aqm var1) {
      dcn[] var2 = new dcn[]{a((double)this.cy(), (double)var1.cy(), var1.p), a((double)this.cy(), (double)var1.cy(), var1.p - 22.5F), a((double)this.cy(), (double)var1.cy(), var1.p + 22.5F), a((double)this.cy(), (double)var1.cy(), var1.p - 45.0F), a((double)this.cy(), (double)var1.cy(), var1.p + 45.0F)};
      Set<fx> var3 = Sets.newLinkedHashSet();
      double var4 = this.cc().e;
      double var6 = this.cc().b - 0.5D;
      fx.a var8 = new fx.a();
      dcn[] var9 = var2;
      int var10 = var2.length;

      for(int var11 = 0; var11 < var10; ++var11) {
         dcn var12 = var9[var11];
         var8.c(this.cD() + var12.b, var4, this.cH() + var12.d);

         for(double var13 = var4; var13 > var6; --var13) {
            var3.add(var8.h());
            var8.c(gc.a);
         }
      }

      Iterator var17 = var3.iterator();

      while(true) {
         fx var18;
         double var19;
         do {
            do {
               if (!var17.hasNext()) {
                  return new dcn(this.cD(), this.cc().e, this.cH());
               }

               var18 = (fx)var17.next();
            } while(this.l.b(var18).a(aef.c));

            var19 = this.l.h(var18);
         } while(!bho.a(var19));

         dcn var20 = dcn.a((gr)var18, var19);
         UnmodifiableIterator var14 = var1.ej().iterator();

         while(var14.hasNext()) {
            aqx var15 = (aqx)var14.next();
            dci var16 = var1.f(var15);
            if (bho.a(this.l, var1, var16.c(var20))) {
               var1.b((aqx)var15);
               return var20;
            }
         }
      }
   }

   public void g(dcn var1) {
      this.q(this.eL());
      this.a(this, this.bt, var1);
   }

   public float eL() {
      return (float)this.b((arg)arl.d) * (this.eK() ? 0.66F : 1.0F);
   }

   public float N_() {
      return (float)this.b((arg)arl.d) * (this.eK() ? 0.23F : 0.55F);
   }

   public void a_(dcn var1) {
      super.g(var1);
   }

   protected float at() {
      return this.B + 0.6F;
   }

   protected void b(fx var1, ceh var2) {
      this.a(this.aQ() ? adq.og : adq.of, 1.0F, 1.0F);
   }

   public boolean O_() {
      return this.bt.a(this.cY());
   }

   protected void a(double var1, boolean var3, ceh var4, fx var5) {
      this.ay();
      if (this.aQ()) {
         this.C = 0.0F;
      } else {
         super.a(var1, var3, var4, var5);
      }
   }

   public void j() {
      if (this.eO() && this.J.nextInt(140) == 0) {
         this.a(adq.ob, 1.0F, this.dH());
      } else if (this.eN() && this.J.nextInt(60) == 0) {
         this.a(adq.oc, 1.0F, this.dH());
      }

      ceh var1 = this.l.d_(this.cB());
      ceh var2 = this.aN();
      boolean var3 = var1.a(aed.ax) || var2.a(aed.ax) || this.b((ael)aef.c) > 0.0D;
      this.t(!var3);
      super.j();
      this.eU();
      this.ay();
   }

   private boolean eN() {
      return this.bv != null && this.bv.h();
   }

   private boolean eO() {
      return this.bu != null && this.bu.h();
   }

   protected boolean q() {
      return true;
   }

   private void eU() {
      if (this.aQ()) {
         dcs var1 = dcs.a((aqa)this);
         if (var1.a(byb.c, this.cB(), true) && !this.l.b(this.cB().b()).a(aef.c)) {
            this.t = true;
         } else {
            this.f(this.cC().a(0.5D).b(0.0D, 0.05D, 0.0D));
         }
      }

   }

   public static ark.a eM() {
      return aqn.p().a(arl.d, 0.17499999701976776D).a(arl.b, 16.0D);
   }

   protected adp I() {
      return !this.eN() && !this.eO() ? adq.oa : null;
   }

   protected adp e(apk var1) {
      return adq.oe;
   }

   protected adp dq() {
      return adq.od;
   }

   protected boolean q(aqa var1) {
      return this.cn().isEmpty() && !this.a((ael)aef.c);
   }

   public boolean dO() {
      return true;
   }

   public boolean bq() {
      return false;
   }

   protected ayj b(brx var1) {
      return new bed.b(this, var1);
   }

   public float a(fx var1, brz var2) {
      if (var2.d_(var1).m().a(aef.c)) {
         return 10.0F;
      } else {
         return this.aQ() ? Float.NEGATIVE_INFINITY : 0.0F;
      }
   }

   public bed b(aag var1, apy var2) {
      return (bed)aqe.aF.a((brx)var1);
   }

   public boolean k(bmb var1) {
      return bo.a(var1);
   }

   protected void dn() {
      super.dn();
      if (this.M_()) {
         this.a((brw)bmd.lO);
      }

   }

   public aou b(bfw var1, aot var2) {
      boolean var3 = this.k(var1.b((aot)var2));
      if (!var3 && this.M_() && !this.bs() && !var1.eq()) {
         if (!this.l.v) {
            var1.m(this);
         }

         return aou.a(this.l.v);
      } else {
         aou var4 = super.b(var1, var2);
         if (!var4.a()) {
            bmb var5 = var1.b((aot)var2);
            return var5.b() == bmd.lO ? var5.a((bfw)var1, (aqm)this, (aot)var2) : aou.c;
         } else {
            if (var3 && !this.aA()) {
               this.l.a((bfw)null, this.cD(), this.cE(), this.cH(), adq.oh, this.cu(), 1.0F, 1.0F + (this.J.nextFloat() - this.J.nextFloat()) * 0.2F);
            }

            return var4;
         }
      }
   }

   public dcn cf() {
      return new dcn(0.0D, (double)(0.6F * this.ce()), (double)(this.cy() * 0.4F));
   }

   @Nullable
   public arc a(bsk var1, aos var2, aqp var3, @Nullable arc var4, @Nullable md var5) {
      if (this.w_()) {
         return super.a(var1, var2, var3, var4, var5);
      } else {
         Object var7;
         if (this.J.nextInt(30) == 0) {
            aqn var6 = (aqn)aqe.bb.a((brx)var1.E());
            var7 = this.a(var1, var2, var6, new bej.b(bej.a(this.J), false));
            var6.a(aqf.a, new bmb(bmd.pl));
            this.a((adr)null);
         } else if (this.J.nextInt(10) == 0) {
            apy var8 = (apy)aqe.aF.a((brx)var1.E());
            var8.c_(-24000);
            var7 = this.a(var1, var2, var8, (arc)null);
         } else {
            var7 = new apy.a(0.5F);
         }

         return super.a(var1, var2, var3, (arc)var7, var5);
      }
   }

   private arc a(bsk var1, aos var2, aqn var3, @Nullable arc var4) {
      var3.b(this.cD(), this.cE(), this.cH(), this.p, 0.0F);
      var3.a((bsk)var1, (aos)var2, aqp.g, (arc)var4, (md)null);
      var3.a((aqa)this, true);
      return new apy.a(0.0F);
   }

   // $FF: synthetic method
   public apy a(aag var1, apy var2) {
      return this.b(var1, var2);
   }

   static {
      bo = bon.a(bmd.bx);
      bp = bon.a(bmd.bx, bmd.pl);
      bq = uv.a(bed.class, uu.b);
      br = uv.a(bed.class, uu.i);
      bs = uv.a(bed.class, uu.i);
   }

   static class a extends awj {
      private final bed g;

      private a(bed var1, double var2) {
         super(var1, var2, 8, 2);
         this.g = var1;
      }

      public fx j() {
         return this.e;
      }

      public boolean b() {
         return !this.g.aQ() && this.a(this.g.l, this.e);
      }

      public boolean a() {
         return !this.g.aQ() && super.a();
      }

      public boolean k() {
         return this.d % 20 == 0;
      }

      protected boolean a(brz var1, fx var2) {
         return var1.d_(var2).a(bup.B) && var1.d_(var2.b()).a(var1, var2, cxe.a);
      }

      // $FF: synthetic method
      a(bed var1, double var2, Object var4) {
         this(var1, var2);
      }
   }

   static class b extends ayi {
      b(bed var1, brx var2) {
         super(var1, var2);
      }

      protected cxf a(int var1) {
         this.o = new cxj();
         return new cxf(this.o, var1);
      }

      protected boolean a(cwz var1) {
         return var1 != cwz.g && var1 != cwz.m && var1 != cwz.l ? super.a(var1) : true;
      }

      public boolean a(fx var1) {
         return this.b.d_(var1).a(bup.B) || super.a(var1);
      }
   }
}
