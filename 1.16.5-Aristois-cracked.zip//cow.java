import com.google.common.collect.Lists;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import java.util.Set;

public class cow extends cpb {
   public static final Codec<cow> a = RecordCodecBuilder.create((var0) -> {
      return a(var0).apply(var0, cow::new);
   });

   public cow(int var1, int var2, int var3) {
      super(var1, var2, var3);
   }

   protected cpc<?> a() {
      return cpc.f;
   }

   public List<cnl.b> a(bsb var1, Random var2, int var3, fx var4, Set<fx> var5, cra var6, cmz var7) {
      int var8 = true;
      int var9 = var3 + 2;
      int var10 = afm.c((double)var9 * 0.618D);
      if (!var7.e) {
         a(var1, var4.c());
      }

      double var11 = 1.0D;
      int var13 = Math.min(1, afm.c(1.382D + Math.pow(1.0D * (double)var9 / 13.0D, 2.0D)));
      int var14 = var4.v() + var10;
      int var15 = var9 - 5;
      List<cow.a> var16 = Lists.newArrayList();
      var16.add(new cow.a(var4.b(var15), var14));

      for(; var15 >= 0; --var15) {
         float var17 = this.b(var9, var15);
         if (!(var17 < 0.0F)) {
            for(int var18 = 0; var18 < var13; ++var18) {
               double var19 = 1.0D;
               double var21 = 1.0D * (double)var17 * ((double)var2.nextFloat() + 0.328D);
               double var23 = (double)(var2.nextFloat() * 2.0F) * 3.141592653589793D;
               double var25 = var21 * Math.sin(var23) + 0.5D;
               double var27 = var21 * Math.cos(var23) + 0.5D;
               fx var29 = var4.a(var25, (double)(var15 - 1), var27);
               fx var30 = var29.b(5);
               if (this.a(var1, var2, var29, var30, false, var5, var6, var7)) {
                  int var31 = var4.u() - var29.u();
                  int var32 = var4.w() - var29.w();
                  double var33 = (double)var29.v() - Math.sqrt((double)(var31 * var31 + var32 * var32)) * 0.381D;
                  int var35 = var33 > (double)var14 ? var14 : (int)var33;
                  fx var36 = new fx(var4.u(), var35, var4.w());
                  if (this.a(var1, var2, var36, var29, false, var5, var6, var7)) {
                     var16.add(new cow.a(var29, var36.v()));
                  }
               }
            }
         }
      }

      this.a(var1, var2, var4, var4.b(var10), true, var5, var6, var7);
      this.a(var1, var2, var9, var4, var16, var5, var6, var7);
      List<cnl.b> var37 = Lists.newArrayList();
      Iterator var38 = var16.iterator();

      while(var38.hasNext()) {
         cow.a var39 = (cow.a)var38.next();
         if (this.a(var9, var39.a() - var4.v())) {
            var37.add(var39.a);
         }
      }

      return var37;
   }

   private boolean a(bsb var1, Random var2, fx var3, fx var4, boolean var5, Set<fx> var6, cra var7, cmz var8) {
      if (!var5 && Objects.equals(var3, var4)) {
         return true;
      } else {
         fx var9 = var4.b(-var3.u(), -var3.v(), -var3.w());
         int var10 = this.a(var9);
         float var11 = (float)var9.u() / (float)var10;
         float var12 = (float)var9.v() / (float)var10;
         float var13 = (float)var9.w() / (float)var10;

         for(int var14 = 0; var14 <= var10; ++var14) {
            fx var15 = var3.a((double)(0.5F + (float)var14 * var11), (double)(0.5F + (float)var14 * var12), (double)(0.5F + (float)var14 * var13));
            if (var5) {
               a(var1, var15, (ceh)var8.b.a(var2, var15).a(bzl.e, this.a(var3, var15)), var7);
               var6.add(var15.h());
            } else if (!cld.c(var1, var15)) {
               return false;
            }
         }

         return true;
      }
   }

   private int a(fx var1) {
      int var2 = afm.a(var1.u());
      int var3 = afm.a(var1.v());
      int var4 = afm.a(var1.w());
      return Math.max(var2, Math.max(var3, var4));
   }

   private gc.a a(fx var1, fx var2) {
      gc.a var3 = gc.a.b;
      int var4 = Math.abs(var2.u() - var1.u());
      int var5 = Math.abs(var2.w() - var1.w());
      int var6 = Math.max(var4, var5);
      if (var6 > 0) {
         if (var4 == var6) {
            var3 = gc.a.a;
         } else {
            var3 = gc.a.c;
         }
      }

      return var3;
   }

   private boolean a(int var1, int var2) {
      return (double)var2 >= (double)var1 * 0.2D;
   }

   private void a(bsb var1, Random var2, int var3, fx var4, List<cow.a> var5, Set<fx> var6, cra var7, cmz var8) {
      Iterator var9 = var5.iterator();

      while(var9.hasNext()) {
         cow.a var10 = (cow.a)var9.next();
         int var11 = var10.a();
         fx var12 = new fx(var4.u(), var11, var4.w());
         if (!var12.equals(var10.a.a()) && this.a(var3, var11 - var4.v())) {
            this.a(var1, var2, var12, var10.a.a(), true, var6, var7, var8);
         }
      }

   }

   private float b(int var1, int var2) {
      if ((float)var2 < (float)var1 * 0.3F) {
         return -1.0F;
      } else {
         float var3 = (float)var1 / 2.0F;
         float var4 = var3 - (float)var2;
         float var5 = afm.c(var3 * var3 - var4 * var4);
         if (var4 == 0.0F) {
            var5 = var3;
         } else if (Math.abs(var4) >= var3) {
            return 0.0F;
         }

         return var5 * 0.5F;
      }
   }

   static class a {
      private final cnl.b a;
      private final int b;

      public a(fx var1, int var2) {
         this.a = new cnl.b(var1, 0, false);
         this.b = var2;
      }

      public int a() {
         return this.b;
      }
   }
}
