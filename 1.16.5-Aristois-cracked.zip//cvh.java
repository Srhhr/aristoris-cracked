import it.unimi.dsi.fastutil.longs.Long2IntLinkedOpenHashMap;

public final class cvh implements cvf {
   private final cwv a;
   private final Long2IntLinkedOpenHashMap b;
   private final int c;

   public cvh(Long2IntLinkedOpenHashMap var1, int var2, cwv var3) {
      this.b = var1;
      this.c = var2;
      this.a = var3;
   }

   public int a(int var1, int var2) {
      long var3 = brd.a(var1, var2);
      synchronized(this.b) {
         int var6 = this.b.get(var3);
         if (var6 != Integer.MIN_VALUE) {
            return var6;
         } else {
            int var7 = this.a.apply(var1, var2);
            this.b.put(var3, var7);
            if (this.b.size() > this.c) {
               for(int var8 = 0; var8 < this.c / 16; ++var8) {
                  this.b.removeFirstInt();
               }
            }

            return var7;
         }
      }
   }

   public int a() {
      return this.c;
   }
}
