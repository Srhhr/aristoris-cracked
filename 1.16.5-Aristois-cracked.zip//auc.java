import com.google.common.collect.ImmutableMap;
import java.util.List;
import java.util.Optional;
import javax.annotation.Nullable;

public class auc extends arv<bfj> {
   private final ayd<List<gf>> b;
   private final ayd<gf> c;
   private final float d;
   private final int e;
   private final int f;
   private long g;
   @Nullable
   private gf h;

   public auc(ayd<List<gf>> var1, float var2, int var3, int var4, ayd<gf> var5) {
      super(ImmutableMap.of(ayd.m, aye.c, var1, aye.a, var5, aye.a));
      this.b = var1;
      this.d = var2;
      this.e = var3;
      this.f = var4;
      this.c = var5;
   }

   protected boolean a(aag var1, bfj var2) {
      Optional<List<gf>> var3 = var2.cJ().c(this.b);
      Optional<gf> var4 = var2.cJ().c(this.c);
      if (var3.isPresent() && var4.isPresent()) {
         List<gf> var5 = (List)var3.get();
         if (!var5.isEmpty()) {
            this.h = (gf)var5.get(var1.u_().nextInt(var5.size()));
            return this.h != null && var1.Y() == this.h.a() && ((gf)var4.get()).b().a(var2.cA(), (double)this.f);
         }
      }

      return false;
   }

   protected void a(aag var1, bfj var2, long var3) {
      if (var3 > this.g && this.h != null) {
         var2.cJ().a((ayd)ayd.m, (Object)(new ayf(this.h.b(), this.d, this.e)));
         this.g = var3 + 100L;
      }

   }
}
