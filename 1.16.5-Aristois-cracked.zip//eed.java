public class eed extends eeu<bhn> {
   private static final vk[] e = new vk[]{new vk("textures/entity/boat/oak.png"), new vk("textures/entity/boat/spruce.png"), new vk("textures/entity/boat/birch.png"), new vk("textures/entity/boat/jungle.png"), new vk("textures/entity/boat/acacia.png"), new vk("textures/entity/boat/dark_oak.png")};
   protected final dtn a = new dtn();

   public eed(eet var1) {
      super(var1);
      this.c = 0.8F;
   }

   public void a(bhn var1, float var2, float var3, dfm var4, eag var5, int var6) {
      var4.a();
      var4.a(0.0D, 0.375D, 0.0D);
      var4.a(g.d.a(180.0F - var2));
      float var7 = (float)var1.n() - var3;
      float var8 = var1.m() - var3;
      if (var8 < 0.0F) {
         var8 = 0.0F;
      }

      if (var7 > 0.0F) {
         var4.a(g.b.a(afm.a(var7) * var7 * var8 / 10.0F * (float)var1.o()));
      }

      float var9 = var1.b(var3);
      if (!afm.a(var9, 0.0F)) {
         var4.a(new d(new g(1.0F, 0.0F, 1.0F), var1.b(var3), true));
      }

      var4.a(-1.0F, -1.0F, 1.0F);
      var4.a(g.d.a(90.0F));
      this.a.a(var1, var3, 0.0F, -0.1F, 0.0F, 0.0F);
      dfq var10 = var5.getBuffer(this.a.a(this.a(var1)));
      this.a.a(var4, var10, var6, ejw.a, 1.0F, 1.0F, 1.0F, 1.0F);
      if (!var1.aI()) {
         dfq var11 = var5.getBuffer(eao.j());
         this.a.c().a(var4, var11, var6, ejw.a);
      }

      var4.b();
      super.a(var1, var2, var3, var4, var5, var6);
   }

   public vk a(bhn var1) {
      return e[var1.p().ordinal()];
   }
}
