import com.google.common.collect.Sets;
import java.util.Collection;
import java.util.Iterator;
import java.util.Set;

public class bgc extends bga {
   private static final us<Integer> f;
   private bnt g;
   private final Set<apu> ag;
   private boolean ah;

   public bgc(aqe<? extends bgc> var1, brx var2) {
      super(var1, var2);
      this.g = bnw.a;
      this.ag = Sets.newHashSet();
   }

   public bgc(brx var1, double var2, double var4, double var6) {
      super(aqe.c, var2, var4, var6, var1);
      this.g = bnw.a;
      this.ag = Sets.newHashSet();
   }

   public bgc(brx var1, aqm var2) {
      super(aqe.c, var2, var1);
      this.g = bnw.a;
      this.ag = Sets.newHashSet();
   }

   public void b(bmb var1) {
      if (var1.b() == bmd.ql) {
         this.g = bnv.d(var1);
         Collection<apu> var2 = bnv.b(var1);
         if (!var2.isEmpty()) {
            Iterator var3 = var2.iterator();

            while(var3.hasNext()) {
               apu var4 = (apu)var3.next();
               this.ag.add(new apu(var4));
            }
         }

         int var5 = c(var1);
         if (var5 == -1) {
            this.z();
         } else {
            this.c(var5);
         }
      } else if (var1.b() == bmd.kd) {
         this.g = bnw.a;
         this.ag.clear();
         this.R.b(f, -1);
      }

   }

   public static int c(bmb var0) {
      md var1 = var0.o();
      return var1 != null && var1.c("CustomPotionColor", 99) ? var1.h("CustomPotionColor") : -1;
   }

   private void z() {
      this.ah = false;
      if (this.g == bnw.a && this.ag.isEmpty()) {
         this.R.b(f, -1);
      } else {
         this.R.b(f, bnv.a((Collection)bnv.a((bnt)this.g, (Collection)this.ag)));
      }

   }

   public void a(apu var1) {
      this.ag.add(var1);
      this.ab().b(f, bnv.a((Collection)bnv.a((bnt)this.g, (Collection)this.ag)));
   }

   protected void e() {
      super.e();
      this.R.a((us)f, (int)-1);
   }

   public void j() {
      super.j();
      if (this.l.v) {
         if (this.b) {
            if (this.c % 5 == 0) {
               this.b(1);
            }
         } else {
            this.b(2);
         }
      } else if (this.b && this.c != 0 && !this.ag.isEmpty() && this.c >= 600) {
         this.l.a(this, (byte)0);
         this.g = bnw.a;
         this.ag.clear();
         this.R.b(f, -1);
      }

   }

   private void b(int var1) {
      int var2 = this.u();
      if (var2 != -1 && var1 > 0) {
         double var3 = (double)(var2 >> 16 & 255) / 255.0D;
         double var5 = (double)(var2 >> 8 & 255) / 255.0D;
         double var7 = (double)(var2 >> 0 & 255) / 255.0D;

         for(int var9 = 0; var9 < var1; ++var9) {
            this.l.a(hh.u, this.d(0.5D), this.cF(), this.g(0.5D), var3, var5, var7);
         }

      }
   }

   public int u() {
      return (Integer)this.R.a(f);
   }

   private void c(int var1) {
      this.ah = true;
      this.R.b(f, var1);
   }

   public void b(md var1) {
      super.b(var1);
      if (this.g != bnw.a && this.g != null) {
         var1.a("Potion", gm.U.b((Object)this.g).toString());
      }

      if (this.ah) {
         var1.b("Color", this.u());
      }

      if (!this.ag.isEmpty()) {
         mj var2 = new mj();
         Iterator var3 = this.ag.iterator();

         while(var3.hasNext()) {
            apu var4 = (apu)var3.next();
            var2.add(var4.a(new md()));
         }

         var1.a((String)"CustomPotionEffects", (mt)var2);
      }

   }

   public void a(md var1) {
      super.a(var1);
      if (var1.c("Potion", 8)) {
         this.g = bnv.c(var1);
      }

      Iterator var2 = bnv.b(var1).iterator();

      while(var2.hasNext()) {
         apu var3 = (apu)var2.next();
         this.a(var3);
      }

      if (var1.c("Color", 99)) {
         this.c(var1.h("Color"));
      } else {
         this.z();
      }

   }

   protected void a(aqm var1) {
      super.a(var1);
      Iterator var2 = this.g.a().iterator();

      apu var3;
      while(var2.hasNext()) {
         var3 = (apu)var2.next();
         var1.c(new apu(var3.a(), Math.max(var3.b() / 8, 1), var3.c(), var3.d(), var3.e()));
      }

      if (!this.ag.isEmpty()) {
         var2 = this.ag.iterator();

         while(var2.hasNext()) {
            var3 = (apu)var2.next();
            var1.c(var3);
         }
      }

   }

   protected bmb m() {
      if (this.ag.isEmpty() && this.g == bnw.a) {
         return new bmb(bmd.kd);
      } else {
         bmb var1 = new bmb(bmd.ql);
         bnv.a(var1, this.g);
         bnv.a((bmb)var1, (Collection)this.ag);
         if (this.ah) {
            var1.p().b("CustomPotionColor", this.u());
         }

         return var1;
      }
   }

   public void a(byte var1) {
      if (var1 == 0) {
         int var2 = this.u();
         if (var2 != -1) {
            double var3 = (double)(var2 >> 16 & 255) / 255.0D;
            double var5 = (double)(var2 >> 8 & 255) / 255.0D;
            double var7 = (double)(var2 >> 0 & 255) / 255.0D;

            for(int var9 = 0; var9 < 20; ++var9) {
               this.l.a(hh.u, this.d(0.5D), this.cF(), this.g(0.5D), var3, var5, var7);
            }
         }
      } else {
         super.a(var1);
      }

   }

   static {
      f = uv.a(bgc.class, uu.b);
   }
}
