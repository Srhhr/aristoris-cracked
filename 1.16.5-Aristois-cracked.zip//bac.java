public class bac extends azz {
   private static final bon bv;
   public float bo;
   public float bp;
   public float bq;
   public float br;
   public float bs = 1.0F;
   public int bt;
   public boolean bu;

   public bac(aqe<? extends bac> var1, brx var2) {
      super(var1, var2);
      this.bt = this.J.nextInt(6000) + 6000;
      this.a(cwz.h, 0.0F);
   }

   protected void o() {
      this.bk.a(0, new avp(this));
      this.bk.a(1, new awp(this, 1.4D));
      this.bk.a(2, new avi(this, 1.0D));
      this.bk.a(3, new axf(this, 1.0D, false, bv));
      this.bk.a(4, new avu(this, 1.1D));
      this.bk.a(5, new axk(this, 1.0D));
      this.bk.a(6, new awd(this, bfw.class, 6.0F));
      this.bk.a(7, new aws(this));
   }

   protected float b(aqx var1, aqb var2) {
      return this.w_() ? var2.b * 0.85F : var2.b * 0.92F;
   }

   public static ark.a eK() {
      return aqn.p().a(arl.a, 4.0D).a(arl.d, 0.25D);
   }

   public void k() {
      super.k();
      this.br = this.bo;
      this.bq = this.bp;
      this.bp = (float)((double)this.bp + (double)(this.t ? -1 : 4) * 0.3D);
      this.bp = afm.a(this.bp, 0.0F, 1.0F);
      if (!this.t && this.bs < 1.0F) {
         this.bs = 1.0F;
      }

      this.bs = (float)((double)this.bs * 0.9D);
      dcn var1 = this.cC();
      if (!this.t && var1.c < 0.0D) {
         this.f(var1.d(1.0D, 0.6D, 1.0D));
      }

      this.bo += this.bs * 2.0F;
      if (!this.l.v && this.aX() && !this.w_() && !this.eL() && --this.bt <= 0) {
         this.a(adq.bJ, 1.0F, (this.J.nextFloat() - this.J.nextFloat()) * 0.2F + 1.0F);
         this.a(bmd.mg);
         this.bt = this.J.nextInt(6000) + 6000;
      }

   }

   public boolean b(float var1, float var2) {
      return false;
   }

   protected adp I() {
      return adq.bH;
   }

   protected adp e(apk var1) {
      return adq.bK;
   }

   protected adp dq() {
      return adq.bI;
   }

   protected void b(fx var1, ceh var2) {
      this.a(adq.bL, 0.15F, 1.0F);
   }

   public bac b(aag var1, apy var2) {
      return (bac)aqe.j.a((brx)var1);
   }

   public boolean k(bmb var1) {
      return bv.a(var1);
   }

   protected int d(bfw var1) {
      return this.eL() ? 10 : super.d(var1);
   }

   public void a(md var1) {
      super.a(var1);
      this.bu = var1.q("IsChickenJockey");
      if (var1.e("EggLayTime")) {
         this.bt = var1.h("EggLayTime");
      }

   }

   public void b(md var1) {
      super.b(var1);
      var1.a("IsChickenJockey", this.bu);
      var1.b("EggLayTime", this.bt);
   }

   public boolean h(double var1) {
      return this.eL();
   }

   public void k(aqa var1) {
      super.k(var1);
      float var2 = afm.a(this.aA * 0.017453292F);
      float var3 = afm.b(this.aA * 0.017453292F);
      float var4 = 0.1F;
      float var5 = 0.0F;
      var1.d(this.cD() + (double)(0.1F * var2), this.e(0.5D) + var1.bb() + 0.0D, this.cH() - (double)(0.1F * var3));
      if (var1 instanceof aqm) {
         ((aqm)var1).aA = this.aA;
      }

   }

   public boolean eL() {
      return this.bu;
   }

   public void t(boolean var1) {
      this.bu = var1;
   }

   // $FF: synthetic method
   public apy a(aag var1, apy var2) {
      return this.b(var1, var2);
   }

   static {
      bv = bon.a(bmd.kV, bmd.nk, bmd.nj, bmd.qg);
   }
}
