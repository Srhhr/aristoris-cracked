import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import java.lang.reflect.Type;
import java.util.Random;

public final class cyr implements czb {
   private final int d;

   public cyr(int var1) {
      this.d = var1;
   }

   public int a(Random var1) {
      return this.d;
   }

   public vk a() {
      return a;
   }

   public static cyr a(int var0) {
      return new cyr(var0);
   }

   public static class a implements JsonDeserializer<cyr>, JsonSerializer<cyr> {
      public cyr a(JsonElement var1, Type var2, JsonDeserializationContext var3) throws JsonParseException {
         return new cyr(afd.g(var1, "value"));
      }

      public JsonElement a(cyr var1, Type var2, JsonSerializationContext var3) {
         return new JsonPrimitive(var1.d);
      }

      // $FF: synthetic method
      public JsonElement serialize(Object var1, Type var2, JsonSerializationContext var3) {
         return this.a((cyr)var1, var2, var3);
      }

      // $FF: synthetic method
      public Object deserialize(JsonElement var1, Type var2, JsonDeserializationContext var3) throws JsonParseException {
         return this.a(var1, var2, var3);
      }
   }
}
