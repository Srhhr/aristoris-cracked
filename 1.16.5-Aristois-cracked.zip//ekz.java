import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;
import java.util.stream.Stream;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ekz implements aci {
   private static final Logger a = LogManager.getLogger();
   private static final eky b = new eky("en_us", "US", "English", false);
   private Map<String, eky> c;
   private String d;
   private eky e;

   public ekz(String var1) {
      this.c = ImmutableMap.of("en_us", b);
      this.e = b;
      this.d = var1;
   }

   private static Map<String, eky> a(Stream<abj> var0) {
      Map<String, eky> var1 = Maps.newHashMap();
      var0.forEach((var1x) -> {
         try {
            elh var2 = (elh)var1x.a((abn)elh.a);
            if (var2 != null) {
               Iterator var3 = var2.a().iterator();

               while(var3.hasNext()) {
                  eky var4 = (eky)var3.next();
                  var1.putIfAbsent(var4.getCode(), var4);
               }
            }
         } catch (IOException | RuntimeException var5) {
            a.warn("Unable to parse language metadata section of resourcepack: {}", var1x.a(), var5);
         }

      });
      return ImmutableMap.copyOf(var1);
   }

   public void a(ach var1) {
      this.c = a(var1.b());
      eky var2 = (eky)this.c.getOrDefault("en_us", b);
      this.e = (eky)this.c.getOrDefault(this.d, var2);
      List<eky> var3 = Lists.newArrayList(new eky[]{var2});
      if (this.e != var2) {
         var3.add(this.e);
      }

      ekv var4 = ekv.a((ach)var1, (List)var3);
      ekx.a((ly)var4);
      ly.a((ly)var4);
   }

   public void a(eky var1) {
      this.d = var1.getCode();
      this.e = var1;
   }

   public eky b() {
      return this.e;
   }

   public SortedSet<eky> d() {
      return Sets.newTreeSet(this.c.values());
   }

   public eky a(String var1) {
      return (eky)this.c.get(var1);
   }
}
