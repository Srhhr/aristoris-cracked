public class dhr extends eoo {
   private static final nr a = new of("mco.client.outdated.title");
   private static final nr[] b = new nr[]{new of("mco.client.outdated.msg.line1"), new of("mco.client.outdated.msg.line2")};
   private static final nr c = new of("mco.client.incompatible.title");
   private static final nr[] p = new nr[]{new of("mco.client.incompatible.msg.line1"), new of("mco.client.incompatible.msg.line2"), new of("mco.client.incompatible.msg.line3")};
   private final dot q;
   private final boolean r;

   public dhr(dot var1, boolean var2) {
      this.q = var1;
      this.r = var2;
   }

   public void b() {
      this.a(new dlj(this.k / 2 - 100, j(12), 200, 20, nq.h, (var1) -> {
         this.i.a(this.q);
      }));
   }

   public void a(dfm var1, int var2, int var3, float var4) {
      this.a(var1);
      nr var5;
      nr[] var6;
      if (this.r) {
         var5 = c;
         var6 = p;
      } else {
         var5 = a;
         var6 = b;
      }

      a(var1, this.o, var5, this.k / 2, j(3), 16711680);

      for(int var7 = 0; var7 < var6.length; ++var7) {
         a(var1, this.o, var6[var7], this.k / 2, j(5) + var7 * 12, 16777215);
      }

      super.a(var1, var2, var3, var4);
   }

   public boolean a(int var1, int var2, int var3) {
      if (var1 != 257 && var1 != 335 && var1 != 256) {
         return super.a(var1, var2, var3);
      } else {
         this.i.a(this.q);
         return true;
      }
   }
}
