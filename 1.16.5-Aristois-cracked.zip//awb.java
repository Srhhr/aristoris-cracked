import java.util.EnumSet;

public class awb extends avv {
   private final aqn a;
   private aqm b;
   private final float c;

   public awb(aqn var1, float var2) {
      this.a = var1;
      this.c = var2;
      this.a(EnumSet.of(avv.a.c, avv.a.a));
   }

   public boolean a() {
      if (this.a.bs()) {
         return false;
      } else {
         this.b = this.a.A();
         if (this.b == null) {
            return false;
         } else {
            double var1 = this.a.h((aqa)this.b);
            if (!(var1 < 4.0D) && !(var1 > 16.0D)) {
               if (!this.a.ao()) {
                  return false;
               } else {
                  return this.a.cY().nextInt(5) == 0;
               }
            } else {
               return false;
            }
         }
      }
   }

   public boolean b() {
      return !this.a.ao();
   }

   public void c() {
      dcn var1 = this.a.cC();
      dcn var2 = new dcn(this.b.cD() - this.a.cD(), 0.0D, this.b.cH() - this.a.cH());
      if (var2.g() > 1.0E-7D) {
         var2 = var2.d().a(0.4D).e(var1.a(0.2D));
      }

      this.a.n(var2.b, (double)this.c, var2.d);
   }
}
