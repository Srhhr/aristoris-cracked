import com.google.common.collect.Lists;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.util.Iterator;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class dgl extends dhc {
   private static final Logger b = LogManager.getLogger();
   public List<dgk> a = Lists.newArrayList();

   public static dgl a(String var0) {
      dgl var1 = new dgl();

      try {
         JsonParser var2 = new JsonParser();
         JsonObject var3 = var2.parse(var0).getAsJsonObject();
         if (var3.get("invites").isJsonArray()) {
            Iterator var4 = var3.get("invites").getAsJsonArray().iterator();

            while(var4.hasNext()) {
               var1.a.add(dgk.a(((JsonElement)var4.next()).getAsJsonObject()));
            }
         }
      } catch (Exception var5) {
         b.error("Could not parse PendingInvitesList: " + var5.getMessage());
      }

      return var1;
   }
}
