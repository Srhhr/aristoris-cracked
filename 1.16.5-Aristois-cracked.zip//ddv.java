import com.google.common.collect.Sets;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.util.Set;
import javax.annotation.Nullable;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.openal.AL;
import org.lwjgl.openal.AL10;
import org.lwjgl.openal.ALC;
import org.lwjgl.openal.ALC10;
import org.lwjgl.openal.ALCCapabilities;
import org.lwjgl.openal.ALCapabilities;
import org.lwjgl.system.MemoryStack;

public class ddv {
   private static final Logger a = LogManager.getLogger();
   private long b;
   private long c;
   private static final ddv.a d = new ddv.a() {
      @Nullable
      public ddu a() {
         return null;
      }

      public boolean a(ddu var1) {
         return false;
      }

      public void b() {
      }

      public int c() {
         return 0;
      }

      public int d() {
         return 0;
      }
   };
   private ddv.a e;
   private ddv.a f;
   private final ddw g;

   public ddv() {
      this.e = d;
      this.f = d;
      this.g = new ddw();
   }

   public void a() {
      this.b = g();
      ALCCapabilities var1 = ALC.createCapabilities(this.b);
      if (ddy.a(this.b, "Get capabilities")) {
         throw new IllegalStateException("Failed to get OpenAL capabilities");
      } else if (!var1.OpenALC11) {
         throw new IllegalStateException("OpenAL 1.1 not supported");
      } else {
         this.c = ALC10.alcCreateContext(this.b, (IntBuffer)null);
         ALC10.alcMakeContextCurrent(this.c);
         int var2 = this.f();
         int var3 = afm.a((int)afm.c((float)var2), 2, 8);
         int var4 = afm.a(var2 - var3, 8, 255);
         this.e = new ddv.b(var4);
         this.f = new ddv.b(var3);
         ALCapabilities var5 = AL.createCapabilities(var1);
         ddy.a("Initialization");
         if (!var5.AL_EXT_source_distance_model) {
            throw new IllegalStateException("AL_EXT_source_distance_model is not supported");
         } else {
            AL10.alEnable(512);
            if (!var5.AL_EXT_LINEAR_DISTANCE) {
               throw new IllegalStateException("AL_EXT_LINEAR_DISTANCE is not supported");
            } else {
               ddy.a("Enable per-source distance models");
               a.info("OpenAL initialized.");
            }
         }
      }
   }

   private int f() {
      MemoryStack var1 = MemoryStack.stackPush();
      Throwable var2 = null;

      try {
         int var3 = ALC10.alcGetInteger(this.b, 4098);
         if (ddy.a(this.b, "Get attributes size")) {
            throw new IllegalStateException("Failed to get OpenAL attributes");
         }

         IntBuffer var4 = var1.mallocInt(var3);
         ALC10.alcGetIntegerv(this.b, 4099, var4);
         if (ddy.a(this.b, "Get attributes")) {
            throw new IllegalStateException("Failed to get OpenAL attributes");
         }

         int var5 = 0;

         while(var5 < var3) {
            int var6 = var4.get(var5++);
            if (var6 == 0) {
               break;
            }

            int var7 = var4.get(var5++);
            if (var6 == 4112) {
               int var8 = var7;
               return var8;
            }
         }
      } catch (Throwable var18) {
         var2 = var18;
         throw var18;
      } finally {
         if (var1 != null) {
            if (var2 != null) {
               try {
                  var1.close();
               } catch (Throwable var17) {
                  var2.addSuppressed(var17);
               }
            } else {
               var1.close();
            }
         }

      }

      return 30;
   }

   private static long g() {
      for(int var0 = 0; var0 < 3; ++var0) {
         long var1 = ALC10.alcOpenDevice((ByteBuffer)null);
         if (var1 != 0L && !ddy.a(var1, "Open device")) {
            return var1;
         }
      }

      throw new IllegalStateException("Failed to open OpenAL device");
   }

   public void b() {
      this.e.b();
      this.f.b();
      ALC10.alcDestroyContext(this.c);
      if (this.b != 0L) {
         ALC10.alcCloseDevice(this.b);
      }

   }

   public ddw c() {
      return this.g;
   }

   @Nullable
   public ddu a(ddv.c var1) {
      return (var1 == ddv.c.b ? this.f : this.e).a();
   }

   public void a(ddu var1) {
      if (!this.e.a(var1) && !this.f.a(var1)) {
         throw new IllegalStateException("Tried to release unknown channel");
      }
   }

   public String d() {
      return String.format("Sounds: %d/%d + %d/%d", this.e.d(), this.e.c(), this.f.d(), this.f.c());
   }

   static class b implements ddv.a {
      private final int a;
      private final Set<ddu> b = Sets.newIdentityHashSet();

      public b(int var1) {
         this.a = var1;
      }

      @Nullable
      public ddu a() {
         if (this.b.size() >= this.a) {
            ddv.a.warn("Maximum sound pool size {} reached", this.a);
            return null;
         } else {
            ddu var1 = ddu.a();
            if (var1 != null) {
               this.b.add(var1);
            }

            return var1;
         }
      }

      public boolean a(ddu var1) {
         if (!this.b.remove(var1)) {
            return false;
         } else {
            var1.b();
            return true;
         }
      }

      public void b() {
         this.b.forEach(ddu::b);
         this.b.clear();
      }

      public int c() {
         return this.a;
      }

      public int d() {
         return this.b.size();
      }
   }

   interface a {
      @Nullable
      ddu a();

      boolean a(ddu var1);

      void b();

      int c();

      int d();
   }

   public static enum c {
      a,
      b;
   }
}
