import com.google.common.collect.Lists;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;

public class cry {
   public static void a(csw var0, fx var1, bzm var2, List<cry.i> var3, Random var4) {
      cry.c var5 = new cry.c(var4);
      cry.d var6 = new cry.d(var0, var4);
      var6.a(var1, var2, var3, var5);
   }

   static class h extends cry.f {
      private h() {
         super(null);
      }

      // $FF: synthetic method
      h(Object var1) {
         this();
      }
   }

   static class f extends cry.b {
      private f() {
         super(null);
      }

      public String a(Random var1) {
         return "1x1_b" + (var1.nextInt(4) + 1);
      }

      public String b(Random var1) {
         return "1x1_as" + (var1.nextInt(4) + 1);
      }

      public String a(Random var1, boolean var2) {
         return var2 ? "1x2_c_stairs" : "1x2_c" + (var1.nextInt(4) + 1);
      }

      public String b(Random var1, boolean var2) {
         return var2 ? "1x2_d_stairs" : "1x2_d" + (var1.nextInt(5) + 1);
      }

      public String c(Random var1) {
         return "1x2_se" + (var1.nextInt(1) + 1);
      }

      public String d(Random var1) {
         return "2x2_b" + (var1.nextInt(5) + 1);
      }

      public String e(Random var1) {
         return "2x2_s1";
      }

      // $FF: synthetic method
      f(Object var1) {
         this();
      }
   }

   static class a extends cry.b {
      private a() {
         super(null);
      }

      public String a(Random var1) {
         return "1x1_a" + (var1.nextInt(5) + 1);
      }

      public String b(Random var1) {
         return "1x1_as" + (var1.nextInt(4) + 1);
      }

      public String a(Random var1, boolean var2) {
         return "1x2_a" + (var1.nextInt(9) + 1);
      }

      public String b(Random var1, boolean var2) {
         return "1x2_b" + (var1.nextInt(5) + 1);
      }

      public String c(Random var1) {
         return "1x2_s" + (var1.nextInt(2) + 1);
      }

      public String d(Random var1) {
         return "2x2_a" + (var1.nextInt(4) + 1);
      }

      public String e(Random var1) {
         return "2x2_s1";
      }

      // $FF: synthetic method
      a(Object var1) {
         this();
      }
   }

   abstract static class b {
      private b() {
      }

      public abstract String a(Random var1);

      public abstract String b(Random var1);

      public abstract String a(Random var1, boolean var2);

      public abstract String b(Random var1, boolean var2);

      public abstract String c(Random var1);

      public abstract String d(Random var1);

      public abstract String e(Random var1);

      // $FF: synthetic method
      b(Object var1) {
         this();
      }
   }

   static class g {
      private final int[][] a;
      private final int b;
      private final int c;
      private final int d;

      public g(int var1, int var2, int var3) {
         this.b = var1;
         this.c = var2;
         this.d = var3;
         this.a = new int[var1][var2];
      }

      public void a(int var1, int var2, int var3) {
         if (var1 >= 0 && var1 < this.b && var2 >= 0 && var2 < this.c) {
            this.a[var1][var2] = var3;
         }

      }

      public void a(int var1, int var2, int var3, int var4, int var5) {
         for(int var6 = var2; var6 <= var4; ++var6) {
            for(int var7 = var1; var7 <= var3; ++var7) {
               this.a(var7, var6, var5);
            }
         }

      }

      public int a(int var1, int var2) {
         return var1 >= 0 && var1 < this.b && var2 >= 0 && var2 < this.c ? this.a[var1][var2] : this.d;
      }

      public void a(int var1, int var2, int var3, int var4) {
         if (this.a(var1, var2) == var3) {
            this.a(var1, var2, var4);
         }

      }

      public boolean b(int var1, int var2, int var3) {
         return this.a(var1 - 1, var2) == var3 || this.a(var1 + 1, var2) == var3 || this.a(var1, var2 + 1) == var3 || this.a(var1, var2 - 1) == var3;
      }
   }

   static class c {
      private final Random a;
      private final cry.g b;
      private final cry.g c;
      private final cry.g[] d;
      private final int e;
      private final int f;

      public c(Random var1) {
         this.a = var1;
         int var2 = true;
         this.e = 7;
         this.f = 4;
         this.b = new cry.g(11, 11, 5);
         this.b.a(this.e, this.f, this.e + 1, this.f + 1, 3);
         this.b.a(this.e - 1, this.f, this.e - 1, this.f + 1, 2);
         this.b.a(this.e + 2, this.f - 2, this.e + 3, this.f + 3, 5);
         this.b.a(this.e + 1, this.f - 2, this.e + 1, this.f - 1, 1);
         this.b.a(this.e + 1, this.f + 2, this.e + 1, this.f + 3, 1);
         this.b.a(this.e - 1, this.f - 1, 1);
         this.b.a(this.e - 1, this.f + 2, 1);
         this.b.a(0, 0, 11, 1, 5);
         this.b.a(0, 9, 11, 11, 5);
         this.a(this.b, this.e, this.f - 2, gc.e, 6);
         this.a(this.b, this.e, this.f + 3, gc.e, 6);
         this.a(this.b, this.e - 2, this.f - 1, gc.e, 3);
         this.a(this.b, this.e - 2, this.f + 2, gc.e, 3);

         while(this.a(this.b)) {
         }

         this.d = new cry.g[3];
         this.d[0] = new cry.g(11, 11, 5);
         this.d[1] = new cry.g(11, 11, 5);
         this.d[2] = new cry.g(11, 11, 5);
         this.a(this.b, this.d[0]);
         this.a(this.b, this.d[1]);
         this.d[0].a(this.e + 1, this.f, this.e + 1, this.f + 1, 8388608);
         this.d[1].a(this.e + 1, this.f, this.e + 1, this.f + 1, 8388608);
         this.c = new cry.g(this.b.b, this.b.c, 5);
         this.b();
         this.a(this.c, this.d[2]);
      }

      public static boolean a(cry.g var0, int var1, int var2) {
         int var3 = var0.a(var1, var2);
         return var3 == 1 || var3 == 2 || var3 == 3 || var3 == 4;
      }

      public boolean a(cry.g var1, int var2, int var3, int var4, int var5) {
         return (this.d[var4].a(var2, var3) & '\uffff') == var5;
      }

      @Nullable
      public gc b(cry.g var1, int var2, int var3, int var4, int var5) {
         Iterator var6 = gc.c.a.iterator();

         gc var7;
         do {
            if (!var6.hasNext()) {
               return null;
            }

            var7 = (gc)var6.next();
         } while(!this.a(var1, var2 + var7.i(), var3 + var7.k(), var4, var5));

         return var7;
      }

      private void a(cry.g var1, int var2, int var3, gc var4, int var5) {
         if (var5 > 0) {
            var1.a(var2, var3, 1);
            var1.a(var2 + var4.i(), var3 + var4.k(), 0, 1);

            gc var7;
            for(int var6 = 0; var6 < 8; ++var6) {
               var7 = gc.b(this.a.nextInt(4));
               if (var7 != var4.f() && (var7 != gc.f || !this.a.nextBoolean())) {
                  int var8 = var2 + var4.i();
                  int var9 = var3 + var4.k();
                  if (var1.a(var8 + var7.i(), var9 + var7.k()) == 0 && var1.a(var8 + var7.i() * 2, var9 + var7.k() * 2) == 0) {
                     this.a(var1, var2 + var4.i() + var7.i(), var3 + var4.k() + var7.k(), var7, var5 - 1);
                     break;
                  }
               }
            }

            gc var10 = var4.g();
            var7 = var4.h();
            var1.a(var2 + var10.i(), var3 + var10.k(), 0, 2);
            var1.a(var2 + var7.i(), var3 + var7.k(), 0, 2);
            var1.a(var2 + var4.i() + var10.i(), var3 + var4.k() + var10.k(), 0, 2);
            var1.a(var2 + var4.i() + var7.i(), var3 + var4.k() + var7.k(), 0, 2);
            var1.a(var2 + var4.i() * 2, var3 + var4.k() * 2, 0, 2);
            var1.a(var2 + var10.i() * 2, var3 + var10.k() * 2, 0, 2);
            var1.a(var2 + var7.i() * 2, var3 + var7.k() * 2, 0, 2);
         }
      }

      private boolean a(cry.g var1) {
         boolean var2 = false;

         for(int var3 = 0; var3 < var1.c; ++var3) {
            for(int var4 = 0; var4 < var1.b; ++var4) {
               if (var1.a(var4, var3) == 0) {
                  int var5 = 0;
                  int var7 = var5 + (a(var1, var4 + 1, var3) ? 1 : 0);
                  var7 += a(var1, var4 - 1, var3) ? 1 : 0;
                  var7 += a(var1, var4, var3 + 1) ? 1 : 0;
                  var7 += a(var1, var4, var3 - 1) ? 1 : 0;
                  if (var7 >= 3) {
                     var1.a(var4, var3, 2);
                     var2 = true;
                  } else if (var7 == 2) {
                     int var6 = 0;
                     int var8 = var6 + (a(var1, var4 + 1, var3 + 1) ? 1 : 0);
                     var8 += a(var1, var4 - 1, var3 + 1) ? 1 : 0;
                     var8 += a(var1, var4 + 1, var3 - 1) ? 1 : 0;
                     var8 += a(var1, var4 - 1, var3 - 1) ? 1 : 0;
                     if (var8 <= 1) {
                        var1.a(var4, var3, 2);
                        var2 = true;
                     }
                  }
               }
            }
         }

         return var2;
      }

      private void b() {
         List<afv<Integer, Integer>> var1 = Lists.newArrayList();
         cry.g var2 = this.d[1];

         int var4;
         int var6;
         for(int var3 = 0; var3 < this.c.c; ++var3) {
            for(var4 = 0; var4 < this.c.b; ++var4) {
               int var5 = var2.a(var4, var3);
               var6 = var5 & 983040;
               if (var6 == 131072 && (var5 & 2097152) == 2097152) {
                  var1.add(new afv(var4, var3));
               }
            }
         }

         if (var1.isEmpty()) {
            this.c.a(0, 0, this.c.b, this.c.c, 5);
         } else {
            afv<Integer, Integer> var11 = (afv)var1.get(this.a.nextInt(var1.size()));
            var4 = var2.a((Integer)var11.a(), (Integer)var11.b());
            var2.a((Integer)var11.a(), (Integer)var11.b(), var4 | 4194304);
            gc var12 = this.b(this.b, (Integer)var11.a(), (Integer)var11.b(), 1, var4 & '\uffff');
            var6 = (Integer)var11.a() + var12.i();
            int var7 = (Integer)var11.b() + var12.k();

            for(int var8 = 0; var8 < this.c.c; ++var8) {
               for(int var9 = 0; var9 < this.c.b; ++var9) {
                  if (!a(this.b, var9, var8)) {
                     this.c.a(var9, var8, 5);
                  } else if (var9 == (Integer)var11.a() && var8 == (Integer)var11.b()) {
                     this.c.a(var9, var8, 3);
                  } else if (var9 == var6 && var8 == var7) {
                     this.c.a(var9, var8, 3);
                     this.d[2].a(var9, var8, 8388608);
                  }
               }
            }

            List<gc> var13 = Lists.newArrayList();
            Iterator var14 = gc.c.a.iterator();

            while(var14.hasNext()) {
               gc var10 = (gc)var14.next();
               if (this.c.a(var6 + var10.i(), var7 + var10.k()) == 0) {
                  var13.add(var10);
               }
            }

            if (var13.isEmpty()) {
               this.c.a(0, 0, this.c.b, this.c.c, 5);
               var2.a((Integer)var11.a(), (Integer)var11.b(), var4);
            } else {
               gc var15 = (gc)var13.get(this.a.nextInt(var13.size()));
               this.a(this.c, var6 + var15.i(), var7 + var15.k(), var15, 4);

               while(this.a(this.c)) {
               }

            }
         }
      }

      private void a(cry.g var1, cry.g var2) {
         List<afv<Integer, Integer>> var3 = Lists.newArrayList();

         int var4;
         for(var4 = 0; var4 < var1.c; ++var4) {
            for(int var5 = 0; var5 < var1.b; ++var5) {
               if (var1.a(var5, var4) == 2) {
                  var3.add(new afv(var5, var4));
               }
            }
         }

         Collections.shuffle(var3, this.a);
         var4 = 10;
         Iterator var19 = var3.iterator();

         while(true) {
            int var7;
            int var8;
            do {
               if (!var19.hasNext()) {
                  return;
               }

               afv<Integer, Integer> var6 = (afv)var19.next();
               var7 = (Integer)var6.a();
               var8 = (Integer)var6.b();
            } while(var2.a(var7, var8) != 0);

            int var9 = var7;
            int var10 = var7;
            int var11 = var8;
            int var12 = var8;
            int var13 = 65536;
            if (var2.a(var7 + 1, var8) == 0 && var2.a(var7, var8 + 1) == 0 && var2.a(var7 + 1, var8 + 1) == 0 && var1.a(var7 + 1, var8) == 2 && var1.a(var7, var8 + 1) == 2 && var1.a(var7 + 1, var8 + 1) == 2) {
               var10 = var7 + 1;
               var12 = var8 + 1;
               var13 = 262144;
            } else if (var2.a(var7 - 1, var8) == 0 && var2.a(var7, var8 + 1) == 0 && var2.a(var7 - 1, var8 + 1) == 0 && var1.a(var7 - 1, var8) == 2 && var1.a(var7, var8 + 1) == 2 && var1.a(var7 - 1, var8 + 1) == 2) {
               var9 = var7 - 1;
               var12 = var8 + 1;
               var13 = 262144;
            } else if (var2.a(var7 - 1, var8) == 0 && var2.a(var7, var8 - 1) == 0 && var2.a(var7 - 1, var8 - 1) == 0 && var1.a(var7 - 1, var8) == 2 && var1.a(var7, var8 - 1) == 2 && var1.a(var7 - 1, var8 - 1) == 2) {
               var9 = var7 - 1;
               var11 = var8 - 1;
               var13 = 262144;
            } else if (var2.a(var7 + 1, var8) == 0 && var1.a(var7 + 1, var8) == 2) {
               var10 = var7 + 1;
               var13 = 131072;
            } else if (var2.a(var7, var8 + 1) == 0 && var1.a(var7, var8 + 1) == 2) {
               var12 = var8 + 1;
               var13 = 131072;
            } else if (var2.a(var7 - 1, var8) == 0 && var1.a(var7 - 1, var8) == 2) {
               var9 = var7 - 1;
               var13 = 131072;
            } else if (var2.a(var7, var8 - 1) == 0 && var1.a(var7, var8 - 1) == 2) {
               var11 = var8 - 1;
               var13 = 131072;
            }

            int var14 = this.a.nextBoolean() ? var9 : var10;
            int var15 = this.a.nextBoolean() ? var11 : var12;
            int var16 = 2097152;
            if (!var1.b(var14, var15, 1)) {
               var14 = var14 == var9 ? var10 : var9;
               var15 = var15 == var11 ? var12 : var11;
               if (!var1.b(var14, var15, 1)) {
                  var15 = var15 == var11 ? var12 : var11;
                  if (!var1.b(var14, var15, 1)) {
                     var14 = var14 == var9 ? var10 : var9;
                     var15 = var15 == var11 ? var12 : var11;
                     if (!var1.b(var14, var15, 1)) {
                        var16 = 0;
                        var14 = var9;
                        var15 = var11;
                     }
                  }
               }
            }

            for(int var17 = var11; var17 <= var12; ++var17) {
               for(int var18 = var9; var18 <= var10; ++var18) {
                  if (var18 == var14 && var17 == var15) {
                     var2.a(var18, var17, 1048576 | var16 | var13 | var4);
                  } else {
                     var2.a(var18, var17, var13 | var4);
                  }
               }
            }

            ++var4;
         }
      }
   }

   static class d {
      private final csw a;
      private final Random b;
      private int c;
      private int d;

      public d(csw var1, Random var2) {
         this.a = var1;
         this.b = var2;
      }

      public void a(fx var1, bzm var2, List<cry.i> var3, cry.c var4) {
         cry.e var5 = new cry.e();
         var5.b = var1;
         var5.a = var2;
         var5.c = "wall_flat";
         cry.e var6 = new cry.e();
         this.a(var3, var5);
         var6.b = var5.b.b(8);
         var6.a = var5.a;
         var6.c = "wall_window";
         if (!var3.isEmpty()) {
         }

         cry.g var7 = var4.b;
         cry.g var8 = var4.c;
         this.c = var4.e + 1;
         this.d = var4.f + 1;
         int var9 = var4.e + 1;
         int var10 = var4.f;
         this.a(var3, var5, var7, gc.d, this.c, this.d, var9, var10);
         this.a(var3, var6, var7, gc.d, this.c, this.d, var9, var10);
         cry.e var11 = new cry.e();
         var11.b = var5.b.b(19);
         var11.a = var5.a;
         var11.c = "wall_window";
         boolean var12 = false;

         int var14;
         for(int var13 = 0; var13 < var8.c && !var12; ++var13) {
            for(var14 = var8.b - 1; var14 >= 0 && !var12; --var14) {
               if (cry.c.a(var8, var14, var13)) {
                  var11.b = var11.b.a(var2.a(gc.d), 8 + (var13 - this.d) * 8);
                  var11.b = var11.b.a(var2.a(gc.f), (var14 - this.c) * 8);
                  this.b(var3, var11);
                  this.a(var3, var11, var8, gc.d, var14, var13, var14, var13);
                  var12 = true;
               }
            }
         }

         this.a(var3, var1.b(16), var2, var7, var8);
         this.a(var3, var1.b(27), var2, (cry.g)var8, (cry.g)null);
         if (!var3.isEmpty()) {
         }

         cry.b[] var33 = new cry.b[]{new cry.a(), new cry.f(), new cry.h()};

         for(var14 = 0; var14 < 3; ++var14) {
            fx var15 = var1.b(8 * var14 + (var14 == 2 ? 3 : 0));
            cry.g var16 = var4.d[var14];
            cry.g var17 = var14 == 2 ? var8 : var7;
            String var18 = var14 == 0 ? "carpet_south_1" : "carpet_south_2";
            String var19 = var14 == 0 ? "carpet_west_1" : "carpet_west_2";

            for(int var20 = 0; var20 < var17.c; ++var20) {
               for(int var21 = 0; var21 < var17.b; ++var21) {
                  if (var17.a(var21, var20) == 1) {
                     fx var22 = var15.a(var2.a(gc.d), 8 + (var20 - this.d) * 8);
                     var22 = var22.a(var2.a(gc.f), (var21 - this.c) * 8);
                     var3.add(new cry.i(this.a, "corridor_floor", var22, var2));
                     if (var17.a(var21, var20 - 1) == 1 || (var16.a(var21, var20 - 1) & 8388608) == 8388608) {
                        var3.add(new cry.i(this.a, "carpet_north", var22.a((gc)var2.a(gc.f), 1).b(), var2));
                     }

                     if (var17.a(var21 + 1, var20) == 1 || (var16.a(var21 + 1, var20) & 8388608) == 8388608) {
                        var3.add(new cry.i(this.a, "carpet_east", var22.a((gc)var2.a(gc.d), 1).a((gc)var2.a(gc.f), 5).b(), var2));
                     }

                     if (var17.a(var21, var20 + 1) == 1 || (var16.a(var21, var20 + 1) & 8388608) == 8388608) {
                        var3.add(new cry.i(this.a, var18, var22.a((gc)var2.a(gc.d), 5).a((gc)var2.a(gc.e), 1), var2));
                     }

                     if (var17.a(var21 - 1, var20) == 1 || (var16.a(var21 - 1, var20) & 8388608) == 8388608) {
                        var3.add(new cry.i(this.a, var19, var22.a((gc)var2.a(gc.e), 1).a((gc)var2.a(gc.c), 1), var2));
                     }
                  }
               }
            }

            String var34 = var14 == 0 ? "indoors_wall_1" : "indoors_wall_2";
            String var35 = var14 == 0 ? "indoors_door_1" : "indoors_door_2";
            List<gc> var36 = Lists.newArrayList();

            for(int var23 = 0; var23 < var17.c; ++var23) {
               for(int var24 = 0; var24 < var17.b; ++var24) {
                  boolean var25 = var14 == 2 && var17.a(var24, var23) == 3;
                  if (var17.a(var24, var23) == 2 || var25) {
                     int var26 = var16.a(var24, var23);
                     int var27 = var26 & 983040;
                     int var28 = var26 & '\uffff';
                     var25 = var25 && (var26 & 8388608) == 8388608;
                     var36.clear();
                     if ((var26 & 2097152) == 2097152) {
                        Iterator var29 = gc.c.a.iterator();

                        while(var29.hasNext()) {
                           gc var30 = (gc)var29.next();
                           if (var17.a(var24 + var30.i(), var23 + var30.k()) == 1) {
                              var36.add(var30);
                           }
                        }
                     }

                     gc var37 = null;
                     if (!var36.isEmpty()) {
                        var37 = (gc)var36.get(this.b.nextInt(var36.size()));
                     } else if ((var26 & 1048576) == 1048576) {
                        var37 = gc.b;
                     }

                     fx var38 = var15.a(var2.a(gc.d), 8 + (var23 - this.d) * 8);
                     var38 = var38.a(var2.a(gc.f), -1 + (var24 - this.c) * 8);
                     if (cry.c.a(var17, var24 - 1, var23) && !var4.a(var17, var24 - 1, var23, var14, var28)) {
                        var3.add(new cry.i(this.a, var37 == gc.e ? var35 : var34, var38, var2));
                     }

                     fx var31;
                     if (var17.a(var24 + 1, var23) == 1 && !var25) {
                        var31 = var38.a((gc)var2.a(gc.f), 8);
                        var3.add(new cry.i(this.a, var37 == gc.f ? var35 : var34, var31, var2));
                     }

                     if (cry.c.a(var17, var24, var23 + 1) && !var4.a(var17, var24, var23 + 1, var14, var28)) {
                        var31 = var38.a((gc)var2.a(gc.d), 7);
                        var31 = var31.a((gc)var2.a(gc.f), 7);
                        var3.add(new cry.i(this.a, var37 == gc.d ? var35 : var34, var31, var2.a(bzm.b)));
                     }

                     if (var17.a(var24, var23 - 1) == 1 && !var25) {
                        var31 = var38.a((gc)var2.a(gc.c), 1);
                        var31 = var31.a((gc)var2.a(gc.f), 7);
                        var3.add(new cry.i(this.a, var37 == gc.c ? var35 : var34, var31, var2.a(bzm.b)));
                     }

                     if (var27 == 65536) {
                        this.a(var3, var38, var2, var37, var33[var14]);
                     } else {
                        gc var39;
                        if (var27 == 131072 && var37 != null) {
                           var39 = var4.b(var17, var24, var23, var14, var28);
                           boolean var32 = (var26 & 4194304) == 4194304;
                           this.a(var3, var38, var2, var39, var37, var33[var14], var32);
                        } else if (var27 == 262144 && var37 != null && var37 != gc.b) {
                           var39 = var37.g();
                           if (!var4.a(var17, var24 + var39.i(), var23 + var39.k(), var14, var28)) {
                              var39 = var39.f();
                           }

                           this.a(var3, var38, var2, var39, var37, var33[var14]);
                        } else if (var27 == 262144 && var37 == gc.b) {
                           this.a(var3, var38, var2, var33[var14]);
                        }
                     }
                  }
               }
            }
         }

      }

      private void a(List<cry.i> var1, cry.e var2, cry.g var3, gc var4, int var5, int var6, int var7, int var8) {
         int var9 = var5;
         int var10 = var6;
         gc var11 = var4;

         do {
            if (!cry.c.a(var3, var9 + var4.i(), var10 + var4.k())) {
               this.c(var1, var2);
               var4 = var4.g();
               if (var9 != var7 || var10 != var8 || var11 != var4) {
                  this.b(var1, var2);
               }
            } else if (cry.c.a(var3, var9 + var4.i(), var10 + var4.k()) && cry.c.a(var3, var9 + var4.i() + var4.h().i(), var10 + var4.k() + var4.h().k())) {
               this.d(var1, var2);
               var9 += var4.i();
               var10 += var4.k();
               var4 = var4.h();
            } else {
               var9 += var4.i();
               var10 += var4.k();
               if (var9 != var7 || var10 != var8 || var11 != var4) {
                  this.b(var1, var2);
               }
            }
         } while(var9 != var7 || var10 != var8 || var11 != var4);

      }

      private void a(List<cry.i> var1, fx var2, bzm var3, cry.g var4, @Nullable cry.g var5) {
         int var6;
         int var7;
         fx var8;
         boolean var9;
         fx var10;
         for(var6 = 0; var6 < var4.c; ++var6) {
            for(var7 = 0; var7 < var4.b; ++var7) {
               var8 = var2.a(var3.a(gc.d), 8 + (var6 - this.d) * 8);
               var8 = var8.a(var3.a(gc.f), (var7 - this.c) * 8);
               var9 = var5 != null && cry.c.a(var5, var7, var6);
               if (cry.c.a(var4, var7, var6) && !var9) {
                  var1.add(new cry.i(this.a, "roof", var8.b(3), var3));
                  if (!cry.c.a(var4, var7 + 1, var6)) {
                     var10 = var8.a((gc)var3.a(gc.f), 6);
                     var1.add(new cry.i(this.a, "roof_front", var10, var3));
                  }

                  if (!cry.c.a(var4, var7 - 1, var6)) {
                     var10 = var8.a((gc)var3.a(gc.f), 0);
                     var10 = var10.a((gc)var3.a(gc.d), 7);
                     var1.add(new cry.i(this.a, "roof_front", var10, var3.a(bzm.c)));
                  }

                  if (!cry.c.a(var4, var7, var6 - 1)) {
                     var10 = var8.a((gc)var3.a(gc.e), 1);
                     var1.add(new cry.i(this.a, "roof_front", var10, var3.a(bzm.d)));
                  }

                  if (!cry.c.a(var4, var7, var6 + 1)) {
                     var10 = var8.a((gc)var3.a(gc.f), 6);
                     var10 = var10.a((gc)var3.a(gc.d), 6);
                     var1.add(new cry.i(this.a, "roof_front", var10, var3.a(bzm.b)));
                  }
               }
            }
         }

         if (var5 != null) {
            for(var6 = 0; var6 < var4.c; ++var6) {
               for(var7 = 0; var7 < var4.b; ++var7) {
                  var8 = var2.a(var3.a(gc.d), 8 + (var6 - this.d) * 8);
                  var8 = var8.a(var3.a(gc.f), (var7 - this.c) * 8);
                  var9 = cry.c.a(var5, var7, var6);
                  if (cry.c.a(var4, var7, var6) && var9) {
                     if (!cry.c.a(var4, var7 + 1, var6)) {
                        var10 = var8.a((gc)var3.a(gc.f), 7);
                        var1.add(new cry.i(this.a, "small_wall", var10, var3));
                     }

                     if (!cry.c.a(var4, var7 - 1, var6)) {
                        var10 = var8.a((gc)var3.a(gc.e), 1);
                        var10 = var10.a((gc)var3.a(gc.d), 6);
                        var1.add(new cry.i(this.a, "small_wall", var10, var3.a(bzm.c)));
                     }

                     if (!cry.c.a(var4, var7, var6 - 1)) {
                        var10 = var8.a((gc)var3.a(gc.e), 0);
                        var10 = var10.a((gc)var3.a(gc.c), 1);
                        var1.add(new cry.i(this.a, "small_wall", var10, var3.a(bzm.d)));
                     }

                     if (!cry.c.a(var4, var7, var6 + 1)) {
                        var10 = var8.a((gc)var3.a(gc.f), 6);
                        var10 = var10.a((gc)var3.a(gc.d), 7);
                        var1.add(new cry.i(this.a, "small_wall", var10, var3.a(bzm.b)));
                     }

                     if (!cry.c.a(var4, var7 + 1, var6)) {
                        if (!cry.c.a(var4, var7, var6 - 1)) {
                           var10 = var8.a((gc)var3.a(gc.f), 7);
                           var10 = var10.a((gc)var3.a(gc.c), 2);
                           var1.add(new cry.i(this.a, "small_wall_corner", var10, var3));
                        }

                        if (!cry.c.a(var4, var7, var6 + 1)) {
                           var10 = var8.a((gc)var3.a(gc.f), 8);
                           var10 = var10.a((gc)var3.a(gc.d), 7);
                           var1.add(new cry.i(this.a, "small_wall_corner", var10, var3.a(bzm.b)));
                        }
                     }

                     if (!cry.c.a(var4, var7 - 1, var6)) {
                        if (!cry.c.a(var4, var7, var6 - 1)) {
                           var10 = var8.a((gc)var3.a(gc.e), 2);
                           var10 = var10.a((gc)var3.a(gc.c), 1);
                           var1.add(new cry.i(this.a, "small_wall_corner", var10, var3.a(bzm.d)));
                        }

                        if (!cry.c.a(var4, var7, var6 + 1)) {
                           var10 = var8.a((gc)var3.a(gc.e), 1);
                           var10 = var10.a((gc)var3.a(gc.d), 8);
                           var1.add(new cry.i(this.a, "small_wall_corner", var10, var3.a(bzm.c)));
                        }
                     }
                  }
               }
            }
         }

         for(var6 = 0; var6 < var4.c; ++var6) {
            for(var7 = 0; var7 < var4.b; ++var7) {
               var8 = var2.a(var3.a(gc.d), 8 + (var6 - this.d) * 8);
               var8 = var8.a(var3.a(gc.f), (var7 - this.c) * 8);
               var9 = var5 != null && cry.c.a(var5, var7, var6);
               if (cry.c.a(var4, var7, var6) && !var9) {
                  fx var11;
                  if (!cry.c.a(var4, var7 + 1, var6)) {
                     var10 = var8.a((gc)var3.a(gc.f), 6);
                     if (!cry.c.a(var4, var7, var6 + 1)) {
                        var11 = var10.a((gc)var3.a(gc.d), 6);
                        var1.add(new cry.i(this.a, "roof_corner", var11, var3));
                     } else if (cry.c.a(var4, var7 + 1, var6 + 1)) {
                        var11 = var10.a((gc)var3.a(gc.d), 5);
                        var1.add(new cry.i(this.a, "roof_inner_corner", var11, var3));
                     }

                     if (!cry.c.a(var4, var7, var6 - 1)) {
                        var1.add(new cry.i(this.a, "roof_corner", var10, var3.a(bzm.d)));
                     } else if (cry.c.a(var4, var7 + 1, var6 - 1)) {
                        var11 = var8.a((gc)var3.a(gc.f), 9);
                        var11 = var11.a((gc)var3.a(gc.c), 2);
                        var1.add(new cry.i(this.a, "roof_inner_corner", var11, var3.a(bzm.b)));
                     }
                  }

                  if (!cry.c.a(var4, var7 - 1, var6)) {
                     var10 = var8.a((gc)var3.a(gc.f), 0);
                     var10 = var10.a((gc)var3.a(gc.d), 0);
                     if (!cry.c.a(var4, var7, var6 + 1)) {
                        var11 = var10.a((gc)var3.a(gc.d), 6);
                        var1.add(new cry.i(this.a, "roof_corner", var11, var3.a(bzm.b)));
                     } else if (cry.c.a(var4, var7 - 1, var6 + 1)) {
                        var11 = var10.a((gc)var3.a(gc.d), 8);
                        var11 = var11.a((gc)var3.a(gc.e), 3);
                        var1.add(new cry.i(this.a, "roof_inner_corner", var11, var3.a(bzm.d)));
                     }

                     if (!cry.c.a(var4, var7, var6 - 1)) {
                        var1.add(new cry.i(this.a, "roof_corner", var10, var3.a(bzm.c)));
                     } else if (cry.c.a(var4, var7 - 1, var6 - 1)) {
                        var11 = var10.a((gc)var3.a(gc.d), 1);
                        var1.add(new cry.i(this.a, "roof_inner_corner", var11, var3.a(bzm.c)));
                     }
                  }
               }
            }
         }

      }

      private void a(List<cry.i> var1, cry.e var2) {
         gc var3 = var2.a.a(gc.e);
         var1.add(new cry.i(this.a, "entrance", var2.b.a((gc)var3, 9), var2.a));
         var2.b = var2.b.a((gc)var2.a.a(gc.d), 16);
      }

      private void b(List<cry.i> var1, cry.e var2) {
         var1.add(new cry.i(this.a, var2.c, var2.b.a((gc)var2.a.a(gc.f), 7), var2.a));
         var2.b = var2.b.a((gc)var2.a.a(gc.d), 8);
      }

      private void c(List<cry.i> var1, cry.e var2) {
         var2.b = var2.b.a((gc)var2.a.a(gc.d), -1);
         var1.add(new cry.i(this.a, "wall_corner", var2.b, var2.a));
         var2.b = var2.b.a((gc)var2.a.a(gc.d), -7);
         var2.b = var2.b.a((gc)var2.a.a(gc.e), -6);
         var2.a = var2.a.a(bzm.b);
      }

      private void d(List<cry.i> var1, cry.e var2) {
         var2.b = var2.b.a((gc)var2.a.a(gc.d), 6);
         var2.b = var2.b.a((gc)var2.a.a(gc.f), 8);
         var2.a = var2.a.a(bzm.d);
      }

      private void a(List<cry.i> var1, fx var2, bzm var3, gc var4, cry.b var5) {
         bzm var6 = bzm.a;
         String var7 = var5.a(this.b);
         if (var4 != gc.f) {
            if (var4 == gc.c) {
               var6 = var6.a(bzm.d);
            } else if (var4 == gc.e) {
               var6 = var6.a(bzm.c);
            } else if (var4 == gc.d) {
               var6 = var6.a(bzm.b);
            } else {
               var7 = var5.b(this.b);
            }
         }

         fx var8 = ctb.a(new fx(1, 0, 0), byg.a, var6, 7, 7);
         var6 = var6.a(var3);
         var8 = var8.a(var3);
         fx var9 = var2.b(var8.u(), 0, var8.w());
         var1.add(new cry.i(this.a, var7, var9, var6));
      }

      private void a(List<cry.i> var1, fx var2, bzm var3, gc var4, gc var5, cry.b var6, boolean var7) {
         fx var8;
         if (var5 == gc.f && var4 == gc.d) {
            var8 = var2.a((gc)var3.a(gc.f), 1);
            var1.add(new cry.i(this.a, var6.a(this.b, var7), var8, var3));
         } else if (var5 == gc.f && var4 == gc.c) {
            var8 = var2.a((gc)var3.a(gc.f), 1);
            var8 = var8.a((gc)var3.a(gc.d), 6);
            var1.add(new cry.i(this.a, var6.a(this.b, var7), var8, var3, byg.b));
         } else if (var5 == gc.e && var4 == gc.c) {
            var8 = var2.a((gc)var3.a(gc.f), 7);
            var8 = var8.a((gc)var3.a(gc.d), 6);
            var1.add(new cry.i(this.a, var6.a(this.b, var7), var8, var3.a(bzm.c)));
         } else if (var5 == gc.e && var4 == gc.d) {
            var8 = var2.a((gc)var3.a(gc.f), 7);
            var1.add(new cry.i(this.a, var6.a(this.b, var7), var8, var3, byg.c));
         } else if (var5 == gc.d && var4 == gc.f) {
            var8 = var2.a((gc)var3.a(gc.f), 1);
            var1.add(new cry.i(this.a, var6.a(this.b, var7), var8, var3.a(bzm.b), byg.b));
         } else if (var5 == gc.d && var4 == gc.e) {
            var8 = var2.a((gc)var3.a(gc.f), 7);
            var1.add(new cry.i(this.a, var6.a(this.b, var7), var8, var3.a(bzm.b)));
         } else if (var5 == gc.c && var4 == gc.e) {
            var8 = var2.a((gc)var3.a(gc.f), 7);
            var8 = var8.a((gc)var3.a(gc.d), 6);
            var1.add(new cry.i(this.a, var6.a(this.b, var7), var8, var3.a(bzm.b), byg.c));
         } else if (var5 == gc.c && var4 == gc.f) {
            var8 = var2.a((gc)var3.a(gc.f), 1);
            var8 = var8.a((gc)var3.a(gc.d), 6);
            var1.add(new cry.i(this.a, var6.a(this.b, var7), var8, var3.a(bzm.d)));
         } else if (var5 == gc.d && var4 == gc.c) {
            var8 = var2.a((gc)var3.a(gc.f), 1);
            var8 = var8.a((gc)var3.a(gc.c), 8);
            var1.add(new cry.i(this.a, var6.b(this.b, var7), var8, var3));
         } else if (var5 == gc.c && var4 == gc.d) {
            var8 = var2.a((gc)var3.a(gc.f), 7);
            var8 = var8.a((gc)var3.a(gc.d), 14);
            var1.add(new cry.i(this.a, var6.b(this.b, var7), var8, var3.a(bzm.c)));
         } else if (var5 == gc.e && var4 == gc.f) {
            var8 = var2.a((gc)var3.a(gc.f), 15);
            var1.add(new cry.i(this.a, var6.b(this.b, var7), var8, var3.a(bzm.b)));
         } else if (var5 == gc.f && var4 == gc.e) {
            var8 = var2.a((gc)var3.a(gc.e), 7);
            var8 = var8.a((gc)var3.a(gc.d), 6);
            var1.add(new cry.i(this.a, var6.b(this.b, var7), var8, var3.a(bzm.d)));
         } else if (var5 == gc.b && var4 == gc.f) {
            var8 = var2.a((gc)var3.a(gc.f), 15);
            var1.add(new cry.i(this.a, var6.c(this.b), var8, var3.a(bzm.b)));
         } else if (var5 == gc.b && var4 == gc.d) {
            var8 = var2.a((gc)var3.a(gc.f), 1);
            var8 = var8.a((gc)var3.a(gc.c), 0);
            var1.add(new cry.i(this.a, var6.c(this.b), var8, var3));
         }

      }

      private void a(List<cry.i> var1, fx var2, bzm var3, gc var4, gc var5, cry.b var6) {
         int var7 = 0;
         int var8 = 0;
         bzm var9 = var3;
         byg var10 = byg.a;
         if (var5 == gc.f && var4 == gc.d) {
            var7 = -7;
         } else if (var5 == gc.f && var4 == gc.c) {
            var7 = -7;
            var8 = 6;
            var10 = byg.b;
         } else if (var5 == gc.c && var4 == gc.f) {
            var7 = 1;
            var8 = 14;
            var9 = var3.a(bzm.d);
         } else if (var5 == gc.c && var4 == gc.e) {
            var7 = 7;
            var8 = 14;
            var9 = var3.a(bzm.d);
            var10 = byg.b;
         } else if (var5 == gc.d && var4 == gc.e) {
            var7 = 7;
            var8 = -8;
            var9 = var3.a(bzm.b);
         } else if (var5 == gc.d && var4 == gc.f) {
            var7 = 1;
            var8 = -8;
            var9 = var3.a(bzm.b);
            var10 = byg.b;
         } else if (var5 == gc.e && var4 == gc.c) {
            var7 = 15;
            var8 = 6;
            var9 = var3.a(bzm.c);
         } else if (var5 == gc.e && var4 == gc.d) {
            var7 = 15;
            var10 = byg.c;
         }

         fx var11 = var2.a((gc)var3.a(gc.f), var7);
         var11 = var11.a((gc)var3.a(gc.d), var8);
         var1.add(new cry.i(this.a, var6.d(this.b), var11, var9, var10));
      }

      private void a(List<cry.i> var1, fx var2, bzm var3, cry.b var4) {
         fx var5 = var2.a((gc)var3.a(gc.f), 1);
         var1.add(new cry.i(this.a, var4.e(this.b), var5, var3, byg.a));
      }
   }

   static class e {
      public bzm a;
      public fx b;
      public String c;

      private e() {
      }

      // $FF: synthetic method
      e(Object var1) {
         this();
      }
   }

   public static class i extends crx {
      private final String d;
      private final bzm e;
      private final byg f;

      public i(csw var1, String var2, fx var3, bzm var4) {
         this(var1, var2, var3, var4, byg.a);
      }

      public i(csw var1, String var2, fx var3, bzm var4, byg var5) {
         super(clb.Z, 0);
         this.d = var2;
         this.c = var3;
         this.e = var4;
         this.f = var5;
         this.a(var1);
      }

      public i(csw var1, md var2) {
         super(clb.Z, var2);
         this.d = var2.l("Template");
         this.e = bzm.valueOf(var2.l("Rot"));
         this.f = byg.valueOf(var2.l("Mi"));
         this.a(var1);
      }

      private void a(csw var1) {
         ctb var2 = var1.a(new vk("woodland_mansion/" + this.d));
         csx var3 = (new csx()).a(true).a(this.e).a(this.f).a((csy)cse.b);
         this.a(var2, this.c, var3);
      }

      protected void a(md var1) {
         super.a(var1);
         var1.a("Template", this.d);
         var1.a("Rot", this.b.d().name());
         var1.a("Mi", this.b.c().name());
      }

      protected void a(String var1, fx var2, bsk var3, Random var4, cra var5) {
         if (var1.startsWith("Chest")) {
            bzm var6 = this.b.d();
            ceh var7 = bup.bR.n();
            if ("ChestWest".equals(var1)) {
               var7 = (ceh)var7.a(bve.b, var6.a(gc.e));
            } else if ("ChestEast".equals(var1)) {
               var7 = (ceh)var7.a(bve.b, var6.a(gc.f));
            } else if ("ChestSouth".equals(var1)) {
               var7 = (ceh)var7.a(bve.b, var6.a(gc.d));
            } else if ("ChestNorth".equals(var1)) {
               var7 = (ceh)var7.a(bve.b, var6.a(gc.c));
            }

            this.a(var3, var5, var4, var2, cyq.D, var7);
         } else {
            byte var8 = -1;
            switch(var1.hashCode()) {
            case -1505748702:
               if (var1.equals("Warrior")) {
                  var8 = 1;
               }
               break;
            case 2390418:
               if (var1.equals("Mage")) {
                  var8 = 0;
               }
            }

            bcy var9;
            switch(var8) {
            case 0:
               var9 = (bcy)aqe.w.a((brx)var3.E());
               break;
            case 1:
               var9 = (bcy)aqe.aQ.a((brx)var3.E());
               break;
            default:
               return;
            }

            var9.es();
            var9.a(var2, 0.0F, 0.0F);
            var9.a(var3, var3.d(var9.cB()), aqp.d, (arc)null, (md)null);
            var3.l(var9);
            var3.a(var2, bup.a.n(), 2);
         }

      }
   }
}
