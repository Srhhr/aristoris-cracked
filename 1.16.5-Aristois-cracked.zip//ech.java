import it.unimi.dsi.fastutil.floats.Float2FloatFunction;
import it.unimi.dsi.fastutil.ints.Int2IntFunction;
import java.util.Calendar;

public class ech<T extends ccj & cdc> extends ece<T> {
   private final dwn a;
   private final dwn c;
   private final dwn d;
   private final dwn e;
   private final dwn f;
   private final dwn g;
   private final dwn h;
   private final dwn i;
   private final dwn j;
   private boolean k;

   public ech(ecd var1) {
      super(var1);
      Calendar var2 = Calendar.getInstance();
      if (var2.get(2) + 1 == 12 && var2.get(5) >= 24 && var2.get(5) <= 26) {
         this.k = true;
      }

      this.c = new dwn(64, 64, 0, 19);
      this.c.a(1.0F, 0.0F, 1.0F, 14.0F, 10.0F, 14.0F, 0.0F);
      this.a = new dwn(64, 64, 0, 0);
      this.a.a(1.0F, 0.0F, 0.0F, 14.0F, 5.0F, 14.0F, 0.0F);
      this.a.b = 9.0F;
      this.a.c = 1.0F;
      this.d = new dwn(64, 64, 0, 0);
      this.d.a(7.0F, -1.0F, 15.0F, 2.0F, 4.0F, 1.0F, 0.0F);
      this.d.b = 8.0F;
      this.f = new dwn(64, 64, 0, 19);
      this.f.a(1.0F, 0.0F, 1.0F, 15.0F, 10.0F, 14.0F, 0.0F);
      this.e = new dwn(64, 64, 0, 0);
      this.e.a(1.0F, 0.0F, 0.0F, 15.0F, 5.0F, 14.0F, 0.0F);
      this.e.b = 9.0F;
      this.e.c = 1.0F;
      this.g = new dwn(64, 64, 0, 0);
      this.g.a(15.0F, -1.0F, 15.0F, 1.0F, 4.0F, 1.0F, 0.0F);
      this.g.b = 8.0F;
      this.i = new dwn(64, 64, 0, 19);
      this.i.a(0.0F, 0.0F, 1.0F, 15.0F, 10.0F, 14.0F, 0.0F);
      this.h = new dwn(64, 64, 0, 0);
      this.h.a(0.0F, 0.0F, 0.0F, 15.0F, 5.0F, 14.0F, 0.0F);
      this.h.b = 9.0F;
      this.h.c = 1.0F;
      this.j = new dwn(64, 64, 0, 0);
      this.j.a(0.0F, -1.0F, 15.0F, 1.0F, 4.0F, 1.0F, 0.0F);
      this.j.b = 8.0F;
   }

   public void a(T var1, float var2, dfm var3, eag var4, int var5, int var6) {
      brx var7 = var1.v();
      boolean var8 = var7 != null;
      ceh var9 = var8 ? var1.p() : (ceh)bup.bR.n().a(bve.b, gc.d);
      cez var10 = var9.b(bve.c) ? (cez)var9.c(bve.c) : cez.a;
      buo var11 = var9.b();
      if (var11 instanceof btn) {
         btn<?> var12 = (btn)var11;
         boolean var13 = var10 != cez.a;
         var3.a();
         float var14 = ((gc)var9.c(bve.b)).o();
         var3.a(0.5D, 0.5D, 0.5D);
         var3.a(g.d.a(-var14));
         var3.a(-0.5D, -0.5D, -0.5D);
         bwc.c var15;
         if (var8) {
            var15 = var12.a(var9, var7, var1.o(), true);
         } else {
            var15 = bwc.b::b;
         }

         float var16 = ((Float2FloatFunction)var15.apply(bve.a((cdc)var1))).get(var2);
         var16 = 1.0F - var16;
         var16 = 1.0F - var16 * var16 * var16;
         int var17 = ((Int2IntFunction)var15.apply(new ecf())).applyAsInt(var5);
         elr var18 = ear.a(var1, var10, this.k);
         dfq var19 = var18.a(var4, eao::c);
         if (var13) {
            if (var10 == cez.b) {
               this.a(var3, var19, this.h, this.j, this.i, var16, var17, var6);
            } else {
               this.a(var3, var19, this.e, this.g, this.f, var16, var17, var6);
            }
         } else {
            this.a(var3, var19, this.a, this.d, this.c, var16, var17, var6);
         }

         var3.b();
      }
   }

   private void a(dfm var1, dfq var2, dwn var3, dwn var4, dwn var5, float var6, int var7, int var8) {
      var3.d = -(var6 * 1.5707964F);
      var4.d = var3.d;
      var3.a(var1, var2, var7, var8);
      var4.a(var1, var2, var7, var8);
      var5.a(var1, var2, var7, var8);
   }
}
