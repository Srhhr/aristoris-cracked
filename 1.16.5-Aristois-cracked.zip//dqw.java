import com.mojang.blaze3d.systems.RenderSystem;

public class dqw extends dqm<bjs> {
   private static final vk A = new vk("textures/gui/container/smithing.png");

   public dqw(bjs var1, bfv var2, nr var3) {
      super(var1, var2, var3, A);
      this.p = 60;
      this.q = 18;
   }

   protected void b(dfm var1, int var2, int var3) {
      RenderSystem.disableBlend();
      super.b(var1, var2, var3);
   }
}
