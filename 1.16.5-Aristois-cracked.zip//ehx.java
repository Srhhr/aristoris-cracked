public class ehx extends eif<bdc, dtw<bdc>> {
   private static final vk a = new vk("textures/entity/creeper/creeper_armor.png");
   private final dtw<bdc> b = new dtw(2.0F);

   public ehx(egk<bdc, dtw<bdc>> var1) {
      super(var1);
   }

   protected float a(float var1) {
      return var1 * 0.01F;
   }

   protected vk a() {
      return a;
   }

   protected duc<bdc> b() {
      return this.b;
   }
}
