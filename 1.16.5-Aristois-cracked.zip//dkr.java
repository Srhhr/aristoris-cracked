public interface dkr {
   int getColor(bmb var1, int var2);
}
