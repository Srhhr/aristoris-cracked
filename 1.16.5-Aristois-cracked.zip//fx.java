import com.google.common.collect.AbstractIterator;
import com.mojang.serialization.Codec;
import java.util.Optional;
import java.util.Random;
import java.util.function.Predicate;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import javax.annotation.concurrent.Immutable;
import org.apache.commons.lang3.Validate;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Immutable
public class fx extends gr {
   public static final Codec<fx> a;
   private static final Logger e;
   public static final fx b;
   private static final int f;
   private static final int g;
   private static final int h;
   private static final long i;
   private static final long j;
   private static final long k;
   private static final int l;
   private static final int m;

   public fx(int var1, int var2, int var3) {
      super(var1, var2, var3);
   }

   public fx(double var1, double var3, double var5) {
      super(var1, var3, var5);
   }

   public fx(dcn var1) {
      this(var1.b, var1.c, var1.d);
   }

   public fx(gk var1) {
      this(var1.a(), var1.b(), var1.c());
   }

   public fx(gr var1) {
      this(var1.u(), var1.v(), var1.w());
   }

   public static long a(long var0, gc var2) {
      return a(var0, var2.i(), var2.j(), var2.k());
   }

   public static long a(long var0, int var2, int var3, int var4) {
      return a(b(var0) + var2, c(var0) + var3, d(var0) + var4);
   }

   public static int b(long var0) {
      return (int)(var0 << 64 - m - f >> 64 - f);
   }

   public static int c(long var0) {
      return (int)(var0 << 64 - h >> 64 - h);
   }

   public static int d(long var0) {
      return (int)(var0 << 64 - l - g >> 64 - g);
   }

   public static fx e(long var0) {
      return new fx(b(var0), c(var0), d(var0));
   }

   public long a() {
      return a(this.u(), this.v(), this.w());
   }

   public static long a(int var0, int var1, int var2) {
      long var3 = 0L;
      var3 |= ((long)var0 & i) << m;
      var3 |= ((long)var1 & j) << 0;
      var3 |= ((long)var2 & k) << l;
      return var3;
   }

   public static long f(long var0) {
      return var0 & -16L;
   }

   public fx a(double var1, double var3, double var5) {
      return var1 == 0.0D && var3 == 0.0D && var5 == 0.0D ? this : new fx((double)this.u() + var1, (double)this.v() + var3, (double)this.w() + var5);
   }

   public fx b(int var1, int var2, int var3) {
      return var1 == 0 && var2 == 0 && var3 == 0 ? this : new fx(this.u() + var1, this.v() + var2, this.w() + var3);
   }

   public fx a(gr var1) {
      return this.b(var1.u(), var1.v(), var1.w());
   }

   public fx b(gr var1) {
      return this.b(-var1.u(), -var1.v(), -var1.w());
   }

   public fx b() {
      return this.a(gc.b);
   }

   public fx b(int var1) {
      return this.a(gc.b, var1);
   }

   public fx c() {
      return this.a(gc.a);
   }

   public fx c(int var1) {
      return this.a(gc.a, var1);
   }

   public fx d() {
      return this.a(gc.c);
   }

   public fx d(int var1) {
      return this.a(gc.c, var1);
   }

   public fx e() {
      return this.a(gc.d);
   }

   public fx e(int var1) {
      return this.a(gc.d, var1);
   }

   public fx f() {
      return this.a(gc.e);
   }

   public fx f(int var1) {
      return this.a(gc.e, var1);
   }

   public fx g() {
      return this.a(gc.f);
   }

   public fx g(int var1) {
      return this.a(gc.f, var1);
   }

   public fx a(gc var1) {
      return new fx(this.u() + var1.i(), this.v() + var1.j(), this.w() + var1.k());
   }

   public fx a(gc var1, int var2) {
      return var2 == 0 ? this : new fx(this.u() + var1.i() * var2, this.v() + var1.j() * var2, this.w() + var1.k() * var2);
   }

   public fx a(gc.a var1, int var2) {
      if (var2 == 0) {
         return this;
      } else {
         int var3 = var1 == gc.a.a ? var2 : 0;
         int var4 = var1 == gc.a.b ? var2 : 0;
         int var5 = var1 == gc.a.c ? var2 : 0;
         return new fx(this.u() + var3, this.v() + var4, this.w() + var5);
      }
   }

   public fx a(bzm var1) {
      switch(var1) {
      case a:
      default:
         return this;
      case b:
         return new fx(-this.w(), this.v(), this.u());
      case c:
         return new fx(-this.u(), this.v(), -this.w());
      case d:
         return new fx(this.w(), this.v(), -this.u());
      }
   }

   public fx c(gr var1) {
      return new fx(this.v() * var1.w() - this.w() * var1.v(), this.w() * var1.u() - this.u() * var1.w(), this.u() * var1.v() - this.v() * var1.u());
   }

   public fx h() {
      return this;
   }

   public fx.a i() {
      return new fx.a(this.u(), this.v(), this.w());
   }

   public static Iterable<fx> a(Random var0, int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      int var8 = var5 - var2 + 1;
      int var9 = var6 - var3 + 1;
      int var10 = var7 - var4 + 1;
      return () -> {
         return new AbstractIterator<fx>() {
            final fx.a a = new fx.a();
            int b = var0;

            protected fx a() {
               if (this.b <= 0) {
                  return (fx)this.endOfData();
               } else {
                  fx var1x = this.a.d(var1 + var2.nextInt(var3), var4 + var2.nextInt(var5), var6 + var2.nextInt(var7));
                  --this.b;
                  return var1x;
               }
            }

            // $FF: synthetic method
            protected Object computeNext() {
               return this.a();
            }
         };
      };
   }

   public static Iterable<fx> a(fx var0, int var1, int var2, int var3) {
      int var4 = var1 + var2 + var3;
      int var5 = var0.u();
      int var6 = var0.v();
      int var7 = var0.w();
      return () -> {
         return new AbstractIterator<fx>() {
            private final fx.a h = new fx.a();
            private int i;
            private int j;
            private int k;
            private int l;
            private int m;
            private boolean n;

            protected fx a() {
               if (this.n) {
                  this.n = false;
                  this.h.q(var0 - (this.h.w() - var0));
                  return this.h;
               } else {
                  fx.a var1x;
                  for(var1x = null; var1x == null; ++this.m) {
                     if (this.m > this.k) {
                        ++this.l;
                        if (this.l > this.j) {
                           ++this.i;
                           if (this.i > var1) {
                              return (fx)this.endOfData();
                           }

                           this.j = Math.min(var2, this.i);
                           this.l = -this.j;
                        }

                        this.k = Math.min(var3, this.i - Math.abs(this.l));
                        this.m = -this.k;
                     }

                     int var2x = this.l;
                     int var3x = this.m;
                     int var4x = this.i - Math.abs(var2x) - Math.abs(var3x);
                     if (var4x <= var4) {
                        this.n = var4x != 0;
                        var1x = this.h.d(var5 + var2x, var6 + var3x, var0 + var4x);
                     }
                  }

                  return var1x;
               }
            }

            // $FF: synthetic method
            protected Object computeNext() {
               return this.a();
            }
         };
      };
   }

   public static Optional<fx> a(fx var0, int var1, int var2, Predicate<fx> var3) {
      return b(var0, var1, var2, var1).filter(var3).findFirst();
   }

   public static Stream<fx> b(fx var0, int var1, int var2, int var3) {
      return StreamSupport.stream(a(var0, var1, var2, var3).spliterator(), false);
   }

   public static Iterable<fx> a(fx var0, fx var1) {
      return b(Math.min(var0.u(), var1.u()), Math.min(var0.v(), var1.v()), Math.min(var0.w(), var1.w()), Math.max(var0.u(), var1.u()), Math.max(var0.v(), var1.v()), Math.max(var0.w(), var1.w()));
   }

   public static Stream<fx> b(fx var0, fx var1) {
      return StreamSupport.stream(a(var0, var1).spliterator(), false);
   }

   public static Stream<fx> a(cra var0) {
      return a(Math.min(var0.a, var0.d), Math.min(var0.b, var0.e), Math.min(var0.c, var0.f), Math.max(var0.a, var0.d), Math.max(var0.b, var0.e), Math.max(var0.c, var0.f));
   }

   public static Stream<fx> a(dci var0) {
      return a(afm.c(var0.a), afm.c(var0.b), afm.c(var0.c), afm.c(var0.d), afm.c(var0.e), afm.c(var0.f));
   }

   public static Stream<fx> a(int var0, int var1, int var2, int var3, int var4, int var5) {
      return StreamSupport.stream(b(var0, var1, var2, var3, var4, var5).spliterator(), false);
   }

   public static Iterable<fx> b(int var0, int var1, int var2, int var3, int var4, int var5) {
      int var6 = var3 - var0 + 1;
      int var7 = var4 - var1 + 1;
      int var8 = var5 - var2 + 1;
      int var9 = var6 * var7 * var8;
      return () -> {
         return new AbstractIterator<fx>() {
            private final fx.a g = new fx.a();
            private int h;

            protected fx a() {
               if (this.h == var0) {
                  return (fx)this.endOfData();
               } else {
                  int var1x = this.h % var1;
                  int var2x = this.h / var1;
                  int var3x = var2x % var2;
                  int var4x = var2x / var2;
                  ++this.h;
                  return this.g.d(var3 + var1x, var4 + var3x, var5 + var4x);
               }
            }

            // $FF: synthetic method
            protected Object computeNext() {
               return this.a();
            }
         };
      };
   }

   public static Iterable<fx.a> a(fx var0, int var1, gc var2, gc var3) {
      Validate.validState(var2.n() != var3.n(), "The two directions cannot be on the same axis", new Object[0]);
      return () -> {
         return new AbstractIterator<fx.a>() {
            private final gc[] e = new gc[]{var0, var1, var0.f(), var1.f()};
            private final fx.a f = var2.i().c(var1);
            private final int g = 4 * var3;
            private int h = -1;
            private int i;
            private int j;
            private int k;
            private int l;
            private int m;

            {
               this.k = this.f.u();
               this.l = this.f.v();
               this.m = this.f.w();
            }

            protected fx.a a() {
               this.f.d(this.k, this.l, this.m).c(this.e[(this.h + 4) % 4]);
               this.k = this.f.u();
               this.l = this.f.v();
               this.m = this.f.w();
               if (this.j >= this.i) {
                  if (this.h >= this.g) {
                     return (fx.a)this.endOfData();
                  }

                  ++this.h;
                  this.j = 0;
                  this.i = this.h / 2 + 1;
               }

               ++this.j;
               return this.f;
            }

            // $FF: synthetic method
            protected Object computeNext() {
               return this.a();
            }
         };
      };
   }

   // $FF: synthetic method
   public gr d(gr var1) {
      return this.c(var1);
   }

   // $FF: synthetic method
   public gr b(gc var1, int var2) {
      return this.a(var1, var2);
   }

   // $FF: synthetic method
   public gr l(int var1) {
      return this.c(var1);
   }

   // $FF: synthetic method
   public gr n() {
      return this.c();
   }

   // $FF: synthetic method
   public gr m(int var1) {
      return this.b(var1);
   }

   // $FF: synthetic method
   public gr o() {
      return this.b();
   }

   static {
      a = Codec.INT_STREAM.comapFlatMap((var0) -> {
         return x.a((IntStream)var0, 3).map((var0x) -> {
            return new fx(var0x[0], var0x[1], var0x[2]);
         });
      }, (var0) -> {
         return IntStream.of(new int[]{var0.u(), var0.v(), var0.w()});
      }).stable();
      e = LogManager.getLogger();
      b = new fx(0, 0, 0);
      f = 1 + afm.f(afm.c(30000000));
      g = f;
      h = 64 - f - g;
      i = (1L << f) - 1L;
      j = (1L << h) - 1L;
      k = (1L << g) - 1L;
      l = h;
      m = h + g;
   }

   public static class a extends fx {
      public a() {
         this(0, 0, 0);
      }

      public a(int var1, int var2, int var3) {
         super(var1, var2, var3);
      }

      public a(double var1, double var3, double var5) {
         this(afm.c(var1), afm.c(var3), afm.c(var5));
      }

      public fx a(double var1, double var3, double var5) {
         return super.a(var1, var3, var5).h();
      }

      public fx b(int var1, int var2, int var3) {
         return super.b(var1, var2, var3).h();
      }

      public fx a(gc var1, int var2) {
         return super.a(var1, var2).h();
      }

      public fx a(gc.a var1, int var2) {
         return super.a(var1, var2).h();
      }

      public fx a(bzm var1) {
         return super.a(var1).h();
      }

      public fx.a d(int var1, int var2, int var3) {
         this.o(var1);
         this.p(var2);
         this.q(var3);
         return this;
      }

      public fx.a c(double var1, double var3, double var5) {
         return this.d(afm.c(var1), afm.c(var3), afm.c(var5));
      }

      public fx.a g(gr var1) {
         return this.d(var1.u(), var1.v(), var1.w());
      }

      public fx.a g(long var1) {
         return this.d(b(var1), c(var1), d(var1));
      }

      public fx.a a(fv var1, int var2, int var3, int var4) {
         return this.d(var1.a(var2, var3, var4, gc.a.a), var1.a(var2, var3, var4, gc.a.b), var1.a(var2, var3, var4, gc.a.c));
      }

      public fx.a a(gr var1, gc var2) {
         return this.d(var1.u() + var2.i(), var1.v() + var2.j(), var1.w() + var2.k());
      }

      public fx.a a(gr var1, int var2, int var3, int var4) {
         return this.d(var1.u() + var2, var1.v() + var3, var1.w() + var4);
      }

      public fx.a c(gc var1) {
         return this.c(var1, 1);
      }

      public fx.a c(gc var1, int var2) {
         return this.d(this.u() + var1.i() * var2, this.v() + var1.j() * var2, this.w() + var1.k() * var2);
      }

      public fx.a e(int var1, int var2, int var3) {
         return this.d(this.u() + var1, this.v() + var2, this.w() + var3);
      }

      public fx.a h(gr var1) {
         return this.d(this.u() + var1.u(), this.v() + var1.v(), this.w() + var1.w());
      }

      public fx.a a(gc.a var1, int var2, int var3) {
         switch(var1) {
         case a:
            return this.d(afm.a(this.u(), var2, var3), this.v(), this.w());
         case b:
            return this.d(this.u(), afm.a(this.v(), var2, var3), this.w());
         case c:
            return this.d(this.u(), this.v(), afm.a(this.w(), var2, var3));
         default:
            throw new IllegalStateException("Unable to clamp axis " + var1);
         }
      }

      public void o(int var1) {
         super.o(var1);
      }

      public void p(int var1) {
         super.p(var1);
      }

      public void q(int var1) {
         super.q(var1);
      }

      public fx h() {
         return new fx(this);
      }

      // $FF: synthetic method
      public gr d(gr var1) {
         return super.c(var1);
      }

      // $FF: synthetic method
      public gr b(gc var1, int var2) {
         return this.a(var1, var2);
      }

      // $FF: synthetic method
      public gr l(int var1) {
         return super.c(var1);
      }

      // $FF: synthetic method
      public gr n() {
         return super.c();
      }

      // $FF: synthetic method
      public gr m(int var1) {
         return super.b(var1);
      }

      // $FF: synthetic method
      public gr o() {
         return super.b();
      }
   }
}
