import javax.annotation.Nullable;

public class edy extends efr<bcn, dti> {
   public static final vk a = new vk("textures/entity/armorstand/wood.png");

   public edy(eet var1) {
      super(var1, new dtj(), 0.0F);
      this.a((eit)(new eik(this, new dti(0.5F), new dti(1.0F))));
      this.a((eit)(new ein(this)));
      this.a((eit)(new eid(this)));
      this.a((eit)(new ehz(this)));
   }

   public vk a(bcn var1) {
      return a;
   }

   protected void a(bcn var1, dfm var2, float var3, float var4, float var5) {
      var2.a(g.d.a(180.0F - var4));
      float var6 = (float)(var1.l.T() - var1.bi) + var5;
      if (var6 < 5.0F) {
         var2.a(g.d.a(afm.a(var6 / 1.5F * 3.1415927F) * 3.0F));
      }

   }

   protected boolean b(bcn var1) {
      double var2 = this.b.b(var1);
      float var4 = var1.bz() ? 32.0F : 64.0F;
      return var2 >= (double)(var4 * var4) ? false : var1.bX();
   }

   @Nullable
   protected eao a(bcn var1, boolean var2, boolean var3, boolean var4) {
      if (!var1.q()) {
         return super.a(var1, var2, var3, var4);
      } else {
         vk var5 = this.a(var1);
         if (var3) {
            return eao.c(var5, false);
         } else {
            return var2 ? eao.a(var5, false) : null;
         }
      }
   }
}
