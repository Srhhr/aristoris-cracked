import com.google.gson.JsonObject;

public class cr extends ck<cr.a> {
   private static final vk a = new vk("villager_trade");

   public vk a() {
      return a;
   }

   public cr.a a(JsonObject var1, bg.b var2, ax var3) {
      bg.b var4 = bg.b.a(var1, "villager", var3);
      bq var5 = bq.a(var1.get("item"));
      return new cr.a(var2, var4, var5);
   }

   public void a(aah var1, bfe var2, bmb var3) {
      cyv var4 = bg.b(var1, var2);
      this.a(var1, (var2x) -> {
         return var2x.a(var4, var3);
      });
   }

   // $FF: synthetic method
   public al b(JsonObject var1, bg.b var2, ax var3) {
      return this.a(var1, var2, var3);
   }

   public static class a extends al {
      private final bg.b a;
      private final bq b;

      public a(bg.b var1, bg.b var2, bq var3) {
         super(cr.a, var1);
         this.a = var2;
         this.b = var3;
      }

      public static cr.a c() {
         return new cr.a(bg.b.a, bg.b.a, bq.a);
      }

      public boolean a(cyv var1, bmb var2) {
         if (!this.a.a(var1)) {
            return false;
         } else {
            return this.b.a(var2);
         }
      }

      public JsonObject a(ci var1) {
         JsonObject var2 = super.a(var1);
         var2.add("item", this.b.a());
         var2.add("villager", this.a.a(var1));
         return var2;
      }
   }
}
