public class cbp extends buo {
   public cbp(ceg.c var1) {
      super(var1);
   }

   public void a(ceh var1, brx var2, fx var3, aqa var4) {
      var4.a(var1, new dcn(0.25D, 0.05000000074505806D, 0.25D));
   }
}
