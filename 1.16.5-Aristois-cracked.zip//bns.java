import java.util.List;
import javax.annotation.Nullable;

public class bns extends blx {
   public bns(blx.a var1) {
      super(var1);
   }

   public static boolean a(@Nullable md var0) {
      if (!bnr.a(var0)) {
         return false;
      } else if (!var0.c("title", 8)) {
         return false;
      } else {
         String var1 = var0.l("title");
         return var1.length() > 32 ? false : var0.c("author", 8);
      }
   }

   public static int d(bmb var0) {
      return var0.o().h("generation");
   }

   public static int g(bmb var0) {
      md var1 = var0.o();
      return var1 != null ? var1.d("pages", 8).size() : 0;
   }

   public nr h(bmb var1) {
      if (var1.n()) {
         md var2 = var1.o();
         String var3 = var2.l("title");
         if (!aft.b(var3)) {
            return new oe(var3);
         }
      }

      return super.h(var1);
   }

   public void a(bmb var1, @Nullable brx var2, List<nr> var3, bnl var4) {
      if (var1.n()) {
         md var5 = var1.o();
         String var6 = var5.l("author");
         if (!aft.b(var6)) {
            var3.add((new of("book.byAuthor", new Object[]{var6})).a(k.h));
         }

         var3.add((new of("book.generation." + var5.h("generation"))).a(k.h));
      }

   }

   public aou a(boa var1) {
      brx var2 = var1.p();
      fx var3 = var1.a();
      ceh var4 = var2.d_(var3);
      if (var4.a(bup.lY)) {
         return bxy.a(var2, var3, var4, var1.m()) ? aou.a(var2.v) : aou.c;
      } else {
         return aou.c;
      }
   }

   public aov<bmb> a(brx var1, bfw var2, aot var3) {
      bmb var4 = var2.b((aot)var3);
      var2.a(var4, var3);
      var2.b(aea.c.b(this));
      return aov.a(var4, var1.s_());
   }

   public static boolean a(bmb var0, @Nullable db var1, @Nullable bfw var2) {
      md var3 = var0.o();
      if (var3 != null && !var3.q("resolved")) {
         var3.a("resolved", true);
         if (!a(var3)) {
            return false;
         } else {
            mj var4 = var3.d("pages", 8);

            for(int var5 = 0; var5 < var4.size(); ++var5) {
               String var6 = var4.j(var5);

               Object var7;
               try {
                  nr var10 = nr.a.b(var6);
                  var7 = ns.a(var1, (nr)var10, var2, 0);
               } catch (Exception var9) {
                  var7 = new oe(var6);
               }

               var4.d(var5, ms.a(nr.a.a((nr)var7)));
            }

            var3.a((String)"pages", (mt)var4);
            return true;
         }
      } else {
         return false;
      }
   }

   public boolean e(bmb var1) {
      return true;
   }
}
