import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Objects;

public class ms implements mt {
   public static final mv<ms> a = new mv<ms>() {
      public ms a(DataInput var1, int var2, mm var3) throws IOException {
         var3.a(288L);
         String var4 = var1.readUTF();
         var3.a((long)(16 * var4.length()));
         return ms.a(var4);
      }

      public String a() {
         return "STRING";
      }

      public String b() {
         return "TAG_String";
      }

      public boolean c() {
         return true;
      }

      // $FF: synthetic method
      public mt b(DataInput var1, int var2, mm var3) throws IOException {
         return this.a(var1, var2, var3);
      }
   };
   private static final ms b = new ms("");
   private final String c;

   private ms(String var1) {
      Objects.requireNonNull(var1, "Null string not allowed");
      this.c = var1;
   }

   public static ms a(String var0) {
      return var0.isEmpty() ? b : new ms(var0);
   }

   public void a(DataOutput var1) throws IOException {
      var1.writeUTF(this.c);
   }

   public byte a() {
      return 8;
   }

   public mv<ms> b() {
      return a;
   }

   public String toString() {
      return b(this.c);
   }

   public ms d() {
      return this;
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else {
         return var1 instanceof ms && Objects.equals(this.c, ((ms)var1).c);
      }
   }

   public int hashCode() {
      return this.c.hashCode();
   }

   public String f_() {
      return this.c;
   }

   public nr a(String var1, int var2) {
      String var3 = b(this.c);
      String var4 = var3.substring(0, 1);
      nr var5 = (new oe(var3.substring(1, var3.length() - 1))).a(e);
      return (new oe(var4)).a(var5).c(var4);
   }

   public static String b(String var0) {
      StringBuilder var1 = new StringBuilder(" ");
      char var2 = 0;

      for(int var3 = 0; var3 < var0.length(); ++var3) {
         char var4 = var0.charAt(var3);
         if (var4 == '\\') {
            var1.append('\\');
         } else if (var4 == '"' || var4 == '\'') {
            if (var2 == 0) {
               var2 = var4 == '"' ? 39 : 34;
            }

            if (var2 == var4) {
               var1.append('\\');
            }
         }

         var1.append(var4);
      }

      if (var2 == 0) {
         var2 = 34;
      }

      var1.setCharAt(0, (char)var2);
      var1.append((char)var2);
      return var1.toString();
   }

   // $FF: synthetic method
   public mt c() {
      return this.d();
   }
}
