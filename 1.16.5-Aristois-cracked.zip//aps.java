import com.google.common.collect.Maps;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.Map.Entry;
import javax.annotation.Nullable;

public class aps {
   private final Map<arg, arj> a = Maps.newHashMap();
   private final apt b;
   private final int c;
   @Nullable
   private String d;

   @Nullable
   public static aps a(int var0) {
      return (aps)gm.P.a(var0);
   }

   public static int a(aps var0) {
      return gm.P.a((Object)var0);
   }

   protected aps(apt var1, int var2) {
      this.b = var1;
      this.c = var2;
   }

   public void a(aqm var1, int var2) {
      if (this == apw.j) {
         if (var1.dk() < var1.dx()) {
            var1.b(1.0F);
         }
      } else if (this == apw.s) {
         if (var1.dk() > 1.0F) {
            var1.a(apk.o, 1.0F);
         }
      } else if (this == apw.t) {
         var1.a(apk.p, 1.0F);
      } else if (this == apw.q && var1 instanceof bfw) {
         ((bfw)var1).t(0.005F * (float)(var2 + 1));
      } else if (this == apw.w && var1 instanceof bfw) {
         if (!var1.l.v) {
            ((bfw)var1).eI().a(var2 + 1, 1.0F);
         }
      } else if ((this != apw.f || var1.dj()) && (this != apw.g || !var1.dj())) {
         if (this == apw.g && !var1.dj() || this == apw.f && var1.dj()) {
            var1.a(apk.o, (float)(6 << var2));
         }
      } else {
         var1.b((float)Math.max(4 << var2, 0));
      }

   }

   public void a(@Nullable aqa var1, @Nullable aqa var2, aqm var3, int var4, double var5) {
      int var7;
      if ((this != apw.f || var3.dj()) && (this != apw.g || !var3.dj())) {
         if ((this != apw.g || var3.dj()) && (this != apw.f || !var3.dj())) {
            this.a(var3, var4);
         } else {
            var7 = (int)(var5 * (double)(6 << var4) + 0.5D);
            if (var1 == null) {
               var3.a(apk.o, (float)var7);
            } else {
               var3.a(apk.c(var1, var2), (float)var7);
            }
         }
      } else {
         var7 = (int)(var5 * (double)(4 << var4) + 0.5D);
         var3.b((float)var7);
      }

   }

   public boolean a(int var1, int var2) {
      int var3;
      if (this == apw.j) {
         var3 = 50 >> var2;
         if (var3 > 0) {
            return var1 % var3 == 0;
         } else {
            return true;
         }
      } else if (this == apw.s) {
         var3 = 25 >> var2;
         if (var3 > 0) {
            return var1 % var3 == 0;
         } else {
            return true;
         }
      } else if (this == apw.t) {
         var3 = 40 >> var2;
         if (var3 > 0) {
            return var1 % var3 == 0;
         } else {
            return true;
         }
      } else {
         return this == apw.q;
      }
   }

   public boolean a() {
      return false;
   }

   protected String b() {
      if (this.d == null) {
         this.d = x.a("effect", gm.P.b((Object)this));
      }

      return this.d;
   }

   public String c() {
      return this.b();
   }

   public nr d() {
      return new of(this.c());
   }

   public apt e() {
      return this.b;
   }

   public int f() {
      return this.c;
   }

   public aps a(arg var1, String var2, double var3, arj.a var5) {
      arj var6 = new arj(UUID.fromString(var2), this::c, var3, var5);
      this.a.put(var1, var6);
      return this;
   }

   public Map<arg, arj> g() {
      return this.a;
   }

   public void a(aqm var1, ari var2, int var3) {
      Iterator var4 = this.a.entrySet().iterator();

      while(var4.hasNext()) {
         Entry<arg, arj> var5 = (Entry)var4.next();
         arh var6 = var2.a((arg)var5.getKey());
         if (var6 != null) {
            var6.d((arj)var5.getValue());
         }
      }

   }

   public void b(aqm var1, ari var2, int var3) {
      Iterator var4 = this.a.entrySet().iterator();

      while(var4.hasNext()) {
         Entry<arg, arj> var5 = (Entry)var4.next();
         arh var6 = var2.a((arg)var5.getKey());
         if (var6 != null) {
            arj var7 = (arj)var5.getValue();
            var6.d(var7);
            var6.c(new arj(var7.a(), this.c() + " " + var3, this.a(var3, var7), var7.c()));
         }
      }

   }

   public double a(int var1, arj var2) {
      return var2.d() * (double)(var1 + 1);
   }

   public boolean h() {
      return this.b == apt.a;
   }
}
