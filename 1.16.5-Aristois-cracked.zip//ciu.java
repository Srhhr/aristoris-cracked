import com.mojang.serialization.Codec;
import java.util.Random;

public class ciu extends cjl<cmh> {
   public ciu(Codec<cmh> var1) {
      super(var1);
   }

   public boolean a(bsr var1, cfy var2, Random var3, fx var4, cmh var5) {
      if (var1.w(var4) && var1.d_(var4.c()).a(bup.ee)) {
         bvf.a(var1, var4, var3, 8);
         return true;
      } else {
         return false;
      }
   }
}
