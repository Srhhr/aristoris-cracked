import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Random;
import java.util.Set;

public class cng extends cnl {
   public static final Codec<cng> a = RecordCodecBuilder.create((var0) -> {
      return b(var0).apply(var0, cng::new);
   });

   public cng(afw var1, afw var2) {
      super(var1, var2);
   }

   protected cnm<?> a() {
      return cnm.d;
   }

   protected void a(bsb var1, Random var2, cmz var3, int var4, cnl.b var5, int var6, int var7, Set<fx> var8, int var9, cra var10) {
      boolean var11 = var5.c();
      fx var12 = var5.a().b(var9);
      this.a(var1, var2, var3, var12, var7 + var5.b(), var8, -1 - var6, var11, var10);
      this.a(var1, var2, var3, var12, var7 - 1, var8, -var6, var11, var10);
      this.a(var1, var2, var3, var12, var7 + var5.b() - 1, var8, 0, var11, var10);
   }

   public int a(Random var1, int var2, cmz var3) {
      return 0;
   }

   protected boolean a(Random var1, int var2, int var3, int var4, int var5, boolean var6) {
      if (var3 == 0) {
         return (var2 > 1 || var4 > 1) && var2 != 0 && var4 != 0;
      } else {
         return var2 == var5 && var4 == var5 && var5 > 0;
      }
   }
}
