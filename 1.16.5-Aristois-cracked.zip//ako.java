import com.mojang.datafixers.DSL;
import com.mojang.datafixers.Typed;
import com.mojang.datafixers.schemas.Schema;
import com.mojang.serialization.Dynamic;

public class ako extends ajv {
   public ako(Schema var1, boolean var2) {
      super(var1, var2, "Remove Golem Gossip Fix", akn.p, "minecraft:villager");
   }

   protected Typed<?> a(Typed<?> var1) {
      return var1.update(DSL.remainderFinder(), ako::a);
   }

   private static Dynamic<?> a(Dynamic<?> var0) {
      return var0.update("Gossips", (var1) -> {
         return var0.createList(var1.asStream().filter((var0x) -> {
            return !var0x.get("Type").asString("").equals("golem");
         }));
      });
   }
}
