import com.google.common.base.Objects;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.Set;

public class aad extends aok {
   private final Set<aah> h = Sets.newHashSet();
   private final Set<aah> i;
   private boolean j;

   public aad(nr var1, aok.a var2, aok.b var3) {
      super(afm.a(), var1, var2, var3);
      this.i = Collections.unmodifiableSet(this.h);
      this.j = true;
   }

   public void a(float var1) {
      if (var1 != this.b) {
         super.a(var1);
         this.a(oz.a.c);
      }

   }

   public void a(aok.a var1) {
      if (var1 != this.c) {
         super.a(var1);
         this.a(oz.a.e);
      }

   }

   public void a(aok.b var1) {
      if (var1 != this.d) {
         super.a(var1);
         this.a(oz.a.e);
      }

   }

   public aok a(boolean var1) {
      if (var1 != this.e) {
         super.a(var1);
         this.a(oz.a.f);
      }

      return this;
   }

   public aok b(boolean var1) {
      if (var1 != this.f) {
         super.b(var1);
         this.a(oz.a.f);
      }

      return this;
   }

   public aok c(boolean var1) {
      if (var1 != this.g) {
         super.c(var1);
         this.a(oz.a.f);
      }

      return this;
   }

   public void a(nr var1) {
      if (!Objects.equal(var1, this.a)) {
         super.a(var1);
         this.a(oz.a.d);
      }

   }

   private void a(oz.a var1) {
      if (this.j) {
         oz var2 = new oz(var1, this);
         Iterator var3 = this.h.iterator();

         while(var3.hasNext()) {
            aah var4 = (aah)var3.next();
            var4.b.a((oj)var2);
         }
      }

   }

   public void a(aah var1) {
      if (this.h.add(var1) && this.j) {
         var1.b.a((oj)(new oz(oz.a.a, this)));
      }

   }

   public void b(aah var1) {
      if (this.h.remove(var1) && this.j) {
         var1.b.a((oj)(new oz(oz.a.b, this)));
      }

   }

   public void b() {
      if (!this.h.isEmpty()) {
         Iterator var1 = Lists.newArrayList(this.h).iterator();

         while(var1.hasNext()) {
            aah var2 = (aah)var1.next();
            this.b(var2);
         }
      }

   }

   public boolean g() {
      return this.j;
   }

   public void d(boolean var1) {
      if (var1 != this.j) {
         this.j = var1;
         Iterator var2 = this.h.iterator();

         while(var2.hasNext()) {
            aah var3 = (aah)var2.next();
            var3.b.a((oj)(new oz(var1 ? oz.a.a : oz.a.b, this)));
         }
      }

   }

   public Collection<aah> h() {
      return this.i;
   }
}
