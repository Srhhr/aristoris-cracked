import it.unimi.dsi.fastutil.ints.Int2IntFunction;

public class ecf<S extends ccj> implements bwc.b<S, Int2IntFunction> {
   public Int2IntFunction a(S var1, S var2) {
      return (var2x) -> {
         int var3 = eae.a((bra)var1.v(), (fx)var1.o());
         int var4 = eae.a((bra)var2.v(), (fx)var2.o());
         int var5 = eaf.a(var3);
         int var6 = eaf.a(var4);
         int var7 = eaf.b(var3);
         int var8 = eaf.b(var4);
         return eaf.a(Math.max(var5, var6), Math.max(var7, var8));
      };
   }

   public Int2IntFunction a(S var1) {
      return (var0) -> {
         return var0;
      };
   }

   public Int2IntFunction a() {
      return (var0) -> {
         return var0;
      };
   }

   // $FF: synthetic method
   public Object b() {
      return this.a();
   }
}
