import com.google.common.collect.Maps;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

public class fm {
   private static final Map<vk, SuggestionProvider<dd>> f = Maps.newHashMap();
   private static final vk g = new vk("ask_server");
   public static final SuggestionProvider<dd> a;
   public static final SuggestionProvider<db> b;
   public static final SuggestionProvider<db> c;
   public static final SuggestionProvider<db> d;
   public static final SuggestionProvider<db> e;

   public static <S extends dd> SuggestionProvider<S> a(vk var0, SuggestionProvider<dd> var1) {
      if (f.containsKey(var0)) {
         throw new IllegalArgumentException("A command suggestion provider is already registered with the name " + var0);
      } else {
         f.put(var0, var1);
         return new fm.a(var0, var1);
      }
   }

   public static SuggestionProvider<dd> a(vk var0) {
      return (SuggestionProvider)f.getOrDefault(var0, a);
   }

   public static vk a(SuggestionProvider<dd> var0) {
      return var0 instanceof fm.a ? ((fm.a)var0).b : g;
   }

   public static SuggestionProvider<dd> b(SuggestionProvider<dd> var0) {
      return var0 instanceof fm.a ? var0 : a;
   }

   static {
      a = a(g, (var0, var1) -> {
         return ((dd)var0.getSource()).a(var0, var1);
      });
      b = a(new vk("all_recipes"), (var0, var1) -> {
         return dd.a(((dd)var0.getSource()).o(), var1);
      });
      c = a(new vk("available_sounds"), (var0, var1) -> {
         return dd.a((Iterable)((dd)var0.getSource()).n(), (SuggestionsBuilder)var1);
      });
      d = a(new vk("available_biomes"), (var0, var1) -> {
         return dd.a((Iterable)((dd)var0.getSource()).q().b(gm.ay).c(), (SuggestionsBuilder)var1);
      });
      e = a(new vk("summonable_entities"), (var0, var1) -> {
         return dd.a(gm.S.g().filter(aqe::b), var1, aqe::a, (var0x) -> {
            return new of(x.a("entity", aqe.a(var0x)));
         });
      });
   }

   public static class a implements SuggestionProvider<dd> {
      private final SuggestionProvider<dd> a;
      private final vk b;

      public a(vk var1, SuggestionProvider<dd> var2) {
         this.a = var2;
         this.b = var1;
      }

      public CompletableFuture<Suggestions> getSuggestions(CommandContext<dd> var1, SuggestionsBuilder var2) throws CommandSyntaxException {
         return this.a.getSuggestions(var1, var2);
      }
   }
}
