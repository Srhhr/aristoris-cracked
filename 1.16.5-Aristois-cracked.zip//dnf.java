import com.google.common.collect.Lists;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.ints.IntSet;
import it.unimi.dsi.fastutil.ints.IntSets;
import java.io.IOException;
import java.util.List;
import javax.annotation.Nullable;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class dnf implements deb {
   private static final Logger a = LogManager.getLogger();
   private final det b;
   private final Int2ObjectMap<dnf.b> c;

   private dnf(det var1, Int2ObjectMap<dnf.b> var2) {
      this.b = var1;
      this.c = var2;
   }

   public void close() {
      this.b.close();
   }

   @Nullable
   public dec a(int var1) {
      return (dec)this.c.get(var1);
   }

   public IntSet a() {
      return IntSets.unmodifiable(this.c.keySet());
   }

   // $FF: synthetic method
   dnf(det var1, Int2ObjectMap var2, Object var3) {
      this(var1, var2);
   }

   static final class b implements dec {
      private final float a;
      private final det b;
      private final int c;
      private final int d;
      private final int e;
      private final int f;
      private final int g;
      private final int h;

      private b(float var1, det var2, int var3, int var4, int var5, int var6, int var7, int var8) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
         this.d = var4;
         this.e = var5;
         this.f = var6;
         this.g = var7;
         this.h = var8;
      }

      public float g() {
         return 1.0F / this.a;
      }

      public int d() {
         return this.e;
      }

      public int e() {
         return this.f;
      }

      public float getAdvance() {
         return (float)this.g;
      }

      public float l() {
         return dec.super.l() + 7.0F - (float)this.h;
      }

      public void a(int var1, int var2) {
         this.b.a(0, var1, var2, this.c, this.d, this.e, this.f, false, false);
      }

      public boolean f() {
         return this.b.c().a() > 1;
      }

      // $FF: synthetic method
      b(float var1, det var2, int var3, int var4, int var5, int var6, int var7, int var8, Object var9) {
         this(var1, var2, var3, var4, var5, var6, var7, var8);
      }
   }

   public static class a implements dng {
      private final vk a;
      private final List<int[]> b;
      private final int c;
      private final int d;

      public a(vk var1, int var2, int var3, List<int[]> var4) {
         this.a = new vk(var1.b(), "textures/" + var1.a());
         this.b = var4;
         this.c = var2;
         this.d = var3;
      }

      public static dnf.a a(JsonObject var0) {
         int var1 = afd.a(var0, "height", (int)8);
         int var2 = afd.n(var0, "ascent");
         if (var2 > var1) {
            throw new JsonParseException("Ascent " + var2 + " higher than height " + var1);
         } else {
            List<int[]> var3 = Lists.newArrayList();
            JsonArray var4 = afd.u(var0, "chars");

            for(int var5 = 0; var5 < var4.size(); ++var5) {
               String var6 = afd.a(var4.get(var5), "chars[" + var5 + "]");
               int[] var7 = var6.codePoints().toArray();
               if (var5 > 0) {
                  int var8 = ((int[])var3.get(0)).length;
                  if (var7.length != var8) {
                     throw new JsonParseException("Elements of chars have to be the same length (found: " + var7.length + ", expected: " + var8 + "), pad with space or \\u0000");
                  }
               }

               var3.add(var7);
            }

            if (!var3.isEmpty() && ((int[])var3.get(0)).length != 0) {
               return new dnf.a(new vk(afd.h(var0, "file")), var1, var2, var3);
            } else {
               throw new JsonParseException("Expected to find data in chars, found none.");
            }
         }
      }

      @Nullable
      public deb a(ach var1) {
         try {
            acg var2 = var1.a(this.a);
            Throwable var3 = null;

            try {
               det var4 = det.a(det.a.a, var2.b());
               int var5 = var4.a();
               int var6 = var4.b();
               int var7 = var5 / ((int[])this.b.get(0)).length;
               int var8 = var6 / this.b.size();
               float var9 = (float)this.c / (float)var8;
               Int2ObjectMap<dnf.b> var10 = new Int2ObjectOpenHashMap();

               for(int var11 = 0; var11 < this.b.size(); ++var11) {
                  int var12 = 0;
                  int[] var13 = (int[])this.b.get(var11);
                  int var14 = var13.length;

                  for(int var15 = 0; var15 < var14; ++var15) {
                     int var16 = var13[var15];
                     int var17 = var12++;
                     if (var16 != 0 && var16 != 32) {
                        int var18 = this.a(var4, var7, var8, var17, var11);
                        dnf.b var19 = (dnf.b)var10.put(var16, new dnf.b(var9, var4, var17 * var7, var11 * var8, var7, var8, (int)(0.5D + (double)((float)var18 * var9)) + 1, this.d));
                        if (var19 != null) {
                           dnf.a.warn("Codepoint '{}' declared multiple times in {}", Integer.toHexString(var16), this.a);
                        }
                     }
                  }
               }

               dnf var31 = new dnf(var4, var10);
               return var31;
            } catch (Throwable var28) {
               var3 = var28;
               throw var28;
            } finally {
               if (var2 != null) {
                  if (var3 != null) {
                     try {
                        var2.close();
                     } catch (Throwable var27) {
                        var3.addSuppressed(var27);
                     }
                  } else {
                     var2.close();
                  }
               }

            }
         } catch (IOException var30) {
            throw new RuntimeException(var30.getMessage());
         }
      }

      private int a(det var1, int var2, int var3, int var4, int var5) {
         int var6;
         for(var6 = var2 - 1; var6 >= 0; --var6) {
            int var7 = var4 * var2 + var6;

            for(int var8 = 0; var8 < var3; ++var8) {
               int var9 = var5 * var3 + var8;
               if (var1.b(var7, var9) != 0) {
                  return var6 + 1;
               }
            }
         }

         return var6 + 1;
      }
   }
}
