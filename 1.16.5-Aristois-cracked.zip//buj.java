import java.util.List;
import java.util.Optional;
import javax.annotation.Nullable;
import org.apache.commons.lang3.ArrayUtils;

public class buj extends bxm implements bwm {
   public static final cfe<cev> a;
   public static final cey b;
   protected static final ddh c;
   protected static final ddh d;
   protected static final ddh e;
   protected static final ddh f;
   protected static final ddh g;
   protected static final ddh h;
   protected static final ddh i;
   protected static final ddh j;
   protected static final ddh k;
   private final bkx o;

   public buj(bkx var1, ceg.c var2) {
      super(var2);
      this.o = var1;
      this.j((ceh)((ceh)((ceh)this.n.b()).a(a, cev.b)).a(b, false));
   }

   @Nullable
   public static gc a(brc var0, fx var1) {
      ceh var2 = var0.d_(var1);
      return var2.b() instanceof buj ? (gc)var2.c(aq) : null;
   }

   public aou a(ceh var1, brx var2, fx var3, bfw var4, aot var5, dcj var6) {
      if (var2.v) {
         return aou.b;
      } else {
         if (var1.c(a) != cev.a) {
            var3 = var3.a((gc)var1.c(aq));
            var1 = var2.d_(var3);
            if (!var1.a(this)) {
               return aou.b;
            }
         }

         if (!a(var2)) {
            var2.a(var3, false);
            fx var7 = var3.a(((gc)var1.c(aq)).f());
            if (var2.d_(var7).a(this)) {
               var2.a(var7, false);
            }

            var2.a((aqa)null, apk.a(), (brq)null, (double)var3.u() + 0.5D, (double)var3.v() + 0.5D, (double)var3.w() + 0.5D, 5.0F, true, brp.a.c);
            return aou.a;
         } else if ((Boolean)var1.c(b)) {
            if (!this.a(var2, var3)) {
               var4.a((nr)(new of("block.minecraft.bed.occupied")), true);
            }

            return aou.a;
         } else {
            var4.a(var3).ifLeft((var1x) -> {
               if (var1x != null) {
                  var4.a(var1x.a(), true);
               }

            });
            return aou.a;
         }
      }
   }

   public static boolean a(brx var0) {
      return var0.k().h();
   }

   private boolean a(brx var1, fx var2) {
      List<bfj> var3 = var1.a(bfj.class, new dci(var2), aqm::em);
      if (var3.isEmpty()) {
         return false;
      } else {
         ((bfj)var3.get(0)).en();
         return true;
      }
   }

   public void a(brx var1, fx var2, aqa var3, float var4) {
      super.a(var1, var2, var3, var4 * 0.5F);
   }

   public void a(brc var1, aqa var2) {
      if (var2.bw()) {
         super.a((brc)var1, (aqa)var2);
      } else {
         this.a(var2);
      }

   }

   private void a(aqa var1) {
      dcn var2 = var1.cC();
      if (var2.c < 0.0D) {
         double var3 = var1 instanceof aqm ? 1.0D : 0.8D;
         var1.n(var2.b, -var2.c * 0.6600000262260437D * var3, var2.d);
      }

   }

   public ceh a(ceh var1, gc var2, ceh var3, bry var4, fx var5, fx var6) {
      if (var2 == a((cev)var1.c(a), (gc)var1.c(aq))) {
         return var3.a(this) && var3.c(a) != var1.c(a) ? (ceh)var1.a(b, var3.c(b)) : bup.a.n();
      } else {
         return super.a(var1, var2, var3, var4, var5, var6);
      }
   }

   private static gc a(cev var0, gc var1) {
      return var0 == cev.b ? var1 : var1.f();
   }

   public void a(brx var1, fx var2, ceh var3, bfw var4) {
      if (!var1.v && var4.b_()) {
         cev var5 = (cev)var3.c(a);
         if (var5 == cev.b) {
            fx var6 = var2.a(a(var5, (gc)var3.c(aq)));
            ceh var7 = var1.d_(var6);
            if (var7.b() == this && var7.c(a) == cev.a) {
               var1.a(var6, bup.a.n(), 35);
               var1.a(var4, 2001, var6, buo.i(var7));
            }
         }
      }

      super.a(var1, var2, var3, var4);
   }

   @Nullable
   public ceh a(bny var1) {
      gc var2 = var1.f();
      fx var3 = var1.a();
      fx var4 = var3.a(var2);
      return var1.p().d_(var4).a(var1) ? (ceh)this.n().a(aq, var2) : null;
   }

   public ddh b(ceh var1, brc var2, fx var3, dcs var4) {
      gc var5 = g(var1).f();
      switch(var5) {
      case c:
         return h;
      case d:
         return i;
      case e:
         return j;
      default:
         return k;
      }
   }

   public static gc g(ceh var0) {
      gc var1 = (gc)var0.c(aq);
      return var0.c(a) == cev.a ? var1.f() : var1;
   }

   public static bwc.a h(ceh var0) {
      cev var1 = (cev)var0.c(a);
      return var1 == cev.a ? bwc.a.b : bwc.a.c;
   }

   private static boolean b(brc var0, fx var1) {
      return var0.d_(var1.c()).b() instanceof buj;
   }

   public static Optional<dcn> a(aqe<?> var0, brg var1, fx var2, float var3) {
      gc var4 = (gc)var1.d_(var2).c(aq);
      gc var5 = var4.g();
      gc var6 = var5.a(var3) ? var5.f() : var5;
      if (b((brc)var1, (fx)var2)) {
         return a(var0, var1, var2, var4, var6);
      } else {
         int[][] var7 = a(var4, var6);
         Optional<dcn> var8 = a(var0, var1, var2, var7, true);
         return var8.isPresent() ? var8 : a(var0, var1, var2, var7, false);
      }
   }

   private static Optional<dcn> a(aqe<?> var0, brg var1, fx var2, gc var3, gc var4) {
      int[][] var5 = b(var3, var4);
      Optional<dcn> var6 = a(var0, var1, var2, var5, true);
      if (var6.isPresent()) {
         return var6;
      } else {
         fx var7 = var2.c();
         Optional<dcn> var8 = a(var0, var1, var7, var5, true);
         if (var8.isPresent()) {
            return var8;
         } else {
            int[][] var9 = a(var3);
            Optional<dcn> var10 = a(var0, var1, var2, var9, true);
            if (var10.isPresent()) {
               return var10;
            } else {
               Optional<dcn> var11 = a(var0, var1, var2, var5, false);
               if (var11.isPresent()) {
                  return var11;
               } else {
                  Optional<dcn> var12 = a(var0, var1, var7, var5, false);
                  return var12.isPresent() ? var12 : a(var0, var1, var2, var9, false);
               }
            }
         }
      }
   }

   private static Optional<dcn> a(aqe<?> var0, brg var1, fx var2, int[][] var3, boolean var4) {
      fx.a var5 = new fx.a();
      int[][] var6 = var3;
      int var7 = var3.length;

      for(int var8 = 0; var8 < var7; ++var8) {
         int[] var9 = var6[var8];
         var5.d(var2.u() + var9[0], var2.v(), var2.w() + var9[1]);
         dcn var10 = bho.a(var0, var1, var5, var4);
         if (var10 != null) {
            return Optional.of(var10);
         }
      }

      return Optional.empty();
   }

   public cvc f(ceh var1) {
      return cvc.b;
   }

   public bzh b(ceh var1) {
      return bzh.b;
   }

   protected void a(cei.a<buo, ceh> var1) {
      var1.a(aq, a, b);
   }

   public ccj a(brc var1) {
      return new ccf(this.o);
   }

   public void a(brx var1, fx var2, ceh var3, @Nullable aqm var4, bmb var5) {
      super.a(var1, var2, var3, var4, var5);
      if (!var1.v) {
         fx var6 = var2.a((gc)var3.c(aq));
         var1.a(var6, (ceh)var3.a(a, cev.a), 3);
         var1.a((fx)var2, (buo)bup.a);
         var3.a(var1, var2, 3);
      }

   }

   public bkx c() {
      return this.o;
   }

   public long a(ceh var1, fx var2) {
      fx var3 = var2.a((gc)var1.c(aq), var1.c(a) == cev.a ? 0 : 1);
      return afm.c(var3.u(), var2.v(), var3.w());
   }

   public boolean a(ceh var1, brc var2, fx var3, cxe var4) {
      return false;
   }

   private static int[][] a(gc var0, gc var1) {
      return (int[][])ArrayUtils.addAll(b(var0, var1), a(var0));
   }

   private static int[][] b(gc var0, gc var1) {
      return new int[][]{{var1.i(), var1.k()}, {var1.i() - var0.i(), var1.k() - var0.k()}, {var1.i() - var0.i() * 2, var1.k() - var0.k() * 2}, {-var0.i() * 2, -var0.k() * 2}, {-var1.i() - var0.i() * 2, -var1.k() - var0.k() * 2}, {-var1.i() - var0.i(), -var1.k() - var0.k()}, {-var1.i(), -var1.k()}, {-var1.i() + var0.i(), -var1.k() + var0.k()}, {var0.i(), var0.k()}, {var1.i() + var0.i(), var1.k() + var0.k()}};
   }

   private static int[][] a(gc var0) {
      return new int[][]{{0, 0}, {-var0.i(), -var0.k()}};
   }

   static {
      a = cex.aE;
      b = cex.t;
      c = buo.a(0.0D, 3.0D, 0.0D, 16.0D, 9.0D, 16.0D);
      d = buo.a(0.0D, 0.0D, 0.0D, 3.0D, 3.0D, 3.0D);
      e = buo.a(0.0D, 0.0D, 13.0D, 3.0D, 3.0D, 16.0D);
      f = buo.a(13.0D, 0.0D, 0.0D, 16.0D, 3.0D, 3.0D);
      g = buo.a(13.0D, 0.0D, 13.0D, 16.0D, 3.0D, 16.0D);
      h = dde.a(c, d, f);
      i = dde.a(c, e, g);
      j = dde.a(c, d, e);
      k = dde.a(c, f, g);
   }
}
