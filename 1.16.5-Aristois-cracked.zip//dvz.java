public class dvz extends duv {
   public static final vk a = new vk("textures/entity/trident.png");
   private final dwn b = new dwn(32, 32, 0, 6);

   public dvz() {
      super(eao::b);
      this.b.a(-0.5F, 2.0F, -0.5F, 1.0F, 25.0F, 1.0F, 0.0F);
      dwn var1 = new dwn(32, 32, 4, 0);
      var1.a(-1.5F, 0.0F, -0.5F, 3.0F, 2.0F, 1.0F);
      this.b.b(var1);
      dwn var2 = new dwn(32, 32, 4, 3);
      var2.a(-2.5F, -3.0F, -0.5F, 1.0F, 4.0F, 1.0F);
      this.b.b(var2);
      dwn var3 = new dwn(32, 32, 0, 0);
      var3.a(-0.5F, -4.0F, -0.5F, 1.0F, 4.0F, 1.0F, 0.0F);
      this.b.b(var3);
      dwn var4 = new dwn(32, 32, 4, 3);
      var4.g = true;
      var4.a(1.5F, -3.0F, -0.5F, 1.0F, 4.0F, 1.0F);
      this.b.b(var4);
   }

   public void a(dfm var1, dfq var2, int var3, int var4, float var5, float var6, float var7, float var8) {
      this.b.a(var1, var2, var3, var4, var5, var6, var7, var8);
   }
}
