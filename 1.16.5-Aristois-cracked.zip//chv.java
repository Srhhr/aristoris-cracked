import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Iterator;
import java.util.Map;
import java.util.Optional;
import javax.annotation.Nullable;

public class chv {
   public static final Codec<chv> a = RecordCodecBuilder.create((var0x) -> {
      return var0x.group(cmx.a.optionalFieldOf("stronghold").forGetter((var0xx) -> {
         return Optional.ofNullable(var0xx.e);
      }), Codec.simpleMap(gm.aG, cmy.a, gm.aG).fieldOf("structures").forGetter((var0xx) -> {
         return var0xx.d;
      })).apply(var0x, chv::new);
   });
   public static final ImmutableMap<cla<?>, cmy> b;
   public static final cmx c;
   private final Map<cla<?>, cmy> d;
   @Nullable
   private final cmx e;

   public chv(Optional<cmx> var1, Map<cla<?>, cmy> var2) {
      this.e = (cmx)var1.orElse((Object)null);
      this.d = var2;
   }

   public chv(boolean var1) {
      this.d = Maps.newHashMap(b);
      this.e = var1 ? c : null;
   }

   public Map<cla<?>, cmy> a() {
      return this.d;
   }

   @Nullable
   public cmy a(cla<?> var1) {
      return (cmy)this.d.get(var1);
   }

   @Nullable
   public cmx b() {
      return this.e;
   }

   static {
      b = ImmutableMap.builder().put(cla.q, new cmy(32, 8, 10387312)).put(cla.f, new cmy(32, 8, 14357617)).put(cla.g, new cmy(32, 8, 14357618)).put(cla.e, new cmy(32, 8, 14357619)).put(cla.j, new cmy(32, 8, 14357620)).put(cla.b, new cmy(32, 8, 165745296)).put(cla.k, new cmy(1, 0, 0)).put(cla.l, new cmy(32, 5, 10387313)).put(cla.o, new cmy(20, 11, 10387313)).put(cla.d, new cmy(80, 20, 10387319)).put(cla.p, new cmy(1, 0, 0)).put(cla.c, new cmy(1, 0, 0)).put(cla.h, new cmy(40, 15, 34222645)).put(cla.i, new cmy(24, 4, 165745295)).put(cla.m, new cmy(20, 8, 14357621)).put(cla.s, new cmy(27, 4, 30084232)).put(cla.n, new cmy(27, 4, 30084232)).put(cla.r, new cmy(2, 1, 14357921)).build();
      Iterator var0 = gm.aG.iterator();

      cla var1;
      do {
         if (!var0.hasNext()) {
            c = new cmx(32, 3, 128);
            return;
         }

         var1 = (cla)var0.next();
      } while(b.containsKey(var1));

      throw new IllegalStateException("Structure feature without default settings: " + gm.aG.b((Object)var1));
   }
}
