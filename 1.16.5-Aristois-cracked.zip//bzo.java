import java.util.Random;

public class bzo extends buu implements buq {
   public static final cfg a;
   protected static final ddh b;
   private final cdq c;

   protected bzo(cdq var1, ceg.c var2) {
      super(var2);
      this.c = var1;
      this.j((ceh)((ceh)this.n.b()).a(a, 0));
   }

   public ddh b(ceh var1, brc var2, fx var3, dcs var4) {
      return b;
   }

   public void b(ceh var1, aag var2, fx var3, Random var4) {
      if (var2.B(var3.b()) >= 9 && var4.nextInt(7) == 0) {
         this.a(var2, var3, var1, var4);
      }

   }

   public void a(aag var1, fx var2, ceh var3, Random var4) {
      if ((Integer)var3.c(a) == 0) {
         var1.a(var2, (ceh)var3.a(a), 4);
      } else {
         this.c.a(var1, var1.i().g(), var2, var3, var4);
      }

   }

   public boolean a(brc var1, fx var2, ceh var3, boolean var4) {
      return true;
   }

   public boolean a(brx var1, Random var2, fx var3, ceh var4) {
      return (double)var1.t.nextFloat() < 0.45D;
   }

   public void a(aag var1, Random var2, fx var3, ceh var4) {
      this.a(var1, var3, var4, var2);
   }

   protected void a(cei.a<buo, ceh> var1) {
      var1.a(a);
   }

   static {
      a = cex.aA;
      b = buo.a(2.0D, 0.0D, 2.0D, 14.0D, 12.0D, 14.0D);
   }
}
