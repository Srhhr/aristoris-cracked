import javax.annotation.Nullable;

public class bbw extends bbt {
   private dcn b;
   private int c;

   public bbw(bbr var1) {
      super(var1);
   }

   public void b() {
      if (this.c++ % 10 == 0) {
         float var1 = (this.a.cY().nextFloat() - 0.5F) * 8.0F;
         float var2 = (this.a.cY().nextFloat() - 0.5F) * 4.0F;
         float var3 = (this.a.cY().nextFloat() - 0.5F) * 8.0F;
         this.a.l.a(hh.v, this.a.cD() + (double)var1, this.a.cE() + 2.0D + (double)var2, this.a.cH() + (double)var3, 0.0D, 0.0D, 0.0D);
      }

   }

   public void c() {
      ++this.c;
      if (this.b == null) {
         fx var1 = this.a.l.a((chn.a)chn.a.e, (fx)cjk.a);
         this.b = dcn.c((gr)var1);
      }

      double var3 = this.b.c(this.a.cD(), this.a.cE(), this.a.cH());
      if (!(var3 < 100.0D) && !(var3 > 22500.0D) && !this.a.u && !this.a.v) {
         this.a.c(1.0F);
      } else {
         this.a.c(0.0F);
      }

   }

   public void d() {
      this.b = null;
      this.c = 0;
   }

   public float f() {
      return 3.0F;
   }

   @Nullable
   public dcn g() {
      return this.b;
   }

   public bch<bbw> i() {
      return bch.j;
   }
}
