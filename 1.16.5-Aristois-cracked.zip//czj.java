import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import java.util.function.Consumer;

public abstract class czj extends czq {
   protected final czq[] c;
   private final czi e;

   protected czj(czq[] var1, dbo[] var2) {
      super(var2);
      this.c = var1;
      this.e = this.a((czi[])var1);
   }

   public void a(czg var1) {
      super.a(var1);
      if (this.c.length == 0) {
         var1.a("Empty children list");
      }

      for(int var2 = 0; var2 < this.c.length; ++var2) {
         this.c[var2].a(var1.b(".entry[" + var2 + "]"));
      }

   }

   protected abstract czi a(czi[] var1);

   public final boolean expand(cyv var1, Consumer<czp> var2) {
      return !this.a((cyv)var1) ? false : this.e.expand(var1, var2);
   }

   public static <T extends czj> czq.b<T> a(final czj.a<T> var0) {
      return new czq.b<T>() {
         public void a(JsonObject var1, T var2, JsonSerializationContext var3) {
            var1.add("children", var3.serialize(var2.c));
         }

         public final T a(JsonObject var1, JsonDeserializationContext var2, dbo[] var3) {
            czq[] var4 = (czq[])afd.a(var1, "children", var2, czq[].class);
            return var0.create(var4, var3);
         }

         // $FF: synthetic method
         public czq b(JsonObject var1, JsonDeserializationContext var2, dbo[] var3) {
            return this.a(var1, var2, var3);
         }
      };
   }

   @FunctionalInterface
   public interface a<T extends czj> {
      T create(czq[] var1, dbo[] var2);
   }
}
