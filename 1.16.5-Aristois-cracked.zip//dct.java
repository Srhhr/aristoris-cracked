import it.unimi.dsi.fastutil.doubles.AbstractDoubleList;

public class dct extends AbstractDoubleList {
   private final int a;

   dct(int var1) {
      this.a = var1;
   }

   public double getDouble(int var1) {
      return (double)var1 / (double)this.a;
   }

   public int size() {
      return this.a + 1;
   }
}
