import com.google.common.collect.Maps;
import com.mojang.blaze3d.systems.RenderSystem;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;

public class dfe {
   private final dfe.a a;
   private final String b;
   private final int c;
   private int d;

   private dfe(dfe.a var1, int var2, String var3) {
      this.a = var1;
      this.c = var2;
      this.b = var3;
   }

   public void a(dfd var1) {
      RenderSystem.assertThread(RenderSystem::isOnRenderThread);
      ++this.d;
      dem.d(var1.a(), this.c);
   }

   public void a() {
      RenderSystem.assertThread(RenderSystem::isOnRenderThread);
      --this.d;
      if (this.d <= 0) {
         dem.d(this.c);
         this.a.c().remove(this.b);
      }

   }

   public String b() {
      return this.b;
   }

   public static dfe a(dfe.a var0, String var1, InputStream var2, String var3) throws IOException {
      RenderSystem.assertThread(RenderSystem::isOnRenderThread);
      String var4 = dex.b(var2);
      if (var4 == null) {
         throw new IOException("Could not load program " + var0.a());
      } else {
         int var5 = dem.e(var0.d());
         dem.a(var5, (CharSequence)var4);
         dem.f(var5);
         if (dem.e(var5, 35713) == 0) {
            String var7 = StringUtils.trim(dem.i(var5, 32768));
            throw new IOException("Couldn't compile " + var0.a() + " program (" + var3 + ", " + var1 + ") : " + var7);
         } else {
            dfe var6 = new dfe(var0, var5, var1);
            var0.c().put(var1, var6);
            return var6;
         }
      }
   }

   public static enum a {
      a("vertex", ".vsh", 35633),
      b("fragment", ".fsh", 35632);

      private final String c;
      private final String d;
      private final int e;
      private final Map<String, dfe> f = Maps.newHashMap();

      private a(String var3, String var4, int var5) {
         this.c = var3;
         this.d = var4;
         this.e = var5;
      }

      public String a() {
         return this.c;
      }

      public String b() {
         return this.d;
      }

      private int d() {
         return this.e;
      }

      public Map<String, dfe> c() {
         return this.f;
      }
   }
}
