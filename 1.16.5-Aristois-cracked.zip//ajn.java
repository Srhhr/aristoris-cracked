import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Lists;
import com.mojang.datafixers.DSL;
import com.mojang.datafixers.DataFix;
import com.mojang.datafixers.DataFixUtils;
import com.mojang.datafixers.OpticFinder;
import com.mojang.datafixers.TypeRewriteRule;
import com.mojang.datafixers.Typed;
import com.mojang.datafixers.schemas.Schema;
import com.mojang.datafixers.types.Type;
import com.mojang.datafixers.types.templates.List.ListType;
import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Dynamic;
import it.unimi.dsi.fastutil.ints.Int2IntMap;
import it.unimi.dsi.fastutil.ints.Int2IntOpenHashMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.ints.IntIterator;
import it.unimi.dsi.fastutil.ints.IntOpenHashSet;
import it.unimi.dsi.fastutil.ints.IntSet;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import javax.annotation.Nullable;

public class ajn extends DataFix {
   private static final int[][] a = new int[][]{{-1, 0, 0}, {1, 0, 0}, {0, -1, 0}, {0, 1, 0}, {0, 0, -1}, {0, 0, 1}};
   private static final Object2IntMap<String> b = (Object2IntMap)DataFixUtils.make(new Object2IntOpenHashMap(), (var0) -> {
      var0.put("minecraft:acacia_leaves", 0);
      var0.put("minecraft:birch_leaves", 1);
      var0.put("minecraft:dark_oak_leaves", 2);
      var0.put("minecraft:jungle_leaves", 3);
      var0.put("minecraft:oak_leaves", 4);
      var0.put("minecraft:spruce_leaves", 5);
   });
   private static final Set<String> c = ImmutableSet.of("minecraft:acacia_bark", "minecraft:birch_bark", "minecraft:dark_oak_bark", "minecraft:jungle_bark", "minecraft:oak_bark", "minecraft:spruce_bark", new String[]{"minecraft:acacia_log", "minecraft:birch_log", "minecraft:dark_oak_log", "minecraft:jungle_log", "minecraft:oak_log", "minecraft:spruce_log", "minecraft:stripped_acacia_log", "minecraft:stripped_birch_log", "minecraft:stripped_dark_oak_log", "minecraft:stripped_jungle_log", "minecraft:stripped_oak_log", "minecraft:stripped_spruce_log"});

   public ajn(Schema var1, boolean var2) {
      super(var1, var2);
   }

   protected TypeRewriteRule makeRule() {
      Type<?> var1 = this.getInputSchema().getType(akn.c);
      OpticFinder<?> var2 = var1.findField("Level");
      OpticFinder<?> var3 = var2.type().findField("Sections");
      Type<?> var4 = var3.type();
      if (!(var4 instanceof ListType)) {
         throw new IllegalStateException("Expecting sections to be a list.");
      } else {
         Type<?> var5 = ((ListType)var4).getElement();
         OpticFinder<?> var6 = DSL.typeFinder(var5);
         return this.fixTypeEverywhereTyped("Leaves fix", var1, (var4x) -> {
            return var4x.updateTyped(var2, (var3x) -> {
               int[] var4 = new int[]{0};
               Typed<?> var5 = var3x.updateTyped(var3, (var3xx) -> {
                  Int2ObjectMap<ajn.a> var4x = new Int2ObjectOpenHashMap((Map)var3xx.getAllTyped(var6).stream().map((var1) -> {
                     return new ajn.a(var1, this.getInputSchema());
                  }).collect(Collectors.toMap(ajn.b::c, (var0) -> {
                     return var0;
                  })));
                  if (var4x.values().stream().allMatch(ajn.b::b)) {
                     return var3xx;
                  } else {
                     List<IntSet> var5 = Lists.newArrayList();

                     int var6x;
                     for(var6x = 0; var6x < 7; ++var6x) {
                        var5.add(new IntOpenHashSet());
                     }

                     ObjectIterator var25 = var4x.values().iterator();

                     while(true) {
                        ajn.a var7;
                        int var10;
                        int var11;
                        do {
                           if (!var25.hasNext()) {
                              for(var6x = 1; var6x < 7; ++var6x) {
                                 IntSet var26 = (IntSet)var5.get(var6x - 1);
                                 IntSet var27 = (IntSet)var5.get(var6x);
                                 IntIterator var28 = var26.iterator();

                                 while(var28.hasNext()) {
                                    var10 = var28.nextInt();
                                    var11 = this.a(var10);
                                    int var12 = this.b(var10);
                                    int var13 = this.c(var10);
                                    int[][] var14 = a;
                                    int var15 = var14.length;

                                    for(int var16 = 0; var16 < var15; ++var16) {
                                       int[] var17 = var14[var16];
                                       int var18 = var11 + var17[0];
                                       int var19 = var12 + var17[1];
                                       int var20 = var13 + var17[2];
                                       if (var18 >= 0 && var18 <= 15 && var20 >= 0 && var20 <= 15 && var19 >= 0 && var19 <= 255) {
                                          ajn.a var21 = (ajn.a)var4x.get(var19 >> 4);
                                          if (var21 != null && !var21.b()) {
                                             int var22 = a(var18, var19 & 15, var20);
                                             int var23 = var21.c(var22);
                                             if (var21.b(var23)) {
                                                int var24 = var21.d(var23);
                                                if (var24 > var6x) {
                                                   var21.a(var22, var23, var6x);
                                                   var27.add(a(var18, var19, var20));
                                                }
                                             }
                                          }
                                       }
                                    }
                                 }
                              }

                              return var3xx.updateTyped(var6, (var1) -> {
                                 return ((ajn.a)var4x.get(((Dynamic)var1.get(DSL.remainderFinder())).get("Y").asInt(0))).a(var1);
                              });
                           }

                           var7 = (ajn.a)var25.next();
                        } while(var7.b());

                        for(int var8 = 0; var8 < 4096; ++var8) {
                           int var9 = var7.c(var8);
                           if (var7.a(var9)) {
                              ((IntSet)var5.get(0)).add(var7.c() << 12 | var8);
                           } else if (var7.b(var9)) {
                              var10 = this.a(var8);
                              var11 = this.c(var8);
                              var4[0] |= a(var10 == 0, var10 == 15, var11 == 0, var11 == 15);
                           }
                        }
                     }
                  }
               });
               if (var4[0] != 0) {
                  var5 = var5.update(DSL.remainderFinder(), (var1) -> {
                     Dynamic<?> var2 = (Dynamic)DataFixUtils.orElse(var1.get("UpgradeData").result(), var1.emptyMap());
                     return var1.set("UpgradeData", var2.set("Sides", var1.createByte((byte)(var2.get("Sides").asByte((byte)0) | var4[0]))));
                  });
               }

               return var5;
            });
         });
      }
   }

   public static int a(int var0, int var1, int var2) {
      return var1 << 8 | var2 << 4 | var0;
   }

   private int a(int var1) {
      return var1 & 15;
   }

   private int b(int var1) {
      return var1 >> 8 & 255;
   }

   private int c(int var1) {
      return var1 >> 4 & 15;
   }

   public static int a(boolean var0, boolean var1, boolean var2, boolean var3) {
      int var4 = 0;
      if (var2) {
         if (var1) {
            var4 |= 2;
         } else if (var0) {
            var4 |= 128;
         } else {
            var4 |= 1;
         }
      } else if (var3) {
         if (var0) {
            var4 |= 32;
         } else if (var1) {
            var4 |= 8;
         } else {
            var4 |= 16;
         }
      } else if (var1) {
         var4 |= 4;
      } else if (var0) {
         var4 |= 64;
      }

      return var4;
   }

   public static final class a extends ajn.b {
      @Nullable
      private IntSet e;
      @Nullable
      private IntSet f;
      @Nullable
      private Int2IntMap g;

      public a(Typed<?> var1, Schema var2) {
         super(var1, var2);
      }

      protected boolean a() {
         this.e = new IntOpenHashSet();
         this.f = new IntOpenHashSet();
         this.g = new Int2IntOpenHashMap();

         for(int var1 = 0; var1 < this.b.size(); ++var1) {
            Dynamic<?> var2 = (Dynamic)this.b.get(var1);
            String var3 = var2.get("Name").asString("");
            if (ajn.b.containsKey(var3)) {
               boolean var4 = Objects.equals(var2.get("Properties").get("decayable").asString(""), "false");
               this.e.add(var1);
               this.g.put(this.a(var3, var4, 7), var1);
               this.b.set(var1, this.a(var2, var3, var4, 7));
            }

            if (ajn.c.contains(var3)) {
               this.f.add(var1);
            }
         }

         return this.e.isEmpty() && this.f.isEmpty();
      }

      private Dynamic<?> a(Dynamic<?> var1, String var2, boolean var3, int var4) {
         Dynamic<?> var5 = var1.emptyMap();
         var5 = var5.set("persistent", var5.createString(var3 ? "true" : "false"));
         var5 = var5.set("distance", var5.createString(Integer.toString(var4)));
         Dynamic<?> var6 = var1.emptyMap();
         var6 = var6.set("Properties", var5);
         var6 = var6.set("Name", var6.createString(var2));
         return var6;
      }

      public boolean a(int var1) {
         return this.f.contains(var1);
      }

      public boolean b(int var1) {
         return this.e.contains(var1);
      }

      private int d(int var1) {
         return this.a(var1) ? 0 : Integer.parseInt(((Dynamic)this.b.get(var1)).get("Properties").get("distance").asString(""));
      }

      private void a(int var1, int var2, int var3) {
         Dynamic<?> var4 = (Dynamic)this.b.get(var2);
         String var5 = var4.get("Name").asString("");
         boolean var6 = Objects.equals(var4.get("Properties").get("persistent").asString(""), "true");
         int var7 = this.a(var5, var6, var3);
         int var8;
         if (!this.g.containsKey(var7)) {
            var8 = this.b.size();
            this.e.add(var8);
            this.g.put(var7, var8);
            this.b.add(this.a(var4, var5, var6, var3));
         }

         var8 = this.g.get(var7);
         if (1 << this.d.b() <= var8) {
            agc var9 = new agc(this.d.b() + 1, 4096);

            for(int var10 = 0; var10 < 4096; ++var10) {
               var9.a(var10, this.d.a(var10));
            }

            this.d = var9;
         }

         this.d.a(var1, var8);
      }
   }

   public abstract static class b {
      private final Type<Pair<String, Dynamic<?>>> e;
      protected final OpticFinder<List<Pair<String, Dynamic<?>>>> a;
      protected final List<Dynamic<?>> b;
      protected final int c;
      @Nullable
      protected agc d;

      public b(Typed<?> var1, Schema var2) {
         this.e = DSL.named(akn.m.typeName(), DSL.remainderType());
         this.a = DSL.fieldFinder("Palette", DSL.list(this.e));
         if (!Objects.equals(var2.getType(akn.m), this.e)) {
            throw new IllegalStateException("Block state type is not what was expected.");
         } else {
            Optional<List<Pair<String, Dynamic<?>>>> var3 = var1.getOptional(this.a);
            this.b = (List)var3.map((var0) -> {
               return (List)var0.stream().map(Pair::getSecond).collect(Collectors.toList());
            }).orElse(ImmutableList.of());
            Dynamic<?> var4 = (Dynamic)var1.get(DSL.remainderFinder());
            this.c = var4.get("Y").asInt(0);
            this.a(var4);
         }
      }

      protected void a(Dynamic<?> var1) {
         if (this.a()) {
            this.d = null;
         } else {
            long[] var2 = var1.get("BlockStates").asLongStream().toArray();
            int var3 = Math.max(4, DataFixUtils.ceillog2(this.b.size()));
            this.d = new agc(var3, 4096, var2);
         }

      }

      public Typed<?> a(Typed<?> var1) {
         return this.b() ? var1 : var1.update(DSL.remainderFinder(), (var1x) -> {
            return var1x.set("BlockStates", var1x.createLongList(Arrays.stream(this.d.a())));
         }).set(this.a, this.b.stream().map((var0) -> {
            return Pair.of(akn.m.typeName(), var0);
         }).collect(Collectors.toList()));
      }

      public boolean b() {
         return this.d == null;
      }

      public int c(int var1) {
         return this.d.a(var1);
      }

      protected int a(String var1, boolean var2, int var3) {
         return ajn.b.get(var1) << 5 | (var2 ? 16 : 0) | var3;
      }

      int c() {
         return this.c;
      }

      protected abstract boolean a();
   }
}
