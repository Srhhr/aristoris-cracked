import java.util.Iterator;
import javax.annotation.Nullable;
import net.minecraft.world.level.ColorResolver;

public class ecv implements bra {
   protected final int a;
   protected final int b;
   protected final fx c;
   protected final int d;
   protected final int e;
   protected final int f;
   protected final cgh[][] g;
   protected final ceh[] h;
   protected final cux[] i;
   protected final brx j;

   @Nullable
   public static ecv a(brx var0, fx var1, fx var2, int var3) {
      int var4 = var1.u() - var3 >> 4;
      int var5 = var1.w() - var3 >> 4;
      int var6 = var2.u() + var3 >> 4;
      int var7 = var2.w() + var3 >> 4;
      cgh[][] var8 = new cgh[var6 - var4 + 1][var7 - var5 + 1];

      for(int var9 = var4; var9 <= var6; ++var9) {
         for(int var10 = var5; var10 <= var7; ++var10) {
            var8[var9 - var4][var10 - var5] = var0.d(var9, var10);
         }
      }

      if (a(var1, var2, var4, var5, var8)) {
         return null;
      } else {
         int var12 = true;
         fx var13 = var1.b(-1, -1, -1);
         fx var11 = var2.b(1, 1, 1);
         return new ecv(var0, var4, var5, var8, var13, var11);
      }
   }

   public static boolean a(fx var0, fx var1, int var2, int var3, cgh[][] var4) {
      for(int var5 = var0.u() >> 4; var5 <= var1.u() >> 4; ++var5) {
         for(int var6 = var0.w() >> 4; var6 <= var1.w() >> 4; ++var6) {
            cgh var7 = var4[var5 - var2][var6 - var3];
            if (!var7.a(var0.v(), var1.v())) {
               return false;
            }
         }
      }

      return true;
   }

   public ecv(brx var1, int var2, int var3, cgh[][] var4, fx var5, fx var6) {
      this.j = var1;
      this.a = var2;
      this.b = var3;
      this.g = var4;
      this.c = var5;
      this.d = var6.u() - var5.u() + 1;
      this.e = var6.v() - var5.v() + 1;
      this.f = var6.w() - var5.w() + 1;
      this.h = new ceh[this.d * this.e * this.f];
      this.i = new cux[this.d * this.e * this.f];

      fx var8;
      cgh var11;
      int var12;
      for(Iterator var7 = fx.a(var5, var6).iterator(); var7.hasNext(); this.i[var12] = var11.b(var8)) {
         var8 = (fx)var7.next();
         int var9 = (var8.u() >> 4) - var2;
         int var10 = (var8.w() >> 4) - var3;
         var11 = var4[var9][var10];
         var12 = this.a(var8);
         this.h[var12] = var11.d_(var8);
      }

   }

   protected final int a(fx var1) {
      return this.a(var1.u(), var1.v(), var1.w());
   }

   protected int a(int var1, int var2, int var3) {
      int var4 = var1 - this.c.u();
      int var5 = var2 - this.c.v();
      int var6 = var3 - this.c.w();
      return var6 * this.d * this.e + var5 * this.d + var4;
   }

   public ceh d_(fx var1) {
      return this.h[this.a(var1)];
   }

   public cux b(fx var1) {
      return this.i[this.a(var1)];
   }

   public float a(gc var1, boolean var2) {
      return this.j.a(var1, var2);
   }

   public cuo e() {
      return this.j.e();
   }

   @Nullable
   public ccj c(fx var1) {
      return this.a(var1, cgh.a.a);
   }

   @Nullable
   public ccj a(fx var1, cgh.a var2) {
      int var3 = (var1.u() >> 4) - this.a;
      int var4 = (var1.w() >> 4) - this.b;
      return this.g[var3][var4].a(var1, var2);
   }

   public int a(fx var1, ColorResolver var2) {
      return this.j.a((fx)var1, (ColorResolver)var2);
   }
}
