import java.util.EnumSet;
import javax.annotation.Nullable;

public abstract class bea extends bcy {
   private static final us<Byte> bo;
   protected int b;
   private bea.a bp;

   protected bea(aqe<? extends bea> var1, brx var2) {
      super(var1, var2);
      this.bp = bea.a.a;
   }

   protected void e() {
      super.e();
      this.R.a((us)bo, (byte)0);
   }

   public void a(md var1) {
      super.a(var1);
      this.b = var1.h("SpellTicks");
   }

   public void b(md var1) {
      super.b(var1);
      var1.b("SpellTicks", this.b);
   }

   public bcy.a m() {
      if (this.eW()) {
         return bcy.a.c;
      } else {
         return this.fd() ? bcy.a.g : bcy.a.a;
      }
   }

   public boolean eW() {
      if (this.l.v) {
         return (Byte)this.R.a(bo) > 0;
      } else {
         return this.b > 0;
      }
   }

   public void a(bea.a var1) {
      this.bp = var1;
      this.R.b(bo, (byte)var1.g);
   }

   protected bea.a eX() {
      return !this.l.v ? this.bp : bea.a.a((Byte)this.R.a(bo));
   }

   protected void N() {
      super.N();
      if (this.b > 0) {
         --this.b;
      }

   }

   public void j() {
      super.j();
      if (this.l.v && this.eW()) {
         bea.a var1 = this.eX();
         double var2 = var1.h[0];
         double var4 = var1.h[1];
         double var6 = var1.h[2];
         float var8 = this.aA * 0.017453292F + afm.b((float)this.K * 0.6662F) * 0.25F;
         float var9 = afm.b(var8);
         float var10 = afm.a(var8);
         this.l.a(hh.u, this.cD() + (double)var9 * 0.6D, this.cE() + 1.8D, this.cH() + (double)var10 * 0.6D, var2, var4, var6);
         this.l.a(hh.u, this.cD() - (double)var9 * 0.6D, this.cE() + 1.8D, this.cH() - (double)var10 * 0.6D, var2, var4, var6);
      }

   }

   protected int eY() {
      return this.b;
   }

   protected abstract adp eM();

   static {
      bo = uv.a(bea.class, uu.a);
   }

   public static enum a {
      a(0, 0.0D, 0.0D, 0.0D),
      b(1, 0.7D, 0.7D, 0.8D),
      c(2, 0.4D, 0.3D, 0.35D),
      d(3, 0.7D, 0.5D, 0.2D),
      e(4, 0.3D, 0.3D, 0.8D),
      f(5, 0.1D, 0.1D, 0.2D);

      private final int g;
      private final double[] h;

      private a(int var3, double var4, double var6, double var8) {
         this.g = var3;
         this.h = new double[]{var4, var6, var8};
      }

      public static bea.a a(int var0) {
         bea.a[] var1 = values();
         int var2 = var1.length;

         for(int var3 = 0; var3 < var2; ++var3) {
            bea.a var4 = var1[var3];
            if (var0 == var4.g) {
               return var4;
            }
         }

         return a;
      }
   }

   public abstract class c extends avv {
      protected int b;
      protected int c;

      protected c() {
      }

      public boolean a() {
         aqm var1 = bea.this.A();
         if (var1 != null && var1.aX()) {
            if (bea.this.eW()) {
               return false;
            } else {
               return bea.this.K >= this.c;
            }
         } else {
            return false;
         }
      }

      public boolean b() {
         aqm var1 = bea.this.A();
         return var1 != null && var1.aX() && this.b > 0;
      }

      public void c() {
         this.b = this.m();
         bea.this.b = this.g();
         this.c = bea.this.K + this.h();
         adp var1 = this.k();
         if (var1 != null) {
            bea.this.a(var1, 1.0F, 1.0F);
         }

         bea.this.a(this.l());
      }

      public void e() {
         --this.b;
         if (this.b == 0) {
            this.j();
            bea.this.a(bea.this.eM(), 1.0F, 1.0F);
         }

      }

      protected abstract void j();

      protected int m() {
         return 20;
      }

      protected abstract int g();

      protected abstract int h();

      @Nullable
      protected abstract adp k();

      protected abstract bea.a l();
   }

   public class b extends avv {
      public b() {
         this.a(EnumSet.of(avv.a.a, avv.a.b));
      }

      public boolean a() {
         return bea.this.eY() > 0;
      }

      public void c() {
         super.c();
         bea.this.bj.o();
      }

      public void d() {
         super.d();
         bea.this.a(bea.a.a);
      }

      public void e() {
         if (bea.this.A() != null) {
            bea.this.t().a(bea.this.A(), (float)bea.this.Q(), (float)bea.this.O());
         }

      }
   }
}
