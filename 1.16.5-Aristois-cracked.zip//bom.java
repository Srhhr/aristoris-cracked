import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

public class bom extends boj {
   private static final bon a;
   private static final bon b;
   private static final bon c;
   private static final Map<blx, blm.a> d;
   private static final bon e;

   public bom(vk var1) {
      super(var1);
   }

   public boolean a(bio var1, brx var2) {
      boolean var3 = false;
      boolean var4 = false;
      boolean var5 = false;
      boolean var6 = false;
      boolean var7 = false;

      for(int var8 = 0; var8 < var1.Z_(); ++var8) {
         bmb var9 = var1.a(var8);
         if (!var9.a()) {
            if (a.a(var9)) {
               if (var5) {
                  return false;
               }

               var5 = true;
            } else if (c.a(var9)) {
               if (var7) {
                  return false;
               }

               var7 = true;
            } else if (b.a(var9)) {
               if (var6) {
                  return false;
               }

               var6 = true;
            } else if (e.a(var9)) {
               if (var3) {
                  return false;
               }

               var3 = true;
            } else {
               if (!(var9.b() instanceof bky)) {
                  return false;
               }

               var4 = true;
            }
         }
      }

      return var3 && var4;
   }

   public bmb a(bio var1) {
      bmb var2 = new bmb(bmd.pp);
      md var3 = var2.a("Explosion");
      blm.a var4 = blm.a.a;
      List<Integer> var5 = Lists.newArrayList();

      for(int var6 = 0; var6 < var1.Z_(); ++var6) {
         bmb var7 = var1.a(var6);
         if (!var7.a()) {
            if (a.a(var7)) {
               var4 = (blm.a)d.get(var7.b());
            } else if (c.a(var7)) {
               var3.a("Flicker", true);
            } else if (b.a(var7)) {
               var3.a("Trail", true);
            } else if (var7.b() instanceof bky) {
               var5.add(((bky)var7.b()).d().g());
            }
         }
      }

      var3.b((String)"Colors", (List)var5);
      var3.a("Type", (byte)var4.a());
      return var2;
   }

   public boolean a(int var1, int var2) {
      return var1 * var2 >= 2;
   }

   public bmb c() {
      return new bmb(bmd.pp);
   }

   public bos<?> ag_() {
      return bos.h;
   }

   static {
      a = bon.a(bmd.oS, bmd.kT, bmd.nt, bmd.pe, bmd.pf, bmd.pi, bmd.pg, bmd.pj, bmd.ph);
      b = bon.a(bmd.kg);
      c = bon.a(bmd.mk);
      d = (Map)x.a((Object)Maps.newHashMap(), (Consumer)((var0) -> {
         var0.put(bmd.oS, blm.a.b);
         var0.put(bmd.kT, blm.a.e);
         var0.put(bmd.nt, blm.a.c);
         var0.put(bmd.pe, blm.a.d);
         var0.put(bmd.pf, blm.a.d);
         var0.put(bmd.pi, blm.a.d);
         var0.put(bmd.pg, blm.a.d);
         var0.put(bmd.pj, blm.a.d);
         var0.put(bmd.ph, blm.a.d);
      }));
      e = bon.a(bmd.kU);
   }
}
