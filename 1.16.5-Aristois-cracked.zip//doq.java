import com.google.common.base.Splitter;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import javax.annotation.Nullable;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class doq extends dot {
   private static final Logger a = LogManager.getLogger();
   private static final List<doq.a> b = Lists.newArrayList();
   private final dnv c;
   private nr p;
   private nr q;
   private doq.b r;
   private dlj s;
   private dlq t;
   private cpf u;

   public doq(dnv var1) {
      super(new of("createWorld.customize.presets.title"));
      this.c = var1;
   }

   @Nullable
   private static cpe a(String var0, int var1) {
      String[] var2 = var0.split("\\*", 2);
      int var3;
      if (var2.length == 2) {
         try {
            var3 = Math.max(Integer.parseInt(var2[0]), 0);
         } catch (NumberFormatException var10) {
            a.error("Error while parsing flat world string => {}", var10.getMessage());
            return null;
         }
      } else {
         var3 = 1;
      }

      int var4 = Math.min(var1 + var3, 256);
      int var5 = var4 - var1;
      String var7 = var2[var2.length - 1];

      buo var6;
      try {
         var6 = (buo)gm.Q.b(new vk(var7)).orElse((Object)null);
      } catch (Exception var9) {
         a.error("Error while parsing flat world string => {}", var9.getMessage());
         return null;
      }

      if (var6 == null) {
         a.error("Error while parsing flat world string => Unknown block, {}", var7);
         return null;
      } else {
         cpe var8 = new cpe(var5, var6);
         var8.a(var1);
         return var8;
      }
   }

   private static List<cpe> b(String var0) {
      List<cpe> var1 = Lists.newArrayList();
      String[] var2 = var0.split(",");
      int var3 = 0;
      String[] var4 = var2;
      int var5 = var2.length;

      for(int var6 = 0; var6 < var5; ++var6) {
         String var7 = var4[var6];
         cpe var8 = a(var7, var3);
         if (var8 == null) {
            return Collections.emptyList();
         }

         var1.add(var8);
         var3 += var8.a();
      }

      return var1;
   }

   public static cpf a(gm<bsv> var0, String var1, cpf var2) {
      Iterator<String> var3 = Splitter.on(';').split(var1).iterator();
      if (!var3.hasNext()) {
         return cpf.a(var0);
      } else {
         List<cpe> var4 = b((String)var3.next());
         if (var4.isEmpty()) {
            return cpf.a(var0);
         } else {
            cpf var5 = var2.a(var4, var2.d());
            vj<bsv> var6 = btb.b;
            if (var3.hasNext()) {
               try {
                  vk var7 = new vk((String)var3.next());
                  var6 = vj.a(gm.ay, var7);
                  var0.c(var6).orElseThrow(() -> {
                     return new IllegalArgumentException("Invalid Biome: " + var7);
                  });
               } catch (Exception var8) {
                  a.error("Error while parsing flat world string => {}", var8.getMessage());
               }
            }

            var5.a(() -> {
               return (bsv)var0.d(var6);
            });
            return var5;
         }
      }
   }

   private static String b(gm<bsv> var0, cpf var1) {
      StringBuilder var2 = new StringBuilder();

      for(int var3 = 0; var3 < var1.f().size(); ++var3) {
         if (var3 > 0) {
            var2.append(",");
         }

         var2.append(var1.f().get(var3));
      }

      var2.append(";");
      var2.append(var0.b((Object)var1.e()));
      return var2.toString();
   }

   protected void b() {
      this.i.m.a(true);
      this.p = new of("createWorld.customize.presets.share");
      this.q = new of("createWorld.customize.presets.list");
      this.t = new dlq(this.o, 50, 40, this.k - 100, 20, this.p);
      this.t.k(1230);
      gm<bsv> var1 = this.c.a.c.b().b((vj)gm.ay);
      this.t.a(b(var1, (cpf)this.c.h()));
      this.u = this.c.h();
      this.e.add(this.t);
      this.r = new doq.b();
      this.e.add(this.r);
      this.s = (dlj)this.a((dlh)(new dlj(this.k / 2 - 155, this.l - 28, 150, 20, new of("createWorld.customize.presets.select"), (var2) -> {
         cpf var3 = a(var1, this.t.b(), this.u);
         this.c.a(var3);
         this.i.a((dot)this.c);
      })));
      this.a((dlh)(new dlj(this.k / 2 + 5, this.l - 28, 150, 20, nq.d, (var1x) -> {
         this.i.a((dot)this.c);
      })));
      this.c(this.r.h() != null);
   }

   public boolean a(double var1, double var3, double var5) {
      return this.r.a(var1, var3, var5);
   }

   public void a(djz var1, int var2, int var3) {
      String var4 = this.t.b();
      this.b(var1, var2, var3);
      this.t.a(var4);
   }

   public void at_() {
      this.i.a((dot)this.c);
   }

   public void e() {
      this.i.m.a(false);
   }

   public void a(dfm var1, int var2, int var3, float var4) {
      this.a((dfm)var1);
      this.r.a(var1, var2, var3, var4);
      RenderSystem.pushMatrix();
      RenderSystem.translatef(0.0F, 0.0F, 400.0F);
      a(var1, this.o, this.d, this.k / 2, 8, 16777215);
      b(var1, this.o, this.p, 50, 30, 10526880);
      b(var1, this.o, this.q, 50, 70, 10526880);
      RenderSystem.popMatrix();
      this.t.a(var1, var2, var3, var4);
      super.a(var1, var2, var3, var4);
   }

   public void d() {
      this.t.a();
      super.d();
   }

   public void c(boolean var1) {
      this.s.o = var1 || this.t.b().length() > 1;
   }

   private static void a(nr var0, brw var1, vj<bsv> var2, List<cla<?>> var3, boolean var4, boolean var5, boolean var6, cpe... var7) {
      b.add(new doq.a(var1.h(), var0, (var6x) -> {
         Map<cla<?>, cmy> var7x = Maps.newHashMap();
         Iterator var8 = var3.iterator();

         while(var8.hasNext()) {
            cla<?> var9 = (cla)var8.next();
            var7x.put(var9, chv.b.get(var9));
         }

         chv var11 = new chv(var4 ? Optional.of(chv.c) : Optional.empty(), var7x);
         cpf var12 = new cpf(var11, var6x);
         if (var5) {
            var12.a();
         }

         if (var6) {
            var12.b();
         }

         for(int var10 = var7.length - 1; var10 >= 0; --var10) {
            var12.f().add(var7[var10]);
         }

         var12.a(() -> {
            return (bsv)var6x.d(var2);
         });
         var12.h();
         return var12.a(var11);
      }));
   }

   static {
      a(new of("createWorld.customize.preset.classic_flat"), bup.i, btb.b, Arrays.asList(cla.q), false, false, false, new cpe(1, bup.i), new cpe(2, bup.j), new cpe(1, bup.z));
      a(new of("createWorld.customize.preset.tunnelers_dream"), bup.b, btb.d, Arrays.asList(cla.c), true, true, false, new cpe(1, bup.i), new cpe(5, bup.j), new cpe(230, bup.b), new cpe(1, bup.z));
      a(new of("createWorld.customize.preset.water_world"), bmd.lL, btb.y, Arrays.asList(cla.m, cla.i, cla.l), false, false, false, new cpe(90, bup.A), new cpe(5, bup.C), new cpe(5, bup.j), new cpe(5, bup.b), new cpe(1, bup.z));
      a(new of("createWorld.customize.preset.overworld"), bup.aR, btb.b, Arrays.asList(cla.q, cla.c, cla.b, cla.h), true, true, true, new cpe(1, bup.i), new cpe(3, bup.j), new cpe(59, bup.b), new cpe(1, bup.z));
      a(new of("createWorld.customize.preset.snowy_kingdom"), bup.cC, btb.m, Arrays.asList(cla.q, cla.g), false, false, false, new cpe(1, bup.cC), new cpe(1, bup.i), new cpe(3, bup.j), new cpe(59, bup.b), new cpe(1, bup.z));
      a(new of("createWorld.customize.preset.bottomless_pit"), bmd.kT, btb.b, Arrays.asList(cla.q), false, false, false, new cpe(1, bup.i), new cpe(3, bup.j), new cpe(2, bup.m));
      a(new of("createWorld.customize.preset.desert"), bup.C, btb.c, Arrays.asList(cla.q, cla.f, cla.c), true, true, false, new cpe(8, bup.C), new cpe(52, bup.at), new cpe(3, bup.b), new cpe(1, bup.z));
      a(new of("createWorld.customize.preset.redstone_ready"), bmd.lP, btb.c, Collections.emptyList(), false, false, false, new cpe(52, bup.at), new cpe(3, bup.b), new cpe(1, bup.z));
      a(new of("createWorld.customize.preset.the_void"), bup.go, btb.Z, Collections.emptyList(), false, true, false, new cpe(1, bup.a));
   }

   static class a {
      public final blx a;
      public final nr b;
      public final Function<gm<bsv>, cpf> c;

      public a(blx var1, nr var2, Function<gm<bsv>, cpf> var3) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
      }

      public nr a() {
         return this.b;
      }
   }

   class b extends dlv<doq.b.a> {
      public b() {
         super(doq.this.i, doq.this.k, doq.this.l, 80, doq.this.l - 37, 24);

         for(int var2 = 0; var2 < doq.b.size(); ++var2) {
            this.b(new doq.b.a());
         }

      }

      public void a(@Nullable doq.b.a var1) {
         super.a(var1);
         if (var1 != null) {
            dkz.b.a((new of("narrator.select", new Object[]{((doq.a)doq.b.get(this.au_().indexOf(var1))).a()})).getString());
         }

         doq.this.c(var1 != null);
      }

      protected boolean b() {
         return doq.this.aw_() == this;
      }

      public boolean a(int var1, int var2, int var3) {
         if (super.a(var1, var2, var3)) {
            return true;
         } else {
            if ((var1 == 257 || var1 == 335) && this.h() != null) {
               ((doq.b.a)this.h()).a();
            }

            return false;
         }
      }

      public class a extends dlv.a<doq.b.a> {
         public void a(dfm var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, boolean var9, float var10) {
            doq.a var11 = (doq.a)doq.b.get(var2);
            this.a(var1, var4, var3, var11.a);
            doq.this.o.b(var1, var11.b, (float)(var4 + 18 + 5), (float)(var3 + 6), 16777215);
         }

         public boolean a(double var1, double var3, int var5) {
            if (var5 == 0) {
               this.a();
            }

            return false;
         }

         private void a() {
            b.this.a(this);
            doq.a var1 = (doq.a)doq.b.get(b.this.au_().indexOf(this));
            gm<bsv> var2 = doq.this.c.a.c.b().b((vj)gm.ay);
            doq.this.u = (cpf)var1.c.apply(var2);
            doq.this.t.a(doq.b(var2, (cpf)doq.this.u));
            doq.this.t.k();
         }

         private void a(dfm var1, int var2, int var3, blx var4) {
            this.a(var1, var2 + 1, var3 + 1);
            RenderSystem.enableRescaleNormal();
            doq.this.j.a(new bmb(var4), var2 + 2, var3 + 2);
            RenderSystem.disableRescaleNormal();
         }

         private void a(dfm var1, int var2, int var3) {
            RenderSystem.color4f(1.0F, 1.0F, 1.0F, 1.0F);
            b.this.b.M().a(dkw.g);
            dkw.a(var1, var2, var3, doq.this.v(), 0.0F, 0.0F, 18, 18, 128, 128);
         }
      }
   }
}
