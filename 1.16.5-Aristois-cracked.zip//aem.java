import com.google.common.collect.BiMap;
import com.google.common.collect.ImmutableBiMap;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.ImmutableSet.Builder;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import javax.annotation.Nullable;

public interface aem<T> {
   Map<vk, ael<T>> a();

   @Nullable
   default ael<T> a(vk var1) {
      return (ael)this.a().get(var1);
   }

   ael<T> b(vk var1);

   @Nullable
   vk a(ael<T> var1);

   default vk b(ael<T> var1) {
      vk var2 = this.a(var1);
      if (var2 == null) {
         throw new IllegalStateException("Unrecognized tag");
      } else {
         return var2;
      }
   }

   default Collection<vk> b() {
      return this.a().keySet();
   }

   default Collection<vk> a(T var1) {
      List<vk> var2 = Lists.newArrayList();
      Iterator var3 = this.a().entrySet().iterator();

      while(var3.hasNext()) {
         Entry<vk, ael<T>> var4 = (Entry)var3.next();
         if (((ael)var4.getValue()).a(var1)) {
            var2.add(var4.getKey());
         }
      }

      return var2;
   }

   default void a(nf var1, gb<T> var2) {
      Map<vk, ael<T>> var3 = this.a();
      var1.d(var3.size());
      Iterator var4 = var3.entrySet().iterator();

      while(var4.hasNext()) {
         Entry<vk, ael<T>> var5 = (Entry)var4.next();
         var1.a((vk)var5.getKey());
         var1.d(((ael)var5.getValue()).b().size());
         Iterator var6 = ((ael)var5.getValue()).b().iterator();

         while(var6.hasNext()) {
            T var7 = var6.next();
            var1.d(var2.a(var7));
         }
      }

   }

   static <T> aem<T> a(nf var0, gm<T> var1) {
      Map<vk, ael<T>> var2 = Maps.newHashMap();
      int var3 = var0.i();

      for(int var4 = 0; var4 < var3; ++var4) {
         vk var5 = var0.p();
         int var6 = var0.i();
         Builder<T> var7 = ImmutableSet.builder();

         for(int var8 = 0; var8 < var6; ++var8) {
            var7.add(var1.a(var0.i()));
         }

         var2.put(var5, ael.b(var7.build()));
      }

      return a((Map)var2);
   }

   static <T> aem<T> c() {
      return a((Map)ImmutableBiMap.of());
   }

   static <T> aem<T> a(Map<vk, ael<T>> var0) {
      final BiMap<vk, ael<T>> var1 = ImmutableBiMap.copyOf(var0);
      return new aem<T>() {
         private final ael<T> b = aei.a();

         public ael<T> b(vk var1x) {
            return (ael)var1.getOrDefault(var1x, this.b);
         }

         @Nullable
         public vk a(ael<T> var1x) {
            return var1x instanceof ael.e ? ((ael.e)var1x).a() : (vk)var1.inverse().get(var1x);
         }

         public Map<vk, ael<T>> a() {
            return var1;
         }
      };
   }
}
