public interface cwt extends cwu {
   default int a(int var1) {
      return var1 - 1;
   }

   default int b(int var1) {
      return var1 - 1;
   }
}
