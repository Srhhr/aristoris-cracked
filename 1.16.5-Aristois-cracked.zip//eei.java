public class eei extends efw<bad, dts<bad>> {
   private static final vk a = new vk("textures/entity/fish/cod.png");

   public eei(eet var1) {
      super(var1, new dts(), 0.3F);
   }

   public vk a(bad var1) {
      return a;
   }

   protected void a(bad var1, dfm var2, float var3, float var4, float var5) {
      super.a(var1, var2, var3, var4, var5);
      float var6 = 4.3F * afm.a(0.6F * var3);
      var2.a(g.d.a(var6));
      if (!var1.aE()) {
         var2.a(0.10000000149011612D, 0.10000000149011612D, -0.10000000149011612D);
         var2.a(g.f.a(90.0F));
      }

   }
}
