import com.mojang.serialization.Codec;
import java.util.Random;

public class cjo extends cjl<cmh> {
   public cjo(Codec<cmh> var1) {
      super(var1);
   }

   public boolean a(bsr var1, cfy var2, Random var3, fx var4, cmh var5) {
      if (!var1.w(var4)) {
         return false;
      } else {
         ceh var6 = var1.d_(var4.b());
         if (!var6.a(bup.cL) && !var6.a(bup.cO) && !var6.a(bup.np)) {
            return false;
         } else {
            var1.a(var4, bup.cS.n(), 2);

            for(int var7 = 0; var7 < 1500; ++var7) {
               fx var8 = var4.b(var3.nextInt(8) - var3.nextInt(8), -var3.nextInt(12), var3.nextInt(8) - var3.nextInt(8));
               if (var1.d_(var8).g()) {
                  int var9 = 0;
                  gc[] var10 = gc.values();
                  int var11 = var10.length;

                  for(int var12 = 0; var12 < var11; ++var12) {
                     gc var13 = var10[var12];
                     if (var1.d_(var8.a(var13)).a(bup.cS)) {
                        ++var9;
                     }

                     if (var9 > 1) {
                        break;
                     }
                  }

                  if (var9 == 1) {
                     var1.a(var8, bup.cS.n(), 2);
                  }
               }
            }

            return true;
         }
      }
   }
}
