import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;

public abstract class kt {
   private static final Int2ObjectMap<vj<bsv>> c = new Int2ObjectArrayMap();
   public static final bsv a;
   public static final bsv b;

   private static bsv a(int var0, vj<bsv> var1, bsv var2) {
      c.put(var0, var1);
      return (bsv)hk.a(hk.i, var0, var1, var2);
   }

   public static vj<bsv> a(int var0) {
      return (vj)c.get(var0);
   }

   static {
      a(0, btb.a, ku.c(false));
      a = a(1, btb.b, ku.a(false));
      a(2, btb.c, ku.a(0.125F, 0.05F, true, true, true));
      a(3, btb.d, ku.a(1.0F, 0.5F, kp.m, false));
      a(4, btb.e, ku.c(0.1F, 0.2F));
      a(5, btb.f, ku.a(0.2F, 0.2F, false, false, true, false));
      a(6, btb.g, ku.d(-0.2F, 0.1F, false));
      a(7, btb.h, ku.a(-0.5F, 0.0F, 0.5F, 4159204, false));
      a(8, btb.i, ku.s());
      a(9, btb.j, ku.i());
      a(10, btb.k, ku.e(false));
      a(11, btb.l, ku.a(-0.5F, 0.0F, 0.0F, 3750089, true));
      a(12, btb.m, ku.a(0.125F, 0.05F, false, false));
      a(13, btb.n, ku.a(0.45F, 0.3F, false, true));
      a(14, btb.o, ku.a(0.2F, 0.3F));
      a(15, btb.p, ku.a(0.0F, 0.025F));
      a(16, btb.q, ku.a(0.0F, 0.025F, 0.8F, 0.4F, 4159204, false, false));
      a(17, btb.r, ku.a(0.45F, 0.3F, false, true, false));
      a(18, btb.s, ku.c(0.45F, 0.3F));
      a(19, btb.t, ku.a(0.45F, 0.3F, false, false, false, false));
      a(20, btb.u, ku.a(0.8F, 0.3F, kp.j, true));
      a(21, btb.v, ku.a());
      a(22, btb.w, ku.e());
      a(23, btb.x, ku.b());
      a(24, btb.y, ku.c(true));
      a(25, btb.z, ku.a(0.1F, 0.8F, 0.2F, 0.3F, 4159204, false, true));
      a(26, btb.A, ku.a(0.0F, 0.025F, 0.05F, 0.3F, 4020182, true, false));
      a(27, btb.B, ku.a(0.1F, 0.2F, false));
      a(28, btb.C, ku.a(0.45F, 0.3F, false));
      a(29, btb.D, ku.c(0.1F, 0.2F, false));
      a(30, btb.E, ku.a(0.2F, 0.2F, true, false, false, true));
      a(31, btb.F, ku.a(0.45F, 0.3F, true, false, false, false));
      a(32, btb.G, ku.a(0.2F, 0.2F, 0.3F, false));
      a(33, btb.H, ku.a(0.45F, 0.3F, 0.3F, false));
      a(34, btb.I, ku.a(1.0F, 0.5F, kp.j, true));
      a(35, btb.J, ku.a(0.125F, 0.05F, 1.2F, false, false));
      a(36, btb.K, ku.m());
      a(37, btb.L, ku.b(0.1F, 0.2F, false));
      a(38, btb.M, ku.b(1.5F, 0.025F));
      a(39, btb.N, ku.b(1.5F, 0.025F, true));
      a(40, btb.O, ku.l());
      a(41, btb.P, ku.j());
      a(42, btb.Q, ku.k());
      a(43, btb.R, ku.h());
      a(44, btb.S, ku.o());
      a(45, btb.T, ku.d(false));
      a(46, btb.U, ku.b(false));
      a(47, btb.V, ku.p());
      a(48, btb.W, ku.d(true));
      a(49, btb.X, ku.b(true));
      a(50, btb.Y, ku.e(true));
      b = a(127, btb.Z, ku.r());
      a(129, btb.aa, ku.a(true));
      a(130, btb.ab, ku.a(0.225F, 0.25F, false, false, false));
      a(131, btb.ac, ku.a(1.0F, 0.5F, kp.k, false));
      a(132, btb.ad, ku.q());
      a(133, btb.ae, ku.a(0.3F, 0.4F, false, true, false, false));
      a(134, btb.af, ku.d(-0.1F, 0.3F, true));
      a(140, btb.ag, ku.a(0.425F, 0.45000002F, true, false));
      a(149, btb.ah, ku.d());
      a(151, btb.ai, ku.c());
      a(155, btb.aj, ku.a(0.2F, 0.4F, true));
      a(156, btb.ak, ku.a(0.55F, 0.5F, true));
      a(157, btb.al, ku.c(0.2F, 0.4F, true));
      a(158, btb.am, ku.a(0.3F, 0.4F, true, true, false, false));
      a(160, btb.an, ku.a(0.2F, 0.2F, 0.25F, true));
      a(161, btb.ao, ku.a(0.2F, 0.2F, 0.25F, true));
      a(162, btb.ap, ku.a(1.0F, 0.5F, kp.k, false));
      a(163, btb.aq, ku.a(0.3625F, 1.225F, 1.1F, true, true));
      a(164, btb.ar, ku.a(1.05F, 1.2125001F, 1.0F, true, true));
      a(165, btb.as, ku.n());
      a(166, btb.at, ku.b(0.45F, 0.3F));
      a(167, btb.au, ku.b(0.45F, 0.3F, true));
      a(168, btb.av, ku.f());
      a(169, btb.aw, ku.g());
      a(170, btb.ax, ku.t());
      a(171, btb.ay, ku.v());
      a(172, btb.az, ku.w());
      a(173, btb.aA, ku.u());
   }
}
