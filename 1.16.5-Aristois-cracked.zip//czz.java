import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Sets;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import java.util.Set;
import java.util.stream.Stream;

public class czz extends dai {
   private final buo a;
   private final Set<cfj<?>> b;

   private czz(dbo[] var1, buo var2, Set<cfj<?>> var3) {
      super(var1);
      this.a = var2;
      this.b = var3;
   }

   public dak b() {
      return dal.v;
   }

   public Set<daz<?>> a() {
      return ImmutableSet.of(dbc.g);
   }

   protected bmb a(bmb var1, cyv var2) {
      ceh var3 = (ceh)var2.c(dbc.g);
      if (var3 != null) {
         md var4 = var1.p();
         md var5;
         if (var4.c("BlockStateTag", 10)) {
            var5 = var4.p("BlockStateTag");
         } else {
            var5 = new md();
            var4.a((String)"BlockStateTag", (mt)var5);
         }

         Stream var10000 = this.b.stream();
         var3.getClass();
         var10000.filter(var3::b).forEach((var2x) -> {
            var5.a(var2x.f(), a(var3, var2x));
         });
      }

      return var1;
   }

   public static czz.a a(buo var0) {
      return new czz.a(var0);
   }

   private static <T extends Comparable<T>> String a(ceh var0, cfj<T> var1) {
      T var2 = var0.c(var1);
      return var1.a(var2);
   }

   // $FF: synthetic method
   czz(dbo[] var1, buo var2, Set var3, Object var4) {
      this(var1, var2, var3);
   }

   public static class b extends dai.c<czz> {
      public void a(JsonObject var1, czz var2, JsonSerializationContext var3) {
         super.a(var1, (dai)var2, var3);
         var1.addProperty("block", gm.Q.b((Object)var2.a).toString());
         JsonArray var4 = new JsonArray();
         var2.b.forEach((var1x) -> {
            var4.add(var1x.f());
         });
         var1.add("properties", var4);
      }

      public czz a(JsonObject var1, JsonDeserializationContext var2, dbo[] var3) {
         vk var4 = new vk(afd.h(var1, "block"));
         buo var5 = (buo)gm.Q.b(var4).orElseThrow(() -> {
            return new IllegalArgumentException("Can't find block " + var4);
         });
         cei<buo, ceh> var6 = var5.m();
         Set<cfj<?>> var7 = Sets.newHashSet();
         JsonArray var8 = afd.a((JsonObject)var1, (String)"properties", (JsonArray)null);
         if (var8 != null) {
            var8.forEach((var2x) -> {
               var7.add(var6.a(afd.a(var2x, "property")));
            });
         }

         return new czz(var3, var5, var7);
      }

      // $FF: synthetic method
      public dai b(JsonObject var1, JsonDeserializationContext var2, dbo[] var3) {
         return this.a(var1, var2, var3);
      }
   }

   public static class a extends dai.a<czz.a> {
      private final buo a;
      private final Set<cfj<?>> b;

      private a(buo var1) {
         this.b = Sets.newHashSet();
         this.a = var1;
      }

      public czz.a a(cfj<?> var1) {
         if (!this.a.m().d().contains(var1)) {
            throw new IllegalStateException("Property " + var1 + " is not present on block " + this.a);
         } else {
            this.b.add(var1);
            return this;
         }
      }

      protected czz.a a() {
         return this;
      }

      public daj b() {
         return new czz(this.g(), this.a, this.b);
      }

      // $FF: synthetic method
      protected dai.a d() {
         return this.a();
      }

      // $FF: synthetic method
      a(buo var1, Object var2) {
         this(var1);
      }
   }
}
