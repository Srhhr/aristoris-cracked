public class dtv<T extends aqa> extends dvi<T> {
   public dtv() {
      super(12, 0.0F, false, 10.0F, 4.0F, 2.0F, 2.0F, 24);
      this.a = new dwn(this, 0, 0);
      this.a.a(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 6.0F, 0.0F);
      this.a.a(0.0F, 4.0F, -8.0F);
      this.a.a(22, 0).a(-5.0F, -5.0F, -4.0F, 1.0F, 3.0F, 1.0F, 0.0F);
      this.a.a(22, 0).a(4.0F, -5.0F, -4.0F, 1.0F, 3.0F, 1.0F, 0.0F);
      this.b = new dwn(this, 18, 4);
      this.b.a(-6.0F, -10.0F, -7.0F, 12.0F, 18.0F, 10.0F, 0.0F);
      this.b.a(0.0F, 5.0F, 2.0F);
      this.b.a(52, 0).a(-2.0F, 2.0F, -8.0F, 4.0F, 6.0F, 1.0F);
      --this.f.a;
      ++this.g.a;
      dwn var10000 = this.f;
      var10000.c += 0.0F;
      var10000 = this.g;
      var10000.c += 0.0F;
      --this.h.a;
      ++this.i.a;
      --this.h.c;
      --this.i.c;
   }

   public dwn c() {
      return this.a;
   }
}
