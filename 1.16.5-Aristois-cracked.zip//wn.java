import com.google.common.collect.Lists;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

public class wn {
   private static final DynamicCommandExceptionType a = new DynamicCommandExceptionType((var0) -> {
      return new of("commands.datapack.unknown", new Object[]{var0});
   });
   private static final DynamicCommandExceptionType b = new DynamicCommandExceptionType((var0) -> {
      return new of("commands.datapack.enable.failed", new Object[]{var0});
   });
   private static final DynamicCommandExceptionType c = new DynamicCommandExceptionType((var0) -> {
      return new of("commands.datapack.disable.failed", new Object[]{var0});
   });
   private static final SuggestionProvider<db> d = (var0, var1) -> {
      return dd.b(((db)var0.getSource()).j().aC().d().stream().map(StringArgumentType::escapeIfRequired), var1);
   };
   private static final SuggestionProvider<db> e = (var0, var1) -> {
      abw var2 = ((db)var0.getSource()).j().aC();
      Collection<String> var3 = var2.d();
      return dd.b(var2.b().stream().filter((var1x) -> {
         return !var3.contains(var1x);
      }).map(StringArgumentType::escapeIfRequired), var1);
   };

   public static void a(CommandDispatcher<db> var0) {
      var0.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)dc.a("datapack").requires((var0x) -> {
         return var0x.c(2);
      })).then(dc.a("enable").then(((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)dc.a((String)"name", (ArgumentType)StringArgumentType.string()).suggests(e).executes((var0x) -> {
         return a((db)var0x.getSource(), a(var0x, "name", true), (var0, var1) -> {
            var1.h().a(var0, var1, (var0x) -> {
               return var0x;
            }, false);
         });
      })).then(dc.a("after").then(dc.a((String)"existing", (ArgumentType)StringArgumentType.string()).suggests(d).executes((var0x) -> {
         return a((db)var0x.getSource(), a(var0x, "name", true), (var1, var2) -> {
            var1.add(var1.indexOf(a(var0x, "existing", false)) + 1, var2);
         });
      })))).then(dc.a("before").then(dc.a((String)"existing", (ArgumentType)StringArgumentType.string()).suggests(d).executes((var0x) -> {
         return a((db)var0x.getSource(), a(var0x, "name", true), (var1, var2) -> {
            var1.add(var1.indexOf(a(var0x, "existing", false)), var2);
         });
      })))).then(dc.a("last").executes((var0x) -> {
         return a((db)var0x.getSource(), a(var0x, "name", true), List::add);
      }))).then(dc.a("first").executes((var0x) -> {
         return a((db)var0x.getSource(), a(var0x, "name", true), (var0, var1) -> {
            var0.add(0, var1);
         });
      }))))).then(dc.a("disable").then(dc.a((String)"name", (ArgumentType)StringArgumentType.string()).suggests(d).executes((var0x) -> {
         return a((db)var0x.getSource(), a(var0x, "name", false));
      })))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)dc.a("list").executes((var0x) -> {
         return a((db)var0x.getSource());
      })).then(dc.a("available").executes((var0x) -> {
         return b((db)var0x.getSource());
      }))).then(dc.a("enabled").executes((var0x) -> {
         return c((db)var0x.getSource());
      }))));
   }

   private static int a(db var0, abu var1, wn.a var2) throws CommandSyntaxException {
      abw var3 = var0.j().aC();
      List<abu> var4 = Lists.newArrayList(var3.e());
      var2.apply(var4, var1);
      var0.a(new of("commands.datapack.modify.enable", new Object[]{var1.a(true)}), true);
      xv.a((Collection)var4.stream().map(abu::e).collect(Collectors.toList()), var0);
      return var4.size();
   }

   private static int a(db var0, abu var1) {
      abw var2 = var0.j().aC();
      List<abu> var3 = Lists.newArrayList(var2.e());
      var3.remove(var1);
      var0.a(new of("commands.datapack.modify.disable", new Object[]{var1.a(true)}), true);
      xv.a((Collection)var3.stream().map(abu::e).collect(Collectors.toList()), var0);
      return var3.size();
   }

   private static int a(db var0) {
      return c(var0) + b(var0);
   }

   private static int b(db var0) {
      abw var1 = var0.j().aC();
      var1.a();
      Collection<? extends abu> var2 = var1.e();
      Collection<? extends abu> var3 = var1.c();
      List<abu> var4 = (List)var3.stream().filter((var1x) -> {
         return !var2.contains(var1x);
      }).collect(Collectors.toList());
      if (var4.isEmpty()) {
         var0.a(new of("commands.datapack.list.available.none"), false);
      } else {
         var0.a(new of("commands.datapack.list.available.success", new Object[]{var4.size(), ns.b(var4, (var0x) -> {
            return var0x.a(false);
         })}), false);
      }

      return var4.size();
   }

   private static int c(db var0) {
      abw var1 = var0.j().aC();
      var1.a();
      Collection<? extends abu> var2 = var1.e();
      if (var2.isEmpty()) {
         var0.a(new of("commands.datapack.list.enabled.none"), false);
      } else {
         var0.a(new of("commands.datapack.list.enabled.success", new Object[]{var2.size(), ns.b(var2, (var0x) -> {
            return var0x.a(true);
         })}), false);
      }

      return var2.size();
   }

   private static abu a(CommandContext<db> var0, String var1, boolean var2) throws CommandSyntaxException {
      String var3 = StringArgumentType.getString(var0, var1);
      abw var4 = ((db)var0.getSource()).j().aC();
      abu var5 = var4.a(var3);
      if (var5 == null) {
         throw a.create(var3);
      } else {
         boolean var6 = var4.e().contains(var5);
         if (var2 && var6) {
            throw b.create(var3);
         } else if (!var2 && !var6) {
            throw c.create(var3);
         } else {
            return var5;
         }
      }
   }

   interface a {
      void apply(List<abu> var1, abu var2) throws CommandSyntaxException;
   }
}
