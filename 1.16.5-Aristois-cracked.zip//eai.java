public class eai {
   private final djz a;
   private final dzu b;
   private float c;

   public eai(dzu var1) {
      this.b = var1;
      this.a = djz.C();
   }

   public void a(float var1, float var2) {
      this.c += var1;
      this.b.a(this.a, afm.a(this.c * 0.001F) * 5.0F + 25.0F, -this.c * 0.1F, var2);
   }
}
