import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.util.UUID;

public class ya {
   public static void a(CommandDispatcher<db> var0) {
      var0.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)dc.a("say").requires((var0x) -> {
         return var0x.c(2);
      })).then(dc.a((String)"message", (ArgumentType)dp.a()).executes((var0x) -> {
         nr var1 = dp.a(var0x, "message");
         of var2 = new of("chat.type.announcement", new Object[]{((db)var0x.getSource()).b(), var1});
         aqa var3 = ((db)var0x.getSource()).f();
         if (var3 != null) {
            ((db)var0x.getSource()).j().ae().a((nr)var2, (no)no.a, (UUID)var3.bS());
         } else {
            ((db)var0x.getSource()).j().ae().a((nr)var2, (no)no.b, (UUID)x.b);
         }

         return 1;
      })));
   }
}
