import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import java.util.Iterator;

public class xz {
   private static final SimpleCommandExceptionType a = new SimpleCommandExceptionType(new of("commands.save.alreadyOn"));

   public static void a(CommandDispatcher<db> var0) {
      var0.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)dc.a("save-on").requires((var0x) -> {
         return var0x.c(4);
      })).executes((var0x) -> {
         db var1 = (db)var0x.getSource();
         boolean var2 = false;
         Iterator var3 = var1.j().G().iterator();

         while(var3.hasNext()) {
            aag var4 = (aag)var3.next();
            if (var4 != null && var4.c) {
               var4.c = false;
               var2 = true;
            }
         }

         if (!var2) {
            throw a.create();
         } else {
            var1.a(new of("commands.save.enabled"), true);
            return 1;
         }
      }));
   }
}
