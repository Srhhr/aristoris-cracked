import com.google.common.collect.ImmutableSet;
import com.mojang.serialization.Codec;
import java.util.BitSet;
import java.util.Random;
import java.util.function.Function;
import org.apache.commons.lang3.mutable.MutableBoolean;

public class cic extends cia {
   public cic(Codec<cmk> var1) {
      super(var1, 128);
      this.j = ImmutableSet.of(bup.b, bup.c, bup.e, bup.g, bup.j, bup.k, new buo[]{bup.l, bup.i, bup.cL, bup.cM, bup.cN, bup.mu, bup.ml, bup.iK, bup.mn, bup.cO, bup.np});
      this.k = ImmutableSet.of(cuy.e, cuy.c);
   }

   protected int a() {
      return 10;
   }

   protected float a(Random var1) {
      return (var1.nextFloat() * 2.0F + var1.nextFloat()) * 2.0F;
   }

   protected double b() {
      return 5.0D;
   }

   protected int b(Random var1) {
      return var1.nextInt(this.l);
   }

   protected boolean a(cfw var1, Function<fx, bsv> var2, BitSet var3, Random var4, fx.a var5, fx.a var6, fx.a var7, int var8, int var9, int var10, int var11, int var12, int var13, int var14, int var15, MutableBoolean var16) {
      int var17 = var13 | var15 << 4 | var14 << 8;
      if (var3.get(var17)) {
         return false;
      } else {
         var3.set(var17);
         var5.d(var11, var14, var12);
         if (this.a(var1.d_(var5))) {
            ceh var18;
            if (var14 <= 31) {
               var18 = i.g();
            } else {
               var18 = g;
            }

            var1.a(var5, var18, false);
            return true;
         } else {
            return false;
         }
      }
   }
}
