import java.util.Random;

public class bdn extends bej {
   public bdn(aqe<? extends bdn> var1, brx var2) {
      super(var1, var2);
   }

   public static boolean a(aqe<bdn> var0, bsk var1, aqp var2, fx var3, Random var4) {
      return b(var0, var1, var2, var3, var4) && (var2 == aqp.c || var1.e(var3));
   }

   protected boolean T_() {
      return false;
   }

   protected adp I() {
      return adq.gj;
   }

   protected adp e(apk var1) {
      return adq.gm;
   }

   protected adp dq() {
      return adq.gl;
   }

   protected adp eL() {
      return adq.gn;
   }

   public boolean B(aqa var1) {
      boolean var2 = super.B(var1);
      if (var2 && this.dD().a() && var1 instanceof aqm) {
         float var3 = this.l.d(this.cB()).b();
         ((aqm)var1).c(new apu(apw.q, 140 * (int)var3));
      }

      return var2;
   }

   protected boolean eN() {
      return true;
   }

   protected void eP() {
      this.b(aqe.aY);
      if (!this.aA()) {
         this.l.a((bfw)null, 1041, this.cB(), 0);
      }

   }

   protected bmb eM() {
      return bmb.b;
   }
}
