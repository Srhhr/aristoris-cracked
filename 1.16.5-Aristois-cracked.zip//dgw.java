import com.google.gson.JsonObject;
import java.util.Objects;

public class dgw extends dhc {
   public Boolean a;
   public Boolean b;
   public Boolean c;
   public Boolean d;
   public Integer e;
   public Boolean f;
   public Boolean g;
   public Integer h;
   public Integer i;
   public String j;
   public long k;
   public String l;
   public boolean m;
   public boolean n;
   private static final String o = null;

   public dgw(Boolean var1, Boolean var2, Boolean var3, Boolean var4, Integer var5, Boolean var6, Integer var7, Integer var8, Boolean var9, String var10) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
      this.e = var5;
      this.f = var6;
      this.h = var7;
      this.i = var8;
      this.g = var9;
      this.j = var10;
   }

   public static dgw a() {
      return new dgw(true, true, true, true, 0, false, 2, 0, false, "");
   }

   public static dgw b() {
      dgw var0 = a();
      var0.a(true);
      return var0;
   }

   public void a(boolean var1) {
      this.n = var1;
   }

   public static dgw a(JsonObject var0) {
      dgw var1 = new dgw(dip.a("pvp", var0, true), dip.a("spawnAnimals", var0, true), dip.a("spawnMonsters", var0, true), dip.a("spawnNPCs", var0, true), dip.a("spawnProtection", var0, 0), dip.a("commandBlocks", var0, false), dip.a("difficulty", var0, 2), dip.a("gameMode", var0, 0), dip.a("forceGameMode", var0, false), dip.a("slotName", var0, ""));
      var1.k = dip.a("worldTemplateId", var0, -1L);
      var1.l = dip.a("worldTemplateImage", var0, o);
      var1.m = dip.a("adventureMap", var0, false);
      return var1;
   }

   public String a(int var1) {
      if (this.j != null && !this.j.isEmpty()) {
         return this.j;
      } else {
         return this.n ? ekx.a("mco.configure.world.slot.empty") : this.b(var1);
      }
   }

   public String b(int var1) {
      return ekx.a("mco.configure.world.slot", var1);
   }

   public String c() {
      JsonObject var1 = new JsonObject();
      if (!this.a) {
         var1.addProperty("pvp", this.a);
      }

      if (!this.b) {
         var1.addProperty("spawnAnimals", this.b);
      }

      if (!this.c) {
         var1.addProperty("spawnMonsters", this.c);
      }

      if (!this.d) {
         var1.addProperty("spawnNPCs", this.d);
      }

      if (this.e != 0) {
         var1.addProperty("spawnProtection", this.e);
      }

      if (this.f) {
         var1.addProperty("commandBlocks", this.f);
      }

      if (this.h != 2) {
         var1.addProperty("difficulty", this.h);
      }

      if (this.i != 0) {
         var1.addProperty("gameMode", this.i);
      }

      if (this.g) {
         var1.addProperty("forceGameMode", this.g);
      }

      if (!Objects.equals(this.j, "")) {
         var1.addProperty("slotName", this.j);
      }

      return var1.toString();
   }

   public dgw d() {
      return new dgw(this.a, this.b, this.c, this.d, this.e, this.f, this.h, this.i, this.g, this.j);
   }

   // $FF: synthetic method
   public Object clone() throws CloneNotSupportedException {
      return this.d();
   }
}
