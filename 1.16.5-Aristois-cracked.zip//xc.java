import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.UUID;

public class xc {
   public static void a(CommandDispatcher<db> var0) {
      LiteralArgumentBuilder<db> var1 = (LiteralArgumentBuilder)dc.a("gamemode").requires((var0x) -> {
         return var0x.c(2);
      });
      bru[] var2 = bru.values();
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         bru var5 = var2[var4];
         if (var5 != bru.a) {
            var1.then(((LiteralArgumentBuilder)dc.a(var5.b()).executes((var1x) -> {
               return a((CommandContext)var1x, (Collection)Collections.singleton(((db)var1x.getSource()).h()), var5);
            })).then(dc.a((String)"target", (ArgumentType)dk.d()).executes((var1x) -> {
               return a(var1x, dk.f(var1x, "target"), var5);
            })));
         }
      }

      var0.register(var1);
   }

   private static void a(db var0, aah var1, bru var2) {
      nr var3 = new of("gameMode." + var2.b());
      if (var0.f() == var1) {
         var0.a(new of("commands.gamemode.success.self", new Object[]{var3}), true);
      } else {
         if (var0.e().V().b(brt.n)) {
            var1.a((nr)(new of("gameMode.changed", new Object[]{var3})), (UUID)x.b);
         }

         var0.a(new of("commands.gamemode.success.other", new Object[]{var1.d(), var3}), true);
      }

   }

   private static int a(CommandContext<db> var0, Collection<aah> var1, bru var2) {
      int var3 = 0;
      Iterator var4 = var1.iterator();

      while(var4.hasNext()) {
         aah var5 = (aah)var4.next();
         if (var5.d.b() != var2) {
            var5.a(var2);
            a((db)var0.getSource(), var5, var2);
            ++var3;
         }
      }

      return var3;
   }
}
