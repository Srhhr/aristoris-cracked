import java.util.Iterator;
import java.util.Random;

public class byn extends buo implements buq {
   public byn(ceg.c var1) {
      super(var1);
   }

   public boolean a(brc var1, fx var2, ceh var3, boolean var4) {
      if (!var1.d_(var2.b()).a(var1, var2)) {
         return false;
      } else {
         Iterator var5 = fx.a(var2.b(-1, -1, -1), var2.b(1, 1, 1)).iterator();

         fx var6;
         do {
            if (!var5.hasNext()) {
               return false;
            }

            var6 = (fx)var5.next();
         } while(!var1.d_(var6).a(aed.ao));

         return true;
      }
   }

   public boolean a(brx var1, Random var2, fx var3, ceh var4) {
      return true;
   }

   public void a(aag var1, Random var2, fx var3, ceh var4) {
      boolean var5 = false;
      boolean var6 = false;
      Iterator var7 = fx.a(var3.b(-1, -1, -1), var3.b(1, 1, 1)).iterator();

      while(var7.hasNext()) {
         fx var8 = (fx)var7.next();
         ceh var9 = var1.d_(var8);
         if (var9.a(bup.ml)) {
            var6 = true;
         }

         if (var9.a(bup.mu)) {
            var5 = true;
         }

         if (var6 && var5) {
            break;
         }
      }

      if (var6 && var5) {
         var1.a(var3, var2.nextBoolean() ? bup.ml.n() : bup.mu.n(), 3);
      } else if (var6) {
         var1.a(var3, bup.ml.n(), 3);
      } else if (var5) {
         var1.a(var3, bup.mu.n(), 3);
      }

   }
}
