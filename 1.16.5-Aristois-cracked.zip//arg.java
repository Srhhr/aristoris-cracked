public class arg {
   private final double a;
   private boolean b;
   private final String c;

   protected arg(String var1, double var2) {
      this.a = var2;
      this.c = var1;
   }

   public double a() {
      return this.a;
   }

   public boolean b() {
      return this.b;
   }

   public arg a(boolean var1) {
      this.b = var1;
      return this;
   }

   public double a(double var1) {
      return var1;
   }

   public String c() {
      return this.c;
   }
}
