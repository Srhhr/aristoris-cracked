import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import com.mojang.datafixers.DataFixer;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.Dynamic;
import com.mojang.serialization.DynamicOps;
import com.mojang.serialization.OptionalDynamic;
import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongLinkedOpenHashSet;
import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.Optional;
import java.util.function.BooleanSupplier;
import java.util.function.Function;
import javax.annotation.Nullable;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class chb<R> implements AutoCloseable {
   private static final Logger a = LogManager.getLogger();
   private final cgv b;
   private final Long2ObjectMap<Optional<R>> c = new Long2ObjectOpenHashMap();
   private final LongLinkedOpenHashSet d = new LongLinkedOpenHashSet();
   private final Function<Runnable, Codec<R>> e;
   private final Function<Runnable, R> f;
   private final DataFixer g;
   private final aga h;

   public chb(File var1, Function<Runnable, Codec<R>> var2, Function<Runnable, R> var3, DataFixer var4, aga var5, boolean var6) {
      this.e = var2;
      this.f = var3;
      this.g = var4;
      this.h = var5;
      this.b = new cgv(var1, var6, var1.getName());
   }

   protected void a(BooleanSupplier var1) {
      while(!this.d.isEmpty() && var1.getAsBoolean()) {
         brd var2 = gp.a(this.d.firstLong()).r();
         this.d(var2);
      }

   }

   @Nullable
   protected Optional<R> c(long var1) {
      return (Optional)this.c.get(var1);
   }

   protected Optional<R> d(long var1) {
      gp var3 = gp.a(var1);
      if (this.b(var3)) {
         return Optional.empty();
      } else {
         Optional<R> var4 = this.c(var1);
         if (var4 != null) {
            return var4;
         } else {
            this.b(var3.r());
            var4 = this.c(var1);
            if (var4 == null) {
               throw (IllegalStateException)x.c((Throwable)(new IllegalStateException()));
            } else {
               return var4;
            }
         }
      }
   }

   protected boolean b(gp var1) {
      return brx.b(gp.c(var1.b()));
   }

   protected R e(long var1) {
      Optional<R> var3 = this.d(var1);
      if (var3.isPresent()) {
         return var3.get();
      } else {
         R var4 = this.f.apply(() -> {
            this.a(var1);
         });
         this.c.put(var1, Optional.of(var4));
         return var4;
      }
   }

   private void b(brd var1) {
      this.a(var1, mo.a, this.c(var1));
   }

   @Nullable
   private md c(brd var1) {
      try {
         return this.b.a(var1);
      } catch (IOException var3) {
         a.error("Error reading chunk {} data from disk", var1, var3);
         return null;
      }
   }

   private <T> void a(brd var1, DynamicOps<T> var2, @Nullable T var3) {
      if (var3 == null) {
         for(int var4 = 0; var4 < 16; ++var4) {
            this.c.put(gp.a(var1, var4).s(), Optional.empty());
         }
      } else {
         Dynamic<T> var14 = new Dynamic(var2, var3);
         int var5 = a(var14);
         int var6 = w.a().getWorldVersion();
         boolean var7 = var5 != var6;
         Dynamic<T> var8 = this.g.update(this.h.a(), var14, var5, var6);
         OptionalDynamic<T> var9 = var8.get("Sections");

         for(int var10 = 0; var10 < 16; ++var10) {
            long var11 = gp.a(var1, var10).s();
            Optional<R> var13 = var9.get(Integer.toString(var10)).result().flatMap((var3x) -> {
               DataResult var10000 = ((Codec)this.e.apply(() -> {
                  this.a(var11);
               })).parse(var3x);
               Logger var10001 = a;
               var10001.getClass();
               return var10000.resultOrPartial(var10001::error);
            });
            this.c.put(var11, var13);
            var13.ifPresent((var4x) -> {
               this.b(var11);
               if (var7) {
                  this.a(var11);
               }

            });
         }
      }

   }

   private void d(brd var1) {
      Dynamic<mt> var2 = this.a(var1, mo.a);
      mt var3 = (mt)var2.getValue();
      if (var3 instanceof md) {
         this.b.a(var1, (md)var3);
      } else {
         a.error("Expected compound tag, got {}", var3);
      }

   }

   private <T> Dynamic<T> a(brd var1, DynamicOps<T> var2) {
      Map<T, T> var3 = Maps.newHashMap();

      for(int var4 = 0; var4 < 16; ++var4) {
         long var5 = gp.a(var1, var4).s();
         this.d.remove(var5);
         Optional<R> var7 = (Optional)this.c.get(var5);
         if (var7 != null && var7.isPresent()) {
            DataResult<T> var8 = ((Codec)this.e.apply(() -> {
               this.a(var5);
            })).encodeStart(var2, var7.get());
            String var9 = Integer.toString(var4);
            Logger var10001 = a;
            var10001.getClass();
            var8.resultOrPartial(var10001::error).ifPresent((var3x) -> {
               var3.put(var2.createString(var9), var3x);
            });
         }
      }

      return new Dynamic(var2, var2.createMap(ImmutableMap.of(var2.createString("Sections"), var2.createMap(var3), var2.createString("DataVersion"), var2.createInt(w.a().getWorldVersion()))));
   }

   protected void b(long var1) {
   }

   protected void a(long var1) {
      Optional<R> var3 = (Optional)this.c.get(var1);
      if (var3 != null && var3.isPresent()) {
         this.d.add(var1);
      } else {
         a.warn("No data for position: {}", gp.a(var1));
      }
   }

   private static int a(Dynamic<?> var0) {
      return var0.get("DataVersion").asInt(1945);
   }

   public void a(brd var1) {
      if (!this.d.isEmpty()) {
         for(int var2 = 0; var2 < 16; ++var2) {
            long var3 = gp.a(var1, var2).s();
            if (this.d.contains(var3)) {
               this.d(var1);
               return;
            }
         }
      }

   }

   public void close() throws IOException {
      this.b.close();
   }
}
