import com.mojang.datafixers.Products.P2;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder.Instance;
import com.mojang.serialization.codecs.RecordCodecBuilder.Mu;
import java.util.Random;
import java.util.Set;

public abstract class cnl {
   public static final Codec<cnl> d;
   protected final afw e;
   protected final afw f;

   protected static <P extends cnl> P2<Mu<P>, afw, afw> b(Instance<P> var0) {
      return var0.group(afw.a(0, 8, 8).fieldOf("radius").forGetter((var0x) -> {
         return var0x.e;
      }), afw.a(0, 8, 8).fieldOf("offset").forGetter((var0x) -> {
         return var0x.f;
      }));
   }

   public cnl(afw var1, afw var2) {
      this.e = var1;
      this.f = var2;
   }

   protected abstract cnm<?> a();

   public void a(bsb var1, Random var2, cmz var3, int var4, cnl.b var5, int var6, int var7, Set<fx> var8, cra var9) {
      this.a(var1, var2, var3, var4, var5, var6, var7, var8, this.a(var2), var9);
   }

   protected abstract void a(bsb var1, Random var2, cmz var3, int var4, cnl.b var5, int var6, int var7, Set<fx> var8, int var9, cra var10);

   public abstract int a(Random var1, int var2, cmz var3);

   public int a(Random var1, int var2) {
      return this.e.a(var1);
   }

   private int a(Random var1) {
      return this.f.a(var1);
   }

   protected abstract boolean a(Random var1, int var2, int var3, int var4, int var5, boolean var6);

   protected boolean b(Random var1, int var2, int var3, int var4, int var5, boolean var6) {
      int var7;
      int var8;
      if (var6) {
         var7 = Math.min(Math.abs(var2), Math.abs(var2 - 1));
         var8 = Math.min(Math.abs(var4), Math.abs(var4 - 1));
      } else {
         var7 = Math.abs(var2);
         var8 = Math.abs(var4);
      }

      return this.a(var1, var7, var3, var8, var5, var6);
   }

   protected void a(bsb var1, Random var2, cmz var3, fx var4, int var5, Set<fx> var6, int var7, boolean var8, cra var9) {
      int var10 = var8 ? 1 : 0;
      fx.a var11 = new fx.a();

      for(int var12 = -var5; var12 <= var5 + var10; ++var12) {
         for(int var13 = -var5; var13 <= var5 + var10; ++var13) {
            if (!this.b(var2, var12, var7, var13, var5, var8)) {
               var11.a((gr)var4, var12, var7, var13);
               if (cld.e(var1, var11)) {
                  var1.a(var11, var3.c.a(var2, var11), 19);
                  var9.c(new cra(var11, var11));
                  var6.add(var11.h());
               }
            }
         }
      }

   }

   static {
      d = gm.aX.dispatch(cnl::a, cnm::a);
   }

   public static final class b {
      private final fx a;
      private final int b;
      private final boolean c;

      public b(fx var1, int var2, boolean var3) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
      }

      public fx a() {
         return this.a;
      }

      public int b() {
         return this.b;
      }

      public boolean c() {
         return this.c;
      }
   }
}
