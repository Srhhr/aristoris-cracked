import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Random;
import java.util.Set;

public class cnq extends cnl {
   public static final Codec<cnq> a = RecordCodecBuilder.create((var0) -> {
      return b(var0).and(afw.a(0, 16, 8).fieldOf("trunk_height").forGetter((var0x) -> {
         return var0x.b;
      })).apply(var0, cnq::new);
   });
   private final afw b;

   public cnq(afw var1, afw var2, afw var3) {
      super(var1, var2);
      this.b = var3;
   }

   protected cnm<?> a() {
      return cnm.b;
   }

   protected void a(bsb var1, Random var2, cmz var3, int var4, cnl.b var5, int var6, int var7, Set<fx> var8, int var9, cra var10) {
      fx var11 = var5.a();
      int var12 = var2.nextInt(2);
      int var13 = 1;
      int var14 = 0;

      for(int var15 = var9; var15 >= -var6; --var15) {
         this.a(var1, var2, var3, var11, var12, var8, var15, var5.c(), var10);
         if (var12 >= var13) {
            var12 = var14;
            var14 = 1;
            var13 = Math.min(var13 + 1, var7 + var5.b());
         } else {
            ++var12;
         }
      }

   }

   public int a(Random var1, int var2, cmz var3) {
      return Math.max(4, var2 - this.b.a(var1));
   }

   protected boolean a(Random var1, int var2, int var3, int var4, int var5, boolean var6) {
      return var2 == var5 && var4 == var5 && var5 > 0;
   }
}
