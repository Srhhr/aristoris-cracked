import java.util.Random;

public class bzc extends buo {
   public static final cey a;

   public bzc(ceg.c var1) {
      super(var1);
      this.j((ceh)this.n().a(a, false));
   }

   public void a(ceh var1, brx var2, fx var3, bfw var4) {
      d(var1, var2, var3);
      super.a((ceh)var1, (brx)var2, (fx)var3, (bfw)var4);
   }

   public void a(brx var1, fx var2, aqa var3) {
      d(var1.d_(var2), var1, var2);
      super.a(var1, var2, var3);
   }

   public aou a(ceh var1, brx var2, fx var3, bfw var4, aot var5, dcj var6) {
      if (var2.v) {
         a(var2, var3);
      } else {
         d(var1, var2, var3);
      }

      bmb var7 = var4.b((aot)var5);
      return var7.b() instanceof bkh && (new bny(var4, var5, var7, var6)).b() ? aou.c : aou.a;
   }

   private static void d(ceh var0, brx var1, fx var2) {
      a(var1, var2);
      if (!(Boolean)var0.c(a)) {
         var1.a(var2, (ceh)var0.a(a, true), 3);
      }

   }

   public boolean a_(ceh var1) {
      return (Boolean)var1.c(a);
   }

   public void b(ceh var1, aag var2, fx var3, Random var4) {
      if ((Boolean)var1.c(a)) {
         var2.a(var3, (ceh)var1.a(a, false), 3);
      }

   }

   public void a(ceh var1, aag var2, fx var3, bmb var4) {
      super.a((ceh)var1, (aag)var2, (fx)var3, (bmb)var4);
      if (bpu.a(bpw.u, var4) == 0) {
         int var5 = 1 + var2.t.nextInt(5);
         this.a(var2, var3, var5);
      }

   }

   public void a(ceh var1, brx var2, fx var3, Random var4) {
      if ((Boolean)var1.c(a)) {
         a(var2, var3);
      }

   }

   private static void a(brx var0, fx var1) {
      double var2 = 0.5625D;
      Random var4 = var0.t;
      gc[] var5 = gc.values();
      int var6 = var5.length;

      for(int var7 = 0; var7 < var6; ++var7) {
         gc var8 = var5[var7];
         fx var9 = var1.a(var8);
         if (!var0.d_(var9).i(var0, var9)) {
            gc.a var10 = var8.n();
            double var11 = var10 == gc.a.a ? 0.5D + 0.5625D * (double)var8.i() : (double)var4.nextFloat();
            double var13 = var10 == gc.a.b ? 0.5D + 0.5625D * (double)var8.j() : (double)var4.nextFloat();
            double var15 = var10 == gc.a.c ? 0.5D + 0.5625D * (double)var8.k() : (double)var4.nextFloat();
            var0.a(hd.a, (double)var1.u() + var11, (double)var1.v() + var13, (double)var1.w() + var15, 0.0D, 0.0D, 0.0D);
         }
      }

   }

   protected void a(cei.a<buo, ceh> var1) {
      var1.a(a);
   }

   static {
      a = bzf.a;
   }
}
