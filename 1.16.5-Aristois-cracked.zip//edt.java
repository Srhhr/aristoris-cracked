import com.google.common.collect.Lists;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.List;

public class edt implements edh.a {
   private final List<fx> a = Lists.newArrayList();
   private final List<Float> b = Lists.newArrayList();
   private final List<Float> c = Lists.newArrayList();
   private final List<Float> d = Lists.newArrayList();
   private final List<Float> e = Lists.newArrayList();
   private final List<Float> f = Lists.newArrayList();

   public void a(fx var1, float var2, float var3, float var4, float var5, float var6) {
      this.a.add(var1);
      this.b.add(var2);
      this.c.add(var6);
      this.d.add(var3);
      this.e.add(var4);
      this.f.add(var5);
   }

   public void a(dfm var1, eag var2, double var3, double var5, double var7) {
      RenderSystem.pushMatrix();
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.disableTexture();
      dfo var9 = dfo.a();
      dfh var10 = var9.c();
      var10.a(5, dfk.l);

      for(int var11 = 0; var11 < this.a.size(); ++var11) {
         fx var12 = (fx)this.a.get(var11);
         Float var13 = (Float)this.b.get(var11);
         float var14 = var13 / 2.0F;
         eae.a(var10, (double)((float)var12.u() + 0.5F - var14) - var3, (double)((float)var12.v() + 0.5F - var14) - var5, (double)((float)var12.w() + 0.5F - var14) - var7, (double)((float)var12.u() + 0.5F + var14) - var3, (double)((float)var12.v() + 0.5F + var14) - var5, (double)((float)var12.w() + 0.5F + var14) - var7, (Float)this.d.get(var11), (Float)this.e.get(var11), (Float)this.f.get(var11), (Float)this.c.get(var11));
      }

      var9.b();
      RenderSystem.enableTexture();
      RenderSystem.popMatrix();
   }
}
