public class bce extends bbu {
   private static final azg b = (new azg()).a(150.0D);
   private final azg c;
   private int d;

   public bce(bbr var1) {
      super(var1);
      this.c = (new azg()).a(20.0D).a((var1x) -> {
         return Math.abs(var1x.cE() - var1.cE()) <= 10.0D;
      });
   }

   public void c() {
      ++this.d;
      aqm var1 = this.a.l.a(this.c, this.a, this.a.cD(), this.a.cE(), this.a.cH());
      if (var1 != null) {
         if (this.d > 25) {
            this.a.eK().a(bch.h);
         } else {
            dcn var2 = (new dcn(var1.cD() - this.a.cD(), 0.0D, var1.cH() - this.a.cH())).d();
            dcn var3 = (new dcn((double)afm.a(this.a.p * 0.017453292F), 0.0D, (double)(-afm.b(this.a.p * 0.017453292F)))).d();
            float var4 = (float)var3.b(var2);
            float var5 = (float)(Math.acos((double)var4) * 57.2957763671875D) + 0.5F;
            if (var5 < 0.0F || var5 > 10.0F) {
               double var6 = var1.cD() - this.a.bo.cD();
               double var8 = var1.cH() - this.a.bo.cH();
               double var10 = afm.a(afm.g(180.0D - afm.d(var6, var8) * 57.2957763671875D - (double)this.a.p), -100.0D, 100.0D);
               bbr var10000 = this.a;
               var10000.bt *= 0.8F;
               float var12 = afm.a(var6 * var6 + var8 * var8) + 1.0F;
               float var13 = var12;
               if (var12 > 40.0F) {
                  var12 = 40.0F;
               }

               var10000 = this.a;
               var10000.bt = (float)((double)var10000.bt + var10 * (double)(0.7F / var12 / var13));
               var10000 = this.a;
               var10000.p += this.a.bt;
            }
         }
      } else if (this.d >= 100) {
         var1 = this.a.l.a(b, this.a, this.a.cD(), this.a.cE(), this.a.cH());
         this.a.eK().a(bch.e);
         if (var1 != null) {
            this.a.eK().a(bch.i);
            ((bbv)this.a.eK().b(bch.i)).a(new dcn(var1.cD(), var1.cE(), var1.cH()));
         }
      }

   }

   public void d() {
      this.d = 0;
   }

   public bch<bce> i() {
      return bch.g;
   }
}
