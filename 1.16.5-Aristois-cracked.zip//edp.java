import com.mojang.blaze3d.systems.RenderSystem;
import java.util.Iterator;

public class edp implements edh.a {
   private final djz a;

   public edp(djz var1) {
      this.a = var1;
   }

   public void a(dfm var1, eag var2, double var3, double var5, double var7) {
      brc var9 = this.a.s.l;
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.lineWidth(2.0F);
      RenderSystem.disableTexture();
      RenderSystem.depthMask(false);
      fx var10 = new fx(var3, var5, var7);
      Iterator var11 = fx.a(var10.b(-6, -6, -6), var10.b(6, 6, 6)).iterator();

      while(true) {
         fx var12;
         ceh var13;
         do {
            if (!var11.hasNext()) {
               RenderSystem.depthMask(true);
               RenderSystem.enableTexture();
               RenderSystem.disableBlend();
               return;
            }

            var12 = (fx)var11.next();
            var13 = var9.d_(var12);
         } while(var13.a(bup.a));

         ddh var14 = var13.j(var9, var12);
         Iterator var15 = var14.d().iterator();

         while(var15.hasNext()) {
            dci var16 = (dci)var15.next();
            dci var17 = var16.a(var12).g(0.002D).d(-var3, -var5, -var7);
            double var18 = var17.a;
            double var20 = var17.b;
            double var22 = var17.c;
            double var24 = var17.d;
            double var26 = var17.e;
            double var28 = var17.f;
            float var30 = 1.0F;
            float var31 = 0.0F;
            float var32 = 0.0F;
            float var33 = 0.5F;
            dfo var34;
            dfh var35;
            if (var13.d(var9, var12, gc.e)) {
               var34 = dfo.a();
               var35 = var34.c();
               var35.a(5, dfk.l);
               var35.a(var18, var20, var22).a(1.0F, 0.0F, 0.0F, 0.5F).d();
               var35.a(var18, var20, var28).a(1.0F, 0.0F, 0.0F, 0.5F).d();
               var35.a(var18, var26, var22).a(1.0F, 0.0F, 0.0F, 0.5F).d();
               var35.a(var18, var26, var28).a(1.0F, 0.0F, 0.0F, 0.5F).d();
               var34.b();
            }

            if (var13.d(var9, var12, gc.d)) {
               var34 = dfo.a();
               var35 = var34.c();
               var35.a(5, dfk.l);
               var35.a(var18, var26, var28).a(1.0F, 0.0F, 0.0F, 0.5F).d();
               var35.a(var18, var20, var28).a(1.0F, 0.0F, 0.0F, 0.5F).d();
               var35.a(var24, var26, var28).a(1.0F, 0.0F, 0.0F, 0.5F).d();
               var35.a(var24, var20, var28).a(1.0F, 0.0F, 0.0F, 0.5F).d();
               var34.b();
            }

            if (var13.d(var9, var12, gc.f)) {
               var34 = dfo.a();
               var35 = var34.c();
               var35.a(5, dfk.l);
               var35.a(var24, var20, var28).a(1.0F, 0.0F, 0.0F, 0.5F).d();
               var35.a(var24, var20, var22).a(1.0F, 0.0F, 0.0F, 0.5F).d();
               var35.a(var24, var26, var28).a(1.0F, 0.0F, 0.0F, 0.5F).d();
               var35.a(var24, var26, var22).a(1.0F, 0.0F, 0.0F, 0.5F).d();
               var34.b();
            }

            if (var13.d(var9, var12, gc.c)) {
               var34 = dfo.a();
               var35 = var34.c();
               var35.a(5, dfk.l);
               var35.a(var24, var26, var22).a(1.0F, 0.0F, 0.0F, 0.5F).d();
               var35.a(var24, var20, var22).a(1.0F, 0.0F, 0.0F, 0.5F).d();
               var35.a(var18, var26, var22).a(1.0F, 0.0F, 0.0F, 0.5F).d();
               var35.a(var18, var20, var22).a(1.0F, 0.0F, 0.0F, 0.5F).d();
               var34.b();
            }

            if (var13.d(var9, var12, gc.a)) {
               var34 = dfo.a();
               var35 = var34.c();
               var35.a(5, dfk.l);
               var35.a(var18, var20, var22).a(1.0F, 0.0F, 0.0F, 0.5F).d();
               var35.a(var24, var20, var22).a(1.0F, 0.0F, 0.0F, 0.5F).d();
               var35.a(var18, var20, var28).a(1.0F, 0.0F, 0.0F, 0.5F).d();
               var35.a(var24, var20, var28).a(1.0F, 0.0F, 0.0F, 0.5F).d();
               var34.b();
            }

            if (var13.d(var9, var12, gc.b)) {
               var34 = dfo.a();
               var35 = var34.c();
               var35.a(5, dfk.l);
               var35.a(var18, var26, var22).a(1.0F, 0.0F, 0.0F, 0.5F).d();
               var35.a(var18, var26, var28).a(1.0F, 0.0F, 0.0F, 0.5F).d();
               var35.a(var24, var26, var22).a(1.0F, 0.0F, 0.0F, 0.5F).d();
               var35.a(var24, var26, var28).a(1.0F, 0.0F, 0.0F, 0.5F).d();
               var34.b();
            }
         }
      }
   }
}
