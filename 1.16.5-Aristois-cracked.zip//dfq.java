import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.system.MemoryStack;

public interface dfq {
   Logger f = LogManager.getLogger();

   dfq a(double var1, double var3, double var5);

   dfq a(int var1, int var2, int var3, int var4);

   dfq a(float var1, float var2);

   dfq a(int var1, int var2);

   dfq b(int var1, int var2);

   dfq b(float var1, float var2, float var3);

   void d();

   default void a(float var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8, float var9, int var10, int var11, float var12, float var13, float var14) {
      this.a((double)var1, (double)var2, (double)var3);
      this.a(var4, var5, var6, var7);
      this.a(var8, var9);
      this.b(var10);
      this.a(var11);
      this.b(var12, var13, var14);
      this.d();
   }

   default dfq a(float var1, float var2, float var3, float var4) {
      return this.a((int)(var1 * 255.0F), (int)(var2 * 255.0F), (int)(var3 * 255.0F), (int)(var4 * 255.0F));
   }

   default dfq a(int var1) {
      return this.b(var1 & '\uffff', var1 >> 16 & '\uffff');
   }

   default dfq b(int var1) {
      return this.a(var1 & '\uffff', var1 >> 16 & '\uffff');
   }

   default void a(dfm.a var1, eba var2, float var3, float var4, float var5, int var6, int var7) {
      this.a(var1, var2, new float[]{1.0F, 1.0F, 1.0F, 1.0F}, var3, var4, var5, new int[]{var6, var6, var6, var6}, var7, false);
   }

   default void a(dfm.a var1, eba var2, float[] var3, float var4, float var5, float var6, int[] var7, int var8, boolean var9) {
      int[] var10 = var2.b();
      gr var11 = var2.e().p();
      g var12 = new g((float)var11.u(), (float)var11.v(), (float)var11.w());
      b var13 = var1.a();
      var12.a(var1.b());
      int var14 = true;
      int var15 = var10.length / 8;
      MemoryStack var16 = MemoryStack.stackPush();
      Throwable var17 = null;

      try {
         ByteBuffer var18 = var16.malloc(dfk.h.b());
         IntBuffer var19 = var18.asIntBuffer();

         for(int var20 = 0; var20 < var15; ++var20) {
            var19.clear();
            var19.put(var10, var20 * 8, 8);
            float var21 = var18.getFloat(0);
            float var22 = var18.getFloat(4);
            float var23 = var18.getFloat(8);
            float var24;
            float var25;
            float var26;
            float var28;
            float var29;
            if (var9) {
               float var27 = (float)(var18.get(12) & 255) / 255.0F;
               var28 = (float)(var18.get(13) & 255) / 255.0F;
               var29 = (float)(var18.get(14) & 255) / 255.0F;
               var24 = var27 * var3[var20] * var4;
               var25 = var28 * var3[var20] * var5;
               var26 = var29 * var3[var20] * var6;
            } else {
               var24 = var3[var20] * var4;
               var25 = var3[var20] * var5;
               var26 = var3[var20] * var6;
            }

            int var40 = var7[var20];
            var28 = var18.getFloat(16);
            var29 = var18.getFloat(20);
            h var30 = new h(var21, var22, var23, 1.0F);
            var30.a(var13);
            this.a(var30.a(), var30.b(), var30.c(), var24, var25, var26, 1.0F, var28, var29, var8, var40, var12.a(), var12.b(), var12.c());
         }
      } catch (Throwable var38) {
         var17 = var38;
         throw var38;
      } finally {
         if (var16 != null) {
            if (var17 != null) {
               try {
                  var16.close();
               } catch (Throwable var37) {
                  var17.addSuppressed(var37);
               }
            } else {
               var16.close();
            }
         }

      }

   }

   default dfq a(b var1, float var2, float var3, float var4) {
      h var5 = new h(var2, var3, var4, 1.0F);
      var5.a(var1);
      return this.a((double)var5.a(), (double)var5.b(), (double)var5.c());
   }

   default dfq a(a var1, float var2, float var3, float var4) {
      g var5 = new g(var2, var3, var4);
      var5.a(var1);
      return this.b(var5.a(), var5.b(), var5.c());
   }
}
