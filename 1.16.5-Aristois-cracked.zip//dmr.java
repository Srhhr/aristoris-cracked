import com.google.common.collect.Queues;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.Arrays;
import java.util.Deque;
import java.util.Iterator;
import javax.annotation.Nullable;

public class dmr extends dkw {
   private final djz a;
   private final dmr.a<?>[] b = new dmr.a[5];
   private final Deque<dmq> c = Queues.newArrayDeque();

   public dmr(djz var1) {
      this.a = var1;
   }

   public void a(dfm var1) {
      if (!this.a.k.aI) {
         for(int var2 = 0; var2 < this.b.length; ++var2) {
            dmr.a<?> var3 = this.b[var2];
            if (var3 != null && var3.a(this.a.aD().o(), var2, var1)) {
               this.b[var2] = null;
            }

            if (this.b[var2] == null && !this.c.isEmpty()) {
               this.b[var2] = new dmr.a((dmq)this.c.removeFirst());
            }
         }

      }
   }

   @Nullable
   public <T extends dmq> T a(Class<? extends T> var1, Object var2) {
      dmr.a[] var3 = this.b;
      int var4 = var3.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         dmr.a<?> var6 = var3[var5];
         if (var6 != null && var1.isAssignableFrom(var6.a().getClass()) && var6.a().c().equals(var2)) {
            return var6.a();
         }
      }

      Iterator var7 = this.c.iterator();

      dmq var8;
      do {
         if (!var7.hasNext()) {
            return null;
         }

         var8 = (dmq)var7.next();
      } while(!var1.isAssignableFrom(var8.getClass()) || !var8.c().equals(var2));

      return var8;
   }

   public void a() {
      Arrays.fill(this.b, (Object)null);
      this.c.clear();
   }

   public void a(dmq var1) {
      this.c.add(var1);
   }

   public djz b() {
      return this.a;
   }

   class a<T extends dmq> {
      private final T b;
      private long c;
      private long d;
      private dmq.a e;

      private a(T var2) {
         this.c = -1L;
         this.d = -1L;
         this.e = dmq.a.a;
         this.b = var2;
      }

      public T a() {
         return this.b;
      }

      private float a(long var1) {
         float var3 = afm.a((float)(var1 - this.c) / 600.0F, 0.0F, 1.0F);
         var3 *= var3;
         return this.e == dmq.a.b ? 1.0F - var3 : var3;
      }

      public boolean a(int var1, int var2, dfm var3) {
         long var4 = x.b();
         if (this.c == -1L) {
            this.c = var4;
            this.e.a(dmr.this.a.W());
         }

         if (this.e == dmq.a.a && var4 - this.c <= 600L) {
            this.d = var4;
         }

         RenderSystem.pushMatrix();
         RenderSystem.translatef((float)var1 - (float)this.b.a() * this.a(var4), (float)(var2 * this.b.d()), (float)(800 + var2));
         dmq.a var6 = this.b.a(var3, dmr.this, var4 - this.d);
         RenderSystem.popMatrix();
         if (var6 != this.e) {
            this.c = var4 - (long)((int)((1.0F - this.a(var4)) * 600.0F));
            this.e = var6;
            this.e.a(dmr.this.a.W());
         }

         return this.e == dmq.a.b && var4 - this.c > 600L;
      }

      // $FF: synthetic method
      a(dmq var2, Object var3) {
         this(var2);
      }
   }
}
