public interface gk {
   double a();

   double b();

   double c();
}
