public enum bik {
   a,
   b,
   c,
   d,
   e,
   f,
   g;
}
