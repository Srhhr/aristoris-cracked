public class dcj extends dcl {
   private final gc b;
   private final fx c;
   private final boolean d;
   private final boolean e;

   public static dcj a(dcn var0, gc var1, fx var2) {
      return new dcj(true, var0, var1, var2, false);
   }

   public dcj(dcn var1, gc var2, fx var3, boolean var4) {
      this(false, var1, var2, var3, var4);
   }

   private dcj(boolean var1, dcn var2, gc var3, fx var4, boolean var5) {
      super(var2);
      this.d = var1;
      this.b = var3;
      this.c = var4;
      this.e = var5;
   }

   public dcj a(gc var1) {
      return new dcj(this.d, this.a, var1, this.c, this.e);
   }

   public dcj a(fx var1) {
      return new dcj(this.d, this.a, this.b, var1, this.e);
   }

   public fx a() {
      return this.c;
   }

   public gc b() {
      return this.b;
   }

   public dcl.a c() {
      return this.d ? dcl.a.a : dcl.a.b;
   }

   public boolean d() {
      return this.e;
   }
}
