import com.google.common.collect.ImmutableList;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.util.Collection;
import java.util.Iterator;

public class xh {
   public static void a(CommandDispatcher<db> var0) {
      var0.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)dc.a("kill").requires((var0x) -> {
         return var0x.c(2);
      })).executes((var0x) -> {
         return a((db)var0x.getSource(), ImmutableList.of(((db)var0x.getSource()).g()));
      })).then(dc.a((String)"targets", (ArgumentType)dk.b()).executes((var0x) -> {
         return a((db)var0x.getSource(), dk.b(var0x, "targets"));
      })));
   }

   private static int a(db var0, Collection<? extends aqa> var1) {
      Iterator var2 = var1.iterator();

      while(var2.hasNext()) {
         aqa var3 = (aqa)var2.next();
         var3.aa();
      }

      if (var1.size() == 1) {
         var0.a(new of("commands.kill.success.single", new Object[]{((aqa)var1.iterator().next()).d()}), true);
      } else {
         var0.a(new of("commands.kill.success.multiple", new Object[]{var1.size()}), true);
      }

      return var1.size();
   }
}
