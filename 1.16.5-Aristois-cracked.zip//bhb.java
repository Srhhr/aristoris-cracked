import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.function.Predicate;
import java.util.stream.Stream;
import javax.annotation.Nullable;

public class bhb {
   private static final nr a = new of("event.minecraft.raid");
   private static final nr b = new of("event.minecraft.raid.victory");
   private static final nr c = new of("event.minecraft.raid.defeat");
   private static final nr d;
   private static final nr e;
   private final Map<Integer, bhc> f = Maps.newHashMap();
   private final Map<Integer, Set<bhc>> g = Maps.newHashMap();
   private final Set<UUID> h = Sets.newHashSet();
   private long i;
   private fx j;
   private final aag k;
   private boolean l;
   private final int m;
   private float n;
   private int o;
   private boolean p;
   private int q;
   private final aad r;
   private int s;
   private int t;
   private final Random u;
   private final int v;
   private bhb.a w;
   private int x;
   private Optional<fx> y;

   public bhb(int var1, aag var2, fx var3) {
      this.r = new aad(a, aok.a.c, aok.b.c);
      this.u = new Random();
      this.y = Optional.empty();
      this.m = var1;
      this.k = var2;
      this.p = true;
      this.t = 300;
      this.r.a(0.0F);
      this.j = var3;
      this.v = this.a(var2.ad());
      this.w = bhb.a.a;
   }

   public bhb(aag var1, md var2) {
      this.r = new aad(a, aok.a.c, aok.b.c);
      this.u = new Random();
      this.y = Optional.empty();
      this.k = var1;
      this.m = var2.h("Id");
      this.l = var2.q("Started");
      this.p = var2.q("Active");
      this.i = var2.i("TicksActive");
      this.o = var2.h("BadOmenLevel");
      this.q = var2.h("GroupsSpawned");
      this.t = var2.h("PreRaidTicks");
      this.s = var2.h("PostRaidTicks");
      this.n = var2.j("TotalHealth");
      this.j = new fx(var2.h("CX"), var2.h("CY"), var2.h("CZ"));
      this.v = var2.h("NumGroups");
      this.w = bhb.a.b(var2.l("Status"));
      this.h.clear();
      if (var2.c("HeroesOfTheVillage", 9)) {
         mj var3 = var2.d("HeroesOfTheVillage", 11);

         for(int var4 = 0; var4 < var3.size(); ++var4) {
            this.h.add(mp.a(var3.k(var4)));
         }
      }

   }

   public boolean a() {
      return this.e() || this.f();
   }

   public boolean b() {
      return this.c() && this.r() == 0 && this.t > 0;
   }

   public boolean c() {
      return this.q > 0;
   }

   public boolean d() {
      return this.w == bhb.a.d;
   }

   public boolean e() {
      return this.w == bhb.a.b;
   }

   public boolean f() {
      return this.w == bhb.a.c;
   }

   public brx i() {
      return this.k;
   }

   public boolean j() {
      return this.l;
   }

   public int k() {
      return this.q;
   }

   private Predicate<aah> x() {
      return (var1) -> {
         fx var2 = var1.cB();
         return var1.aX() && this.k.b_(var2) == this;
      };
   }

   private void y() {
      Set<aah> var1 = Sets.newHashSet(this.r.h());
      List<aah> var2 = this.k.a(this.x());
      Iterator var3 = var2.iterator();

      aah var4;
      while(var3.hasNext()) {
         var4 = (aah)var3.next();
         if (!var1.contains(var4)) {
            this.r.a(var4);
         }
      }

      var3 = var1.iterator();

      while(var3.hasNext()) {
         var4 = (aah)var3.next();
         if (!var2.contains(var4)) {
            this.r.b(var4);
         }
      }

   }

   public int l() {
      return 5;
   }

   public int m() {
      return this.o;
   }

   public void a(bfw var1) {
      if (var1.a((aps)apw.E)) {
         this.o += var1.b((aps)apw.E).c() + 1;
         this.o = afm.a(this.o, 0, this.l());
      }

      var1.d((aps)apw.E);
   }

   public void n() {
      this.p = false;
      this.r.b();
      this.w = bhb.a.d;
   }

   public void o() {
      if (!this.d()) {
         if (this.w == bhb.a.a) {
            boolean var1 = this.p;
            this.p = this.k.C(this.j);
            if (this.k.ad() == aor.a) {
               this.n();
               return;
            }

            if (var1 != this.p) {
               this.r.d(this.p);
            }

            if (!this.p) {
               return;
            }

            if (!this.k.a_(this.j)) {
               this.z();
            }

            if (!this.k.a_(this.j)) {
               if (this.q > 0) {
                  this.w = bhb.a.c;
               } else {
                  this.n();
               }
            }

            ++this.i;
            if (this.i >= 48000L) {
               this.n();
               return;
            }

            int var2 = this.r();
            boolean var3;
            if (var2 == 0 && this.A()) {
               if (this.t <= 0) {
                  if (this.t == 0 && this.q > 0) {
                     this.t = 300;
                     this.r.a(a);
                     return;
                  }
               } else {
                  var3 = this.y.isPresent();
                  boolean var4 = !var3 && this.t % 5 == 0;
                  if (var3 && !this.k.i().a(new brd((fx)this.y.get()))) {
                     var4 = true;
                  }

                  if (var4) {
                     int var5 = 0;
                     if (this.t < 100) {
                        var5 = 1;
                     } else if (this.t < 40) {
                        var5 = 2;
                     }

                     this.y = this.d(var5);
                  }

                  if (this.t == 300 || this.t % 20 == 0) {
                     this.y();
                  }

                  --this.t;
                  this.r.a(afm.a((float)(300 - this.t) / 300.0F, 0.0F, 1.0F));
               }
            }

            if (this.i % 20L == 0L) {
               this.y();
               this.F();
               if (var2 > 0) {
                  if (var2 <= 2) {
                     this.r.a((nr)a.e().c(" - ").a((nr)(new of("event.minecraft.raid.raiders_remaining", new Object[]{var2}))));
                  } else {
                     this.r.a(a);
                  }
               } else {
                  this.r.a(a);
               }
            }

            var3 = false;
            int var10 = 0;

            while(this.G()) {
               fx var11 = this.y.isPresent() ? (fx)this.y.get() : this.a(var10, 20);
               if (var11 != null) {
                  this.l = true;
                  this.b(var11);
                  if (!var3) {
                     this.a(var11);
                     var3 = true;
                  }
               } else {
                  ++var10;
               }

               if (var10 > 3) {
                  this.n();
                  break;
               }
            }

            if (this.j() && !this.A() && var2 == 0) {
               if (this.s < 40) {
                  ++this.s;
               } else {
                  this.w = bhb.a.b;
                  Iterator var12 = this.h.iterator();

                  while(var12.hasNext()) {
                     UUID var6 = (UUID)var12.next();
                     aqa var7 = this.k.a(var6);
                     if (var7 instanceof aqm && !var7.a_()) {
                        aqm var8 = (aqm)var7;
                        var8.c(new apu(apw.F, 48000, this.o - 1, false, false, true));
                        if (var8 instanceof aah) {
                           aah var9 = (aah)var8;
                           var9.a((vk)aea.aA);
                           ac.H.a(var9);
                        }
                     }
                  }
               }
            }

            this.H();
         } else if (this.a()) {
            ++this.x;
            if (this.x >= 600) {
               this.n();
               return;
            }

            if (this.x % 20 == 0) {
               this.y();
               this.r.d(true);
               if (this.e()) {
                  this.r.a(0.0F);
                  this.r.a(d);
               } else {
                  this.r.a(e);
               }
            }
         }

      }
   }

   private void z() {
      Stream<gp> var1 = gp.a((gp)gp.a(this.j), 2);
      aag var10001 = this.k;
      var10001.getClass();
      var1.filter(var10001::a).map(gp::q).min(Comparator.comparingDouble((var1x) -> {
         return var1x.j(this.j);
      })).ifPresent(this::c);
   }

   private Optional<fx> d(int var1) {
      for(int var2 = 0; var2 < 3; ++var2) {
         fx var3 = this.a(var1, 1);
         if (var3 != null) {
            return Optional.of(var3);
         }
      }

      return Optional.empty();
   }

   private boolean A() {
      if (this.C()) {
         return !this.D();
      } else {
         return !this.B();
      }
   }

   private boolean B() {
      return this.k() == this.v;
   }

   private boolean C() {
      return this.o > 1;
   }

   private boolean D() {
      return this.k() > this.v;
   }

   private boolean E() {
      return this.B() && this.r() == 0 && this.C();
   }

   private void F() {
      Iterator<Set<bhc>> var1 = this.g.values().iterator();
      HashSet var2 = Sets.newHashSet();

      label54:
      while(var1.hasNext()) {
         Set<bhc> var3 = (Set)var1.next();
         Iterator var4 = var3.iterator();

         while(true) {
            while(true) {
               if (!var4.hasNext()) {
                  continue label54;
               }

               bhc var5 = (bhc)var4.next();
               fx var6 = var5.cB();
               if (!var5.y && var5.l.Y() == this.k.Y() && !(this.j.j(var6) >= 12544.0D)) {
                  if (var5.K > 600) {
                     if (this.k.a(var5.bS()) == null) {
                        var2.add(var5);
                     }

                     if (!this.k.a_(var6) && var5.dd() > 2400) {
                        var5.b(var5.fe() + 1);
                     }

                     if (var5.fe() >= 30) {
                        var2.add(var5);
                     }
                  }
               } else {
                  var2.add(var5);
               }
            }
         }
      }

      Iterator var7 = var2.iterator();

      while(var7.hasNext()) {
         bhc var8 = (bhc)var7.next();
         this.a(var8, true);
      }

   }

   private void a(fx var1) {
      float var2 = 13.0F;
      int var3 = true;
      Collection<aah> var4 = this.r.h();
      Iterator var5 = this.k.x().iterator();

      while(true) {
         aah var6;
         float var9;
         double var10;
         double var12;
         do {
            if (!var5.hasNext()) {
               return;
            }

            var6 = (aah)var5.next();
            dcn var7 = var6.cA();
            dcn var8 = dcn.a((gr)var1);
            var9 = afm.a((var8.b - var7.b) * (var8.b - var7.b) + (var8.d - var7.d) * (var8.d - var7.d));
            var10 = var7.b + (double)(13.0F / var9) * (var8.b - var7.b);
            var12 = var7.d + (double)(13.0F / var9) * (var8.d - var7.d);
         } while(!(var9 <= 64.0F) && !var4.contains(var6));

         var6.b.a((oj)(new rn(adq.md, adr.g, var10, var6.cE(), var12, 64.0F, 1.0F)));
      }
   }

   private void b(fx var1) {
      boolean var2 = false;
      int var3 = this.q + 1;
      this.n = 0.0F;
      aos var4 = this.k.d((fx)var1);
      boolean var5 = this.E();
      bhb.b[] var6 = bhb.b.f;
      int var7 = var6.length;

      for(int var8 = 0; var8 < var7; ++var8) {
         bhb.b var9 = var6[var8];
         int var10 = this.a(var9, var3, var5) + this.a(var9, this.u, var3, var4, var5);
         int var11 = 0;

         for(int var12 = 0; var12 < var10; ++var12) {
            bhc var13 = (bhc)var9.g.a((brx)this.k);
            if (!var2 && var13.eN()) {
               var13.t(true);
               this.a(var3, var13);
               var2 = true;
            }

            this.a(var3, var13, var1, false);
            if (var9.g == aqe.ap) {
               bhc var14 = null;
               if (var3 == this.a(aor.c)) {
                  var14 = (bhc)aqe.ak.a((brx)this.k);
               } else if (var3 >= this.a(aor.d)) {
                  if (var11 == 0) {
                     var14 = (bhc)aqe.w.a((brx)this.k);
                  } else {
                     var14 = (bhc)aqe.aQ.a((brx)this.k);
                  }
               }

               ++var11;
               if (var14 != null) {
                  this.a(var3, var14, var1, false);
                  var14.a(var1, 0.0F, 0.0F);
                  var14.m(var13);
               }
            }
         }
      }

      this.y = Optional.empty();
      ++this.q;
      this.p();
      this.H();
   }

   public void a(int var1, bhc var2, @Nullable fx var3, boolean var4) {
      boolean var5 = this.b(var1, var2);
      if (var5) {
         var2.a(this);
         var2.a(var1);
         var2.w(true);
         var2.b(0);
         if (!var4 && var3 != null) {
            var2.d((double)var3.u() + 0.5D, (double)var3.v() + 1.0D, (double)var3.w() + 0.5D);
            var2.a(this.k, this.k.d((fx)var3), aqp.h, (arc)null, (md)null);
            var2.a(var1, false);
            var2.c(true);
            this.k.l(var2);
         }
      }

   }

   public void p() {
      this.r.a(afm.a(this.q() / this.n, 0.0F, 1.0F));
   }

   public float q() {
      float var1 = 0.0F;
      Iterator var2 = this.g.values().iterator();

      while(var2.hasNext()) {
         Set<bhc> var3 = (Set)var2.next();

         bhc var5;
         for(Iterator var4 = var3.iterator(); var4.hasNext(); var1 += var5.dk()) {
            var5 = (bhc)var4.next();
         }
      }

      return var1;
   }

   private boolean G() {
      return this.t == 0 && (this.q < this.v || this.E()) && this.r() == 0;
   }

   public int r() {
      return this.g.values().stream().mapToInt(Set::size).sum();
   }

   public void a(bhc var1, boolean var2) {
      Set<bhc> var3 = (Set)this.g.get(var1.fc());
      if (var3 != null) {
         boolean var4 = var3.remove(var1);
         if (var4) {
            if (var2) {
               this.n -= var1.dk();
            }

            var1.a((bhb)null);
            this.p();
            this.H();
         }
      }

   }

   private void H() {
      this.k.z().b();
   }

   public static bmb s() {
      bmb var0 = new bmb(bmd.pM);
      md var1 = var0.a("BlockEntityTag");
      mj var2 = (new ccb.a()).a(ccb.z, bkx.j).a(ccb.f, bkx.i).a(ccb.j, bkx.h).a(ccb.E, bkx.i).a(ccb.k, bkx.p).a(ccb.B, bkx.i).a(ccb.y, bkx.i).a(ccb.E, bkx.p).a();
      var1.a((String)"Patterns", (mt)var2);
      var0.a(bmb.a.f);
      var0.a((nr)(new of("block.minecraft.ominous_banner")).a(k.g));
      return var0;
   }

   @Nullable
   public bhc b(int var1) {
      return (bhc)this.f.get(var1);
   }

   @Nullable
   private fx a(int var1, int var2) {
      int var3 = var1 == 0 ? 2 : 2 - var1;
      fx.a var7 = new fx.a();

      for(int var8 = 0; var8 < var2; ++var8) {
         float var9 = this.k.t.nextFloat() * 6.2831855F;
         int var4 = this.j.u() + afm.d(afm.b(var9) * 32.0F * (float)var3) + this.k.t.nextInt(5);
         int var6 = this.j.w() + afm.d(afm.a(var9) * 32.0F * (float)var3) + this.k.t.nextInt(5);
         int var5 = this.k.a(chn.a.b, var4, var6);
         var7.d(var4, var5, var6);
         if ((!this.k.a_(var7) || var1 >= 2) && this.k.a(var7.u() - 10, var7.v() - 10, var7.w() - 10, var7.u() + 10, var7.v() + 10, var7.w() + 10) && this.k.i().a(new brd(var7)) && (bsg.a((ard.c)ard.c.a, (brz)this.k, var7, (aqe)aqe.ap) || this.k.d_(var7.c()).a(bup.cC) && this.k.d_(var7).g())) {
            return var7;
         }
      }

      return null;
   }

   private boolean b(int var1, bhc var2) {
      return this.a(var1, var2, true);
   }

   public boolean a(int var1, bhc var2, boolean var3) {
      this.g.computeIfAbsent(var1, (var0) -> {
         return Sets.newHashSet();
      });
      Set<bhc> var4 = (Set)this.g.get(var1);
      bhc var5 = null;
      Iterator var6 = var4.iterator();

      while(var6.hasNext()) {
         bhc var7 = (bhc)var6.next();
         if (var7.bS().equals(var2.bS())) {
            var5 = var7;
            break;
         }
      }

      if (var5 != null) {
         var4.remove(var5);
         var4.add(var2);
      }

      var4.add(var2);
      if (var3) {
         this.n += var2.dk();
      }

      this.p();
      this.H();
      return true;
   }

   public void a(int var1, bhc var2) {
      this.f.put(var1, var2);
      var2.a(aqf.f, s());
      var2.a(aqf.f, 2.0F);
   }

   public void c(int var1) {
      this.f.remove(var1);
   }

   public fx t() {
      return this.j;
   }

   private void c(fx var1) {
      this.j = var1;
   }

   public int u() {
      return this.m;
   }

   private int a(bhb.b var1, int var2, boolean var3) {
      return var3 ? var1.h[this.v] : var1.h[var2];
   }

   private int a(bhb.b var1, Random var2, int var3, aos var4, boolean var5) {
      aor var6 = var4.a();
      boolean var7 = var6 == aor.b;
      boolean var8 = var6 == aor.c;
      int var9;
      switch(var1) {
      case d:
         if (!var7 && var3 > 2 && var3 != 4) {
            var9 = 1;
            break;
         }

         return 0;
      case c:
      case a:
         if (var7) {
            var9 = var2.nextInt(2);
         } else if (var8) {
            var9 = 1;
         } else {
            var9 = 2;
         }
         break;
      case e:
         var9 = !var7 && var5 ? 1 : 0;
         break;
      default:
         return 0;
      }

      return var9 > 0 ? var2.nextInt(var9 + 1) : 0;
   }

   public boolean v() {
      return this.p;
   }

   public md a(md var1) {
      var1.b("Id", this.m);
      var1.a("Started", this.l);
      var1.a("Active", this.p);
      var1.a("TicksActive", this.i);
      var1.b("BadOmenLevel", this.o);
      var1.b("GroupsSpawned", this.q);
      var1.b("PreRaidTicks", this.t);
      var1.b("PostRaidTicks", this.s);
      var1.a("TotalHealth", this.n);
      var1.b("NumGroups", this.v);
      var1.a("Status", this.w.a());
      var1.b("CX", this.j.u());
      var1.b("CY", this.j.v());
      var1.b("CZ", this.j.w());
      mj var2 = new mj();
      Iterator var3 = this.h.iterator();

      while(var3.hasNext()) {
         UUID var4 = (UUID)var3.next();
         var2.add(mp.a(var4));
      }

      var1.a((String)"HeroesOfTheVillage", (mt)var2);
      return var1;
   }

   public int a(aor var1) {
      switch(var1) {
      case b:
         return 3;
      case c:
         return 5;
      case d:
         return 7;
      default:
         return 0;
      }
   }

   public float w() {
      int var1 = this.m();
      if (var1 == 2) {
         return 0.1F;
      } else if (var1 == 3) {
         return 0.25F;
      } else if (var1 == 4) {
         return 0.5F;
      } else {
         return var1 == 5 ? 0.75F : 0.0F;
      }
   }

   public void a(aqa var1) {
      this.h.add(var1.bS());
   }

   static {
      d = a.e().c(" - ").a(b);
      e = a.e().c(" - ").a(c);
   }

   static enum b {
      a(aqe.aQ, new int[]{0, 0, 2, 0, 1, 4, 2, 5}),
      b(aqe.w, new int[]{0, 0, 0, 0, 0, 1, 1, 2}),
      c(aqe.ak, new int[]{0, 4, 3, 3, 4, 4, 4, 2}),
      d(aqe.aS, new int[]{0, 0, 0, 0, 3, 0, 0, 1}),
      e(aqe.ap, new int[]{0, 0, 0, 1, 0, 1, 0, 2});

      private static final bhb.b[] f = values();
      private final aqe<? extends bhc> g;
      private final int[] h;

      private b(aqe<? extends bhc> var3, int[] var4) {
         this.g = var3;
         this.h = var4;
      }
   }

   static enum a {
      a,
      b,
      c,
      d;

      private static final bhb.a[] e = values();

      private static bhb.a b(String var0) {
         bhb.a[] var1 = e;
         int var2 = var1.length;

         for(int var3 = 0; var3 < var2; ++var3) {
            bhb.a var4 = var1[var3];
            if (var0.equalsIgnoreCase(var4.name())) {
               return var4;
            }
         }

         return a;
      }

      public String a() {
         return this.name().toLowerCase(Locale.ROOT);
      }
   }
}
