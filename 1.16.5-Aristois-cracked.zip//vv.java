import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import javax.annotation.Nullable;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class vv extends acj {
   private static final Logger a = LogManager.getLogger();
   private static final Gson b = (new GsonBuilder()).create();
   private z c = new z();
   private final cza d;

   public vv(cza var1) {
      super(b, "advancements");
      this.d = var1;
   }

   protected void a(Map<vk, JsonElement> var1, ach var2, anw var3) {
      Map<vk, y.a> var4 = Maps.newHashMap();
      var1.forEach((var2x, var3x) -> {
         try {
            JsonObject var4x = afd.m(var3x, "advancement");
            y.a var5 = y.a.a(var4x, new ax(var2x, this.d));
            var4.put(var2x, var5);
         } catch (IllegalArgumentException | JsonParseException var6) {
            a.error("Parsing error loading custom advancement {}: {}", var2x, var6.getMessage());
         }

      });
      z var5 = new z();
      var5.a((Map)var4);
      Iterator var6 = var5.b().iterator();

      while(var6.hasNext()) {
         y var7 = (y)var6.next();
         if (var7.c() != null) {
            ak.a(var7);
         }
      }

      this.c = var5;
   }

   @Nullable
   public y a(vk var1) {
      return this.c.a(var1);
   }

   public Collection<y> a() {
      return this.c.c();
   }
}
