import com.google.common.collect.ImmutableMap;
import java.util.Random;

public class asi<E extends aqn> extends arv<E> {
   private final int b;
   private final float c;

   public asi(int var1, float var2) {
      super(ImmutableMap.of(ayd.S, aye.a, ayd.o, aye.b, ayd.m, aye.b, ayd.n, aye.c));
      this.b = var1;
      this.c = var2;
   }

   protected void a(aag var1, aqn var2, long var3) {
      fx var5 = a(var2);
      boolean var6 = var5.a(var2.cB(), (double)this.b);
      if (!var6) {
         arw.a(var2, (fx)a(var2, var5), this.c, this.b);
      }

   }

   private static fx a(aqn var0, fx var1) {
      Random var2 = var0.l.t;
      return var1.b(a(var2), 0, a(var2));
   }

   private static int a(Random var0) {
      return var0.nextInt(3) - 1;
   }

   private static fx a(aqn var0) {
      return (fx)var0.cJ().c(ayd.S).get();
   }
}
