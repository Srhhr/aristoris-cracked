public abstract class bxm extends buo {
   public static final cfb aq;

   protected bxm(ceg.c var1) {
      super(var1);
   }

   public ceh a(ceh var1, bzm var2) {
      return (ceh)var1.a(aq, var2.a((gc)var1.c(aq)));
   }

   public ceh a(ceh var1, byg var2) {
      return var1.a(var2.a((gc)var1.c(aq)));
   }

   static {
      aq = cex.O;
   }
}
