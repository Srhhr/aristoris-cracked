import com.mojang.blaze3d.systems.RenderSystem;
import javax.annotation.Nullable;

public class eaq {
   private static final vk a = new vk("textures/misc/underwater.png");

   public static void a(djz var0, dfm var1) {
      RenderSystem.disableAlphaTest();
      bfw var2 = var0.s;
      if (!var2.H) {
         ceh var3 = a(var2);
         if (var3 != null) {
            a(var0, var0.ab().a().a(var3), var1);
         }
      }

      if (!var0.s.a_()) {
         if (var0.s.a((ael)aef.b)) {
            b(var0, var1);
         }

         if (var0.s.bq()) {
            c(var0, var1);
         }
      }

      RenderSystem.enableAlphaTest();
   }

   @Nullable
   private static ceh a(bfw var0) {
      fx.a var1 = new fx.a();

      for(int var2 = 0; var2 < 8; ++var2) {
         double var3 = var0.cD() + (double)(((float)((var2 >> 0) % 2) - 0.5F) * var0.cy() * 0.8F);
         double var5 = var0.cG() + (double)(((float)((var2 >> 1) % 2) - 0.5F) * 0.1F);
         double var7 = var0.cH() + (double)(((float)((var2 >> 2) % 2) - 0.5F) * var0.cy() * 0.8F);
         var1.c(var3, var5, var7);
         ceh var9 = var0.l.d_(var1);
         if (var9.h() != bzh.a && var9.p(var0.l, var1)) {
            return var9;
         }
      }

      return null;
   }

   private static void a(djz var0, ekc var1, dfm var2) {
      var0.M().a(var1.m().g());
      dfh var3 = dfo.a().c();
      float var4 = 0.1F;
      float var5 = -1.0F;
      float var6 = 1.0F;
      float var7 = -1.0F;
      float var8 = 1.0F;
      float var9 = -0.5F;
      float var10 = var1.h();
      float var11 = var1.i();
      float var12 = var1.j();
      float var13 = var1.k();
      b var14 = var2.c().a();
      var3.a(7, dfk.o);
      var3.a(var14, -1.0F, -1.0F, -0.5F).a(0.1F, 0.1F, 0.1F, 1.0F).a(var11, var13).d();
      var3.a(var14, 1.0F, -1.0F, -0.5F).a(0.1F, 0.1F, 0.1F, 1.0F).a(var10, var13).d();
      var3.a(var14, 1.0F, 1.0F, -0.5F).a(0.1F, 0.1F, 0.1F, 1.0F).a(var10, var12).d();
      var3.a(var14, -1.0F, 1.0F, -0.5F).a(0.1F, 0.1F, 0.1F, 1.0F).a(var11, var12).d();
      var3.c();
      dfi.a(var3);
   }

   private static void b(djz var0, dfm var1) {
      RenderSystem.enableTexture();
      var0.M().a(a);
      dfh var2 = dfo.a().c();
      float var3 = var0.s.aR();
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      float var4 = 4.0F;
      float var5 = -1.0F;
      float var6 = 1.0F;
      float var7 = -1.0F;
      float var8 = 1.0F;
      float var9 = -0.5F;
      float var10 = -var0.s.p / 64.0F;
      float var11 = var0.s.q / 64.0F;
      b var12 = var1.c().a();
      var2.a(7, dfk.o);
      var2.a(var12, -1.0F, -1.0F, -0.5F).a(var3, var3, var3, 0.1F).a(4.0F + var10, 4.0F + var11).d();
      var2.a(var12, 1.0F, -1.0F, -0.5F).a(var3, var3, var3, 0.1F).a(0.0F + var10, 4.0F + var11).d();
      var2.a(var12, 1.0F, 1.0F, -0.5F).a(var3, var3, var3, 0.1F).a(0.0F + var10, 0.0F + var11).d();
      var2.a(var12, -1.0F, 1.0F, -0.5F).a(var3, var3, var3, 0.1F).a(4.0F + var10, 0.0F + var11).d();
      var2.c();
      dfi.a(var2);
      RenderSystem.disableBlend();
   }

   private static void c(djz var0, dfm var1) {
      dfh var2 = dfo.a().c();
      RenderSystem.depthFunc(519);
      RenderSystem.depthMask(false);
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.enableTexture();
      ekc var3 = els.b.c();
      var0.M().a(var3.m().g());
      float var4 = var3.h();
      float var5 = var3.i();
      float var6 = (var4 + var5) / 2.0F;
      float var7 = var3.j();
      float var8 = var3.k();
      float var9 = (var7 + var8) / 2.0F;
      float var10 = var3.p();
      float var11 = afm.g(var10, var4, var6);
      float var12 = afm.g(var10, var5, var6);
      float var13 = afm.g(var10, var7, var9);
      float var14 = afm.g(var10, var8, var9);
      float var15 = 1.0F;

      for(int var16 = 0; var16 < 2; ++var16) {
         var1.a();
         float var17 = -0.5F;
         float var18 = 0.5F;
         float var19 = -0.5F;
         float var20 = 0.5F;
         float var21 = -0.5F;
         var1.a((double)((float)(-(var16 * 2 - 1)) * 0.24F), -0.30000001192092896D, 0.0D);
         var1.a(g.d.a((float)(var16 * 2 - 1) * 10.0F));
         b var22 = var1.c().a();
         var2.a(7, dfk.o);
         var2.a(var22, -0.5F, -0.5F, -0.5F).a(1.0F, 1.0F, 1.0F, 0.9F).a(var12, var14).d();
         var2.a(var22, 0.5F, -0.5F, -0.5F).a(1.0F, 1.0F, 1.0F, 0.9F).a(var11, var14).d();
         var2.a(var22, 0.5F, 0.5F, -0.5F).a(1.0F, 1.0F, 1.0F, 0.9F).a(var11, var13).d();
         var2.a(var22, -0.5F, 0.5F, -0.5F).a(1.0F, 1.0F, 1.0F, 0.9F).a(var12, var13).d();
         var2.c();
         dfi.a(var2);
         var1.b();
      }

      RenderSystem.disableBlend();
      RenderSystem.depthMask(true);
      RenderSystem.depthFunc(515);
   }
}
