import java.util.Iterator;

public class ayi extends ayj {
   private boolean p;

   public ayi(aqn var1, brx var2) {
      super(var1, var2);
   }

   protected cxf a(int var1) {
      this.o = new cxj();
      this.o.a(true);
      return new cxf(this.o, var1);
   }

   protected boolean a() {
      return this.a.ao() || this.p() || this.a.br();
   }

   protected dcn b() {
      return new dcn(this.a.cD(), (double)this.u(), this.a.cH());
   }

   public cxd a(fx var1, int var2) {
      fx var3;
      if (this.b.d_(var1).g()) {
         for(var3 = var1.c(); var3.v() > 0 && this.b.d_(var3).g(); var3 = var3.c()) {
         }

         if (var3.v() > 0) {
            return super.a(var3.b(), var2);
         }

         while(var3.v() < this.b.L() && this.b.d_(var3).g()) {
            var3 = var3.b();
         }

         var1 = var3;
      }

      if (!this.b.d_(var1).c().b()) {
         return super.a(var1, var2);
      } else {
         for(var3 = var1.b(); var3.v() < this.b.L() && this.b.d_(var3).c().b(); var3 = var3.b()) {
         }

         return super.a(var3, var2);
      }
   }

   public cxd a(aqa var1, int var2) {
      return this.a(var1.cB(), var2);
   }

   private int u() {
      if (this.a.aE() && this.r()) {
         int var1 = afm.c(this.a.cE());
         buo var2 = this.b.d_(new fx(this.a.cD(), (double)var1, this.a.cH())).b();
         int var3 = 0;

         do {
            if (var2 != bup.A) {
               return var1;
            }

            ++var1;
            var2 = this.b.d_(new fx(this.a.cD(), (double)var1, this.a.cH())).b();
            ++var3;
         } while(var3 <= 16);

         return afm.c(this.a.cE());
      } else {
         return afm.c(this.a.cE() + 0.5D);
      }
   }

   protected void D_() {
      super.D_();
      if (this.p) {
         if (this.b.e(new fx(this.a.cD(), this.a.cE() + 0.5D, this.a.cH()))) {
            return;
         }

         for(int var1 = 0; var1 < this.c.e(); ++var1) {
            cxb var2 = this.c.a(var1);
            if (this.b.e(new fx(var2.a, var2.b, var2.c))) {
               this.c.b(var1);
               return;
            }
         }
      }

   }

   protected boolean a(dcn var1, dcn var2, int var3, int var4, int var5) {
      int var6 = afm.c(var1.b);
      int var7 = afm.c(var1.d);
      double var8 = var2.b - var1.b;
      double var10 = var2.d - var1.d;
      double var12 = var8 * var8 + var10 * var10;
      if (var12 < 1.0E-8D) {
         return false;
      } else {
         double var14 = 1.0D / Math.sqrt(var12);
         var8 *= var14;
         var10 *= var14;
         var3 += 2;
         var5 += 2;
         if (!this.a(var6, afm.c(var1.c), var7, var3, var4, var5, var1, var8, var10)) {
            return false;
         } else {
            var3 -= 2;
            var5 -= 2;
            double var16 = 1.0D / Math.abs(var8);
            double var18 = 1.0D / Math.abs(var10);
            double var20 = (double)var6 - var1.b;
            double var22 = (double)var7 - var1.d;
            if (var8 >= 0.0D) {
               ++var20;
            }

            if (var10 >= 0.0D) {
               ++var22;
            }

            var20 /= var8;
            var22 /= var10;
            int var24 = var8 < 0.0D ? -1 : 1;
            int var25 = var10 < 0.0D ? -1 : 1;
            int var26 = afm.c(var2.b);
            int var27 = afm.c(var2.d);
            int var28 = var26 - var6;
            int var29 = var27 - var7;

            do {
               if (var28 * var24 <= 0 && var29 * var25 <= 0) {
                  return true;
               }

               if (var20 < var22) {
                  var20 += var16;
                  var6 += var24;
                  var28 = var26 - var6;
               } else {
                  var22 += var18;
                  var7 += var25;
                  var29 = var27 - var7;
               }
            } while(this.a(var6, afm.c(var1.c), var7, var3, var4, var5, var1, var8, var10));

            return false;
         }
      }
   }

   private boolean a(int var1, int var2, int var3, int var4, int var5, int var6, dcn var7, double var8, double var10) {
      int var12 = var1 - var4 / 2;
      int var13 = var3 - var6 / 2;
      if (!this.b(var12, var2, var13, var4, var5, var6, var7, var8, var10)) {
         return false;
      } else {
         for(int var14 = var12; var14 < var12 + var4; ++var14) {
            for(int var15 = var13; var15 < var13 + var6; ++var15) {
               double var16 = (double)var14 + 0.5D - var7.b;
               double var18 = (double)var15 + 0.5D - var7.d;
               if (!(var16 * var8 + var18 * var10 < 0.0D)) {
                  cwz var20 = this.o.a(this.b, var14, var2 - 1, var15, this.a, var4, var5, var6, true, true);
                  if (!this.a(var20)) {
                     return false;
                  }

                  var20 = this.o.a(this.b, var14, var2, var15, this.a, var4, var5, var6, true, true);
                  float var21 = this.a.a(var20);
                  if (var21 < 0.0F || var21 >= 8.0F) {
                     return false;
                  }

                  if (var20 == cwz.m || var20 == cwz.l || var20 == cwz.q) {
                     return false;
                  }
               }
            }
         }

         return true;
      }
   }

   protected boolean a(cwz var1) {
      if (var1 == cwz.h) {
         return false;
      } else if (var1 == cwz.g) {
         return false;
      } else {
         return var1 != cwz.b;
      }
   }

   private boolean b(int var1, int var2, int var3, int var4, int var5, int var6, dcn var7, double var8, double var10) {
      Iterator var12 = fx.a(new fx(var1, var2, var3), new fx(var1 + var4 - 1, var2 + var5 - 1, var3 + var6 - 1)).iterator();

      fx var13;
      double var14;
      double var16;
      do {
         if (!var12.hasNext()) {
            return true;
         }

         var13 = (fx)var12.next();
         var14 = (double)var13.u() + 0.5D - var7.b;
         var16 = (double)var13.w() + 0.5D - var7.d;
      } while(var14 * var8 + var16 * var10 < 0.0D || this.b.d_(var13).a(this.b, var13, cxe.a));

      return false;
   }

   public void a(boolean var1) {
      this.o.b(var1);
   }

   public boolean f() {
      return this.o.c();
   }

   public void c(boolean var1) {
      this.p = var1;
   }
}
