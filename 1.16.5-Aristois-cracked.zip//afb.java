@FunctionalInterface
public interface afb {
   boolean accept(int var1, ob var2, int var3);
}
