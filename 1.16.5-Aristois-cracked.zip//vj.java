import com.google.common.collect.Maps;
import java.util.Collections;
import java.util.Map;
import java.util.function.Function;

public class vj<T> {
   private static final Map<String, vj<?>> a = Collections.synchronizedMap(Maps.newIdentityHashMap());
   private final vk b;
   private final vk c;

   public static <T> vj<T> a(vj<? extends gm<T>> var0, vk var1) {
      return a(var0.c, var1);
   }

   public static <T> vj<gm<T>> a(vk var0) {
      return a(gm.d, var0);
   }

   private static <T> vj<T> a(vk var0, vk var1) {
      String var2 = (var0 + ":" + var1).intern();
      return (vj)a.computeIfAbsent(var2, (var2x) -> {
         return new vj(var0, var1);
      });
   }

   private vj(vk var1, vk var2) {
      this.b = var1;
      this.c = var2;
   }

   public String toString() {
      return "ResourceKey[" + this.b + " / " + this.c + ']';
   }

   public boolean a(vj<? extends gm<?>> var1) {
      return this.b.equals(var1.a());
   }

   public vk a() {
      return this.c;
   }

   public static <T> Function<vk, vj<T>> b(vj<? extends gm<T>> var0) {
      return (var1) -> {
         return a(var0, var1);
      };
   }
}
