public enum cat {
   a {
      public boolean a(ceh var1, brc var2, fx var3, gc var4) {
         return buo.a(var1.l(var2, var3), var4);
      }
   },
   b {
      private final int d = 1;
      private final ddh e = buo.a(7.0D, 0.0D, 7.0D, 9.0D, 10.0D, 9.0D);

      public boolean a(ceh var1, brc var2, fx var3, gc var4) {
         return !dde.c(var1.l(var2, var3).a(var4), this.e, dcr.c);
      }
   },
   c {
      private final int d = 2;
      private final ddh e;

      {
         this.e = dde.a(dde.b(), buo.a(2.0D, 0.0D, 2.0D, 14.0D, 16.0D, 14.0D), dcr.e);
      }

      public boolean a(ceh var1, brc var2, fx var3, gc var4) {
         return !dde.c(var1.l(var2, var3).a(var4), this.e, dcr.c);
      }
   };

   private cat() {
   }

   public abstract boolean a(ceh var1, brc var2, fx var3, gc var4);

   // $FF: synthetic method
   cat(Object var3) {
      this();
   }
}
