import net.minecraft.server.MinecraftServer;

public class aaw implements tw {
   private final MinecraftServer a;
   private final nd b;

   public aaw(MinecraftServer var1, nd var2) {
      this.a = var1;
      this.b = var2;
   }

   public void a(tv var1) {
      this.b.a(var1.b());
      this.b.a((ni)(new aba(this.a, this.b)));
   }

   public void a(nr var1) {
   }

   public nd a() {
      return this.b;
   }
}
