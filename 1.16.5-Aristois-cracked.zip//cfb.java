import com.google.common.collect.Lists;
import java.util.Arrays;
import java.util.Collection;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class cfb extends cfe<gc> {
   protected cfb(String var1, Collection<gc> var2) {
      super(var1, gc.class, var2);
   }

   public static cfb a(String var0, Predicate<gc> var1) {
      return a(var0, (Collection)Arrays.stream(gc.values()).filter(var1).collect(Collectors.toList()));
   }

   public static cfb a(String var0, gc... var1) {
      return a(var0, (Collection)Lists.newArrayList(var1));
   }

   public static cfb a(String var0, Collection<gc> var1) {
      return new cfb(var0, var1);
   }
}
