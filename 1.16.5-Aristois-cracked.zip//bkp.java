public class bkp extends blx {
   public bkp(blx.a var1) {
      super(var1);
   }

   public bmb a(bmb var1, brx var2, aqm var3) {
      bmb var4 = super.a(var1, var2, var3);
      if (!var2.v) {
         double var5 = var3.cD();
         double var7 = var3.cE();
         double var9 = var3.cH();

         for(int var11 = 0; var11 < 16; ++var11) {
            double var12 = var3.cD() + (var3.cY().nextDouble() - 0.5D) * 16.0D;
            double var14 = afm.a(var3.cE() + (double)(var3.cY().nextInt(16) - 8), 0.0D, (double)(var2.ae() - 1));
            double var16 = var3.cH() + (var3.cY().nextDouble() - 0.5D) * 16.0D;
            if (var3.br()) {
               var3.l();
            }

            if (var3.a(var12, var14, var16, true)) {
               adp var18 = var3 instanceof bah ? adq.ez : adq.bO;
               var2.a((bfw)null, var5, var7, var9, var18, adr.h, 1.0F, 1.0F);
               var3.a(var18, 1.0F, 1.0F);
               break;
            }
         }

         if (var3 instanceof bfw) {
            ((bfw)var3).eT().a(this, 20);
         }
      }

      return var4;
   }
}
