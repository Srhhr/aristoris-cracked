import com.mojang.authlib.GameProfile;
import java.util.UUID;

public class dzn extends dzj {
   public dzn(dwt var1, GameProfile var2) {
      super(var1, var2);
      this.G = 1.0F;
      this.H = true;
   }

   public boolean a(double var1) {
      double var3 = this.cc().a() * 10.0D;
      if (Double.isNaN(var3)) {
         var3 = 1.0D;
      }

      var3 *= 64.0D * bW();
      return var1 < var3 * var3;
   }

   public boolean a(apk var1, float var2) {
      return true;
   }

   public void j() {
      super.j();
      this.a(this, false);
   }

   public void k() {
      if (this.aU > 0) {
         double var1 = this.cD() + (this.aV - this.cD()) / (double)this.aU;
         double var3 = this.cE() + (this.aW - this.cE()) / (double)this.aU;
         double var5 = this.cH() + (this.aX - this.cH()) / (double)this.aU;
         this.p = (float)((double)this.p + afm.g(this.aY - (double)this.p) / (double)this.aU);
         this.q = (float)((double)this.q + (this.aZ - (double)this.q) / (double)this.aU);
         --this.aU;
         this.d(var1, var3, var5);
         this.a(this.p, this.q);
      }

      if (this.bb > 0) {
         this.aC = (float)((double)this.aC + afm.g(this.ba - (double)this.aC) / (double)this.bb);
         --this.bb;
      }

      this.bs = this.bt;
      this.dA();
      float var7;
      if (this.t && !this.dl()) {
         var7 = Math.min(0.1F, afm.a(c(this.cC())));
      } else {
         var7 = 0.0F;
      }

      float var2;
      if (!this.t && !this.dl()) {
         var2 = (float)Math.atan(-this.cC().c * 0.20000000298023224D) * 15.0F;
      } else {
         var2 = 0.0F;
      }

      this.bt += (var7 - this.bt) * 0.4F;
      this.l.Z().a("push");
      this.dQ();
      this.l.Z().c();
   }

   protected void eu() {
   }

   public void a(nr var1, UUID var2) {
      djz var3 = djz.C();
      if (!var3.a(var2)) {
         var3.j.c().a(var1);
      }

   }
}
