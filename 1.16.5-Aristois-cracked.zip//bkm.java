import java.util.function.Consumer;
import java.util.function.Predicate;

public class bkm extends bmo implements bno {
   public bkm(blx.a var1) {
      super(var1);
   }

   public void a(bmb var1, brx var2, aqm var3, int var4) {
      if (var3 instanceof bfw) {
         bfw var5 = (bfw)var3;
         boolean var6 = var5.bC.d || bpu.a(bpw.A, var1) > 0;
         bmb var7 = var5.f(var1);
         if (!var7.a() || var6) {
            if (var7.a()) {
               var7 = new bmb(bmd.kd);
            }

            int var8 = this.e_(var1) - var4;
            float var9 = a(var8);
            if (!((double)var9 < 0.1D)) {
               boolean var10 = var6 && var7.b() == bmd.kd;
               if (!var2.v) {
                  bkc var11 = (bkc)((bkc)(var7.b() instanceof bkc ? var7.b() : bmd.kd));
                  bga var12 = var11.a(var2, var7, var5);
                  var12.a(var5, var5.q, var5.p, 0.0F, var9 * 3.0F, 1.0F);
                  if (var9 == 1.0F) {
                     var12.a(true);
                  }

                  int var13 = bpu.a(bpw.x, var1);
                  if (var13 > 0) {
                     var12.h(var12.n() + (double)var13 * 0.5D + 0.5D);
                  }

                  int var14 = bpu.a(bpw.y, var1);
                  if (var14 > 0) {
                     var12.a(var14);
                  }

                  if (bpu.a(bpw.z, var1) > 0) {
                     var12.f(100);
                  }

                  var1.a(1, (aqm)var5, (Consumer)((var1x) -> {
                     var1x.d((aot)var5.dX());
                  }));
                  if (var10 || var5.bC.d && (var7.b() == bmd.qk || var7.b() == bmd.ql)) {
                     var12.d = bga.a.c;
                  }

                  var2.c((aqa)var12);
               }

               var2.a((bfw)null, var5.cD(), var5.cE(), var5.cH(), adq.Y, adr.h, 1.0F, 1.0F / (h.nextFloat() * 0.4F + 1.2F) + var9 * 0.5F);
               if (!var10 && !var5.bC.d) {
                  var7.g(1);
                  if (var7.a()) {
                     var5.bm.f(var7);
                  }
               }

               var5.b(aea.c.b(this));
            }
         }
      }
   }

   public static float a(int var0) {
      float var1 = (float)var0 / 20.0F;
      var1 = (var1 * var1 + var1 * 2.0F) / 3.0F;
      if (var1 > 1.0F) {
         var1 = 1.0F;
      }

      return var1;
   }

   public int e_(bmb var1) {
      return 72000;
   }

   public bnn d_(bmb var1) {
      return bnn.e;
   }

   public aov<bmb> a(brx var1, bfw var2, aot var3) {
      bmb var4 = var2.b((aot)var3);
      boolean var5 = !var2.f(var4).a();
      if (!var2.bC.d && !var5) {
         return aov.d(var4);
      } else {
         var2.c((aot)var3);
         return aov.b(var4);
      }
   }

   public Predicate<bmb> b() {
      return a;
   }

   public int d() {
      return 15;
   }
}
