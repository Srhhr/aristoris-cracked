import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import javax.annotation.Nullable;

public class dbx implements dbo {
   @Nullable
   private final Boolean a;
   @Nullable
   private final Boolean b;

   private dbx(@Nullable Boolean var1, @Nullable Boolean var2) {
      this.a = var1;
      this.b = var2;
   }

   public dbp b() {
      return dbq.n;
   }

   public boolean a(cyv var1) {
      aag var2 = var1.c();
      if (this.a != null && this.a != var2.X()) {
         return false;
      } else {
         return this.b == null || this.b == var2.W();
      }
   }

   // $FF: synthetic method
   public boolean test(Object var1) {
      return this.a((cyv)var1);
   }

   // $FF: synthetic method
   dbx(Boolean var1, Boolean var2, Object var3) {
      this(var1, var2);
   }

   public static class b implements cze<dbx> {
      public void a(JsonObject var1, dbx var2, JsonSerializationContext var3) {
         var1.addProperty("raining", var2.a);
         var1.addProperty("thundering", var2.b);
      }

      public dbx b(JsonObject var1, JsonDeserializationContext var2) {
         Boolean var3 = var1.has("raining") ? afd.j(var1, "raining") : null;
         Boolean var4 = var1.has("thundering") ? afd.j(var1, "thundering") : null;
         return new dbx(var3, var4);
      }

      // $FF: synthetic method
      public Object a(JsonObject var1, JsonDeserializationContext var2) {
         return this.b(var1, var2);
      }
   }
}
