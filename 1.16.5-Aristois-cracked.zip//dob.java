import it.unimi.dsi.fastutil.booleans.BooleanConsumer;
import java.net.IDN;
import java.util.function.Predicate;

public class dob extends dot {
   private static final nr a = new of("addServer.enterName");
   private static final nr b = new of("addServer.enterIp");
   private dlj c;
   private final BooleanConsumer p;
   private final dwz q;
   private dlq r;
   private dlq s;
   private dlj t;
   private final dot u;
   private final Predicate<String> v = (var0) -> {
      if (aft.b(var0)) {
         return true;
      } else {
         String[] var1 = var0.split(":");
         if (var1.length == 0) {
            return true;
         } else {
            try {
               String var2 = IDN.toASCII(var1[0]);
               return true;
            } catch (IllegalArgumentException var3) {
               return false;
            }
         }
      }
   };

   public dob(dot var1, BooleanConsumer var2, dwz var3) {
      super(new of("addServer.title"));
      this.u = var1;
      this.p = var2;
      this.q = var3;
   }

   public void d() {
      this.s.a();
      this.r.a();
   }

   protected void b() {
      this.i.m.a(true);
      this.s = new dlq(this.o, this.k / 2 - 100, 66, 200, 20, new of("addServer.enterName"));
      this.s.e(true);
      this.s.a(this.q.a);
      this.s.a(this::b);
      this.e.add(this.s);
      this.r = new dlq(this.o, this.k / 2 - 100, 106, 200, 20, new of("addServer.enterIp"));
      this.r.k(128);
      this.r.a(this.q.b);
      this.r.a(this.v);
      this.r.a(this::b);
      this.e.add(this.r);
      this.t = (dlj)this.a((dlh)(new dlj(this.k / 2 - 100, this.l / 4 + 72, 200, 20, a(this.q.b()), (var1) -> {
         this.q.a(dwz.a.values()[(this.q.b().ordinal() + 1) % dwz.a.values().length]);
         this.t.a(a(this.q.b()));
      })));
      this.c = (dlj)this.a((dlh)(new dlj(this.k / 2 - 100, this.l / 4 + 96 + 18, 200, 20, new of("addServer.add"), (var1) -> {
         this.h();
      })));
      this.a((dlh)(new dlj(this.k / 2 - 100, this.l / 4 + 120 + 18, 200, 20, nq.d, (var1) -> {
         this.p.accept(false);
      })));
      this.i();
   }

   private static nr a(dwz.a var0) {
      return (new of("addServer.resourcePack")).c(": ").a(var0.a());
   }

   public void a(djz var1, int var2, int var3) {
      String var4 = this.r.b();
      String var5 = this.s.b();
      this.b(var1, var2, var3);
      this.r.a(var4);
      this.s.a(var5);
   }

   private void b(String var1) {
      this.i();
   }

   public void e() {
      this.i.m.a(false);
   }

   private void h() {
      this.q.a = this.s.b();
      this.q.b = this.r.b();
      this.p.accept(true);
   }

   public void at_() {
      this.i();
      this.i.a(this.u);
   }

   private void i() {
      String var1 = this.r.b();
      boolean var2 = !var1.isEmpty() && var1.split(":").length > 0 && var1.indexOf(32) == -1;
      this.c.o = var2 && !this.s.b().isEmpty();
   }

   public void a(dfm var1, int var2, int var3, float var4) {
      this.a((dfm)var1);
      a(var1, this.o, this.d, this.k / 2, 17, 16777215);
      b(var1, this.o, a, this.k / 2 - 100, 53, 10526880);
      b(var1, this.o, b, this.k / 2 - 100, 94, 10526880);
      this.s.a(var1, var2, var3, var4);
      this.r.a(var1, var2, var3, var4);
      super.a(var1, var2, var3, var4);
   }
}
