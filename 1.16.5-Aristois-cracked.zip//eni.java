import com.google.common.collect.Lists;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class eni {
   private static final AtomicInteger a = new AtomicInteger(0);
   private static final Logger b = LogManager.getLogger();

   public static class a extends Thread {
      private final eni.b a;
      private final InetAddress b;
      private final MulticastSocket c;

      public a(eni.b var1) throws IOException {
         super("LanServerDetector #" + eni.a.incrementAndGet());
         this.a = var1;
         this.setDaemon(true);
         this.setUncaughtExceptionHandler(new o(eni.b));
         this.c = new MulticastSocket(4445);
         this.b = InetAddress.getByName("224.0.2.60");
         this.c.setSoTimeout(5000);
         this.c.joinGroup(this.b);
      }

      public void run() {
         byte[] var2 = new byte[1024];

         while(!this.isInterrupted()) {
            DatagramPacket var1 = new DatagramPacket(var2, var2.length);

            try {
               this.c.receive(var1);
            } catch (SocketTimeoutException var5) {
               continue;
            } catch (IOException var6) {
               eni.b.error("Couldn't ping server", var6);
               break;
            }

            String var3 = new String(var1.getData(), var1.getOffset(), var1.getLength(), StandardCharsets.UTF_8);
            eni.b.debug("{}: {}", var1.getAddress(), var3);
            this.a.a(var3, var1.getAddress());
         }

         try {
            this.c.leaveGroup(this.b);
         } catch (IOException var4) {
         }

         this.c.close();
      }
   }

   public static class b {
      private final List<enh> a = Lists.newArrayList();
      private boolean b;

      public synchronized boolean a() {
         return this.b;
      }

      public synchronized void b() {
         this.b = false;
      }

      public synchronized List<enh> c() {
         return Collections.unmodifiableList(this.a);
      }

      public synchronized void a(String var1, InetAddress var2) {
         String var3 = enj.a(var1);
         String var4 = enj.b(var1);
         if (var4 != null) {
            var4 = var2.getHostAddress() + ":" + var4;
            boolean var5 = false;
            Iterator var6 = this.a.iterator();

            while(var6.hasNext()) {
               enh var7 = (enh)var6.next();
               if (var7.b().equals(var4)) {
                  var7.c();
                  var5 = true;
                  break;
               }
            }

            if (!var5) {
               this.a.add(new enh(var3, var4));
               this.b = true;
            }

         }
      }
   }
}
