import com.google.common.collect.Iterables;
import com.google.common.collect.Maps;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nullable;

public class bna extends blx {
   private static final Map<aqe<?>, bna> a = Maps.newIdentityHashMap();
   private final int b;
   private final int c;
   private final aqe<?> d;

   public bna(aqe<?> var1, int var2, int var3, blx.a var4) {
      super(var4);
      this.d = var1;
      this.b = var2;
      this.c = var3;
      a.put(var1, this);
   }

   public aou a(boa var1) {
      brx var2 = var1.p();
      if (!(var2 instanceof aag)) {
         return aou.a;
      } else {
         bmb var3 = var1.m();
         fx var4 = var1.a();
         gc var5 = var1.j();
         ceh var6 = var2.d_(var4);
         if (var6.a(bup.bP)) {
            ccj var7 = var2.c(var4);
            if (var7 instanceof cdi) {
               bqz var11 = ((cdi)var7).d();
               aqe<?> var9 = this.a(var3.o());
               var11.a(var9);
               var7.X_();
               var2.a(var4, var6, var6, 3);
               var3.g(1);
               return aou.b;
            }
         }

         fx var10;
         if (var6.k(var2, var4).b()) {
            var10 = var4;
         } else {
            var10 = var4.a(var5);
         }

         aqe<?> var8 = this.a(var3.o());
         if (var8.a((aag)var2, var3, var1.n(), var10, aqp.m, true, !Objects.equals(var4, var10) && var5 == gc.b) != null) {
            var3.g(1);
         }

         return aou.b;
      }
   }

   public aov<bmb> a(brx var1, bfw var2, aot var3) {
      bmb var4 = var2.b((aot)var3);
      dcl var5 = a(var1, var2, brf.b.b);
      if (var5.c() != dcl.a.b) {
         return aov.c(var4);
      } else if (!(var1 instanceof aag)) {
         return aov.a(var4);
      } else {
         dcj var6 = (dcj)var5;
         fx var7 = var6.a();
         if (!(var1.d_(var7).b() instanceof byb)) {
            return aov.c(var4);
         } else if (var1.a(var2, var7) && var2.a(var7, var6.b(), var4)) {
            aqe<?> var8 = this.a(var4.o());
            if (var8.a((aag)var1, var4, var2, var7, aqp.m, false, false) == null) {
               return aov.c(var4);
            } else {
               if (!var2.bC.d) {
                  var4.g(1);
               }

               var2.b(aea.c.b(this));
               return aov.b(var4);
            }
         } else {
            return aov.d(var4);
         }
      }
   }

   public boolean a(@Nullable md var1, aqe<?> var2) {
      return Objects.equals(this.a(var1), var2);
   }

   public int a(int var1) {
      return var1 == 0 ? this.b : this.c;
   }

   @Nullable
   public static bna a(@Nullable aqe<?> var0) {
      return (bna)a.get(var0);
   }

   public static Iterable<bna> f() {
      return Iterables.unmodifiableIterable(a.values());
   }

   public aqe<?> a(@Nullable md var1) {
      if (var1 != null && var1.c("EntityTag", 10)) {
         md var2 = var1.p("EntityTag");
         if (var2.c("id", 8)) {
            return (aqe)aqe.a(var2.l("id")).orElse(this.d);
         }
      }

      return this.d;
   }

   public Optional<aqn> a(bfw var1, aqn var2, aqe<? extends aqn> var3, aag var4, dcn var5, bmb var6) {
      if (!this.a(var6.o(), var3)) {
         return Optional.empty();
      } else {
         Object var7;
         if (var2 instanceof apy) {
            var7 = ((apy)var2).a(var4, (apy)var2);
         } else {
            var7 = (aqn)var3.a((brx)var4);
         }

         if (var7 == null) {
            return Optional.empty();
         } else {
            ((aqn)var7).a(true);
            if (!((aqn)var7).w_()) {
               return Optional.empty();
            } else {
               ((aqn)var7).b(var5.a(), var5.b(), var5.c(), 0.0F, 0.0F);
               var4.l((aqa)var7);
               if (var6.t()) {
                  ((aqn)var7).a((nr)var6.r());
               }

               if (!var1.bC.d) {
                  var6.g(1);
               }

               return Optional.of(var7);
            }
         }
      }
   }
}
