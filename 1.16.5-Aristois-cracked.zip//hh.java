import com.mojang.serialization.Codec;
import java.util.function.Function;

public class hh {
   public static final hi a = a("ambient_entity_effect", false);
   public static final hi b = a("angry_villager", false);
   public static final hi c = a("barrier", false);
   public static final hg<hc> d;
   public static final hi e;
   public static final hi f;
   public static final hi g;
   public static final hi h;
   public static final hi i;
   public static final hi j;
   public static final hi k;
   public static final hi l;
   public static final hi m;
   public static final hi n;
   public static final hg<hd> o;
   public static final hi p;
   public static final hi q;
   public static final hi r;
   public static final hi s;
   public static final hi t;
   public static final hi u;
   public static final hi v;
   public static final hi w;
   public static final hg<hc> x;
   public static final hi y;
   public static final hi z;
   public static final hi A;
   public static final hi B;
   public static final hi C;
   public static final hi D;
   public static final hi E;
   public static final hi F;
   public static final hi G;
   public static final hi H;
   public static final hg<he> I;
   public static final hi J;
   public static final hi K;
   public static final hi L;
   public static final hi M;
   public static final hi N;
   public static final hi O;
   public static final hi P;
   public static final hi Q;
   public static final hi R;
   public static final hi S;
   public static final hi T;
   public static final hi U;
   public static final hi V;
   public static final hi W;
   public static final hi X;
   public static final hi Y;
   public static final hi Z;
   public static final hi aa;
   public static final hi ab;
   public static final hi ac;
   public static final hi ad;
   public static final hi ae;
   public static final hi af;
   public static final hi ag;
   public static final hi ah;
   public static final hi ai;
   public static final hi aj;
   public static final hi ak;
   public static final hi al;
   public static final hi am;
   public static final hi an;
   public static final hi ao;
   public static final hi ap;
   public static final hi aq;
   public static final hi ar;
   public static final hi as;
   public static final hi at;
   public static final Codec<hf> au;

   private static hi a(String var0, boolean var1) {
      return (hi)gm.a((gm)gm.V, (String)var0, (Object)(new hi(var1)));
   }

   private static <T extends hf> hg<T> a(String var0, hf.a<T> var1, final Function<hg<T>, Codec<T>> var2) {
      return (hg)gm.a((gm)gm.V, (String)var0, (Object)(new hg<T>(false, var1) {
         public Codec<T> e() {
            return (Codec)var2.apply(this);
         }
      }));
   }

   static {
      d = a("block", hc.a, hc::a);
      e = a("bubble", false);
      f = a("cloud", false);
      g = a("crit", false);
      h = a("damage_indicator", true);
      i = a("dragon_breath", false);
      j = a("dripping_lava", false);
      k = a("falling_lava", false);
      l = a("landing_lava", false);
      m = a("dripping_water", false);
      n = a("falling_water", false);
      o = a("dust", hd.c, (var0) -> {
         return hd.b;
      });
      p = a("effect", false);
      q = a("elder_guardian", true);
      r = a("enchanted_hit", false);
      s = a("enchant", false);
      t = a("end_rod", false);
      u = a("entity_effect", false);
      v = a("explosion_emitter", true);
      w = a("explosion", true);
      x = a("falling_dust", hc.a, hc::a);
      y = a("firework", false);
      z = a("fishing", false);
      A = a("flame", false);
      B = a("soul_fire_flame", false);
      C = a("soul", false);
      D = a("flash", false);
      E = a("happy_villager", false);
      F = a("composter", false);
      G = a("heart", false);
      H = a("instant_effect", false);
      I = a("item", he.a, he::a);
      J = a("item_slime", false);
      K = a("item_snowball", false);
      L = a("large_smoke", false);
      M = a("lava", false);
      N = a("mycelium", false);
      O = a("note", false);
      P = a("poof", true);
      Q = a("portal", false);
      R = a("rain", false);
      S = a("smoke", false);
      T = a("sneeze", false);
      U = a("spit", true);
      V = a("squid_ink", true);
      W = a("sweep_attack", true);
      X = a("totem_of_undying", false);
      Y = a("underwater", false);
      Z = a("splash", false);
      aa = a("witch", false);
      ab = a("bubble_pop", false);
      ac = a("current_down", false);
      ad = a("bubble_column_up", false);
      ae = a("nautilus", false);
      af = a("dolphin", false);
      ag = a("campfire_cosy_smoke", true);
      ah = a("campfire_signal_smoke", true);
      ai = a("dripping_honey", false);
      aj = a("falling_honey", false);
      ak = a("landing_honey", false);
      al = a("falling_nectar", false);
      am = a("ash", false);
      an = a("crimson_spore", false);
      ao = a("warped_spore", false);
      ap = a("dripping_obsidian_tear", false);
      aq = a("falling_obsidian_tear", false);
      ar = a("landing_obsidian_tear", false);
      as = a("reverse_portal", false);
      at = a("white_ash", false);
      au = gm.V.dispatch("type", hf::b, hg::e);
   }
}
