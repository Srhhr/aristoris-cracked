import java.util.List;
import java.util.Random;

public class afz {
   public static int a(List<? extends afz.a> var0) {
      int var1 = 0;
      int var2 = 0;

      for(int var3 = var0.size(); var2 < var3; ++var2) {
         afz.a var4 = (afz.a)var0.get(var2);
         var1 += var4.a;
      }

      return var1;
   }

   public static <T extends afz.a> T a(Random var0, List<T> var1, int var2) {
      if (var2 <= 0) {
         throw (IllegalArgumentException)x.c((Throwable)(new IllegalArgumentException()));
      } else {
         int var3 = var0.nextInt(var2);
         return a(var1, var3);
      }
   }

   public static <T extends afz.a> T a(List<T> var0, int var1) {
      int var2 = 0;

      for(int var3 = var0.size(); var2 < var3; ++var2) {
         T var4 = (afz.a)var0.get(var2);
         var1 -= var4.a;
         if (var1 < 0) {
            return var4;
         }
      }

      return null;
   }

   public static <T extends afz.a> T a(Random var0, List<T> var1) {
      return a(var0, var1, a(var1));
   }

   public static class a {
      protected final int a;

      public a(int var1) {
         this.a = var1;
      }
   }
}
