import com.google.common.collect.Lists;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.datafixers.util.Either;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.annotation.Nullable;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class dii extends eoo {
   private static final Logger a = LogManager.getLogger();
   private static final vk b = new vk("realms", "textures/gui/realms/link_icons.png");
   private static final vk c = new vk("realms", "textures/gui/realms/trailer_icons.png");
   private static final vk p = new vk("realms", "textures/gui/realms/slot_frame.png");
   private static final nr q = new of("mco.template.info.tooltip");
   private static final nr r = new of("mco.template.trailer.tooltip");
   private final dig s;
   private dii.b t;
   private int u;
   private nr v;
   private dlj w;
   private dlj x;
   private dlj y;
   @Nullable
   private nr z;
   private String A;
   private final dgq.c B;
   private int C;
   @Nullable
   private nr[] D;
   private String E;
   private boolean F;
   private boolean G;
   @Nullable
   private List<diu.a> H;

   public dii(dig var1, dgq.c var2) {
      this(var1, var2, (dhf)null);
   }

   public dii(dig var1, dgq.c var2, @Nullable dhf var3) {
      this.u = -1;
      this.s = var1;
      this.B = var2;
      if (var3 == null) {
         this.t = new dii.b();
         this.a(new dhf(10));
      } else {
         this.t = new dii.b(Lists.newArrayList(var3.a));
         this.a(var3);
      }

      this.v = new of("mco.template.title");
   }

   public void a(nr var1) {
      this.v = var1;
   }

   public void a(nr... var1) {
      this.D = var1;
      this.F = true;
   }

   public boolean a(double var1, double var3, int var5) {
      if (this.G && this.E != null) {
         x.i().a("https://www.minecraft.net/realms/adventure-maps-in-1-9");
         return true;
      } else {
         return super.a(var1, var3, var5);
      }
   }

   public void b() {
      this.i.m.a(true);
      this.t = new dii.b(this.t.g());
      this.x = (dlj)this.a((dlh)(new dlj(this.k / 2 - 206, this.l - 32, 100, 20, new of("mco.template.button.trailer"), (var1x) -> {
         this.t();
      })));
      this.w = (dlj)this.a((dlh)(new dlj(this.k / 2 - 100, this.l - 32, 100, 20, new of("mco.template.button.select"), (var1x) -> {
         this.q();
      })));
      nr var1 = this.B == dgq.c.b ? nq.d : nq.h;
      dlj var2 = new dlj(this.k / 2 + 6, this.l - 32, 100, 20, var1, (var1x) -> {
         this.p();
      });
      this.a((dlh)var2);
      this.y = (dlj)this.a((dlh)(new dlj(this.k / 2 + 112, this.l - 32, 100, 20, new of("mco.template.button.publisher"), (var1x) -> {
         this.u();
      })));
      this.w.o = false;
      this.x.p = false;
      this.y.p = false;
      this.d((dmi)this.t);
      this.c((dmi)this.t);
      Stream<nr> var3 = Stream.of(this.v);
      if (this.D != null) {
         var3 = Stream.concat(Stream.of(this.D), var3);
      }

      eoj.a((Iterable)var3.filter(Objects::nonNull).map(nr::getString).collect(Collectors.toList()));
   }

   private void k() {
      this.y.p = this.m();
      this.x.p = this.o();
      this.w.o = this.l();
   }

   private boolean l() {
      return this.u != -1;
   }

   private boolean m() {
      return this.u != -1 && !this.n().e.isEmpty();
   }

   private dhe n() {
      return this.t.b(this.u);
   }

   private boolean o() {
      return this.u != -1 && !this.n().g.isEmpty();
   }

   public void d() {
      super.d();
      --this.C;
      if (this.C < 0) {
         this.C = 0;
      }

   }

   public boolean a(int var1, int var2, int var3) {
      if (var1 == 256) {
         this.p();
         return true;
      } else {
         return super.a(var1, var2, var3);
      }
   }

   private void p() {
      this.s.a((dhe)null);
      this.i.a((dot)this.s);
   }

   private void q() {
      if (this.r()) {
         this.s.a(this.n());
      }

   }

   private boolean r() {
      return this.u >= 0 && this.u < this.t.l();
   }

   private void t() {
      if (this.r()) {
         dhe var1 = this.n();
         if (!"".equals(var1.g)) {
            x.i().a(var1.g);
         }
      }

   }

   private void u() {
      if (this.r()) {
         dhe var1 = this.n();
         if (!"".equals(var1.e)) {
            x.i().a(var1.e);
         }
      }

   }

   private void a(final dhf var1) {
      (new Thread("realms-template-fetcher") {
         public void run() {
            dhf var1x = var1;

            Either var3;
            for(dgb var2 = dgb.a(); var1x != null; var1x = (dhf)dii.this.i.a((Supplier)(() -> {
               if (var3.right().isPresent()) {
                  dii.a.error("Couldn't fetch templates: {}", var3.right().get());
                  if (dii.this.t.f()) {
                     dii.this.H = diu.a(ekx.a("mco.template.select.failure"));
                  }

                  return null;
               } else {
                  dhf var2 = (dhf)var3.left().get();
                  Iterator var3x = var2.a.iterator();

                  while(var3x.hasNext()) {
                     dhe var4 = (dhe)var3x.next();
                     dii.this.t.a(var4);
                  }

                  if (var2.a.isEmpty()) {
                     if (dii.this.t.f()) {
                        String var5 = ekx.a("mco.template.select.none", "%link");
                        diu.b var6 = diu.b.a(ekx.a("mco.template.select.none.linkTitle"), "https://aka.ms/MinecraftRealmsContentCreator");
                        dii.this.H = diu.a(var5, var6);
                     }

                     return null;
                  } else {
                     return var2;
                  }
               }
            })).join()) {
               var3 = dii.this.a(var1x, var2);
            }

         }
      }).start();
   }

   private Either<dhf, String> a(dhf var1, dgb var2) {
      try {
         return Either.left(var2.a(var1.b + 1, var1.c, this.B));
      } catch (dhi var4) {
         return Either.right(var4.getMessage());
      }
   }

   public void a(dfm var1, int var2, int var3, float var4) {
      this.z = null;
      this.A = null;
      this.G = false;
      this.a((dfm)var1);
      this.t.a(var1, var2, var3, var4);
      if (this.H != null) {
         this.a(var1, var2, var3, this.H);
      }

      a(var1, this.o, this.v, this.k / 2, 13, 16777215);
      if (this.F) {
         nr[] var5 = this.D;

         int var6;
         int var8;
         for(var6 = 0; var6 < var5.length; ++var6) {
            int var7 = this.o.a((nu)var5[var6]);
            var8 = this.k / 2 - var7 / 2;
            int var9 = j(-1 + var6);
            if (var2 >= var8 && var2 <= var8 + var7 && var3 >= var9) {
               this.o.getClass();
               if (var3 <= var9 + 9) {
                  this.G = true;
               }
            }
         }

         for(var6 = 0; var6 < var5.length; ++var6) {
            nr var10 = var5[var6];
            var8 = 10526880;
            if (this.E != null) {
               if (this.G) {
                  var8 = 7107012;
                  var10 = ((nr)var10).e().a(k.s);
               } else {
                  var8 = 3368635;
               }
            }

            a(var1, this.o, (nr)var10, this.k / 2, j(-1 + var6), var8);
         }
      }

      super.a(var1, var2, var3, var4);
      this.a(var1, this.z, var2, var3);
   }

   private void a(dfm var1, int var2, int var3, List<diu.a> var4) {
      for(int var5 = 0; var5 < var4.size(); ++var5) {
         diu.a var6 = (diu.a)var4.get(var5);
         int var7 = j(4 + var5);
         int var8 = var6.a.stream().mapToInt((var1x) -> {
            return this.o.b(var1x.a());
         }).sum();
         int var9 = this.k / 2 - var8 / 2;

         int var13;
         for(Iterator var10 = var6.a.iterator(); var10.hasNext(); var9 = var13) {
            diu.b var11 = (diu.b)var10.next();
            int var12 = var11.b() ? 3368635 : 16777215;
            var13 = this.o.a(var1, var11.a(), (float)var9, (float)var7, var12);
            if (var11.b() && var2 > var9 && var2 < var13 && var3 > var7 - 3 && var3 < var7 + 8) {
               this.z = new oe(var11.c());
               this.A = var11.c();
            }
         }
      }

   }

   protected void a(dfm var1, @Nullable nr var2, int var3, int var4) {
      if (var2 != null) {
         int var5 = var3 + 12;
         int var6 = var4 - 12;
         int var7 = this.o.a((nu)var2);
         this.a(var1, var5 - 3, var6 - 3, var5 + var7 + 3, var6 + 8 + 3, -1073741824, -1073741824);
         this.o.a(var1, var2, (float)var5, (float)var6, 16777215);
      }
   }

   class a extends dlv.a<dii.a> {
      private final dhe b;

      public a(dhe var2) {
         this.b = var2;
      }

      public void a(dfm var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, boolean var9, float var10) {
         this.a(var1, this.b, var4, var3, var7, var8);
      }

      private void a(dfm var1, dhe var2, int var3, int var4, int var5, int var6) {
         int var7 = var3 + 45 + 20;
         dii.this.o.b(var1, var2.b, (float)var7, (float)(var4 + 2), 16777215);
         dii.this.o.b(var1, var2.d, (float)var7, (float)(var4 + 15), 7105644);
         dii.this.o.b(var1, var2.c, (float)(var7 + 227 - dii.this.o.b(var2.c)), (float)(var4 + 1), 7105644);
         if (!"".equals(var2.e) || !"".equals(var2.g) || !"".equals(var2.h)) {
            this.a(var1, var7 - 1, var4 + 25, var5, var6, var2.e, var2.g, var2.h);
         }

         this.a(var1, var3, var4 + 1, var5, var6, var2);
      }

      private void a(dfm var1, int var2, int var3, int var4, int var5, dhe var6) {
         dir.a(var6.a, var6.f);
         RenderSystem.color4f(1.0F, 1.0F, 1.0F, 1.0F);
         dkw.a(var1, var2 + 1, var3 + 1, 0.0F, 0.0F, 38, 38, 38, 38);
         dii.this.i.M().a(dii.p);
         RenderSystem.color4f(1.0F, 1.0F, 1.0F, 1.0F);
         dkw.a(var1, var2, var3, 0.0F, 0.0F, 40, 40, 40, 40);
      }

      private void a(dfm var1, int var2, int var3, int var4, int var5, String var6, String var7, String var8) {
         if (!"".equals(var8)) {
            dii.this.o.b(var1, var8, (float)var2, (float)(var3 + 4), 5000268);
         }

         int var9 = "".equals(var8) ? 0 : dii.this.o.b(var8) + 2;
         boolean var10 = false;
         boolean var11 = false;
         boolean var12 = "".equals(var6);
         if (var4 >= var2 + var9 && var4 <= var2 + var9 + 32 && var5 >= var3 && var5 <= var3 + 15 && var5 < dii.this.l - 15 && var5 > 32) {
            if (var4 <= var2 + 15 + var9 && var4 > var9) {
               if (var12) {
                  var11 = true;
               } else {
                  var10 = true;
               }
            } else if (!var12) {
               var11 = true;
            }
         }

         if (!var12) {
            dii.this.i.M().a(dii.b);
            RenderSystem.color4f(1.0F, 1.0F, 1.0F, 1.0F);
            RenderSystem.pushMatrix();
            RenderSystem.scalef(1.0F, 1.0F, 1.0F);
            float var13 = var10 ? 15.0F : 0.0F;
            dkw.a(var1, var2 + var9, var3, var13, 0.0F, 15, 15, 30, 15);
            RenderSystem.popMatrix();
         }

         if (!"".equals(var7)) {
            dii.this.i.M().a(dii.c);
            RenderSystem.color4f(1.0F, 1.0F, 1.0F, 1.0F);
            RenderSystem.pushMatrix();
            RenderSystem.scalef(1.0F, 1.0F, 1.0F);
            int var15 = var2 + var9 + (var12 ? 0 : 17);
            float var14 = var11 ? 15.0F : 0.0F;
            dkw.a(var1, var15, var3, var14, 0.0F, 15, 15, 30, 15);
            RenderSystem.popMatrix();
         }

         if (var10) {
            dii.this.z = dii.q;
            dii.this.A = var6;
         } else if (var11 && !"".equals(var7)) {
            dii.this.z = dii.r;
            dii.this.A = var7;
         }

      }
   }

   class b extends eon<dii.a> {
      public b() {
         this(Collections.emptyList());
      }

      public b(Iterable<dhe> var2) {
         super(dii.this.k, dii.this.l, dii.this.F ? dii.j(1) : 32, dii.this.l - 40, 46);
         var2.forEach(this::a);
      }

      public void a(dhe var1) {
         this.a((dlv.a)(dii.this.new a(var1)));
      }

      public boolean a(double var1, double var3, int var5) {
         if (var5 == 0 && var3 >= (double)this.i && var3 <= (double)this.j) {
            int var6 = this.d / 2 - 150;
            if (dii.this.A != null) {
               x.i().a(dii.this.A);
            }

            int var7 = (int)Math.floor(var3 - (double)this.i) - this.n + (int)this.m() - 4;
            int var8 = var7 / this.c;
            if (var1 >= (double)var6 && var1 < (double)this.e() && var8 >= 0 && var7 >= 0 && var8 < this.l()) {
               this.a(var8);
               this.a(var7, var8, var1, var3, this.d);
               if (var8 >= dii.this.t.l()) {
                  return super.a(var1, var3, var5);
               }

               dii.this.C = dii.this.C + 7;
               if (dii.this.C >= 10) {
                  dii.this.q();
               }

               return true;
            }
         }

         return super.a(var1, var3, var5);
      }

      public void a(int var1) {
         this.j(var1);
         if (var1 != -1) {
            dhe var2 = dii.this.t.b(var1);
            String var3 = ekx.a("narrator.select.list.position", var1 + 1, dii.this.t.l());
            String var4 = ekx.a("mco.template.select.narrate.version", var2.c);
            String var5 = ekx.a("mco.template.select.narrate.authors", var2.d);
            String var6 = eoj.b((Iterable)Arrays.asList(var2.b, var5, var2.h, var4, var3));
            eoj.a(ekx.a("narrator.select", var6));
         }

      }

      public void a(@Nullable dii.a var1) {
         super.a((dlf.a)var1);
         dii.this.u = this.au_().indexOf(var1);
         dii.this.k();
      }

      public int c() {
         return this.l() * 46;
      }

      public int d() {
         return 300;
      }

      public void a(dfm var1) {
         dii.this.a((dfm)var1);
      }

      public boolean b() {
         return dii.this.aw_() == this;
      }

      public boolean f() {
         return this.l() == 0;
      }

      public dhe b(int var1) {
         return ((dii.a)this.au_().get(var1)).b;
      }

      public List<dhe> g() {
         return (List)this.au_().stream().map((var0) -> {
            return var0.b;
         }).collect(Collectors.toList());
      }
   }
}
