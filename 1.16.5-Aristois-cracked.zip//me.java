import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public class me extends mq {
   public static final me a = new me(0.0D);
   public static final mv<me> b = new mv<me>() {
      public me a(DataInput var1, int var2, mm var3) throws IOException {
         var3.a(128L);
         return me.a(var1.readDouble());
      }

      public String a() {
         return "DOUBLE";
      }

      public String b() {
         return "TAG_Double";
      }

      public boolean c() {
         return true;
      }

      // $FF: synthetic method
      public mt b(DataInput var1, int var2, mm var3) throws IOException {
         return this.a(var1, var2, var3);
      }
   };
   private final double c;

   private me(double var1) {
      this.c = var1;
   }

   public static me a(double var0) {
      return var0 == 0.0D ? a : new me(var0);
   }

   public void a(DataOutput var1) throws IOException {
      var1.writeDouble(this.c);
   }

   public byte a() {
      return 6;
   }

   public mv<me> b() {
      return b;
   }

   public String toString() {
      return this.c + "d";
   }

   public me d() {
      return this;
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else {
         return var1 instanceof me && this.c == ((me)var1).c;
      }
   }

   public int hashCode() {
      long var1 = Double.doubleToLongBits(this.c);
      return (int)(var1 ^ var1 >>> 32);
   }

   public nr a(String var1, int var2) {
      nr var3 = (new oe("d")).a(g);
      return (new oe(String.valueOf(this.c))).a(var3).a(f);
   }

   public long e() {
      return (long)Math.floor(this.c);
   }

   public int f() {
      return afm.c(this.c);
   }

   public short g() {
      return (short)(afm.c(this.c) & '\uffff');
   }

   public byte h() {
      return (byte)(afm.c(this.c) & 255);
   }

   public double i() {
      return this.c;
   }

   public float j() {
      return (float)this.c;
   }

   public Number k() {
      return this.c;
   }

   // $FF: synthetic method
   public mt c() {
      return this.d();
   }
}
