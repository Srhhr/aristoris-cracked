public interface dmi {
   default void e(double var1, double var3) {
   }

   default boolean a(double var1, double var3, int var5) {
      return false;
   }

   default boolean c(double var1, double var3, int var5) {
      return false;
   }

   default boolean a(double var1, double var3, int var5, double var6, double var8) {
      return false;
   }

   default boolean a(double var1, double var3, double var5) {
      return false;
   }

   default boolean a(int var1, int var2, int var3) {
      return false;
   }

   default boolean b(int var1, int var2, int var3) {
      return false;
   }

   default boolean a(char var1, int var2) {
      return false;
   }

   default boolean c_(boolean var1) {
      return false;
   }

   default boolean b(double var1, double var3) {
      return false;
   }
}
