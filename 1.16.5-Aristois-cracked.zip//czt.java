import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import java.util.function.Consumer;

public class czt extends czs {
   private final vk g;

   private czt(vk var1, int var2, int var3, dbo[] var4, daj[] var5) {
      super(var2, var3, var4, var5);
      this.g = var1;
   }

   public czr a() {
      return czo.c;
   }

   public void a(Consumer<bmb> var1, cyv var2) {
      cyy var3 = var2.a(this.g);
      var3.a(var2, var1);
   }

   public void a(czg var1) {
      if (var1.a(this.g)) {
         var1.a("Table " + this.g + " is recursively called");
      } else {
         super.a(var1);
         cyy var2 = var1.c(this.g);
         if (var2 == null) {
            var1.a("Unknown loot table called " + this.g);
         } else {
            var2.a(var1.a("->{" + this.g + "}", this.g));
         }

      }
   }

   public static czs.a<?> a(vk var0) {
      return a((czs.d)((var1, var2, var3, var4) -> {
         return new czt(var0, var1, var2, var3, var4);
      }));
   }

   // $FF: synthetic method
   czt(vk var1, int var2, int var3, dbo[] var4, daj[] var5, Object var6) {
      this(var1, var2, var3, var4, var5);
   }

   public static class a extends czs.e<czt> {
      public void a(JsonObject var1, czt var2, JsonSerializationContext var3) {
         super.a(var1, (czs)var2, (JsonSerializationContext)var3);
         var1.addProperty("name", var2.g.toString());
      }

      protected czt a(JsonObject var1, JsonDeserializationContext var2, int var3, int var4, dbo[] var5, daj[] var6) {
         vk var7 = new vk(afd.h(var1, "name"));
         return new czt(var7, var3, var4, var5, var6);
      }

      // $FF: synthetic method
      protected czs b(JsonObject var1, JsonDeserializationContext var2, int var3, int var4, dbo[] var5, daj[] var6) {
         return this.a(var1, var2, var3, var4, var5, var6);
      }
   }
}
